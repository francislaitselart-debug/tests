// Depouillement d'un source JavaScript : retire les commentaires,
// l'indentation et les lignes vides, SANS renommer quoi que ce soit ni
// toucher au contenu des chaines. Partage par tests/build-three-bundle.js
// (bundle 3D) et tests/build-dist.js (dossier livrable).
//
// Aucune dependance : un petit analyseur lexical suffit. Il distingue
// chaines ' " , gabarits ` avec ${ } imbriques, litteraux d'expression
// reguliere, commentaires de ligne et de bloc. Le contenu des chaines et
// des gabarits est recopie caractere pour caractere (l'indentation d'un
// gabarit multiligne fait partie de la valeur affichee).
//
// L'heuristique classique tranche entre division et expression reguliere :
// un "/" ouvre une expression reguliere si le dernier jeton significatif
// n'est pas la fin d'une valeur (identificateur, nombre, ) ]), ou s'il suit
// un mot-cle qui attend une expression. Le resultat est verifie par
// node --check et par les bancs du composant.
'use strict';

const MOTS_CLES = new Set([
  'return', 'typeof', 'instanceof', 'in', 'of', 'new', 'delete', 'void',
  'case', 'do', 'else', 'yield', 'await', 'throw',
]);

const IDENT = /[A-Za-z0-9_$]/;

function finDeValeur(dernier, dernierMot) {
  if (dernierMot && MOTS_CLES.has(dernierMot)) return false;
  return /[A-Za-z0-9_$)\]]/.test(dernier);
}

/* Rend le source depouille de ses commentaires, de son indentation et de
   ses lignes vides. */
function strip(src) {
  const out = [];
  let ligne = '';           // ligne en cours
  let debutLigne = true;    // rien encore emis sur cette ligne
  let dernier = '';         // dernier caractere significatif
  let mot = '';             // identificateur en cours (= dernier mot)

  const pousseLigne = (finDeLigne) => {
    if (ligne.length) out.push(ligne, finDeLigne);
    ligne = '';
    debutLigne = true;
  };
  const emet = (texte) => {
    if (texte.length) { ligne += texte; debutLigne = false; }
  };

  let i = 0;
  const n = src.length;
  while (i < n) {
    const c = src[i];
    const d = src[i + 1];

    if (c === '\r' || c === '\n') {
      const fin = (c === '\r' && d === '\n') ? '\r\n' : c;
      pousseLigne(fin);
      i += fin.length;
      continue;
    }

    if (c === ' ' || c === '\t') {
      if (!debutLigne) emet(c);
      i++;
      continue;
    }

    if (c === '/' && d === '/') {
      while (i < n && src[i] !== '\r' && src[i] !== '\n') i++;
      continue;
    }

    if (c === '/' && d === '*') {
      const fin = src.indexOf('*/', i + 2);
      const bloc = src.slice(i, fin < 0 ? n : fin + 2);
      i = fin < 0 ? n : fin + 2;
      if (/[\r\n]/.test(bloc)) {
        // Commentaire multiligne : la ligne en cours est close.
        pousseLigne('\n');
      } else if (!debutLigne) {
        // Commentaire au milieu d'une ligne : une espace evite de souder
        // les deux jetons qui l'encadraient.
        emet(' ');
      }
      continue;
    }

    if (c === '"' || c === "'") {
      let j = i + 1;
      while (j < n && src[j] !== c) { if (src[j] === '\\') j++; j++; }
      emet(src.slice(i, j + 1));
      dernier = c; mot = '';
      i = j + 1;
      continue;
    }

    if (c === '`') {
      let j = i + 1;
      let profondeur = 0;
      while (j < n) {
        if (src[j] === '\\') { j += 2; continue; }
        if (src[j] === '`' && profondeur === 0) break;
        if (src[j] === '$' && src[j + 1] === '{') { profondeur++; j += 2; continue; }
        if (src[j] === '}' && profondeur > 0) { profondeur--; j++; continue; }
        j++;
      }
      emet(src.slice(i, j + 1));
      dernier = '`'; mot = '';
      i = j + 1;
      continue;
    }

    if (c === '/' && !finDeValeur(dernier, mot)) {
      let j = i + 1;
      let classe = false;
      let ferme = false;
      while (j < n) {
        const e = src[j];
        if (e === '\\') { j += 2; continue; }
        if (e === '\r' || e === '\n') break;
        if (e === '[') classe = true;
        else if (e === ']') classe = false;
        else if (e === '/' && !classe) { ferme = true; break; }
        j++;
      }
      if (ferme) {
        j++;
        while (j < n && /[a-z]/.test(src[j])) j++;
        emet(src.slice(i, j));
        dernier = '/'; mot = '';
        i = j;
        continue;
      }
    }

    emet(c);
    mot = IDENT.test(c) ? mot + c : '';
    dernier = c;
    i++;
  }
  pousseLigne('\n');
  return out.join('');
}

module.exports = { strip };
