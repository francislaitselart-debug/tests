// Genere les objets 3D de demonstration de la bibliotheque editModels
// (readme sec. 10 bis) dans Images/models/ : cube.obj, cuve.obj (cylindre),
// borne.obj (pyramide tronquee) et cube.glb (glTF binaire, materiau colore),
// chacun avec son <fichier>.js pour demo.html en file:// (texte du .obj, ou
// base64 du .glb, enregistre dans window.ThreeViewerModels[fichier] ; voir
// three-viewer.js loadModel). Les modeles sont en unites arbitraires : le
// composant les ramene a la taille reelle declaree (cle size).
// Usage : node tests/build-demo-models.js
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const DIR = path.join(ROOT, 'Images', 'models');
fs.mkdirSync(DIR, { recursive: true });

function objText(name, vertices, faces) {
  const lines = ['# ' + name + ' - genere par tests/build-demo-models.js', 'o ' + name];
  for (const v of vertices) lines.push('v ' + v.map((n) => String(Math.round(n * 1e4) / 1e4)).join(' '));
  for (const f of faces) lines.push('f ' + f.map((i) => String(i + 1)).join(' '));
  return lines.join('\n') + '\n';
}

/* Cube unite (0..1) pose sur le sol (y = 0). */
function cube() {
  const v = [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1], [0, 1, 0], [1, 1, 0], [1, 1, 1], [0, 1, 1]];
  const f = [[0, 3, 2, 1], [4, 5, 6, 7], [0, 1, 5, 4], [1, 2, 6, 5], [2, 3, 7, 6], [3, 0, 4, 7]];
  return objText('cube', v, f);
}

/* Cylindre vertical de rayon 0,5 et de hauteur 2 (cuve). */
function cuve() {
  const n = 24, v = [], f = [];
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    v.push([Math.cos(a) * 0.5, 0, Math.sin(a) * 0.5]);
    v.push([Math.cos(a) * 0.5, 2, Math.sin(a) * 0.5]);
  }
  v.push([0, 0, 0]);
  v.push([0, 2, 0]);
  for (let i = 0; i < n; i++) {
    const j = (i + 1) % n;
    f.push([i * 2, j * 2, j * 2 + 1, i * 2 + 1]);
    f.push([j * 2, i * 2, n * 2]);
    f.push([i * 2 + 1, j * 2 + 1, n * 2 + 1]);
  }
  return objText('cuve', v, f);
}

/* Borne : pyramide tronquee (base 1 x 1, sommet 0,4 x 0,4, hauteur 1,2). */
function borne() {
  const v = [[-0.5, 0, -0.5], [0.5, 0, -0.5], [0.5, 0, 0.5], [-0.5, 0, 0.5],
    [-0.2, 1.2, -0.2], [0.2, 1.2, -0.2], [0.2, 1.2, 0.2], [-0.2, 1.2, 0.2]];
  const f = [[0, 3, 2, 1], [4, 5, 6, 7], [0, 1, 5, 4], [1, 2, 6, 5], [2, 3, 7, 6], [3, 0, 4, 7]];
  return objText('borne', v, f);
}

/* Cube glTF binaire (.glb) : 8 sommets, 12 triangles, materiau bleu. */
function cubeGlb() {
  const positions = new Float32Array([
    0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 1,
  ]);
  const indices = new Uint16Array([
    0, 2, 1, 0, 3, 2, 4, 5, 6, 4, 6, 7, 0, 1, 5, 0, 5, 4,
    1, 2, 6, 1, 6, 5, 2, 3, 7, 2, 7, 6, 3, 0, 4, 3, 4, 7,
  ]);
  const posBytes = Buffer.from(positions.buffer);
  const idxBytes = Buffer.from(indices.buffer);
  const pad4 = (n) => (4 - (n % 4)) % 4;
  const bin = Buffer.concat([posBytes, Buffer.alloc(pad4(posBytes.length)), idxBytes, Buffer.alloc(pad4(idxBytes.length))]);
  const json = {
    asset: { version: '2.0', generator: 'tests/build-demo-models.js' },
    scene: 0,
    scenes: [{ nodes: [0] }],
    nodes: [{ mesh: 0, name: 'cube' }],
    meshes: [{ primitives: [{ attributes: { POSITION: 0 }, indices: 1, material: 0 }] }],
    materials: [{ name: 'bleu', pbrMetallicRoughness: { baseColorFactor: [0.2, 0.5, 0.9, 1], metallicFactor: 0.1, roughnessFactor: 0.8 } }],
    buffers: [{ byteLength: bin.length }],
    bufferViews: [
      { buffer: 0, byteOffset: 0, byteLength: posBytes.length, target: 34962 },
      { buffer: 0, byteOffset: posBytes.length + pad4(posBytes.length), byteLength: idxBytes.length, target: 34963 },
    ],
    accessors: [
      { bufferView: 0, componentType: 5126, count: 8, type: 'VEC3', min: [0, 0, 0], max: [1, 1, 1] },
      { bufferView: 1, componentType: 5123, count: 36, type: 'SCALAR' },
    ],
  };
  let jsonBytes = Buffer.from(JSON.stringify(json), 'utf8');
  if (jsonBytes.length % 4) jsonBytes = Buffer.concat([jsonBytes, Buffer.alloc(4 - (jsonBytes.length % 4), 0x20)]);
  const header = Buffer.alloc(12);
  header.write('glTF', 0, 'ascii');
  header.writeUInt32LE(2, 4);
  header.writeUInt32LE(12 + 8 + jsonBytes.length + 8 + bin.length, 8);
  const jsonChunk = Buffer.alloc(8);
  jsonChunk.writeUInt32LE(jsonBytes.length, 0);
  jsonChunk.write('JSON', 4, 'ascii');
  const binChunk = Buffer.alloc(8);
  binChunk.writeUInt32LE(bin.length, 0);
  binChunk.write('BIN\0', 4, 'ascii');
  return Buffer.concat([header, jsonChunk, jsonBytes, binChunk, bin]);
}

function wrapper(rel, data) {
  return '/* GENERE par tests/build-demo-models.js : objet 3D de demonstration pour\n' +
    '   demo.html en file:// (voir three-viewer.js loadModel). */\n' +
    '(window.ThreeViewerModels = window.ThreeViewerModels || {})[' + JSON.stringify(rel) + '] = ' +
    JSON.stringify(data) + ';\n';
}

const files = { 'cube.obj': cube(), 'cuve.obj': cuve(), 'borne.obj': borne() };
for (const [name, text] of Object.entries(files)) {
  fs.writeFileSync(path.join(DIR, name), text, 'utf8');
  fs.writeFileSync(path.join(DIR, name + '.js'), wrapper('Images/models/' + name, text), 'utf8');
}
const glb = cubeGlb();
fs.writeFileSync(path.join(DIR, 'cube.glb'), glb);
fs.writeFileSync(path.join(DIR, 'cube.glb.js'), wrapper('Images/models/cube.glb', glb.toString('base64')), 'utf8');
console.log('Images/models : ' + Object.keys(files).join(', ') + ', cube.glb (' + glb.length + ' octets) + wrappers .js');
