// Banc puppeteer MyPnPlanViewerV2 « demo » : ouvre demo.html en file:// dans
// Chrome local et verifie ids / parent_id, selectedNodePath JSON, une seule
// representation par noeud (2D ou 3D), indicateurs de l'arbre (sans plan /
// 3D), message de la zone des plans, alarmes par parent_id, signets,
// avertissements, mode sans navigation, capteurs, ecriture de
// current_plan_drawnShapes_json et garde anti-echo.
// Pre-requis : puppeteer-core (chemin NM ci-dessous) et Chrome local.
// Usage : node tests/bench-demo.js
'use strict';

const path = require('path');
const NM = process.env.VD4_BANCS || path.resolve(__dirname, '..', '..', '..', '.bancs', 'node_modules');
const puppeteer = require(path.join(NM, 'puppeteer-core'));

const URL = 'file:///' + path.resolve(__dirname, '..', 'demo.html').replace(/\\/g, '/');
const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const SHOTS = __dirname;

let ok = 0, ko = 0;
const check = (nom, cond, detail) => {
  if (cond) { ok++; console.log('  OK   ' + nom); }
  else { ko++; console.log('  ECHEC ' + nom + (detail === undefined ? '' : ' -> ' + JSON.stringify(detail))); }
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const browser = await puppeteer.launch({
    executablePath: CHROME, headless: 'new',
    args: ['--allow-file-access-from-files', '--window-size=1600,950'],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1600, height: 950 });

  const erreurs = [];
  page.on('pageerror', (e) => erreurs.push('pageerror: ' + e.message));
  page.on('console', (m) => {
    if (m.type() === 'error' && !/favicon|three-viewer|JSON invalide|Three\.js/.test(m.text())) erreurs.push('console: ' + m.text());
  });

  await page.goto(URL, { waitUntil: 'networkidle2' });
  await sleep(700);

  const lastWrite = (name) => page.evaluate((n) => {
    const map = { selectedNodePath: 'outNode', eventsDetailRequest_json: 'outEvents', current_plan_drawnShapes_json: 'outShapes', current_plan_scene3d_json: 'outScene' };
    const t = document.getElementById(map[n]).textContent;
    try { return JSON.parse(t); } catch (e) { return null; }
  }, name);
  const status = () => page.evaluate(() => Object.assign({}, window.MyPnPlanViewerV2NS.state.propertyStatus));
  const clickRow = async (id) => {
    await page.evaluate((i) => document.querySelector('#siteTree .row[data-id="' + i + '"]').click(), id);
    await sleep(60);
  };
  const rowInfo = (id) => page.evaluate((i) => {
    const row = document.querySelector('#siteTree .row[data-id="' + i + '"]');
    if (!row) return null;
    const node = row.parentElement;
    const dot = row.querySelector('.event-dot');
    return {
      selected: row.classList.contains('selected'),
      expanded: node.classList.contains('expanded'),
      dot: dot ? { hidden: dot.classList.contains('dot-hidden'), color: dot.style.background, all: dot.dataset.allColor, own: dot.dataset.ownColor } : null,
    };
  }, id);
  const badges = () => page.evaluate(() => Array.from(document.querySelectorAll('#topbarBadges .count-badge')).map((b) => ({
    text: b.textContent, event: b.classList.contains('event-badge'), bg: b.style.background, cls: b.className })));

  /* --- 1. Demarrage --- */
  console.log('\n1. Demarrage (file://, sans serveur)');
  check('stub Panorama expose', await page.evaluate(() => typeof window.PanoDemo === 'object'));
  check('espace de noms V2', await page.evaluate(() => !!(window.MyPnPlanViewerV2NS && window.MyPnPlanViewerV2NS.applyConfig && window.MyPnPlanViewerV2NS.applyEvents)));
  check('espace de noms V1 absent', await page.evaluate(() => window.MyPnPlanViewerNS === undefined));
  const dom = await page.evaluate(() => document.getElementById('statDom').textContent);
  check('copie d index.html complete', /compl/.test(dom), dom);
  check('8 jeux d essai', (await page.evaluate(() => document.querySelectorAll('#demoScenario option').length)) === 8);

  /* --- 2. Arbre, ids, parent_id --- */
  console.log('\n2. Arbre du jeu "site" : ids et index');
  const tree = await page.evaluate(() => {
    const NS = window.MyPnPlanViewerV2NS;
    const cfg = NS.state.currentConfig;
    const n11 = cfg.byId.get(11), n221 = cfg.byId.get(221), n1 = cfg.byId.get(1);
    return {
      rows: document.querySelectorAll('#siteTree .tree-node').length,
      ids: Array.from(document.querySelectorAll('#siteTree .row')).map((r) => r.dataset.id),
      size: cfg.byId.size,
      n11: n11 && { id: n11.id, parent_id: n11.parent_id, path: n11.path, labels: n11.labels },
      n221: n221 && { parent_id: n221.parent_id, path: n221.path },
      n1parent: n1 && n1.parent_id,
      warnings: cfg.warnings,
      pins: Array.from(document.querySelectorAll('#pinnedList .pin-label')).map((l) => l.textContent),
    };
  });
  check('10 lignes, 10 n\u0153uds indexes', tree.rows === 10 && tree.size === 10, tree);
  check('data-id sur chaque ligne', tree.ids.join(',') === '1,11,111,112,12,121,122,2,22,221', tree.ids);
  check('parent_id construit (11 -> 1, 221 -> 22, 1 -> 0)', tree.n11.parent_id === 1 && tree.n221.parent_id === 22 && tree.n1parent === 0, tree);
  check('path / labels du n\u0153ud 11', tree.n11.path === 'Site Sud \u2014 B\u00e2timent A' && tree.n11.labels.length === 2, tree.n11);
  check('aucun avertissement sur l exemple du readme', tree.warnings.length === 0, tree.warnings);
  check('2 vues epinglees (libelle fourni + libelle par defaut)', tree.pins.length === 2 && tree.pins[0] === 'Site Nord Niv1 batD' && tree.pins[1] === 'Site Sud B\u00e2timent A RDC batA', tree.pins);

  /* --- 3. selectedNodePath --- */
  console.log('\n3. selectedNodePath (JSON)');
  let sel = await lastWrite('selectedNodePath');
  check('reconstruction : id 0 / planIndex 0 / path vide', sel && sel.id === 0 && sel.parent_id === 0 && sel.planIndex === 0 && sel.path === '' && sel.labels.length === 0 && sel.filename === '', sel);
  const serial0 = sel.serial;
  await clickRow(1); // Site Sud (deplie)
  await clickRow(11); // Batiment A
  sel = await lastWrite('selectedNodePath');
  check('n\u0153ud 11 : id / parent_id / path / labels / planIndex 1 / filename', sel && sel.id === 11 && sel.parent_id === 1 && sel.path === 'Site Sud \u2014 B\u00e2timent A' && sel.labels[1] === 'B\u00e2timent A' && sel.planIndex === 1 && sel.filename === 'Images/planA.jpg', sel);
  check('serial croissant', sel.serial > serial0, [serial0, sel.serial]);
  const serial11 = sel.serial;
  await clickRow(11);
  sel = await lastWrite('selectedNodePath');
  check('re-selection identique : serial + 1', sel.serial === serial11 + 1, sel.serial);
  await clickRow(112); // Niv1 batA, sans plan
  sel = await lastWrite('selectedNodePath');
  check('n\u0153ud sans plan : planIndex 0, filename vide', sel.id === 112 && sel.planIndex === 0 && sel.filename === '', sel);

  // Une seule representation par nœud (2D ou 3D) : le nœud 121 porte un
  // modele 3D.
  await clickRow(1);
  sel = await lastWrite('selectedNodePath');
  check('Site Sud : planIndex 1 (une seule representation)', sel.id === 1 && sel.planIndex === 1 && /face_nu\.svg$/.test(sel.filename), sel);
  await clickRow(12);
  await clickRow(121);
  await sleep(300);
  sel = await lastWrite('selectedNodePath');
  const v3d = await page.evaluate(() => ({
    three: !document.getElementById('threeViewport').hidden,
    planHidden: document.getElementById('planViewport').hidden,
    anchorAbsent: document.getElementById('planSelectAnchor') === null,
    badges: document.querySelectorAll('#siteTree .plans-badge').length,
  }));
  check('n\u0153ud 121 (modele 3D) : planIndex 1, filename .obj, cadre Three.js affiche', sel.id === 121 && sel.planIndex === 1 && /RB_SP_MD_011\.obj$/.test(sel.filename) && v3d.three && v3d.planHidden, [sel, v3d]);
  // Le moteur 3D est un script classique (three-viewer.bundle.js) : il doit
  // fonctionner en file:// et charger le .obj (message de chargement masque).
  await page.waitForFunction(() => document.getElementById('threeLoading').hidden, { timeout: 15000 }).catch(() => {});
  const three = await page.evaluate(() => ({
    viewer: typeof window.ThreeViewer === 'object' && window.ThreeViewer.isActive(),
    loadingHidden: document.getElementById('threeLoading').hidden,
    canvas: document.getElementById('threeCanvas').width > 0,
    zoom: document.getElementById('zoomLevel').textContent,
  }));
  check('bundle Three.js charge en file:// : modele .obj rendu (' + three.zoom + ')', three.viewer && three.loadingHidden && three.canvas, three);
  check('SpeedDial de selection et badge \u00ab n plans \u00bb absents', v3d.anchorAbsent && v3d.badges === 0, v3d);

  /* --- 3bis. Indicateurs de l'arbre et message « sans plan » --- */
  console.log('\n3bis. Indicateurs de l arbre (sans plan / 3D) et message de la zone des plans');
  // Site Sud a ete replie par le clic de la section 3 : le redeplier pour
  // que les lignes mesurees soient visibles ; drawer ouvert (la
  // reconstruction qui suit le referme).
  await clickRow(1);
  await clickRow(11);
  await clickRow(112);
  if (!(await page.evaluate(() => document.getElementById('siteNav').classList.contains('open')))) await page.click('#drawerBtn');
  await sleep(250);
  const ind = await page.evaluate(() => {
    const q = (s) => Array.from(document.querySelectorAll(s));
    const np = document.querySelector('#siteTree .row[data-id="112"] .no-plan-indicator');
    const md = document.querySelector('#siteTree .row[data-id="121"] .model-indicator');
    const mask = (el) => { const cs = getComputedStyle(el); return /data:image\/svg\+xml/.test(cs.webkitMaskImage || cs.maskImage); };
    return {
      noPlan: q('#siteTree .no-plan-indicator').map((e) => e.closest('.row').dataset.id),
      model: q('#siteTree .model-indicator').map((e) => e.closest('.row').dataset.id),
      np: np && { title: np.title, size: np.offsetWidth + 'x' + np.offsetHeight, bg: getComputedStyle(np).backgroundColor, svg: mask(np) },
      md: md && { title: md.title, size: md.offsetWidth + 'x' + md.offsetHeight, bg: getComputedStyle(md).backgroundColor, svg: mask(md) },
      emptyHidden: document.getElementById('planEmpty').hidden,
      title: document.getElementById('planEmptyTitle').textContent,
      loc: document.getElementById('planLocation').textContent,
    };
  });
  check('indicateur \u00ab sans plan \u00bb sur 112, 122, 2, 22 (SVG inline rouge 13x13)', ind.noPlan.join() === '112,122,2,22' && ind.np && ind.np.title === 'Aucun plan \u00e0 visualiser' && ind.np.size === '13x13' && ind.np.bg === 'rgb(220, 38, 38)' && ind.np.svg, ind);
  check('indicateur \u00ab representation 3D \u00bb sur 121 seulement (cube SVG bleu 13x13)', ind.model.join() === '121' && ind.md && ind.md.title === 'Repr\u00e9sentation 3D' && ind.md.size === '13x13' && ind.md.bg === 'rgb(29, 78, 216)' && ind.md.svg, ind);
  check('n\u0153ud sans plan : \u00ab Aucune representation disponible / Selectionnez un element avec un plan \u00bb', !ind.emptyHidden && ind.title === 'Aucune repr\u00e9sentation disponible' && ind.loc === 'S\u00e9lectionnez un \u00e9l\u00e9ment avec un plan', ind);
  await page.evaluate(() => {
    const cfg = JSON.parse(document.getElementById('demoEditor').value);
    cfg.showNoPlanIndicator = false;
    document.getElementById('demoEditor').value = JSON.stringify(cfg);
    document.getElementById('demoApply').click();
  });
  await sleep(80);
  const noInd = await page.evaluate(() => ({
    np: document.querySelectorAll('#siteTree .no-plan-indicator').length,
    md: document.querySelectorAll('#siteTree .model-indicator').length,
    loc: document.getElementById('planLocation').textContent,
  }));
  check('showNoPlanIndicator false : indicateur \u00ab sans plan \u00bb masque, cube 3D conserve, invite affichee', noInd.np === 0 && noInd.md === 1 && /S\u00e9lectionnez/.test(noInd.loc), noInd);
  // Retour au jeu « site » (VRAIE reconstruction : showNoPlanIndicator
  // change) ; Site Sud reste replie pour la section 5, qui rejoue le jeu
  // sans changement structurel (mise a jour a chaud, arbre conserve).
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);

  /* --- 4. Reponse automatique : capteurs --- */
  console.log('\n4. current_plan_element_json (reponse automatique du banc)');
  await clickRow(11);
  await sleep(120);
  let st = await status();
  const elems = await page.evaluate(() => window.MyPnPlanViewerV2NS.state.currentElements.map((e) => [e.id, e.show_mode, e.size]));
  check('5 capteurs retenus pour le plan affiche', elems.length === 5 && elems[0][0] === 1001 && elems[0][2] === 28 && elems[2][1] === 'masked', elems);
  check('statut de la propriete', /5 capteur\(s\) pour plan affich/.test(st.current_plan_element_json), st.current_plan_element_json);
  // Valeur pour un autre plan : memorisee, pas affichee
  await page.evaluate(() => window.PanoDemo.push('current_plan_element_json', JSON.stringify({ node_id: 111, planIndex: 1, elements: [{ id: 5, x: 0.5, y: 0.5 }] })));
  st = await status();
  const stillElems = await page.evaluate(() => window.MyPnPlanViewerV2NS.state.currentElements.length);
  check('autre plan : memorise, plan affiche inchange', /non affich/.test(st.current_plan_element_json) && stillElems === 5, [st.current_plan_element_json, stillElems]);
  await page.evaluate(() => { document.getElementById('demoAutoReply').checked = false; });
  await clickRow(111);
  await sleep(80);
  const cached = await page.evaluate(() => window.MyPnPlanViewerV2NS.state.currentElements.map((e) => e.id));
  check('plan 111 : capteurs memorises reaffiches sans nouvelle reponse', cached.length === 1 && cached[0] === 5, cached);
  await page.evaluate(() => { document.getElementById('demoAutoReply').checked = true; });

  /* --- 4bis. Affichage des capteurs sur le plan et etat d'alarme --- */
  console.log('\n4bis. Affichage des capteurs (show_mode, alarmes, survol, clic, zoom)');
  await clickRow(11);
  await sleep(150);
  const disp = await page.evaluate(() =>
    Array.from(document.querySelectorAll('.plan-layer-elements .plan-element')).map((w) => ({
      id: w._point.id,
      tag: w.firstChild.tagName,
      src: w.firstChild.tagName === 'IMG' ? w.firstChild.getAttribute('src') : null,
      size: w.firstChild.style.width,
      halo: w.classList.contains('alarm-halo'),
      inAlarm: w.classList.contains('in-alarm'),
      left: w.style.left,
    })));
  const d = (id) => disp.find((x) => x.id === id);
  check('4 capteurs affiches, le capteur masque absent', disp.length === 4 && !d(1003), disp.map((x) => x.id));
  check('1001 : pastille par defaut en alarme, halo anime', d(1001).tag === 'SPAN' && d(1001).inAlarm && d(1001).halo && d(1001).size === '28px' && d(1001).left === '22%', d(1001));
  check('1002 : pastille sans alarme', d(1002).tag === 'SPAN' && !d(1002).inAlarm && !d(1002).halo, d(1002));
  check('1004 : image basculee sur icon_alarm, sans halo', d(1004).tag === 'IMG' && /times\.png$/.test(d(1004).src) && d(1004).inAlarm && !d(1004).halo, d(1004));
  check('1005 : en alarme mais fige (always_without_animation)', !d(1005).inAlarm && !d(1005).halo, d(1005));

  // Carte de details au survol
  const pos1001 = await page.evaluate(() => {
    const w = Array.from(document.querySelectorAll('.plan-element')).find((x) => x._point.id === 1001);
    const r = w.getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  });
  await page.mouse.move(pos1001.x, pos1001.y);
  await sleep(120);
  const card = await page.evaluate(() => ({
    hidden: document.getElementById('markerCard').hidden,
    text: document.getElementById('markerCard').textContent,
  }));
  check('carte au survol : libelle et proprietes', !card.hidden && /D12/.test(card.text) && /Fum/.test(card.text) && /A3/.test(card.text), card);

  // Clic -> eventsDetailRequest_json source element, serial croissant
  await page.mouse.click(pos1001.x, pos1001.y);
  await sleep(80);
  let det = await lastWrite('eventsDetailRequest_json');
  check('clic capteur : source element, ids et planIndex', det && det.source === 'element' && det.element_id === 1001 && det.node_id === 11 && det.planIndex === 1 && /D12/.test(det.label), det);
  const detSerial = det.serial;
  await page.mouse.click(pos1001.x, pos1001.y);
  await sleep(80);
  det = await lastWrite('eventsDetailRequest_json');
  check('second clic identique : serial + 1', det.serial === detSerial + 1, det.serial);

  // Mise a jour a chaud des alarmes, EN PLACE (le calque n'est pas reconstruit)
  await page.evaluate(() => { document.querySelector('.plan-layer-elements .plan-element')._temoin = 42; });
  await page.evaluate(() => window.PanoDemo.push('configuration_events_json', JSON.stringify({ events: [
    { id: 7002, node_id: 122, priority: 2, color: 'amber', count: 3 },
    { id: 7004, element_id: 1004, priority: 1, color: 'red', count: 1 },
  ] })));
  await sleep(60);
  const hotAlarm = await page.evaluate(() => {
    const w = (id) => Array.from(document.querySelectorAll('.plan-element')).find((x) => x._point.id === id);
    return {
      halo1001: w(1001).classList.contains('alarm-halo'),
      src1004: w(1004).firstChild.getAttribute('src'),
      temoin: document.querySelector('.plan-layer-elements .plan-element')._temoin,
      count: document.querySelectorAll('.plan-layer-elements .plan-element').length,
    };
  });
  check('a chaud : 1001 sort d alarme, 1004 reste basculee, calque intact (en place)',
    !hotAlarm.halo1001 && /times\.png$/.test(hotAlarm.src1004) && hotAlarm.temoin === 42 && hotAlarm.count === 4, hotAlarm);
  await page.evaluate(() => window.PanoDemo.push('configuration_events_json', ''));
  await sleep(60);
  const cleared = await page.evaluate(() => {
    const w = (id) => Array.from(document.querySelectorAll('.plan-element')).find((x) => x._point.id === id);
    return { in1004: w(1004).classList.contains('in-alarm'), src1004: w(1004).firstChild.getAttribute('src') };
  });
  check('plus aucune alarme : 1004 revient a son image par defaut', !cleared.in1004 && /image\.png$/.test(cleared.src1004), cleared);

  // Les capteurs suivent le zoom (meme transformation que les calques)
  await page.evaluate(() => document.getElementById('zoomInBtn').click());
  await sleep(60);
  const layerTransform = await page.evaluate(() => document.querySelector('.plan-layer-elements').style.transform);
  check('les capteurs suivent le zoom', /scale\(1\.3/.test(layerTransform), layerTransform);
  await page.evaluate(() => document.getElementById('zoomResetBtn').click());
  await sleep(60);
  await page.screenshot({ path: SHOTS + '/shot-demo-capteurs.png' });

  /* --- 5. Alarmes : pastilles, badges, remontee parent_id --- */
  console.log('\n5. configuration_events_json : pastilles, badges, remontee par parent_id');
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(150);
  let r1 = await rowInfo(1), r2 = await rowInfo(2), r11 = await rowInfo(11), r12 = await rowInfo(12), r122 = await rowInfo(122);
  check('Site Sud replie : pastille rouge (remontee de 11 via parent_id)', r1.dot && !r1.dot.hidden && /sev-red/.test(r1.dot.all), r1);
  check('Site Nord : aucune pastille', r2.dot === null, r2);
  await clickRow(1);
  r1 = await rowInfo(1); r11 = await rowInfo(11); r12 = await rowInfo(12);
  check('Site Sud deplie : pastille masquee (aucun evenement propre)', r1.expanded && r1.dot && r1.dot.hidden, r1);
  check('Batiment A : rouge ; Batiment D replie : ambre (remontee de 122)', r11.dot && /sev-red/.test(r11.dot.color) && r12.dot && /sev-amber/.test(r12.dot.color), [r11, r12]);
  await clickRow(12);
  r12 = await rowInfo(12); r122 = await rowInfo(122);
  check('Batiment D deplie : masquee ; Niv1 batD ambre', r12.dot.hidden && r122.dot && /sev-amber/.test(r122.dot.color), [r12, r122]);
  await clickRow(1);
  let b = await badges();
  check('badges Site Sud : 1 (rouge) puis 3 (ambre) puis fixes 12, PPI', b.length === 4 && b[0].text === '1' && b[0].event && /sev-red/.test(b[0].bg) && b[1].text === '3' && /sev-amber/.test(b[1].bg) && b[2].text === '12' && b[3].text === 'PPI', b);
  await page.evaluate(() => document.querySelector('#topbarBadges .event-badge').click());
  await sleep(50);
  let req = await lastWrite('eventsDetailRequest_json');
  // serial est un compteur commun avec les clics sur les capteurs (4bis) :
  // seule sa croissance compte, pas sa valeur absolue.
  check('clic badge : eventsDetailRequest_json source badge', req && req.source === 'badge' && req.node_id === 1 && req.path === 'Site Sud' && req.priority === 1 && req.count === 1 && req.serial > 0, req);
  await clickRow(11);
  b = await badges();
  check('badges Batiment A : 1 rouge seul + fixes', b.length === 3 && b[0].text === '1' && b[0].event, b);

  // Mise a jour a chaud : selection, drawer et depliage conserves
  const before = await page.evaluate(() => ({
    drawer: document.getElementById('siteNav').classList.contains('open'),
    expanded: document.querySelectorAll('#siteTree .tree-node.expanded').length,
    selected: document.querySelector('#siteTree .row.selected').dataset.id,
    serial: window.MyPnPlanViewerV2NS.state.selectionSerial,
  }));
  await page.evaluate(() => window.PanoDemo.push('configuration_events_json', JSON.stringify({ events: [
    { id: 7001, element_id: 1001, node_id: 11, priority: 1, color: 'red', count: 4 },
    { id: 7003, node_id: 11, priority: 3, color: 'blue', count: 2 },
    { id: 7002, node_id: 122, priority: 2, color: 'amber', count: 9 },
  ] })));
  await sleep(50);
  const after = await page.evaluate(() => ({
    drawer: document.getElementById('siteNav').classList.contains('open'),
    expanded: document.querySelectorAll('#siteTree .tree-node.expanded').length,
    selected: document.querySelector('#siteTree .row.selected').dataset.id,
    serial: window.MyPnPlanViewerV2NS.state.selectionSerial,
  }));
  b = await badges();
  check('a chaud : badges 4 rouge, 2 bleu ; selection, drawer, depliage, serial conserves',
    b[0].text === '4' && b[1].text === '2' && /sev-blue/.test(b[1].bg) && JSON.stringify(before) === JSON.stringify(after), [b, before, after]);
  await page.evaluate(() => window.PanoDemo.push('configuration_events_json', ''));
  await sleep(50);
  b = await badges();
  const dots = await page.evaluate(() => document.querySelectorAll('#siteTree .event-dot').length);
  check('valeur vide : plus aucune pastille ni badge d evenement', dots === 0 && b.length === 2, [dots, b]);
  await page.evaluate(() => window.PanoDemo.push('configuration_events_json', '{ "events": [ { "id": 1 '));
  st = await status();
  check('JSON invalide : etat precedent conserve', /JSON invalide/.test(st.configuration_events_json) && /conserv/.test(st.configuration_events_json), st.configuration_events_json);

  /* --- 6. Vues epinglees et signets --- */
  console.log('\n6. Vues epinglees et signets (par id)');
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);
  await page.evaluate(() => document.querySelectorAll('#pinnedList .pinned')[0].click());
  await sleep(60);
  sel = await lastWrite('selectedNodePath');
  const r221 = await rowInfo(221), r22 = await rowInfo(22);
  check('vue epinglee -> n\u0153ud 221 (parent_id 22), ligne selectionnee, parents deplies', sel.id === 221 && sel.parent_id === 22 && r221.selected && r22.expanded, [sel, r221, r22]);
  await clickRow(11);
  await page.click('#pinAddBtn');
  await page.click('#pinAddBtn');
  let pins = await page.evaluate(() => Array.from(document.querySelectorAll('#pinnedList .pin-label')).map((l) => l.textContent));
  check('bouton + : signet ajoute une seule fois', pins.length === 3 && pins[2] === 'Site Sud B\u00e2timent A', pins);
  // VRAIE reconstruction : le titre change (une configuration au texte
  // identique passerait par le chemin « a chaud », qui ne rejoue pas les
  // signets).
  await page.evaluate(() => {
    const cfg = JSON.parse(document.getElementById('demoEditor').value);
    cfg.title = cfg.title + ' (reconstruit)';
    document.getElementById('demoEditor').value = JSON.stringify(cfg);
    document.getElementById('demoApply').click();
  });
  await sleep(80);
  const rebuilt = await page.evaluate(() => ({
    pins: document.querySelectorAll('#pinnedList .pin-label').length,
    selected: document.querySelectorAll('#siteTree .row.selected').length,
  }));
  check('signet conserve apres une VRAIE reconstruction (id toujours present, selection annulee)',
    rebuilt.pins === 3 && rebuilt.selected === 0, rebuilt);
  // Renommage d'une vue epinglee de la configuration, puis mise a jour
  // « badges seuls » : le chemin a chaud doit etre conserve (le libelle
  // renomme n'entre pas dans l'empreinte structurelle).
  await page.evaluate(() => {
    const NSv2 = window.MyPnPlanViewerV2NS;
    NSv2.state.currentConfig.pinned[0].label = 'Renomme par l\u2019operateur';
    const cfg = JSON.parse(document.getElementById('demoEditor').value);
    cfg.badges = [{ value: 99, color: 'red' }];
    document.getElementById('demoEditor').value = JSON.stringify(cfg);
  });
  await clickRow(221);
  const serialHot = await page.evaluate(() => window.MyPnPlanViewerV2NS.state.selectionSerial);
  await page.evaluate(() => document.getElementById('demoApply').click());
  await sleep(80);
  const hot = await page.evaluate(() => ({
    serial: window.MyPnPlanViewerV2NS.state.selectionSerial,
    selected: document.querySelectorAll('#siteTree .row.selected').length,
    badge99: Array.from(document.querySelectorAll('#topbarBadges .count-badge')).some((b) => b.textContent === '99'),
  }));
  check('badges seuls apres renommage d une vue epinglee : mise a jour a chaud conservee',
    hot.serial === serialHot && hot.selected === 1 && hot.badge99, [serialHot, hot]);
  // × sur une vue de la configuration puis « + » sur le meme nœud : le
  // signet doit pouvoir etre recree (anti-doublon sur les vues AFFICHEES).
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);
  await page.evaluate(() => document.querySelectorAll('#pinnedList .pinned')[0].querySelector('.close').click());
  await clickRow(2);
  await clickRow(22);
  await clickRow(221);
  await page.click('#pinAddBtn');
  // Le signet 11 de l'operateur (ajoute plus haut) survit au rechargement
  // du jeu : la liste attendue est [111 config, 11 signet, 221 re-epinglee].
  pins = await page.evaluate(() => Array.from(document.querySelectorAll('#pinnedList .pin-label')).map((l) => l.textContent));
  check('vue de la configuration retiree (x) puis re-epinglee par \u00ab + \u00bb',
    pins.length === 3 && pins[0] !== 'Site Nord Niv1 batD'
      && pins[2] === 'Site Nord B\u00e2timent D Niv1 batD', pins);
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);
  await clickRow(1);
  await clickRow(11);
  await page.click('#pinAddBtn');
  pins = await page.evaluate(() => document.querySelectorAll('#pinnedList .pin-label').length);
  await page.evaluate(() => {
    const cfg = JSON.parse(document.getElementById('demoEditor').value);
    cfg.tree[0].children = cfg.tree[0].children.filter((n) => n.id !== 11);
    document.getElementById('demoEditor').value = JSON.stringify(cfg);
    document.getElementById('demoApply').click();
  });
  await sleep(80);
  // Restent : la vue 221 de la configuration et le signet 221 de
  // l'operateur (test precedent) ; la vue 111 et le signet 11, sous le
  // nœud retire, disparaissent.
  pins = await page.evaluate(() => Array.from(document.querySelectorAll('#pinnedList .pin-label')).map((l) => l.textContent));
  check('signet retire quand son id disparait ; vue 111 (sous 11) ignoree',
    pins.length === 2 && pins[0] === 'Site Nord Niv1 batD'
      && pins[1] === 'Site Nord B\u00e2timent D Niv1 batD', pins);
  const warnPin = await page.evaluate(() => window.MyPnPlanViewerV2NS.state.currentConfig.warnings);
  check('avertissement : vue epinglee vers id inconnu', warnPin.length === 1 && /111/.test(warnPin[0]), warnPin);

  /* --- 7. Cas limites : avertissements --- */
  console.log('\n7. Cas limites : normalisation et avertissements');
  await page.evaluate(() => window.PanoDemo.chargerJeu('limites'));
  await sleep(150);
  const lim = await page.evaluate(() => {
    const NS = window.MyPnPlanViewerV2NS;
    const cfg = NS.state.currentConfig;
    return {
      warnings: cfg.warnings,
      has40: cfg.byId.has(40), has381: cfg.byId.has(381), has391: cfg.byId.has(391), has411: cfg.byId.has(411),
      has31: cfg.byId.has(31), label31: cfg.byId.get(31) && cfg.byId.get(31).label,
      n35layers: cfg.byId.get(35).plans[0].layers.map((l) => l.kind + ':' + l.label),
      plans33: cfg.byId.get(33).plans.length, label33: cfg.byId.get(33).plans[0].label,
      pins: cfg.pinned.map((p) => p.id),
      evWarnings: NS.state.events.warnings,
      ev40: NS.state.events.byNode.has(40),
      evEl500: NS.state.events.byElement.has(500),
      rows: document.querySelectorAll('#siteTree .tree-node').length,
    };
  });
  const w = lim.warnings.join('\n');
  check('id chaine "40" accepte ; descendances des n\u0153uds sans id / en doublon / sans libelle perdues', lim.has40 && !lim.has381 && !lim.has391 && !lim.has411, lim);
  check('id 31 : premiere occurrence conservee', lim.has31 && /indicateur/.test(lim.label31), lim.label31);
  check('calques V1 ignores, seul le calque image valide reste', lim.n35layers.length === 1 && lim.n35layers[0] === 'image:Zone \u00e0 risque', lim.n35layers);
  check('avertissements : sans id, doublon, decimal, 0, negatif', /sans id valide/.test(w) && /id 31 d\u00e9j\u00e0 port/.test(w) && (w.match(/sans id valide/g) || []).length >= 4, lim.warnings);
  check('avertissements : cles V1 events / alarm', (w.match(/events \/ alarm ignor/g) || []).length === 2, lim.warnings);
  check('avertissements : calques markers / shapes / image sans fichier', /kind "markers" ignor/.test(w) && /kind "shapes" ignor/.test(w) && /sans filename/.test(w), lim.warnings);
  check('quatre plans : seule la premiere retenue, avertissement', lim.plans33 === 1 && lim.label33 === 'Plan 1' && /4 repr\u00e9sentations re\u00e7ues, seule la premi\u00e8re \("Plan 1"\)/.test(w), [lim.plans33, lim.label33, lim.warnings]);
  check('avertissements : vues epinglees (id inconnu, V1 path, sans id) ; seule la vue 31 retenue', /aucun n\u0153ud d\u2019id 99999/.test(w) && (w.match(/Vue \u00e9pingl\u00e9e .* sans id valide/g) || []).length === 2 && lim.pins.join() === '31', [lim.pins, lim.warnings]);
  check('evenements : node_id "40" en chaine accepte ; element_id 500 indexe ; count "trois" ignore', lim.ev40 && lim.evEl500 && lim.evWarnings.some((x) => /count nul ou invalide/.test(x)), [lim.ev40, lim.evEl500, lim.evWarnings]);
  const statW = await page.evaluate(() => document.getElementById('statWarnings').textContent);
  check('panneau du banc : avertissements listes', /configuration : \d+/.test(statW), statW.slice(0, 80));
  // Capteurs du jeu limites (plan 32:1)
  await clickRow(30);
  await clickRow(32);
  await sleep(120);
  const el32 = await page.evaluate(() => window.MyPnPlanViewerV2NS.state.currentElements.map((e) => [e.id, e.show_mode, e.size]));
  check('capteurs : doublon / sans id ignores ; hors plan ramene au bord ; show_mode et size corriges', el32.length === 4 && el32[0][0] === 1 && el32[1][0] === 2 && el32[2][1] === 'always_with_animation' && el32[3][2] === 128, el32);
  const el32w = await page.evaluate(() => window.MyPnPlanViewerV2NS.state.propertyStatus.current_plan_element_json);
  check('capteurs : avertissements comptes dans le statut', /4 avertissement/.test(el32w), el32w);

  /* --- 8. Mode sans navigation --- */
  console.log('\n8. Mode sans navigation (plans a la racine)');
  await page.evaluate(() => window.PanoDemo.chargerJeu('racine'));
  await sleep(150);
  sel = await lastWrite('selectedNodePath');
  const racine = await page.evaluate(() => ({
    drawerHidden: document.getElementById('drawerBtn').hidden,
    elements: window.MyPnPlanViewerV2NS.state.currentElements.map((e) => e.id),
    title: document.getElementById('siteTitle').textContent,
  }));
  check('selectedNodePath : id 0, planIndex 1, path = title, labels [title]', sel.id === 0 && sel.parent_id === 0 && sel.planIndex === 1 && sel.path === racine.title && sel.labels.length === 1 && /planA/.test(sel.filename), sel);
  check('drawer masque ; capteurs 0:1 recus', racine.drawerHidden && racine.elements.join() === '1001,1002', racine);
  const racinePlans = await page.evaluate(() => window.MyPnPlanViewerV2NS.state.currentPlans.length);
  check('une seule representation racine', racinePlans === 1, racinePlans);

  /* --- 9. Vide / invalide --- */
  console.log('\n9. Configurations vide et invalide');
  await page.evaluate(() => window.PanoDemo.chargerJeu('invalide'));
  await sleep(100);
  const inv = await page.evaluate(() => ({
    loc: document.getElementById('planLocation').textContent,
    status: Object.assign({}, window.MyPnPlanViewerV2NS.state.propertyStatus),
    tooltip: document.getElementById('configTooltipText').textContent.split('\n').slice(0, 4),
  }));
  check('JSON invalide : message sous le repere et statut', /JSON invalide/.test(inv.loc) && /JSON invalide/.test(inv.status.configuration_plan_json), inv);
  check('info-bulle : etat des 4 proprietes en tete', inv.tooltip.length === 4 && /configuration_plan_json/.test(inv.tooltip[0]) && /current_plan_drawnShapes_json/.test(inv.tooltip[3]), inv.tooltip);
  const serialBeforeInvalid = await page.evaluate(() => window.MyPnPlanViewerV2NS.state.selectionSerial);
  await page.evaluate(() => window.PanoDemo.push('configuration_plan_json', ''));
  const serialAfterEmpty = await page.evaluate(() => window.MyPnPlanViewerV2NS.state.selectionSerial);
  check('configuration vide : aucune ecriture de selectedNodePath', serialAfterEmpty === serialBeforeInvalid, [serialBeforeInvalid, serialAfterEmpty]);

  /* --- 10. Mode edition : ecriture + anti-echo --- */
  console.log('\n10. Mode edition : current_plan_drawnShapes_json (ecriture) et garde anti-echo');
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);
  await page.evaluate(() => { const c = document.getElementById('demoEditing'); c.checked = true; c.dispatchEvent(new Event('change')); });
  await sleep(100);
  await clickRow(1);
  await clickRow(11);
  await sleep(150);
  await page.waitForFunction(() => {
    const img = document.getElementById('planImage');
    return img && img.complete && img.naturalWidth > 0 && img.offsetWidth > 0;
  }, { timeout: 10000 });
  await page.click('#shapeEditLock');
  await page.waitForSelector('#shapeEditToolbar:not([hidden])');
  await page.click('#shapeEditToolbar button[data-tool="rect"]');
  const planPoint = (fx, fy) => page.evaluate((a, b2) => {
    const r = document.getElementById('planImage').getBoundingClientRect();
    return { x: r.left + r.width * a, y: r.top + r.height * b2 };
  }, fx, fy);
  const p1 = await planPoint(0.1, 0.1), p2 = await planPoint(0.6, 0.6);
  await page.mouse.move(p1.x, p1.y);
  await page.mouse.down();
  await page.mouse.move((p1.x + p2.x) / 2, (p1.y + p2.y) / 2, { steps: 4 });
  await page.mouse.move(p2.x, p2.y, { steps: 4 });
  await page.mouse.up();
  await sleep(150);
  const shapes = await lastWrite('current_plan_drawnShapes_json');
  // La reponse automatique a deja pousse 3 formes (3001-3003) : le
  // rectangle dessine s'y ajoute, avec l'id suivant (3004).
  const rect = shapes && shapes.shapes.find((s) => s.type === 'rect' && s.id === 3004);
  check('ecriture : node_id 11, planIndex 1, filename, 3 formes recues + le rectangle', shapes && shapes.node_id === 11 && shapes.planIndex === 1 && shapes.filename === 'Images/planA.jpg' && shapes.shapes.length === 4 && Boolean(rect), shapes && shapes.shapes.map((s) => s.id + ':' + s.type));
  check('rectangle : id 3004, show_mode par defaut', rect && rect.show_mode === 'always_without_animation', rect);
  check('elements : ids des capteurs couverts (1001, 1002 ; 1003 hors du rectangle)', rect && rect.elements.join() === '1001,1002', rect && rect.elements);
  check('formes recues reecrites avec leur id, show_mode et elements', shapes && shapes.shapes.some((s) => s.id === 3001 && s.show_mode === 'always_with_animation' && s.elements.join() === '1001'), shapes && shapes.shapes[0]);
  check('plus de cle sensors / node', rect && rect.sensors === undefined && shapes.node === undefined);
  st = await status();
  check('echo du stub ignore (garde anti-echo)', /\u00e9cho/.test(st.current_plan_drawnShapes_json), st.current_plan_drawnShapes_json);
  const cov = await page.evaluate(() => document.getElementById('shapeCoverageInfo').textContent);
  check('indicateur capteurs couverts : 2', /Capteurs couverts \(2\)/.test(cov), cov);
  await page.screenshot({ path: SHOTS + '/shot-demo-edition.png' });

  /* --- 10bis. Lecture de current_plan_drawnShapes_json --- */
  console.log('\n10bis. Lecture des formes (show_mode, alarmes, ids, liaison elements)');
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(120);
  await clickRow(1);
  await clickRow(11);
  await sleep(200);
  const rs = await page.evaluate(() => {
    const NSv2 = window.MyPnPlanViewerV2NS;
    const nodes = Array.from(document.querySelectorAll('#planEditLayer .pe-shape'));
    return {
      shapes: NSv2.edit.shapes.map((s) => [s.id, s.type, s.show_mode, (s.elements || []).join('|')]),
      rendered: nodes.map((n) => ({
        alarm: n.classList.contains('pe-shape-alarm'),
        fill: n.getAttribute('fill'),
        tag: n.tagName,
      })),
      layerHidden: document.getElementById('planEditLayer').hasAttribute('hidden'),
      lockHidden: document.getElementById('shapeEditLock').hidden,
      status: NSv2.state.propertyStatus.current_plan_drawnShapes_json,
    };
  });
  check('3 formes recues (ids, show_mode, elements)', rs.shapes.length === 3
    && rs.shapes[0].join() === '3001,polygon,always_with_animation,1001'
    && rs.shapes[1].join() === '3002,circle,always_without_animation,'
    && rs.shapes[2].join() === '3003,rect,masked,', rs.shapes);
  check('sans shapeEditing : formes affichees, cadenas masque', !rs.layerHidden && rs.lockHidden, rs);
  check('rendu cadenas ferme : polygone en alarme (halo) + cercle ; rect masque absent',
    rs.rendered.length === 2 && rs.rendered.filter((n) => n.alarm).length === 1, rs.rendered);
  check('apparence css internalisee (rgba -> fillColor/fillOpacity)',
    rs.rendered.some((n) => /rgba\(220, 38, 38, 0\.15\)/.test(n.fill || '')), rs.rendered);
  check('statut : 3 forme(s) pour plan affiche', /3 forme\(s\) pour plan affich/.test(rs.status), rs.status);

  // Plus d'alarme sur 1001 : le polygone « sur alarme » disparait, a chaud.
  await page.evaluate(() => window.PanoDemo.push('configuration_events_json', ''));
  await sleep(80);
  const rsOff = await page.evaluate(() => document.querySelectorAll('#planEditLayer .pe-shape').length);
  check('sans alarme : seule la forme toujours affichee reste', rsOff === 1, rsOff);

  // Ids : forme sans id -> attribue ; doublon -> re-attribue + avertissement.
  await page.evaluate(() => window.PanoDemo.push('current_plan_drawnShapes_json', JSON.stringify({
    node_id: 11, planIndex: 1, shapes: [
      { type: 'circle', cx: 0.3, cy: 0.3, r: 0.04 },
      { id: 7, type: 'pin', x: 0.5, y: 0.5 },
      { id: 7, type: 'pin', x: 0.6, y: 0.5 },
      { type: 'soucoupe', x: 0.1, y: 0.1 },
    ] })));
  await sleep(60);
  const ids = await page.evaluate(() => ({
    ids: window.MyPnPlanViewerV2NS.edit.shapes.map((s) => s.id),
    status: window.MyPnPlanViewerV2NS.state.propertyStatus.current_plan_drawnShapes_json,
  }));
  check('remplacement + ids : sans id -> 8, doublon 7 -> 9, type inconnu ignore',
    ids.ids.join() === '8,7,9' && /3 forme\(s\)/.test(ids.status) && /2 avertissement/.test(ids.status), ids);

  // Edition d'une forme recue : liaison conservee sur un changement
  // d'apparence, recalculee sur un changement de geometrie.
  await page.evaluate(() => { const c = document.getElementById('demoEditing'); c.checked = true; c.dispatchEvent(new Event('change')); });
  await sleep(120);
  await clickRow(1);
  await clickRow(11);
  await sleep(200);
  await page.waitForFunction(() => {
    const img = document.getElementById('planImage');
    return img && img.complete && img.naturalWidth > 0 && img.offsetWidth > 0;
  }, { timeout: 10000 });
  // L'etat du cadenas vaut pour la page : il est reste ouvert depuis la
  // section 10 — ne cliquer que s'il est ferme.
  if (!(await page.evaluate(() => window.MyPnPlanViewerV2NS.edit.unlocked))) {
    await page.click('#shapeEditLock');
  }
  await page.waitForSelector('#shapeEditToolbar:not([hidden])');
  // Selection du polygone recu (clic en son centre, outil « selectionner »).
  const pCentroid = await planPoint(0.28, 0.65);
  await page.mouse.click(pCentroid.x, pCentroid.y);
  await sleep(120);
  const selInfo = await page.evaluate(() => ({
    id: window.MyPnPlanViewerV2NS.edit.selected && window.MyPnPlanViewerV2NS.edit.selected.id,
    showMode: document.getElementById('shapeShowMode').value,
    panelHidden: document.getElementById('shapeStylePanel').hidden,
  }));
  check('polygone recu selectionnable ; panneau Affichage synchronise', selInfo.id === 3001 && selInfo.showMode === 'always_with_animation' && !selInfo.panelHidden, selInfo);
  // Changement d'apparence : la liaison [1001] posee par l'application est
  // CONSERVEE (le polygone ne couvre geometriquement aucun capteur).
  await page.evaluate(() => {
    const input = document.getElementById('shapeFillColor');
    input.value = '#00aa55';
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  });
  await sleep(120);
  let wr = await lastWrite('current_plan_drawnShapes_json');
  let poly = wr && wr.shapes.find((s) => s.id === 3001);
  check('apparence changee : elements [1001] conservee', poly && poly.elements.join() === '1001' && /0\.6/.test(String(poly.fill)) === false && poly.fill.indexOf('rgba(0, 170, 85') === 0, poly && [poly.elements, poly.fill]);
  // Deplacement (geometrie) : la liaison est recalculee (aucun capteur couvert).
  const pTo = await planPoint(0.30, 0.62);
  await page.mouse.move(pCentroid.x, pCentroid.y);
  await page.mouse.down();
  await page.mouse.move((pCentroid.x + pTo.x) / 2, (pCentroid.y + pTo.y) / 2, { steps: 3 });
  await page.mouse.move(pTo.x, pTo.y, { steps: 3 });
  await page.mouse.up();
  await sleep(150);
  wr = await lastWrite('current_plan_drawnShapes_json');
  poly = wr && wr.shapes.find((s) => s.id === 3001);
  check('geometrie changee : elements recalculee (vide, aucun capteur couvert)', poly && poly.elements.length === 0, poly && poly.elements);
  // Section « Affichage » : passer le polygone en « masquee », verrouiller.
  await page.evaluate(() => {
    const sel2 = document.getElementById('shapeShowMode');
    sel2.value = 'masked';
    sel2.dispatchEvent(new Event('change', { bubbles: true }));
  });
  await sleep(100);
  wr = await lastWrite('current_plan_drawnShapes_json');
  poly = wr && wr.shapes.find((s) => s.id === 3001);
  const ghosts = await page.evaluate(() => document.querySelectorAll('#planEditLayer .pe-hidden-mode').length);
  check('show_mode via le panneau : ecrit "masked" ; fantomes cadenas ouvert', poly && poly.show_mode === 'masked' && ghosts >= 2, [poly && poly.show_mode, ghosts]);
  await page.click('#shapeEditLock');
  await sleep(100);
  const lockedCount = await page.evaluate(() => document.querySelectorAll('#planEditLayer .pe-shape').length);
  check('cadenas ferme : seule la forme toujours affichee reste rendue', lockedCount === 1, lockedCount);
  await page.screenshot({ path: SHOTS + '/shot-demo-formes.png' });

  /* --- 10ter. Scene 3D : cadenas partage, outils 3D, vue par defaut --- */
  console.log('\n10ter. Scene 3D (current_plan_scene3d_json, vue par defaut)');
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);
  await page.evaluate(() => { const c = document.getElementById('demoEditing'); c.checked = true; c.dispatchEvent(new Event('change')); });
  await sleep(100);
  await clickRow(1);
  await clickRow(12);
  await clickRow(121);
  await page.waitForFunction(() => document.getElementById('threeLoading').hidden && window.ThreeViewer && window.ThreeViewer.isActive(), { timeout: 20000 }).catch(() => {});
  await sleep(250);
  const st3 = await status();
  check('scene recue par la reponse automatique : statut \u00ab vue par defaut enregistree \u00bb', /enregistr/.test(st3.current_plan_scene3d_json || ''), st3.current_plan_scene3d_json);
  const cam0 = await page.evaluate(() => window.ThreeViewer.getCameraState());
  check('camera placee sur la vue par defaut du jeu d essai (position [150, 95, -170], cible y 15)', cam0 && Math.abs(cam0.position[0] - 150) < 0.5 && Math.abs(cam0.position[2] + 170) < 0.5 && Math.abs(cam0.target[1] - 15) < 0.5, cam0);
  const ui0 = await page.evaluate(() => ({
    lock: !document.getElementById('shapeEditLock').hidden,
    toolbarHidden: document.getElementById('shapeEditToolbar').hidden,
    panelHidden: document.getElementById('scenePanel').hidden,
    mode3d: document.getElementById('shapeEditToolbar').classList.contains('mode-3d'),
  }));
  check('cadenas visible sur le modele 3D (shapeEditing) ; barre et panneau masques cadenas ferme', ui0.lock && ui0.toolbarHidden && ui0.panelHidden && ui0.mode3d, ui0);
  await page.click('#shapeEditLock');
  await sleep(120);
  const ui1 = await page.evaluate(() => ({
    toolbar: !document.getElementById('shapeEditToolbar').hidden,
    panel: !document.getElementById('scenePanel').hidden,
    stylePanelHidden: document.getElementById('shapeStylePanel').hidden,
    tools2d: Array.from(document.querySelectorAll('#shapeEditToolbar [data-mode="2d"] button')).filter((b) => b.offsetParent !== null).length,
    tools3d: Array.from(document.querySelectorAll('#shapeEditToolbar [data-mode="3d"] button')).filter((b) => b.offsetParent !== null).length,
    status: document.getElementById('sceneViewStatus').textContent,
    autoEnabled: !document.getElementById('sceneViewAutoBtn').disabled,
    title: document.getElementById('shapeEditLock').title,
  }));
  check('cadenas ouvert : barre en mode 3D (outils 2D masques), panneau Scene 3D, vue enregistree, titre du cadenas', ui1.toolbar && ui1.panel && ui1.stylePanelHidden && ui1.tools2d === 0 && ui1.tools3d >= 1 && /enregistr/.test(ui1.status) && ui1.autoEnabled && /3D/.test(ui1.title), ui1);
  // Zoom avant puis « Definir la vue actuelle » : ecriture avec la camera courante.
  await page.click('#zoomInBtn');
  await sleep(50);
  await page.click('#zoomInBtn');
  await sleep(80);
  const stDiff = await page.evaluate(() => document.getElementById('sceneViewStatus').textContent);
  check('camera deplacee : le panneau signale que la vue actuelle differe', /diff/.test(stDiff), stDiff);
  const camZ = await page.evaluate(() => window.ThreeViewer.getCameraState());
  await page.click('#sceneViewSetBtn');
  await sleep(150);
  let ws = await lastWrite('current_plan_scene3d_json');
  check('\u00ab Definir la vue actuelle \u00bb ecrit { node_id 121, planIndex 1, filename .obj, serial, unit m, camera courante }', ws && ws.node_id === 121 && ws.planIndex === 1 && /\.obj$/.test(ws.filename) && ws.serial >= 1 && ws.unit === 'm' && ws.camera && Math.abs(ws.camera.position[0] - camZ.position[0]) < 0.01 && Math.abs(ws.camera.target[2] - camZ.target[2]) < 0.01 && Array.isArray(ws.objects) && Array.isArray(ws.zones), ws);
  const serialA = ws ? ws.serial : 0;
  const st4 = await status();
  check('echo de l ecriture ignore', /cho de la derni/.test(st4.current_plan_scene3d_json || ''), st4.current_plan_scene3d_json);
  await page.screenshot({ path: SHOTS + '/shot-demo-scene3d.png' });
  // Le bouton de reinitialisation revient a la vue enregistree (100 %).
  await page.click('#zoomOutBtn');
  await sleep(50);
  await page.click('#zoomOutBtn');
  await sleep(50);
  await page.click('#zoomResetBtn');
  await sleep(120);
  const camR = await page.evaluate(() => window.ThreeViewer.getCameraState());
  const zoomTxt = await page.evaluate(() => document.getElementById('zoomLevel').textContent);
  check('bouton de reinitialisation : retour a la vue enregistree, 100 %', Math.abs(camR.position[0] - camZ.position[0]) < 0.01 && Math.abs(camR.position[1] - camZ.position[1]) < 0.01 && zoomTxt === '100%', [camR, camZ, zoomTxt]);
  // Vue automatique : camera null ecrite, recadrage du modele.
  await page.click('#sceneViewAutoBtn');
  await sleep(150);
  ws = await lastWrite('current_plan_scene3d_json');
  const camA = await page.evaluate(() => window.ThreeViewer.getCameraState());
  check('\u00ab Vue automatique \u00bb : camera null ecrite, serial + 1, modele recadre', ws && ws.camera === null && ws.serial === serialA + 1 && Math.abs(camA.position[0] - camZ.position[0]) > 1, [ws && ws.camera, ws && ws.serial, camA]);
  // Lecture : l application pousse une autre vue par defaut et une unite.
  await page.evaluate(() => window.PanoDemo.push('current_plan_scene3d_json', JSON.stringify({ node_id: 121, planIndex: 1, unit: 'ft', camera: { position: [-120, 60, 90], target: [10, 5, -5] } })));
  await sleep(150);
  const camP = await page.evaluate(() => window.ThreeViewer.getCameraState());
  const unitP = await page.evaluate(() => document.getElementById('sceneUnitInput').value);
  check('scene recue de l application : camera appliquee, unite reprise dans le panneau', Math.abs(camP.position[0] + 120) < 0.5 && Math.abs(camP.target[0] - 10) < 0.5 && unitP === 'ft', [camP, unitP]);
  // Scene d un autre plan : memorisee, sans effet sur l affichage.
  await page.evaluate(() => window.PanoDemo.push('current_plan_scene3d_json', JSON.stringify({ node_id: 11, planIndex: 1, camera: { position: [1, 2, 3], target: [0, 0, 0] } })));
  await sleep(100);
  const st5 = await status();
  const camP2 = await page.evaluate(() => window.ThreeViewer.getCameraState());
  check('scene d un autre plan : memorisee (non affiche), camera inchangee', /non affich/.test(st5.current_plan_scene3d_json || '') && Math.abs(camP2.position[0] + 120) < 0.5, [st5.current_plan_scene3d_json, camP2]);
  // Camera incomplete : avertissement, vue automatique.
  await page.evaluate(() => window.PanoDemo.push('current_plan_scene3d_json', JSON.stringify({ node_id: 121, planIndex: 1, camera: { position: [1, 2] } })));
  await sleep(150);
  const st6 = await status();
  const camI = await page.evaluate(() => window.ThreeViewer.getCameraState());
  check('camera incomplete : avertissement, vue automatique (modele recadre)', /avertissement/.test(st6.current_plan_scene3d_json || '') && /automatique/.test(st6.current_plan_scene3d_json || '') && Math.abs(camI.position[0] + 120) > 1, [st6.current_plan_scene3d_json, camI]);
  // Cadenas ferme puis plan 2D : panneau masque, barre hors mode 3D.
  await page.click('#shapeEditLock');
  await sleep(100);
  const ui2 = await page.evaluate(() => ({ toolbarHidden: document.getElementById('shapeEditToolbar').hidden, panelHidden: document.getElementById('scenePanel').hidden }));
  check('cadenas ferme : barre et panneau Scene 3D masques', ui2.toolbarHidden && ui2.panelHidden, ui2);
  await clickRow(11);
  await sleep(120);
  const ui3 = await page.evaluate(() => ({ lock: !document.getElementById('shapeEditLock').hidden, mode3d: document.getElementById('shapeEditToolbar').classList.contains('mode-3d'), panelHidden: document.getElementById('scenePanel').hidden }));
  check('plan 2D : cadenas visible, barre hors mode 3D, panneau Scene 3D masque', ui3.lock && !ui3.mode3d && ui3.panelHidden, ui3);

  /* --- 10quater. Scene 3D : emprise au sol et fond de plan --- */
  console.log('\n10quater. Scene 3D : emprise au sol (footprint) et fond de plan (floorImage)');
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);
  await page.evaluate(() => { const c = document.getElementById('demoEditing'); c.checked = true; c.dispatchEvent(new Event('change')); });
  await sleep(100);
  await clickRow(1);
  await clickRow(12);
  await clickRow(121);
  await page.waitForFunction(() => document.getElementById('threeLoading').hidden && window.ThreeViewer && window.ThreeViewer.isActive(), { timeout: 20000 }).catch(() => {});
  await page.waitForFunction(() => { const d = window.MyPnPlanViewerV2NS.scene3dRender.debug(); return d.floor && d.floor.map; }, { timeout: 8000 }).catch(() => {});
  const dbg = () => page.evaluate(() => window.MyPnPlanViewerV2NS.scene3dRender.debug());
  const dbg0 = await dbg();
  check('scene du jeu d essai rendue cadenas ferme : emprise (2 maillages) + fond de plan texture (PlanD.png, largeur 200) + fleche nord, aucune poignee', dbg0.pickables === 9 && dbg0.floor && dbg0.floor.map && dbg0.handles === 0 && Math.abs(dbg0.floor.w - 200) < 0.01, dbg0);
  await page.click('#shapeEditLock');
  await sleep(120);
  const gp = (x, z) => page.evaluate((px, pz) => { const R = window.MyPnPlanViewerV2NS.scene3dRender; return R.project(px, R.groundY(), pz); }, x, z);
  const clickGround = async (x, z) => { const p = await gp(x, z); await page.mouse.click(p.x, p.y); await sleep(80); };
  const near = (p, x, z) => Boolean(p) && Math.abs(p[0] - x) < 2 && Math.abs(p[1] - z) < 2;
  // Outil Emprise : quatre sommets, Entree.
  await page.click('#shapeEditToolbar button[data-tool3d="footprint"]');
  await sleep(60);
  const drawing = await page.evaluate(() => document.getElementById('threeViewport').classList.contains('scene-drawing'));
  check('outil Emprise actif : curseur de trace', drawing, drawing);
  await clickGround(-60, -30);
  await clickGround(60, -30);
  await clickGround(60, 30);
  const dbgDraft = await dbg();
  check('trace en cours : 3 poignees de sommets', dbgDraft.handles === 3, dbgDraft.handles);
  await clickGround(-60, 30);
  await page.keyboard.press('Enter');
  await sleep(150);
  let ws2 = await lastWrite('current_plan_scene3d_json');
  const fp0 = ws2 && ws2.footprint;
  check('Entree : emprise ecrite (4 sommets au sol, pointilles, contour par defaut), le reste de la scene conserve', fp0 && fp0.points.length === 4 && near(fp0.points[0], -60, -30) && near(fp0.points[2], 60, 30) && fp0.dashed === true && fp0.stroke === '#1d4ed8' && ws2.camera && ws2.floorImage, fp0);
  const uiFp = await page.evaluate(() => ({ section: !document.getElementById('sceneFootprintSection').hidden, generalHidden: document.getElementById('sceneGeneralSection').hidden, del: !document.getElementById('shapeDeleteBtn').disabled, orbit: document.querySelector('#shapeEditToolbar button[data-tool3d="orbit"]').classList.contains('active'), handles: window.MyPnPlanViewerV2NS.scene3dRender.debug().handles }));
  check('emprise selectionnee : section Emprise, bouton Supprimer actif, outil Navigation, 4 poignees', uiFp.section && uiFp.generalHidden && uiFp.del && uiFp.orbit && uiFp.handles === 4, uiFp);
  // Panneau : contour, trait plein.
  await page.evaluate(() => { const i = document.getElementById('sceneFpStroke'); i.value = '#00aa55'; i.dispatchEvent(new Event('input', { bubbles: true })); i.dispatchEvent(new Event('change', { bubbles: true })); });
  await page.evaluate(() => { const i = document.getElementById('sceneFpDashed'); i.checked = false; i.dispatchEvent(new Event('change', { bubbles: true })); });
  await sleep(150);
  ws2 = await lastWrite('current_plan_scene3d_json');
  check('panneau Emprise : contour #00aa55 et trait plein ecrits', ws2.footprint.stroke === '#00aa55' && ws2.footprint.dashed === false, ws2.footprint);
  // Glisser du sommet 0 vers (-80, -40) : OrbitControls suspendu.
  const h0 = await gp(-60, -30);
  const h1 = await gp(-80, -40);
  await page.mouse.move(h0.x, h0.y);
  await page.mouse.down();
  await page.mouse.move((h0.x + h1.x) / 2, (h0.y + h1.y) / 2, { steps: 3 });
  await page.mouse.move(h1.x, h1.y, { steps: 3 });
  await page.mouse.up();
  await sleep(150);
  ws2 = await lastWrite('current_plan_scene3d_json');
  const camDrag = await page.evaluate(() => window.ThreeViewer.getCameraState());
  check('poignee de sommet glissee : sommet 0 vers (-80, -40) ecrit, camera immobile', near(ws2.footprint.points[0], -80, -40) && Math.abs(camDrag.position[0] - 150) < 0.5, [ws2.footprint.points[0], camDrag]);
  // Suppr : emprise retiree.
  await page.keyboard.press('Delete');
  await sleep(150);
  ws2 = await lastWrite('current_plan_scene3d_json');
  const uiDel = await page.evaluate(() => ({ sectionHidden: document.getElementById('sceneFootprintSection').hidden, pick: window.MyPnPlanViewerV2NS.scene3dRender.debug().pickables }));
  check('touche Suppr : footprint null ecrit, section masquee, seul le fond de plan reste (+ etalon, mesures, fleche nord)', ws2.footprint === null && uiDel.sectionHidden && uiDel.pick === 7, [ws2.footprint, uiDel]);
  // Fond de plan : selection par clic, largeur / rotation par le panneau.
  await clickGround(0, 0);
  await sleep(100);
  const uiFl = await page.evaluate(() => ({ section: !document.getElementById('sceneFloorSection').hidden, gallery: document.querySelectorAll('#sceneFloorGallery button').length, file: document.getElementById('sceneFloorFile').value, width: document.getElementById('sceneFloorWidth').value, handles: window.MyPnPlanViewerV2NS.scene3dRender.debug().handles }));
  check('clic sur le fond de plan : section Fond de plan (galerie 2 images, fichier, largeur 200), 5 poignees', uiFl.section && uiFl.gallery === 2 && /PlanD/.test(uiFl.file) && uiFl.width === '200' && uiFl.handles === 5, uiFl);
  await page.evaluate(() => { const i = document.getElementById('sceneFloorWidth'); i.value = '150'; i.dispatchEvent(new Event('change', { bubbles: true })); });
  await page.evaluate(() => { const i = document.getElementById('sceneFloorRotation'); i.value = '30'; i.dispatchEvent(new Event('change', { bubbles: true })); });
  await sleep(150);
  ws2 = await lastWrite('current_plan_scene3d_json');
  const dbgFl = await dbg();
  check('panneau Fond de plan : largeur 150 et rotation 30 ecrites et rendues', ws2.floorImage.width === 150 && ws2.floorImage.rotation === 30 && Math.abs(dbgFl.floor.w - 150) < 0.01 && Math.abs(dbgFl.floor.rotY + 30 * Math.PI / 180) < 1e-6, [ws2.floorImage, dbgFl.floor]);
  await page.screenshot({ path: SHOTS + '/shot-demo-scene3d-sol.png' });
  // Galerie : choix du SVG (rasterise en texture).
  await page.click('#sceneFloorGallery button:nth-child(2)');
  await page.waitForFunction(() => { const d = window.MyPnPlanViewerV2NS.scene3dRender.debug(); return d.textures.some((t) => /svg:ok/.test(t)); }, { timeout: 5000 }).catch(() => {});
  ws2 = await lastWrite('current_plan_scene3d_json');
  const dbgSvg = await dbg();
  check('galerie : fichier SVG ecrit et texture', /face_nu\.svg$/.test(ws2.floorImage.filename) && dbgSvg.floor.map, [ws2.floorImage.filename, dbgSvg.textures]);
  // Outil Fond de plan : nouveau placement au clic (remplace l ancien).
  await page.keyboard.press('Escape');
  await sleep(60);
  await page.click('#shapeEditToolbar button[data-tool3d="floorimage"]');
  await sleep(60);
  await clickGround(40, 20);
  await sleep(150);
  ws2 = await lastWrite('current_plan_scene3d_json');
  check('outil Fond de plan : image posee au clic (centre ~ (40, 20), premier fichier de la galerie, largeur auto)', ws2.floorImage && Math.abs(ws2.floorImage.x - 40) < 2 && Math.abs(ws2.floorImage.z - 20) < 2 && /PlanD/.test(ws2.floorImage.filename) && ws2.floorImage.width === null, ws2.floorImage);
  // Scene relue avec emprise : « Ajuster a l emprise ».
  await page.evaluate(() => window.PanoDemo.push('current_plan_scene3d_json', JSON.stringify({ node_id: 121, planIndex: 1, camera: { position: [150, 95, -170], target: [0, 15, 0] }, footprint: { points: [[-100, -50], [100, -50], [100, 50], [-100, 50]] }, floorImage: { filename: 'Images/PlanD.png', x: 30, z: 10, width: 80, rotation: 45 } })));
  await sleep(200);
  await clickGround(30, 10);
  await sleep(100);
  await page.click('#sceneFloorFitBtn');
  await sleep(150);
  ws2 = await lastWrite('current_plan_scene3d_json');
  check('\u00ab Ajuster a l emprise \u00bb : fond de plan centre (0, 0), largeur 200, hauteur 100, rotation 0', ws2.floorImage.x === 0 && ws2.floorImage.z === 0 && ws2.floorImage.width === 200 && ws2.floorImage.height === 100 && ws2.floorImage.rotation === 0, ws2.floorImage);
  // Normalisation : emprise a 2 sommets et fond de plan sans fichier ignores.
  await page.evaluate(() => window.PanoDemo.push('current_plan_scene3d_json', JSON.stringify({ node_id: 121, planIndex: 1, footprint: { points: [[0, 0], [1, 1]], stroke: 'rouge' }, floorImage: { x: 1 } })));
  await sleep(150);
  const st7 = await status();
  const dbg7 = await dbg();
  check('normalisation : emprise a 2 sommets et fond de plan sans fichier ignores (2 avertissements), rien de rendu', /2 avertissement/.test(st7.current_plan_scene3d_json || '') && dbg7.pickables === 0, [st7.current_plan_scene3d_json, dbg7]);
  await page.click('#shapeEditLock');
  await sleep(100);

  /* --- 10quinquies. Scene 3D : etalon d echelle et mesures --- */
  console.log('\n10quinquies. Scene 3D : etalon (scale) et mesures (measures)');
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);
  await page.evaluate(() => { const c = document.getElementById('demoEditing'); c.checked = true; c.dispatchEvent(new Event('change')); });
  await sleep(100);
  await clickRow(1);
  await clickRow(12);
  await clickRow(121);
  await page.waitForFunction(() => document.getElementById('threeLoading').hidden && window.ThreeViewer && window.ThreeViewer.isActive(), { timeout: 20000 }).catch(() => {});
  await sleep(250);
  const dbgM0 = await dbg();
  check('scene du jeu d essai : etalon 60,00 m, facade 30,00 m, parking 156,90 m2 en etiquettes (+ N de la fleche nord)', dbgM0.labels.length === 4 && dbgM0.labels.includes('60,00 m') && dbgM0.labels.some((t) => /^Fa\u00e7ade : 30,00 m$/.test(t)) && dbgM0.labels.some((t) => /^Parking : 156,90 m\u00b2$/.test(t)), dbgM0.labels);
  await page.click('#shapeEditLock');
  await sleep(120);
  const scaleStatus = await page.evaluate(() => document.getElementById('sceneScaleStatus').textContent);
  check('panneau : echelle 1 unite = 0,31 m (etalon trace)', /1 unit\u00e9 du mod\u00e8le = 0,31 m/.test(scaleStatus) && /talon/.test(scaleStatus), scaleStatus);
  // Outil Etalon : deux clics, longueur prereemplie selon l echelle en vigueur.
  await page.click('#shapeEditToolbar button[data-tool3d="scale"]');
  await sleep(60);
  await clickGround(-50, 0);
  await clickGround(50, 0);
  await sleep(150);
  let ws3 = await lastWrite('current_plan_scene3d_json');
  const uiSc = await page.evaluate(() => ({ section: !document.getElementById('sceneScaleSection').hidden, length: document.getElementById('sceneScaleLength').value, unit: document.getElementById('sceneScaleUnit').value, orbit: document.querySelector('#shapeEditToolbar button[data-tool3d="orbit"]').classList.contains('active') }));
  check('outil Etalon : segment (-50,0)-(50,0) ecrit, longueur prereemplie 31,32 (facteur conserve), section Etalon, outil Navigation', ws3.scale && near([ws3.scale.x1, ws3.scale.z1], -50, 0) && near([ws3.scale.x2, ws3.scale.z2], 50, 0) && Math.abs(ws3.scale.length - 31.32) < 0.05 && Math.abs(ws3.scale.value - 0.3132) < 0.001 && uiSc.section && uiSc.unit === 'm' && uiSc.orbit, [ws3.scale, uiSc]);
  await page.evaluate(() => { const i = document.getElementById('sceneScaleLength'); i.value = '50'; i.dispatchEvent(new Event('change', { bubbles: true })); });
  await sleep(150);
  ws3 = await lastWrite('current_plan_scene3d_json');
  const dbgM1 = await dbg();
  check('longueur reelle 50 : value 0,5 ecrit ; etiquettes recalculees (etalon 50,00 m, facade 47,90 m, parking 400,00 m2)', Math.abs(ws3.scale.value - 0.5) < 1e-6 && ws3.scale.length === 50 && dbgM1.labels.includes('50,00 m') && dbgM1.labels.some((t) => /47,90 m$/.test(t)) && dbgM1.labels.some((t) => /400,00 m\u00b2$/.test(t)), [ws3.scale, dbgM1.labels]);
  // Outil Distance : 3 points, Entree.
  await page.click('#shapeEditToolbar button[data-tool3d="measure"]');
  await sleep(60);
  await clickGround(0, 80);
  await clickGround(40, 80);
  await clickGround(40, 120);
  await page.keyboard.press('Enter');
  await sleep(150);
  ws3 = await lastWrite('current_plan_scene3d_json');
  const m3 = ws3.measures[ws3.measures.length - 1];
  const uiMe = await page.evaluate(() => ({ section: !document.getElementById('sceneMeasureSection').hidden, info: document.getElementById('sceneMeasureInfo').textContent, labels: window.MyPnPlanViewerV2NS.scene3dRender.debug().labels }));
  check('outil Distance : mesure id 3 (3 points, 80 u = 40,00 m) ecrite, section Mesure', ws3.measures.length === 3 && m3.id === 3 && m3.type === 'distance' && m3.points.length === 3 && /Distance : 40,00 m/.test(uiMe.info) && uiMe.labels.includes('40,00 m'), [m3, uiMe]);
  await page.evaluate(() => { const i = document.getElementById('sceneMeasureLabel'); i.value = 'Allee'; i.dispatchEvent(new Event('change', { bubbles: true })); });
  await sleep(150);
  ws3 = await lastWrite('current_plan_scene3d_json');
  check('libelle de la mesure ecrit et affiche', ws3.measures[2].label === 'Allee' && (await dbg()).labels.includes('Allee : 40,00 m'), ws3.measures[2]);
  // Outil Surface : 4 sommets, Entree.
  await page.click('#shapeEditToolbar button[data-tool3d="area"]');
  await sleep(60);
  await clickGround(-40, 80);
  await clickGround(0, 80);
  await clickGround(0, 120);
  await clickGround(-40, 120);
  await page.keyboard.press('Enter');
  await sleep(150);
  ws3 = await lastWrite('current_plan_scene3d_json');
  const m4 = ws3.measures[ws3.measures.length - 1];
  check('outil Surface : mesure id 4 (aire 1600 u2 = 400,00 m2) ecrite', ws3.measures.length === 4 && m4.id === 4 && m4.type === 'area' && m4.points.length === 4 && (await dbg()).labels.filter((t) => /400,00 m/.test(t)).length === 2, m4);
  // Suppr : la surface selectionnee est retiree.
  await page.keyboard.press('Delete');
  await sleep(150);
  ws3 = await lastWrite('current_plan_scene3d_json');
  check('Suppr : surface retiree (3 mesures)', ws3.measures.length === 3 && !ws3.measures.some((m) => m.id === 4), ws3.measures.map((m) => m.id));
  // Selection d une mesure par clic sur son trace, puis suppression.
  await clickGround(20, 80);
  await sleep(100);
  const uiSel = await page.evaluate(() => ({ section: !document.getElementById('sceneMeasureSection').hidden, info: document.getElementById('sceneMeasureInfo').textContent, handles: window.MyPnPlanViewerV2NS.scene3dRender.debug().handles }));
  check('clic sur le trace d une distance : selectionnee (section Mesure, 3 poignees)', uiSel.section && /Distance/.test(uiSel.info) && uiSel.handles === 3, uiSel);
  await page.click('#shapeDeleteBtn');
  await sleep(150);
  ws3 = await lastWrite('current_plan_scene3d_json');
  check('bouton Supprimer : mesure retiree (2 mesures)', ws3.measures.length === 2, ws3.measures.map((m) => m.id));
  // Selection de l etalon par clic sur son trace, suppression : mesures en unites.
  await clickGround(0, 0);
  await sleep(100);
  const uiEt = await page.evaluate(() => !document.getElementById('sceneScaleSection').hidden);
  check('clic sur l etalon : section Etalon', uiEt, uiEt);
  await page.keyboard.press('Delete');
  await sleep(150);
  ws3 = await lastWrite('current_plan_scene3d_json');
  const dbgM2 = await dbg();
  const scaleStatus2 = await page.evaluate(() => document.getElementById('sceneScaleStatus').textContent);
  check('etalon supprime : scale null, mesures en unites du modele (95,80 u), echelle inconnue', ws3.scale === null && dbgM2.labels.some((t) => /95,80 u$/.test(t)) && /inconnue/.test(scaleStatus2), [ws3.scale, dbgM2.labels, scaleStatus2]);
  await page.screenshot({ path: SHOTS + '/shot-demo-scene3d-mesures.png' });
  // Normalisation : scale sans value ni etalon, mesure de type inconnu.
  await page.evaluate(() => window.PanoDemo.push('current_plan_scene3d_json', JSON.stringify({ node_id: 121, planIndex: 1, scale: { shown: true }, measures: [{ type: 'volume', points: [[0, 0], [1, 1]] }, { type: 'distance', points: [[0, 0], [10, 0]] }] })));
  await sleep(150);
  const st8 = await status();
  const dbgM3 = await dbg();
  check('normalisation : scale sans value ignoree, mesure de type inconnu ignoree (2 avertissements), 1 mesure rendue en unites', /2 avertissement/.test(st8.current_plan_scene3d_json || '') && dbgM3.labels.length === 1 && /10,00 u$/.test(dbgM3.labels[0]), [st8.current_plan_scene3d_json, dbgM3.labels]);
  await page.click('#shapeEditLock');
  await sleep(100);

  /* --- 10sexies. Scene 3D : objets 3D ajoutes (.obj / .glb) --- */
  console.log('\n10sexies. Scene 3D : objets ajoutes (objects, editModels, .obj et .glb)');
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);
  await page.evaluate(() => { const c = document.getElementById('demoEditing'); c.checked = true; c.dispatchEvent(new Event('change')); });
  await sleep(100);
  await clickRow(1);
  await clickRow(12);
  await clickRow(121);
  await page.waitForFunction(() => document.getElementById('threeLoading').hidden && window.ThreeViewer && window.ThreeViewer.isActive(), { timeout: 20000 }).catch(() => {});
  await page.waitForFunction(() => { const d = window.MyPnPlanViewerV2NS.scene3dRender.debug(); return d.objects[0] && d.objects[0].loaded; }, { timeout: 8000 }).catch(() => {});
  const dbgO0 = await dbg();
  const cuve = dbgO0.objects[0];
  check('objet du jeu d essai (cuve.obj, 6 m) charge en file:// et ramene a l echelle : facteur 9,58 (= 6 / 0,3132 / 2), position (130, 30), couleur', cuve && cuve.loaded && cuve.meshes === 1 && Math.abs(cuve.scale - 9.579) < 0.05 && cuve.x === 130 && cuve.z === 30 && /^#0ea[45]e[89]$/.test(cuve.color || ''), cuve);
  await page.click('#shapeEditLock');
  await sleep(120);
  // Outil Objet : galerie dans le panneau, choix du cube glTF, pose au clic.
  await page.click('#shapeEditToolbar button[data-tool3d="object"]');
  await sleep(80);
  const uiPick = await page.evaluate(() => ({ pick: !document.getElementById('sceneModelPick').hidden, n: document.querySelectorAll('#sceneModelPickGallery button').length, sel: (document.querySelector('#sceneModelPickGallery button.selected') || {}).textContent }));
  check('outil Objet : galerie editModels (4 objets), premier objet preselectionne', uiPick.pick && uiPick.n === 4 && /Local technique/.test(uiPick.sel || ''), uiPick);
  await page.click('#sceneModelPickGallery button:nth-child(4)');
  await sleep(60);
  await clickGround(60, 90);
  await page.waitForFunction(() => { const d = window.MyPnPlanViewerV2NS.scene3dRender.debug(); return d.objects[1] && d.objects[1].loaded; }, { timeout: 8000 }).catch(() => {});
  let ws4 = await lastWrite('current_plan_scene3d_json');
  const o2 = ws4.objects[ws4.objects.length - 1];
  const dbgO1 = await dbg();
  const uiObj = await page.evaluate(() => ({ section: !document.getElementById('sceneObjectSection').hidden, handles: window.MyPnPlanViewerV2NS.scene3dRender.debug().handles, label: document.getElementById('sceneObjectLabel').value, size: document.getElementById('sceneObjectSize').value }));
  check('cube.glb pose au clic : objet id 2 ecrit (fichier, taille 3, position ~ (60, 90)), charge par GLTFLoader (base64 en file://), section Objet, 2 poignees', ws4.objects.length === 2 && o2.id === 2 && /cube\.glb$/.test(o2.filename) && o2.size === 3 && Math.abs(o2.x - 60) < 2 && Math.abs(o2.z - 90) < 2 && o2.color === null && dbgO1.objects[1].loaded && dbgO1.objects[1].meshes >= 1 && uiObj.section && uiObj.handles === 2 && uiObj.label === 'Cube glTF' && uiObj.size === '3', [o2, dbgO1.objects[1], uiObj]);
  check('materiaux du fichier glTF conserves (bleu du .glb)', /^#[0-9a-f]{6}$/.test(dbgO1.objects[1].color || '') && dbgO1.objects[1].color !== '#64748b', dbgO1.objects[1].color);
  // Panneau : rotation, facteur, couleur.
  await page.evaluate(() => { const i = document.getElementById('sceneObjectRotation'); i.value = '45'; i.dispatchEvent(new Event('change', { bubbles: true })); });
  await page.evaluate(() => { const i = document.getElementById('sceneObjectScale'); i.value = '2'; i.dispatchEvent(new Event('change', { bubbles: true })); });
  await sleep(150);
  ws4 = await lastWrite('current_plan_scene3d_json');
  const dbgO2 = await dbg();
  check('rotation 45 et facteur 2 ecrits et rendus (facteur 3 / 0,3132 x 2 = 19,16 sur un cube unite)', ws4.objects[1].rotation === 45 && ws4.objects[1].scale === 2 && Math.abs(dbgO2.objects[1].rotY + Math.PI / 4) < 1e-6 && Math.abs(dbgO2.objects[1].scale - 19.16) < 0.1, [ws4.objects[1], dbgO2.objects[1]]);
  await page.evaluate(() => { const c = document.getElementById('sceneObjectColorNone'); c.checked = false; c.dispatchEvent(new Event('change', { bubbles: true })); });
  await page.evaluate(() => { const i = document.getElementById('sceneObjectColor'); i.value = '#ff0000'; i.dispatchEvent(new Event('input', { bubbles: true })); i.dispatchEvent(new Event('change', { bubbles: true })); });
  await sleep(150);
  ws4 = await lastWrite('current_plan_scene3d_json');
  const dbgO3 = await dbg();
  check('couleur #ff0000 ecrite et appliquee au glTF', ws4.objects[1].color === '#ff0000' && dbgO3.objects[1].color === '#ff0000', [ws4.objects[1].color, dbgO3.objects[1].color]);
  // Poignee de taille : glisser vers l exterieur double le facteur.
  const hpts = await page.evaluate(() => { const NS2 = window.MyPnPlanViewerV2NS; const o = NS2.scene3d.scene.objects[1]; const R = NS2.scene3dRender; const hp = R.objectHandlePoints(o); const y = R.groundY(); return { s: R.project(hp.scale[0], y, hp.scale[1]), s2: R.project(o.x + (hp.scale[0] - o.x) * 2, y, o.z + (hp.scale[1] - o.z) * 2) }; });
  await page.mouse.move(hpts.s.x, hpts.s.y);
  await page.mouse.down();
  await page.mouse.move((hpts.s.x + hpts.s2.x) / 2, (hpts.s.y + hpts.s2.y) / 2, { steps: 3 });
  await page.mouse.move(hpts.s2.x, hpts.s2.y, { steps: 3 });
  await page.mouse.up();
  await sleep(150);
  ws4 = await lastWrite('current_plan_scene3d_json');
  check('poignee verte glissee au double de son rayon : facteur ~ 4', Math.abs(ws4.objects[1].scale - 4) < 0.3, ws4.objects[1].scale);
  // Selection de la cuve par clic sur son corps, suppression.
  await page.keyboard.press('Escape');
  await sleep(60);
  // La cuve (x = 130) est hors champ de la vue enregistree : recul de la camera.
  for (let k = 0; k < 3; k++) { await page.click('#zoomOutBtn'); await sleep(40); }
  const pc = await page.evaluate(() => { const R = window.MyPnPlanViewerV2NS.scene3dRender; return R.project(130, R.groundY() + 6, 30); });
  await page.mouse.click(pc.x, pc.y);
  await sleep(120);
  const uiCuve = await page.evaluate(() => ({ section: !document.getElementById('sceneObjectSection').hidden, label: document.getElementById('sceneObjectLabel').value, info: document.getElementById('sceneObjectInfo').textContent }));
  check('clic sur la cuve : selectionnee (libelle Cuve, taille 6,00 m = 19,16 unites)', uiCuve.section && uiCuve.label === 'Cuve' && /6,00 m/.test(uiCuve.info) && /19,16/.test(uiCuve.info), uiCuve);
  await page.keyboard.press('Delete');
  await sleep(150);
  ws4 = await lastWrite('current_plan_scene3d_json');
  check('Suppr : cuve retiree, le cube glTF reste', ws4.objects.length === 1 && ws4.objects[0].id === 2, ws4.objects.map((o) => o.id));
  await page.screenshot({ path: SHOTS + '/shot-demo-scene3d-objets.png' });
  // Normalisation : objet sans fichier ignore, id manquant attribue.
  await page.evaluate(() => window.PanoDemo.push('current_plan_scene3d_json', JSON.stringify({ node_id: 121, planIndex: 1, objects: [{ x: 1 }, { filename: 'Images/models/borne.obj', x: 10, z: 10, size: 1.2, scale: 200 }] })));
  await page.waitForFunction(() => { const d = window.MyPnPlanViewerV2NS.scene3dRender.debug(); return d.objects[0] && d.objects[0].loaded; }, { timeout: 8000 }).catch(() => {});
  const st9 = await status();
  const sc9 = await page.evaluate(() => window.MyPnPlanViewerV2NS.scene3d.scene.objects.map((o) => ({ id: o.id, scale: o.scale, color: o.color })));
  check('normalisation : objet sans fichier ignore (1 avertissement), id 1 attribue, facteur borne a 100, couleur null', /1 avertissement/.test(st9.current_plan_scene3d_json || '') && sc9.length === 1 && sc9[0].id === 1 && sc9[0].scale === 100 && sc9[0].color === null, [st9.current_plan_scene3d_json, sc9]);
  await page.click('#shapeEditLock');
  await sleep(100);
  const dbgO4 = await dbg();
  check('cadenas ferme : objet toujours rendu (borne.obj), aucune poignee', dbgO4.objects[0] && dbgO4.objects[0].loaded && dbgO4.handles === 0, dbgO4.objects);

  /* --- 10septies. Scene 3D : zones (survol, carte, clic, alarme, groupes) --- */
  console.log('\n10septies. Scene 3D : zones (zones, survol, detail, alarme, groupe du modele)');
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);
  await page.evaluate(() => { const c = document.getElementById('demoEditing'); c.checked = true; c.dispatchEvent(new Event('change')); });
  await sleep(100);
  await clickRow(1);
  await clickRow(12);
  await clickRow(121);
  await page.waitForFunction(() => document.getElementById('threeLoading').hidden && window.ThreeViewer && window.ThreeViewer.isActive(), { timeout: 20000 }).catch(() => {});
  await sleep(300);
  const dz0 = (await dbg()).zones;
  check('zones du jeu d essai : prisme \u00ab Aile Ouest \u00bb en alarme (capteur 1001) qui clignote, zone liee au groupe RB-SP-MD-011', dz0.length === 2 && dz0[0].prism && dz0[0].alarm && dz0[0].opacity > 0 && dz0[1].groupBound && dz0[1].group === 'RB-SP-MD-011', dz0);
  // Survol du prisme (cadenas ferme) : surbrillance + carte.
  const pz = await page.evaluate(() => { const R = window.MyPnPlanViewerV2NS.scene3dRender; return R.project(-68, R.groundY() + 25, -50); });
  await page.mouse.move(pz.x, pz.y);
  await sleep(120);
  const hov = await page.evaluate(() => ({ hover: window.MyPnPlanViewerV2NS.scene3dZones.hover, card: !document.getElementById('zoneCard').hidden, text: document.getElementById('zoneCard').textContent, cursor: document.getElementById('threeViewport').classList.contains('zone-hover') }));
  check('survol de la zone : surbrillance, carte (libelle, description, capteur en alarme), curseur', hov.hover === 0 && hov.card && /Aile Ouest/.test(hov.text) && /Bureaux R\+2/.test(hov.text) && /1 capteur en alarme/.test(hov.text) && hov.cursor, hov);
  // Clic : eventsDetailRequest_json source zone.
  await page.mouse.click(pz.x, pz.y);
  await sleep(150);
  const evz = await lastWrite('eventsDetailRequest_json');
  check('clic sur la zone (cadenas ferme) : eventsDetailRequest_json { source zone, zone_id 1, node_id 121, planIndex 1, label, elements, serial }', evz && evz.source === 'zone' && evz.zone_id === 1 && evz.node_id === 121 && evz.planIndex === 1 && evz.label === 'Aile Ouest' && evz.elements.join() === '1001' && evz.serial > 0, evz);
  // Survol de la zone liee au groupe : le maillage du batiment est colore.
  const pg = await page.evaluate(() => { const R = window.MyPnPlanViewerV2NS.scene3dRender; return R.project(60, R.groundY() + 25, -49.5); });
  await page.mouse.move(pg.x, pg.y);
  await sleep(120);
  const hov2 = await page.evaluate(() => ({ hover: window.MyPnPlanViewerV2NS.scene3dZones.hover, text: document.getElementById('zoneCard').textContent, zones: window.MyPnPlanViewerV2NS.scene3dRender.debug().zones }));
  check('survol du batiment hors prisme : zone liee au groupe survolee (maillage du modele colore), carte \u00ab Batiment entier \u00bb', hov2.hover === 1 && /B\u00e2timent entier/.test(hov2.text) && hov2.zones[1].highlighted, hov2);
  await page.mouse.move(5, 5);
  await sleep(100);
  const hov3 = await page.evaluate(() => ({ hover: window.MyPnPlanViewerV2NS.scene3dZones.hover, card: document.getElementById('zoneCard').hidden, zones: window.MyPnPlanViewerV2NS.scene3dRender.debug().zones }));
  check('pointeur sorti : plus de survol, carte masquee, materiau du modele restaure', hov3.hover === -1 && hov3.card && !hov3.zones[1].highlighted, hov3);
  // Alarmes retirees : la zone cesse de clignoter (a chaud).
  await page.evaluate(() => window.PanoDemo.push('configuration_events_json', ''));
  await sleep(200);
  const dz1 = (await dbg()).zones;
  check('plus d alarme : la zone n est plus en alarme, invisible (opacite 0)', !dz1[0].alarm && dz1[0].opacity === 0, dz1[0]);
  // Zone hors alarme (invisible) : le survol doit quand meme la trouver.
  await page.mouse.move(pz.x, pz.y);
  await sleep(120);
  const hov4 = await page.evaluate(() => ({ hover: window.MyPnPlanViewerV2NS.scene3dZones.hover, card: !document.getElementById('zoneCard').hidden, text: document.getElementById('zoneCard').textContent, zones: window.MyPnPlanViewerV2NS.scene3dRender.debug().zones }));
  check('zone hors alarme : le survol la colore (prisme invisible mais selectionnable) et affiche sa carte sans mention d alarme', hov4.hover === 0 && hov4.card && /Aile Ouest/.test(hov4.text) && !/alarme/.test(hov4.text) && hov4.zones[0].opacity > 0, hov4);
  await page.mouse.move(5, 5);
  await sleep(100);
  const hov5 = (await dbg()).zones[0];
  check('pointeur sorti : la zone hors alarme redevient invisible', hov5.opacity === 0 && !hov5.visible, hov5);
  await page.evaluate(() => window.PanoDemo.push('configuration_events_json', JSON.stringify({ events: [{ id: 7001, element_id: 1001, node_id: 11, priority: 1, color: 'red', count: 1 }] })));
  await sleep(200);
  const dz2 = (await dbg()).zones;
  check('alarme revenue : zone en alarme a nouveau', dz2[0].alarm && dz2[0].opacity > 0, dz2[0]);
  // Edition : prismes fantomes, outil Zone, panneau.
  await page.click('#shapeEditLock');
  await sleep(120);
  const dz3 = (await dbg()).zones;
  check('cadenas ouvert : prisme visible en fantome', dz3[0].visible, dz3);
  await page.click('#shapeEditToolbar button[data-tool3d="zone"]');
  await sleep(60);
  await clickGround(-30, 80);
  await clickGround(10, 80);
  await clickGround(10, 120);
  await clickGround(-30, 120);
  await page.keyboard.press('Enter');
  await sleep(150);
  let ws5 = await lastWrite('current_plan_scene3d_json');
  const z3 = ws5.zones[ws5.zones.length - 1];
  const uiZ = await page.evaluate(() => ({ section: !document.getElementById('sceneZoneSection').hidden, label: document.getElementById('sceneZoneLabel').value, groups: Array.from(document.querySelectorAll('#sceneZoneGroup option')).map((o) => o.value), handles: window.MyPnPlanViewerV2NS.scene3dRender.debug().handles }));
  check('outil Zone : zone id 3 ecrite (4 sommets, hauteur par defaut 25,2 = moitie du modele, libelle Zone 3), section Zone, groupes du modele listes, 4 poignees', ws5.zones.length === 3 && z3.id === 3 && z3.points.length === 4 && Math.abs(z3.height - 25.2) < 0.01 && z3.label === 'Zone 3' && z3.show_mode === 'always_without_animation' && uiZ.section && uiZ.label === 'Zone 3' && uiZ.groups.join() === ',RB-SP-MD-011' && uiZ.handles === 4, [z3, uiZ]);
  await page.evaluate(() => { const i = document.getElementById('sceneZoneLabel'); i.value = 'Zone test'; i.dispatchEvent(new Event('change', { bubbles: true })); });
  await page.evaluate(() => { const i = document.getElementById('sceneZoneHeight'); i.value = '20'; i.dispatchEvent(new Event('change', { bubbles: true })); });
  await page.evaluate(() => { const i = document.getElementById('sceneZoneElements'); i.value = '1001, 1002'; i.dispatchEvent(new Event('change', { bubbles: true })); });
  await page.evaluate(() => { const s = document.getElementById('sceneZoneShowMode'); s.value = 'always_with_animation'; s.dispatchEvent(new Event('change', { bubbles: true })); });
  await sleep(150);
  ws5 = await lastWrite('current_plan_scene3d_json');
  const dz4 = (await dbg()).zones;
  check('panneau Zone : libelle, hauteur 20, capteurs [1001, 1002], regle clignotante ecrits ; la zone (1001 en alarme) clignote', ws5.zones[2].label === 'Zone test' && ws5.zones[2].height === 20 && ws5.zones[2].elements.join() === '1001,1002' && ws5.zones[2].show_mode === 'always_with_animation' && dz4[2].alarm, [ws5.zones[2], dz4[2]]);
  await page.evaluate(() => { const s = document.getElementById('sceneZoneGroup'); s.value = 'RB-SP-MD-011'; s.dispatchEvent(new Event('change', { bubbles: true })); });
  await sleep(150);
  ws5 = await lastWrite('current_plan_scene3d_json');
  check('liaison au groupe du modele ecrite (plus de prisme)', ws5.zones[2].group === 'RB-SP-MD-011' && !(await dbg()).zones[2].prism, ws5.zones[2].group);
  await page.keyboard.press('Delete');
  await sleep(150);
  ws5 = await lastWrite('current_plan_scene3d_json');
  check('Suppr : zone retiree (2 zones)', ws5.zones.length === 2, ws5.zones.map((z) => z.id));
  await page.screenshot({ path: SHOTS + '/shot-demo-scene3d-zones.png' });
  // Normalisation : zone sans groupe ni 3 sommets ignoree.
  await page.evaluate(() => window.PanoDemo.push('current_plan_scene3d_json', JSON.stringify({ node_id: 121, planIndex: 1, zones: [{ points: [[0, 0], [1, 1]] }, { label: 'Ok', points: [[0, 0], [10, 0], [10, 10]] }] })));
  await sleep(150);
  const st10 = await status();
  const sz10 = await page.evaluate(() => window.MyPnPlanViewerV2NS.scene3d.scene.zones.map((z) => ({ id: z.id, label: z.label, height: z.height, color: z.color })));
  check('normalisation : zone a 2 sommets ignoree (1 avertissement), valeurs par defaut (id 1, hauteur 10, couleur ambre)', /1 avertissement/.test(st10.current_plan_scene3d_json || '') && sz10.length === 1 && sz10[0].id === 1 && sz10[0].height === 10 && sz10[0].color === '#f59e0b', [st10.current_plan_scene3d_json, sz10]);
  await page.click('#shapeEditLock');
  await sleep(100);

  /* --- 10octies. Repere d'orientation : bouton, cadran, cle north, fleche au sol --- */
  console.log('\n10octies. Repere d orientation (orientationHelper, cadran cliquable, cle north, fleche nord au sol)');
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);
  await page.evaluate(() => { const c = document.getElementById('demoEditing'); c.checked = true; c.dispatchEvent(new Event('change')); });
  await sleep(100);
  await clickRow(1);
  await clickRow(11);
  await sleep(150);
  const hb2d = await page.evaluate(() => ({ btn: document.getElementById('helperBtn').hidden, svg: document.getElementById('threeHelper').hasAttribute('hidden') }));
  check('plan 2D : bouton et cadran du repere masques', hb2d.btn && hb2d.svg, hb2d);
  await clickRow(12);
  await clickRow(121);
  await page.waitForFunction(() => document.getElementById('threeLoading').hidden && window.ThreeViewer && window.ThreeViewer.isActive(), { timeout: 20000 }).catch(() => {});
  await sleep(300);
  const hb = await page.evaluate(() => ({
    btn: !document.getElementById('helperBtn').hidden, pressed: document.getElementById('helperBtn').getAttribute('aria-pressed'),
    svg: !document.getElementById('threeHelper').hasAttribute('hidden'),
    dirs: Array.from(document.querySelectorAll('#threeHelper .helper-item[data-snap]')).map((g) => g.dataset.snap).sort().join(','),
    north: window.MyPnPlanViewerV2NS.northAngle(),
  }));
  check('modele 3D : bouton visible et enfonce (orientationHelper shown par defaut), cadran avec X/Y/Z et N/E/S/O, nord 30 du jeu d essai', hb.btn && hb.pressed === 'true' && hb.svg && hb.dirs === 'e,n,s,top,w,x,z' && hb.north === 30, hb);
  const dbgN = await dbg();
  check('fleche nord au sol cadenas ferme : etiquette N, position par defaut au nord-est du modele', dbgN.labels.includes('N') && dbgN.north && dbgN.north.angle === 30 && dbgN.north.pos[0] > 95 && dbgN.north.pos[1] < -49, dbgN.north);
  await page.evaluate(() => { window.MyPnPlanViewerV2NS.helperAnimationMs = 0; });
  // Clic sur une direction du cadran (puppeteer ne calcule pas de point cliquable sur un <g> SVG).
  const clickHelper = async (name) => { const p = await page.evaluate((n) => { const r = document.querySelector('#threeHelper .helper-item[data-snap="' + n + '"] circle').getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; }, name); await page.mouse.click(p.x, p.y); };
  await clickHelper('n');
  await sleep(150);
  const camN = await page.evaluate(() => window.ThreeViewer.getCameraState());
  const offN = camN ? [camN.position[0] - camN.target[0], camN.position[2] - camN.target[2]] : null;
  check('clic sur N : camera au sud de la cible (x < 0, z > 0, rapport tan 30), regard vers le nord', offN && offN[0] < 0 && offN[1] > 0 && Math.abs(Math.abs(offN[0] / offN[1]) - Math.tan(30 * Math.PI / 180)) < 0.02, offN);
  await clickHelper('top');
  await sleep(150);
  const camT = await page.evaluate(() => window.ThreeViewer.getCameraState());
  const distT = camT ? Math.hypot(camT.position[0] - camT.target[0], camT.position[1] - camT.target[1], camT.position[2] - camT.target[2]) : 0;
  check('clic sur Y : vue de dessus (camera a la verticale de la cible, distance conservee)', camT && camT.position[1] - camT.target[1] > 0.99 * distT && distT > 1, camT);
  await page.click('#helperBtn');
  await sleep(60);
  const hOff = await page.evaluate(() => ({ svg: document.getElementById('threeHelper').hasAttribute('hidden'), pressed: document.getElementById('helperBtn').getAttribute('aria-pressed') }));
  check('bouton : repere masque, aria-pressed false', hOff.svg && hOff.pressed === 'false', hOff);
  await page.click('#helperBtn');
  await sleep(60);
  check('bouton : repere affiche a nouveau', await page.evaluate(() => !document.getElementById('threeHelper').hasAttribute('hidden')));
  // Edition : champ Nord du panneau, angle modifie, ecriture de la cle north.
  await page.click('#shapeEditLock');
  await sleep(120);
  const nf = await page.evaluate(() => ({ angle: document.getElementById('sceneNorthAngle').value, shown: document.getElementById('sceneNorthShown').checked }));
  check('cadenas ouvert : champ Nord 30, fleche au sol cochee', nf.angle === '30' && nf.shown, nf);
  await page.evaluate(() => { const i = document.getElementById('sceneNorthAngle'); i.value = '90'; i.dispatchEvent(new Event('change')); });
  await sleep(150);
  let wsN = await lastWrite('current_plan_scene3d_json');
  check('angle 90 saisi : north { angle 90, shown true, x/z null } ecrit', wsN && wsN.north && wsN.north.angle === 90 && wsN.north.shown === true && wsN.north.x === null && wsN.north.z === null, wsN && wsN.north);
  // Selection de la fleche par clic sur son corps, en vue de dessus (en perspective, le rayon
  // traverserait le prisme de la zone 1 ; le cadenas a reapplique la vue par defaut).
  await clickHelper('top');
  await sleep(150);
  // Recul de deux crans : la fleche (nord-est) sort de sous le panneau Scene 3D.
  await page.click('#zoomOutBtn');
  await page.click('#zoomOutBtn');
  await sleep(100);
  const npos = await page.evaluate(() => { const NS = window.MyPnPlanViewerV2NS; return NS.scene3dRender.northPosition(NS.scene3d.scene.north); });
  await clickGround(npos[0], npos[1]);
  await sleep(120);
  const selN = await page.evaluate(() => ({ sel: window.MyPnPlanViewerV2NS.scene3d.selected, section: !document.getElementById('sceneNorthSection').hidden, handles: window.MyPnPlanViewerV2NS.scene3dRender.debug().handles, x: document.getElementById('sceneNorthX').value }));
  check('clic sur la fleche : selectionnee, section Fleche nord (X = position par defaut), poignee de rotation', selN.sel === 'north' && selN.section && selN.handles === 1 && Math.abs(Number(selN.x) - npos[0]) < 0.01, selN);
  // Poignee ambre glissee vers le sud (z croissant) : angle 180.
  const hpN = await page.evaluate(() => { const r = window.MyPnPlanViewerV2NS.scene3dRender; const p = r.handles[0].position; return r.project(p.x, p.y, p.z); });
  const tgtN = await gp(npos[0], npos[1] + 40);
  await page.mouse.move(hpN.x, hpN.y);
  await page.mouse.down();
  await page.mouse.move(hpN.x + 4, hpN.y + 4);
  await page.mouse.move(tgtN.x, tgtN.y, { steps: 4 });
  await page.mouse.up();
  await sleep(150);
  wsN = await lastWrite('current_plan_scene3d_json');
  check('poignee de rotation glissee vers le sud : angle 180 ecrit, rose des vents suit', wsN && wsN.north && wsN.north.angle === 180, wsN && wsN.north);
  // Position par le panneau : x fixe, z = position par defaut materialisee.
  await page.evaluate(() => { const i = document.getElementById('sceneNorthX'); i.value = '-50'; i.dispatchEvent(new Event('change')); });
  await sleep(150);
  wsN = await lastWrite('current_plan_scene3d_json');
  check('centre X saisi : north.x -50 et north.z (position par defaut) ecrits', wsN && wsN.north && wsN.north.x === -50 && Math.abs(wsN.north.z - npos[1]) < 0.01, wsN && wsN.north);
  // Suppr : nord inconnu, rose des vents retiree, etiquette N disparue.
  await page.keyboard.press('Delete');
  await sleep(150);
  wsN = await lastWrite('current_plan_scene3d_json');
  const hbDel = await page.evaluate(() => ({
    dirs: Array.from(document.querySelectorAll('#threeHelper .helper-item[data-snap]')).map((g) => g.dataset.snap).sort().join(','),
    labels: window.MyPnPlanViewerV2NS.scene3dRender.debug().labels,
    angle: document.getElementById('sceneNorthAngle').value, shownDisabled: document.getElementById('sceneNorthShown').disabled,
  }));
  check('Suppr sur la fleche : north null ecrit, cadran sans rose des vents, etiquette N retiree, champ Nord vide et case inactive', wsN && wsN.north === null && hbDel.dirs === 'top,x,z' && !hbDel.labels.includes('N') && hbDel.angle === '' && hbDel.shownDisabled, [wsN && wsN.north, hbDel]);
  // Lecture : nord recu de l application (nombre seul accepte).
  await page.evaluate(() => window.PanoDemo.push('current_plan_scene3d_json', JSON.stringify({ node_id: 121, planIndex: 1, north: 45 })));
  await sleep(150);
  const hbIn = await page.evaluate(() => ({ north: window.MyPnPlanViewerV2NS.northAngle(), n: document.querySelectorAll('#threeHelper .helper-item[data-snap="n"]').length, labels: window.MyPnPlanViewerV2NS.scene3dRender.debug().labels }));
  check('scene recue avec north 45 (nombre seul) : rose des vents et fleche au sol', hbIn.north === 45 && hbIn.n === 1 && hbIn.labels.includes('N'), hbIn);
  await page.evaluate(() => window.PanoDemo.push('current_plan_scene3d_json', JSON.stringify({ node_id: 121, planIndex: 1, north: { shown: true } })));
  await sleep(150);
  const stN = await status();
  check('north sans angle : avertissement, nord inconnu', /avertissement/.test(stN.current_plan_scene3d_json || '') && (await page.evaluate(() => window.MyPnPlanViewerV2NS.northAngle())) === null, stN.current_plan_scene3d_json);
  await page.click('#shapeEditLock');
  await sleep(100);
  // Configuration orientationHelper "none" : ni bouton ni cadran ; "hidden" : bouton seul.
  const cfgHelper = (mode) => page.evaluate((m) => {
    const cfg = JSON.parse(document.getElementById('demoEditor').value);
    cfg.orientationHelper = m;
    window.PanoDemo.push('configuration_plan_json', JSON.stringify(cfg));
  }, mode);
  await cfgHelper('none');
  await sleep(150);
  await clickRow(1);
  await clickRow(12);
  await clickRow(121);
  await sleep(300);
  const hbNone = await page.evaluate(() => ({ btn: document.getElementById('helperBtn').hidden, svg: document.getElementById('threeHelper').hasAttribute('hidden'), mode: window.MyPnPlanViewerV2NS.state.currentConfig.orientationHelper }));
  check('orientationHelper "none" : ni bouton ni cadran', hbNone.btn && hbNone.svg && hbNone.mode === 'none', hbNone);
  await cfgHelper('hidden');
  await sleep(150);
  await clickRow(1);
  await clickRow(12);
  await clickRow(121);
  await sleep(300);
  const hbHid = await page.evaluate(() => ({ btn: !document.getElementById('helperBtn').hidden, pressed: document.getElementById('helperBtn').getAttribute('aria-pressed'), svg: document.getElementById('threeHelper').hasAttribute('hidden') }));
  check('orientationHelper "hidden" : bouton visible non enfonce, cadran masque', hbHid.btn && hbHid.pressed === 'false' && hbHid.svg, hbHid);
  await cfgHelper('bizarre');
  await sleep(150);
  const stCfg = await status();
  const cfgW = await page.evaluate(() => ({ mode: window.MyPnPlanViewerV2NS.state.currentConfig.orientationHelper, warnings: window.MyPnPlanViewerV2NS.state.currentConfig.warnings || [] }));
  check('orientationHelper inconnue : avertissement, valeur shown', cfgW.mode === 'shown' && cfgW.warnings.some((w) => /orientationHelper/.test(w)) && /avertissement/.test(stCfg.configuration_plan_json || ''), [cfgW, stCfg.configuration_plan_json]);
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);
  await clickRow(1);
  await clickRow(12);
  await clickRow(121);
  await page.waitForFunction(() => document.getElementById('threeLoading').hidden && window.ThreeViewer && window.ThreeViewer.isActive(), { timeout: 20000 }).catch(() => {});
  await sleep(300);
  await page.screenshot({ path: SHOTS + '/shot-demo-scene3d-repere.png' });

  /* --- 10nonies. Vue en plan : bouton, menu, camera orthographique, puce, retour 3D --- */
  console.log('\n10nonies. Vue en plan (showPlanViewButton, menu, camera orthographique nord en haut, zoom, deplacement, retour 3D)');
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);
  await page.evaluate(() => { const c = document.getElementById('demoEditing'); c.checked = true; c.dispatchEvent(new Event('change')); });
  await sleep(100);
  await clickRow(1);
  await clickRow(11);
  await sleep(150);
  const pv2d = await page.evaluate(() => ({ btn: document.getElementById('planViewBtn').hidden, chip: document.getElementById('planModeChip').hidden }));
  check('plan 2D : bouton Vue en plan et puce masques', pv2d.btn && pv2d.chip, pv2d);
  await clickRow(12);
  await clickRow(121);
  await page.waitForFunction(() => document.getElementById('threeLoading').hidden && window.ThreeViewer && window.ThreeViewer.isActive(), { timeout: 20000 }).catch(() => {});
  await sleep(300);
  await page.evaluate(() => { window.ThreeViewer.setAnimationMs(0); window.MyPnPlanViewerV2NS.helperAnimationMs = 0; });
  const pv0 = await page.evaluate(() => ({ btn: !document.getElementById('planViewBtn').hidden, chip: !document.getElementById('planModeChip').hidden, on3d: document.getElementById('planModeChip3d').classList.contains('on'), plan: window.ThreeViewer.isPlanView() }));
  check('modele 3D : bouton visible, puce \u00ab 3D \u00bb', pv0.btn && pv0.chip && pv0.on3d && !pv0.plan, pv0);
  await page.click('#planViewBtn');
  await sleep(80);
  const pvMenu = await page.evaluate(() => ({ open: !document.getElementById('planViewMenu').hidden, label: document.getElementById('planViewToggleLabel').textContent, png: document.getElementById('planViewPng').disabled, svg: document.getElementById('planViewSvg').disabled, hint: document.getElementById('planViewHint').textContent }));
  check('menu ouvert : \u00ab Afficher la vue en plan \u00bb, nord 30 dans l indication', pvMenu.open && /Afficher la vue en plan/.test(pvMenu.label) && /30,00/.test(pvMenu.hint), pvMenu);
  await page.click('#planViewToggle');
  await sleep(200);
  const pv1 = await page.evaluate(() => { const c = window.ThreeViewer.getContext(); const up = c.camera.up.toArray(); const cs = window.ThreeViewer.getCameraState(); return { plan: window.ThreeViewer.isPlanView(), ortho: !!c.camera.isOrthographicCamera, up, above: Math.abs(cs.position[0] - cs.target[0]) < 0.01 && Math.abs(cs.position[2] - cs.target[2]) < 0.01 && cs.position[1] > cs.target[1], chipPlan: document.getElementById('planModeChipPlan').classList.contains('on'), zoom: document.getElementById('zoomLevel').textContent, rotate: c.controls.enableRotate, label: document.getElementById('planViewToggleLabel').textContent, menuClosed: document.getElementById('planViewMenu').hidden, cls: document.getElementById('threeViewport').classList.contains('plan-view') }; });
  check('bascule : camera orthographique a la verticale de la cible, haut = nord 30 (sin 30, 0, -cos 30), rotation desactivee, puce \u00ab Vue en plan \u00bb, 100 %, menu ferme', pv1.plan && pv1.ortho && Math.abs(pv1.up[0] - 0.5) < 0.01 && Math.abs(pv1.up[2] + 0.866) < 0.01 && pv1.above && pv1.chipPlan && pv1.zoom === '100%' && !pv1.rotate && /Revenir/.test(pv1.label) && pv1.menuClosed && pv1.cls, pv1);
  await page.click('#zoomInBtn');
  await sleep(80);
  const pvZoom = await page.evaluate(() => ({ lvl: document.getElementById('zoomLevel').textContent, z: window.ThreeViewer.getContext().camera.zoom }));
  check('zoom + en vue en plan : zoom orthographique 1,3 (130 %)', pvZoom.lvl === '130%' && Math.abs(pvZoom.z - 1.3) < 0.01, pvZoom);
  await page.click('#zoomOutBtn');
  await page.click('#zoomOutBtn');
  await page.click('#zoomOutBtn');
  await sleep(80);
  // Cadenas ouvert en vue en plan : la vue de dessus est conservee ; selection par rayon orthographique.
  await page.click('#shapeEditLock');
  await sleep(150);
  const pvLock = await page.evaluate(() => ({ plan: window.ThreeViewer.isPlanView(), panel: !document.getElementById('scenePanel').hidden, ortho: !!window.ThreeViewer.getContext().camera.isOrthographicCamera }));
  check('cadenas ouvert en vue en plan : vue en plan conservee, panneau Scene 3D', pvLock.plan && pvLock.panel && pvLock.ortho, pvLock);
  const nposP = await page.evaluate(() => { const NS = window.MyPnPlanViewerV2NS; return NS.scene3dRender.northPosition(NS.scene3d.scene.north); });
  await clickGround(nposP[0], nposP[1]);
  await sleep(150);
  const pvSel = await page.evaluate(() => ({ sel: window.MyPnPlanViewerV2NS.scene3d.selected, handles: window.MyPnPlanViewerV2NS.scene3dRender.debug().handles }));
  check('clic sur la fleche nord en vue en plan : selection par lancer de rayon orthographique, poignee', pvSel.sel === 'north' && pvSel.handles === 1, pvSel);
  await page.keyboard.press('Escape');
  await sleep(80);
  // Deplacement au bouton gauche : la cible bouge, la camera reste a la verticale.
  const vpc = await page.evaluate(() => { const r = document.getElementById('threeViewport').getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; });
  await page.mouse.move(vpc.x, vpc.y);
  await page.mouse.down();
  await page.mouse.move(vpc.x + 60, vpc.y + 40, { steps: 5 });
  await page.mouse.up();
  await sleep(120);
  const pvPan = await page.evaluate(() => { const cs = window.ThreeViewer.getCameraState(); return { t: cs.target, above: Math.abs(cs.position[0] - cs.target[0]) < 0.01 && Math.abs(cs.position[2] - cs.target[2]) < 0.01, plan: window.ThreeViewer.isPlanView() }; });
  check('glisser au bouton gauche : deplacement (cible deplacee), camera toujours a la verticale, vue en plan conservee', pvPan.plan && pvPan.above && (Math.abs(pvPan.t[0]) > 0.5 || Math.abs(pvPan.t[2]) > 0.5), pvPan);
  // Repere de coin : N ramene a la 3D, oriente vers le nord.
  await clickHelper('n');
  await sleep(200);
  const pvN = await page.evaluate(() => { const cs = window.ThreeViewer.getCameraState(); const c = window.ThreeViewer.getContext(); return { plan: window.ThreeViewer.isPlanView(), persp: !!c.camera.isPerspectiveCamera, off: [cs.position[0] - cs.target[0], cs.position[2] - cs.target[2]], chip3d: document.getElementById('planModeChip3d').classList.contains('on'), rotate: c.controls.enableRotate }; });
  check('clic sur N du repere : retour a la 3D (perspective, rotation retablie, puce 3D), camera au sud', !pvN.plan && pvN.persp && pvN.off[0] < 0 && pvN.off[1] > 0 && pvN.chip3d && pvN.rotate, pvN);
  // Bascule puis bouton de reinitialisation : retour a la vue par defaut enregistree.
  await page.evaluate(() => window.MyPnPlanViewerV2NS.scene3dPlanView.setPlanView(true));
  await sleep(150);
  check('setPlanView(true) : vue en plan', await page.evaluate(() => window.ThreeViewer.isPlanView()));
  await page.click('#zoomResetBtn');
  await sleep(150);
  const pvReset = await page.evaluate(() => ({ plan: window.ThreeViewer.isPlanView(), cam: window.ThreeViewer.getCameraState(), lvl: document.getElementById('zoomLevel').textContent }));
  check('bouton de reinitialisation en vue en plan : retour a la 3D sur la vue par defaut (150, 95, -170), 100 %', !pvReset.plan && Math.abs(pvReset.cam.position[0] - 150) < 0.5 && Math.abs(pvReset.cam.position[2] + 170) < 0.5 && pvReset.lvl === '100%', pvReset);
  // Changement de representation en vue en plan : la 3D repart en perspective.
  await page.click('#shapeEditLock');
  await sleep(100);
  await page.evaluate(() => window.MyPnPlanViewerV2NS.scene3dPlanView.setPlanView(true));
  await sleep(150);
  await clickRow(11);
  await sleep(150);
  await clickRow(121);
  await page.waitForFunction(() => document.getElementById('threeLoading').hidden && window.ThreeViewer && window.ThreeViewer.isActive(), { timeout: 20000 }).catch(() => {});
  await sleep(300);
  const pvBack = await page.evaluate(() => ({ plan: window.ThreeViewer.isPlanView(), on3d: document.getElementById('planModeChip3d').classList.contains('on'), persp: !!window.ThreeViewer.getContext().camera.isPerspectiveCamera }));
  check('plan 2D puis retour au modele : 3D en perspective, puce 3D', !pvBack.plan && pvBack.on3d && pvBack.persp, pvBack);
  // Nord inconnu : indication du menu ; Echap ; showPlanViewButton false.
  await page.evaluate(() => window.PanoDemo.push('current_plan_scene3d_json', JSON.stringify({ node_id: 121, planIndex: 1 })));
  await sleep(120);
  await page.click('#planViewBtn');
  await sleep(80);
  const hintNo = await page.evaluate(() => document.getElementById('planViewHint').textContent);
  check('nord inconnu : le menu l indique (axe -Z en haut)', /Nord inconnu/.test(hintNo), hintNo);
  await page.keyboard.press('Escape');
  await sleep(60);
  check('Echap ferme le menu', await page.evaluate(() => document.getElementById('planViewMenu').hidden));
  const cfgPlan = (v) => page.evaluate((m) => { const cfg = JSON.parse(document.getElementById('demoEditor').value); cfg.showPlanViewButton = m; window.PanoDemo.push('configuration_plan_json', JSON.stringify(cfg)); }, v);
  await cfgPlan(false);
  await sleep(150);
  await clickRow(1);
  await clickRow(12);
  await clickRow(121);
  await sleep(300);
  const pvOff = await page.evaluate(() => ({ btn: document.getElementById('planViewBtn').hidden, chip: document.getElementById('planModeChip').hidden }));
  check('showPlanViewButton false : bouton et puce masques', pvOff.btn && pvOff.chip, pvOff);
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);
  await clickRow(1);
  await clickRow(12);
  await clickRow(121);
  await page.waitForFunction(() => document.getElementById('threeLoading').hidden && window.ThreeViewer && window.ThreeViewer.isActive(), { timeout: 20000 }).catch(() => {});
  await sleep(300);
  await page.evaluate(() => window.MyPnPlanViewerV2NS.scene3dPlanView.setPlanView(true, { animate: false }));
  await sleep(250);
  await page.screenshot({ path: SHOTS + '/shot-demo-scene3d-plan.png' });
  await page.evaluate(() => window.MyPnPlanViewerV2NS.scene3dPlanView.setPlanView(false, { animate: false }));
  await sleep(100);

  /* --- 10decies. Export PNG de la vue en plan --- */
  console.log('\n10decies. Export PNG de la vue en plan (planExport.pngScale, mode export, en-tete, telechargement)');
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);
  await page.evaluate(() => { const c = document.getElementById('demoEditing'); c.checked = true; c.dispatchEvent(new Event('change')); });
  await sleep(100);
  await clickRow(1);
  await clickRow(12);
  await clickRow(121);
  await page.waitForFunction(() => document.getElementById('threeLoading').hidden && window.ThreeViewer && window.ThreeViewer.isActive(), { timeout: 20000 }).catch(() => {});
  await page.waitForFunction(() => { const d = window.MyPnPlanViewerV2NS.scene3dRender.debug(); return d.objects[0] && d.objects[0].loaded; }, { timeout: 8000 }).catch(() => {});
  await sleep(300);
  await page.evaluate(() => { window.ThreeViewer.setAnimationMs(0); window.MyPnPlanViewerV2NS.helperAnimationMs = 0; });
  await page.click('#planViewBtn');
  await sleep(80);
  const exMenu = await page.evaluate(() => ({ png: document.getElementById('planViewPng').disabled, svg: document.getElementById('planViewSvg').disabled }));
  check('menu : \u00ab Exporter en PNG \u00bb actif', !exMenu.png, exMenu);
  await page.keyboard.press('Escape');
  await sleep(60);
  const exFrame = await page.evaluate(() => { const c = document.getElementById('threeCanvas'); return { w: c.clientWidth, h: c.clientHeight, dpr: window.devicePixelRatio }; });
  const exName = await page.evaluate(() => window.MyPnPlanViewerV2NS.scene3dExport.exportPng());
  const ex1 = await page.evaluate(() => { const e = window.MyPnPlanViewerV2NS.lastPlanExport; return e ? { kind: e.kind, name: e.name, type: e.blob.type, size: e.blob.size, w: e.width, h: e.height, plan: window.ThreeViewer.isPlanView(), exporting: window.MyPnPlanViewerV2NS.scene3dRender.exporting, notice: document.getElementById('printNotice').textContent } : null; });
  check('exportPng depuis la 3D : passage en vue en plan, PNG plan-site-sud-batiment-d-rdc-batd-<date>.png, 2 x le cadre + en-tete 92 px, message', exName && ex1 && ex1.kind === 'png' && /^plan-site-sud-batiment-d-rdc-batd-\d{8}-\d{4}\.png$/.test(ex1.name) && ex1.type === 'image/png' && ex1.size > 20000 && ex1.w === exFrame.w * 2 && ex1.h === exFrame.h * 2 + 92 && ex1.plan && !ex1.exporting && /PNG/.test(ex1.notice), [exName, ex1, exFrame]);
  const exPx = await page.evaluate(async () => {
    const e = window.MyPnPlanViewerV2NS.lastPlanExport;
    const bmp = await createImageBitmap(e.blob);
    const c = document.createElement('canvas'); c.width = bmp.width; c.height = bmp.height;
    const g = c.getContext('2d'); g.drawImage(bmp, 0, 0);
    const top = Array.from(g.getImageData(5, 5, 1, 1).data);
    const band = g.getImageData(0, 120, c.width, c.height - 140).data;
    let dark = 0, total = 0;
    // Batiment : zone 2 liee au groupe -> bleu (r faible) ; fleche nord : rouge #dc2626.
    let red = 0;
    for (let i = 0; i < band.length; i += 4 * 53) { total++; if (band[i] < 110) dark++; if (band[i] > 190 && band[i + 1] < 90 && band[i + 2] < 90) red++; }
    // Titre : des pixels sombres dans la bande de l'en-tete, a gauche.
    const head = g.getImageData(20, 10, 400, 30).data;
    let ink = 0;
    for (let i = 0; i < head.length; i += 4) if (head[i] < 90) ink++;
    return { top, dark, red, total, ink, w: c.width, h: c.height };
  });
  check('image : en-tete blanc avec le fil d Ariane, batiment present (pixels bleus / sombres), fleche nord rouge dans le cadre (plan entier)', exPx.top[0] === 255 && exPx.top[1] === 255 && exPx.top[2] === 255 && exPx.ink > 100 && exPx.dark > exPx.total * 0.02 && exPx.red >= 3, exPx);
  const exFit = await page.evaluate(() => { const cs = window.ThreeViewer.getCameraState(); return { t: cs.target, zoom: window.ThreeViewer.getContext().camera.zoom, lvl: document.getElementById('zoomLevel').textContent }; });
  check('cadrage rendu a l operateur apres l export (cible d origine, zoom 100 %)', Math.abs(exFit.t[0]) < 0.01 && Math.abs(exFit.t[2]) < 0.01 && Math.abs(exFit.zoom - 1) < 1e-6 && exFit.lvl === '100%', exFit);
  const exRestore = await page.evaluate(() => { const c = document.getElementById('threeCanvas'); return { w: c.width, h: c.height, expected: Math.round(c.clientWidth * window.devicePixelRatio) }; });
  check('affichage restaure apres la capture (canvas a sa resolution ecran)', exRestore.w === exRestore.expected, exRestore);
  // Mode export : cadenas ouvert, fleche selectionnee -> poignees et estompage retires pendant l export, retablis ensuite.
  await page.click('#shapeEditLock');
  await sleep(150);
  await page.click('#zoomOutBtn');
  await page.click('#zoomOutBtn');
  await page.click('#zoomOutBtn');
  await sleep(80);
  const nposX = await page.evaluate(() => { const NS = window.MyPnPlanViewerV2NS; return NS.scene3dRender.northPosition(NS.scene3d.scene.north); });
  await clickGround(nposX[0], nposX[1]);
  await sleep(150);
  const exHandles = await page.evaluate(() => {
    const NS = window.MyPnPlanViewerV2NS;
    const before = NS.scene3dRender.debug().handles;
    let during = null, zonesDuring = null;
    NS.scene3dExport.withExportScene(() => { const d = NS.scene3dRender.debug(); during = d.handles; zonesDuring = d.zones.map((z) => z.visible || z.highlighted); });
    const after = NS.scene3dRender.debug();
    return { sel: NS.scene3d.selected, before, during, zonesDuring, after: after.handles, zonesAfter: after.zones.map((z) => z.visible || z.highlighted), exporting: NS.scene3dRender.exporting };
  });
  check('mode export : poignees retirees pendant l export (1 -> 0) et retablies, zones (prisme + groupe) visibles pendant l export', exHandles.sel === 'north' && exHandles.before === 1 && exHandles.during === 0 && exHandles.after === 1 && exHandles.zonesDuring.every(Boolean) && !exHandles.exporting, exHandles);
  await page.keyboard.press('Escape');
  await sleep(80);
  // Echelle 1 par la configuration ; hors bornes : avertissement et 2.
  const cfgExport = (v) => page.evaluate((m) => { const cfg = JSON.parse(document.getElementById('demoEditor').value); cfg.planExport = { pngScale: m }; window.PanoDemo.push('configuration_plan_json', JSON.stringify(cfg)); }, v);
  await cfgExport(1);
  await sleep(150);
  await clickRow(1);
  await clickRow(12);
  await clickRow(121);
  await page.waitForFunction(() => document.getElementById('threeLoading').hidden && window.ThreeViewer && window.ThreeViewer.isActive(), { timeout: 20000 }).catch(() => {});
  await sleep(300);
  await page.evaluate(() => window.MyPnPlanViewerV2NS.scene3dExport.exportPng());
  await sleep(100);
  const ex2 = await page.evaluate(() => { const e = window.MyPnPlanViewerV2NS.lastPlanExport; const c = document.getElementById('threeCanvas'); return { w: e.width, h: e.height, fw: c.clientWidth, fh: c.clientHeight, k: window.MyPnPlanViewerV2NS.state.currentConfig.planExport.pngScale }; });
  check('planExport.pngScale 1 : PNG a la taille du cadre + en-tete 46 px', ex2.k === 1 && ex2.w === ex2.fw && ex2.h === ex2.fh + 46, ex2);
  await cfgExport(9);
  await sleep(150);
  const ex3 = await page.evaluate(() => ({ k: window.MyPnPlanViewerV2NS.state.currentConfig.planExport.pngScale, warnings: window.MyPnPlanViewerV2NS.state.currentConfig.warnings || [] }));
  check('planExport.pngScale 9 : avertissement, valeur 2', ex3.k === 2 && ex3.warnings.some((w) => /pngScale/.test(w)), ex3);
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);

  /* --- 10undecies. Export SVG de la vue en plan --- */
  console.log('\n10undecies. Export SVG de la vue en plan (modele en image, entites vectorielles, fond de plan, barre d echelle, metadonnees)');
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);
  await clickRow(1);
  await clickRow(12);
  await clickRow(121);
  await page.waitForFunction(() => document.getElementById('threeLoading').hidden && window.ThreeViewer && window.ThreeViewer.isActive(), { timeout: 20000 }).catch(() => {});
  await page.waitForFunction(() => { const d = window.MyPnPlanViewerV2NS.scene3dRender.debug(); return d.objects[0] && d.objects[0].loaded && d.floor && d.floor.map; }, { timeout: 8000 }).catch(() => {});
  await sleep(300);
  await page.evaluate(() => { window.ThreeViewer.setAnimationMs(0); window.MyPnPlanViewerV2NS.helperAnimationMs = 0; });
  await page.click('#planViewBtn');
  await sleep(80);
  check('menu : \u00ab Exporter en SVG \u00bb actif', await page.evaluate(() => !document.getElementById('planViewSvg').disabled));
  await page.click('#planViewSvg');
  await sleep(400);
  const sv = await page.evaluate(() => { const e = window.MyPnPlanViewerV2NS.lastPlanExport; const c = document.getElementById('threeCanvas'); return e ? { kind: e.kind, name: e.name, type: e.blob.type, len: e.text.length, text: e.text, W: c.clientWidth, H: c.clientHeight, plan: window.ThreeViewer.isPlanView(), notice: document.getElementById('printNotice').textContent } : null; });
  check('clic sur \u00ab Exporter en SVG \u00bb : passage en vue en plan, fichier plan-...svg (image/svg+xml), message', sv && sv.kind === 'svg' && /^plan-site-sud-batiment-d-rdc-batd-\d{8}-\d{4}\.svg$/.test(sv.name) && /svg/.test(sv.type) && sv.plan && /SVG/.test(sv.notice), sv && [sv.name, sv.type, sv.notice]);
  const svInfo = sv ? {
    root: /^<svg xmlns="http:\/\/www.w3.org\/2000\/svg"[^>]*width="(\d+)" height="(\d+)"/.exec(sv.text),
    north: /data-north="([^"]*)"/.exec(sv.text), scale: /data-scale-value="([^"]*)"/.exec(sv.text), width: /data-plan-width="([^"]*)"/.exec(sv.text), unit: /data-unit="([^"]*)"/.exec(sv.text),
    groups: ['header', 'drawing', 'floorImage', 'model', 'footprint', 'zones', 'scale', 'measures', 'objects', 'north', 'scaleBar'].filter((id) => sv.text.indexOf('id="' + id + '"') >= 0),
    modelImg: /id="model"><image [^>]*href="data:image\/png;base64,/.test(sv.text),
    floorImg: /id="floorImage"[^>]*>\s*<image [^>]*href="data:image\/png;base64,/.test(sv.text) || /id="floorImage"[^>]*>\s*<image [^>]*href="Images\/PlanD.png"/.test(sv.text),
    floorData: /id="floorImage"[^>]*>\s*<image [^>]*href="data:/.test(sv.text),
    labels: ['Fa\u00e7ade : 30,00 m', 'Parking : 156,90 m\u00b2', '60,00 m', 'Cuve', '>N<', 'Aile Ouest'].filter((t) => sv.text.indexOf(t) >= 0),
    zonesTraced: (sv.text.match(/class="zone"/g) || []).length, objects: (sv.text.match(/class="object"/g) || []).length,
    title: /<title>([^<]*)<\/title>/.exec(sv.text),
  } : null;
  check('document : racine W x (H + 46), data-north 30, data-scale-value 60/191.6, data-plan-width, data-unit m, titre', svInfo && svInfo.root && Number(svInfo.root[1]) === sv.W && Number(svInfo.root[2]) === sv.H + 46 && svInfo.north[1] === '30' && Math.abs(Number(svInfo.scale[1]) - 60 / 191.6) < 1e-3 && Number(svInfo.width[1]) > 60 && svInfo.unit[1] === 'm' && /vue en plan/.test(svInfo.title[1]), svInfo && [svInfo.root && svInfo.root.slice(1), svInfo.north, svInfo.scale, svInfo.width, svInfo.title]);
  check('groupes : en-tete, fond de plan, modele, emprise, zones, etalon, mesures, objets, nord, barre d echelle', svInfo && svInfo.groups.length === 11, svInfo && svInfo.groups);
  check('modele en <image> PNG base64, fond de plan en <image> (texture du rendu en base64)', svInfo && svInfo.modelImg && svInfo.floorImg && svInfo.floorData, svInfo && [svInfo.modelImg, svInfo.floorImg, svInfo.floorData]);
  // L image du modele est transparente hors du batiment (le fond de plan reste visible dessous).
  const svAlpha = await page.evaluate(async () => {
    const m = /id="model"><image [^>]*href="([^"]+)"/.exec(window.MyPnPlanViewerV2NS.lastPlanExport.text);
    const img = new Image();
    await new Promise((res, rej) => { img.onload = res; img.onerror = rej; img.src = m[1]; });
    const c = document.createElement('canvas'); c.width = img.naturalWidth; c.height = img.naturalHeight;
    const g = c.getContext('2d'); g.drawImage(img, 0, 0);
    const d = g.getImageData(0, 0, c.width, c.height).data;
    let clear = 0, opaque = 0;
    for (let i = 3; i < d.length; i += 4 * 61) { if (d[i] === 0) clear++; else if (d[i] === 255) opaque++; }
    return { clear, opaque };
  });
  check('image du modele sans fond : pixels transparents autour, opaques sur le batiment', svAlpha.clear > svAlpha.opaque && svAlpha.opaque > 100, svAlpha);
  check('etiquettes vectorielles : Facade, Parking, 60,00 m, Cuve, N, Aile Ouest ; 1 zone tracee (la zone liee au groupe reste dans l image), 1 objet', svInfo && svInfo.labels.length === 6 && svInfo.zonesTraced === 1 && svInfo.objects === 1, svInfo && [svInfo.labels, svInfo.zonesTraced, svInfo.objects]);
  // Le SVG se charge comme image et s affiche a sa taille.
  const svImg = await page.evaluate(() => new Promise((resolve) => { const e = window.MyPnPlanViewerV2NS.lastPlanExport; const url = URL.createObjectURL(e.blob); const img = new Image(); img.onload = () => resolve({ ok: true, w: img.naturalWidth, h: img.naturalHeight }); img.onerror = () => resolve({ ok: false }); img.src = url; }));
  check('le SVG se charge comme image (document bien forme), a la taille annoncee', svImg.ok && svImg.w === sv.W && svImg.h === sv.H + 46, svImg);
  // Nord inconnu et sans echelle : attributs vides, pas de barre d echelle, ni de rose.
  await page.evaluate(() => window.PanoDemo.push('current_plan_scene3d_json', JSON.stringify({ node_id: 121, planIndex: 1, footprint: { points: [[-100, -50], [100, -50], [100, 50], [-100, 50]] } })));
  await sleep(200);
  await page.evaluate(() => window.MyPnPlanViewerV2NS.scene3dExport.exportSvg());
  await sleep(300);
  const sv2 = await page.evaluate(() => window.MyPnPlanViewerV2NS.lastPlanExport.text);
  check('scene sans nord ni echelle : data-north et data-scale-value vides, pas de barre d echelle ni de fleche, emprise presente, sous-titre \u00ab nord inconnu \u00bb', /data-north=""/.test(sv2) && /data-scale-value=""/.test(sv2) && sv2.indexOf('id="scaleBar"') < 0 && sv2.indexOf('id="north"') < 0 && /id="footprint"><polygon/.test(sv2) && /nord inconnu/.test(sv2), [sv2.length, /data-north="[^"]*"/.exec(sv2), /nord inconnu/.test(sv2)]);
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);

  /* --- 10duodecies. Export SVG avec coupe horizontale vectorielle --- */
  console.log('\n10duodecies. Coupe horizontale vectorielle (planExport.cutHeight, chainage, <path> du modele)');
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);
  await clickRow(1);
  await clickRow(12);
  await clickRow(121);
  await page.waitForFunction(() => document.getElementById('threeLoading').hidden && window.ThreeViewer && window.ThreeViewer.isActive(), { timeout: 20000 }).catch(() => {});
  await sleep(300);
  await page.evaluate(() => { window.ThreeViewer.setAnimationMs(0); window.MyPnPlanViewerV2NS.helperAnimationMs = 0; });
  const cut0 = await page.evaluate(() => { const X = window.MyPnPlanViewerV2NS.scene3dExport; const h = X.cutHeightUnits(); const segs = X.cutSegments(window.MyPnPlanViewerV2NS.scene3dRender.groundY() + h); const lines = X.cutLines(); return { real: X.cutHeightReal(), h, segs: segs.length, lines: lines.length, longest: Math.max.apply(null, lines.map((l) => l.length)) }; });
  check('coupe a 1,20 m = 3,83 unites (echelle 60/191,6) : des centaines de segments, chaines en polylignes', Math.abs(cut0.real - 1.2) < 1e-9 && Math.abs(cut0.h - 1.2 * 191.6 / 60) < 0.01 && cut0.segs > 200 && cut0.lines > 0 && cut0.lines < cut0.segs && cut0.longest >= 4, cut0);
  await page.click('#planViewBtn');
  await sleep(80);
  check('menu : \u00ab Exporter en SVG (coupe) \u00bb actif', await page.evaluate(() => !document.getElementById('planViewSvgCut').disabled));
  await page.click('#planViewSvgCut');
  await sleep(500);
  const cs = await page.evaluate(() => { const e = window.MyPnPlanViewerV2NS.lastPlanExport; return { name: e.name, kind: e.kind, text: e.text }; });
  const csInfo = {
    model: /<g id="model" class="cut" data-cut-height="([^"]+)" data-cut-lines="(\d+)" data-cut-points="(\d+)"/.exec(cs.text),
    noImage: !/id="model"><image/.test(cs.text) && !/id="model"[^>]*>\s*<image/.test(cs.text),
    path: (cs.text.match(/L[\d.]+ [\d.]+/g) || []).length,
    floor: /id="floorImage"/.test(cs.text), north: /id="north"/.test(cs.text),
    subtitle: /coupe \u00e0 1,20 m du sol/.test(cs.text),
  };
  check('fichier plan-...coupe.svg : groupe model en <path> (pas d image), centaines de points, fond de plan et fleche nord conserves, sous-titre \u00ab coupe a 1,20 m du sol \u00bb', /\.coupe\.svg$/.test(cs.name) && cs.kind === 'svg' && csInfo.model && Number(csInfo.model[3]) > 300 && csInfo.noImage && csInfo.path > 300 && csInfo.floor && csInfo.north && csInfo.subtitle, [cs.name, csInfo.model && csInfo.model.slice(1), csInfo.noImage, csInfo.path, csInfo.subtitle]);
  const csImg = await page.evaluate(() => new Promise((resolve) => { const e = window.MyPnPlanViewerV2NS.lastPlanExport; const img = new Image(); img.onload = () => resolve({ ok: true, w: img.naturalWidth }); img.onerror = () => resolve({ ok: false }); img.src = URL.createObjectURL(e.blob); }));
  check('le SVG de coupe se charge comme image', csImg.ok && csImg.w > 100, csImg);
  const cfgCut = (v) => page.evaluate((m) => { const cfg = JSON.parse(document.getElementById('demoEditor').value); cfg.planExport = { cutHeight: m }; window.PanoDemo.push('configuration_plan_json', JSON.stringify(cfg)); }, v);
  await cfgCut(3);
  await sleep(150);
  await clickRow(1);
  await clickRow(12);
  await clickRow(121);
  await page.waitForFunction(() => document.getElementById('threeLoading').hidden && window.ThreeViewer && window.ThreeViewer.isActive(), { timeout: 20000 }).catch(() => {});
  await sleep(300);
  const cut3 = await page.evaluate(() => { const X = window.MyPnPlanViewerV2NS.scene3dExport; return { real: X.cutHeightReal(), h: X.cutHeightUnits(), k: window.MyPnPlanViewerV2NS.state.currentConfig.planExport.pngScale }; });
  check('planExport.cutHeight 3 : coupe a 3 m (9,58 unites), pngScale garde son defaut 2', cut3.real === 3 && Math.abs(cut3.h - 3 * 191.6 / 60) < 0.01 && cut3.k === 2, cut3);
  await cfgCut(-1);
  await sleep(150);
  const cutBad = await page.evaluate(() => ({ h: window.MyPnPlanViewerV2NS.state.currentConfig.planExport.cutHeight, warnings: window.MyPnPlanViewerV2NS.state.currentConfig.warnings || [] }));
  check('planExport.cutHeight -1 : avertissement, valeur 1,2', cutBad.h === 1.2 && cutBad.warnings.some((w) => /cutHeight/.test(w)), cutBad);
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);

  /* --- 11. Captures --- */
  await page.evaluate(() => window.PanoDemo.chargerJeu('site'));
  await sleep(100);
  await clickRow(1);
  await page.click('#drawerBtn');
  await sleep(300);
  await page.screenshot({ path: SHOTS + '/shot-demo-site.png' });
  await page.evaluate(() => window.PanoDemo.chargerJeu('limites'));
  await sleep(150);
  await page.screenshot({ path: SHOTS + '/shot-demo-limites.png' });

  /* --- Bilan --- */
  console.log('\nErreurs console / page : ' + erreurs.length);
  erreurs.forEach((e) => console.log('  ' + e));
  check('aucune erreur JavaScript', erreurs.length === 0);
  console.log('\n' + ok + ' OK, ' + ko + ' ECHEC');
  await browser.close();
  process.exit(ko ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(2); });
