// Construit tests/samples.js (window.demoSamples) a partir des echantillons JSON
// produits par le banc de l'extension .NET (MyPnPlanViewerExtension\tests\samples :
// configuration_plan.json, configuration_events.json, current_plan_element.json,
// current_plan_drawnShapes.json = sorties reelles des procedures pview.usp_Get*
// sur la base VISIODEF4). demo.html?data=server charge ce fichier et ajoute le jeu
// d'essai « Donnees SQL (serveur) » a la liste.
// Usage : node tests/make-samples.js
const fs = require('fs');
const path = require('path');

const src = path.resolve(__dirname, '..', '..', '..', '..', 'MyPnPlanViewerExtension', 'tests', 'samples');
const out = path.join(__dirname, 'samples.js');

// Les alarmes reelles pesent ~ 570 Ko (13 500 en cours) : la demo n'en garde
// qu'un echantillon, en conservant EN ENTIER celles qui portent un element_id
// (ce sont elles qui mettent les capteurs du plan en alarme).
const MAX_EVENTS = 1500;

function read(name) {
  const text = fs.readFileSync(path.join(src, name), 'utf8').replace(/^﻿/, '');
  return JSON.parse(text);
}

const config = read('configuration_plan.json');
const events = read('configuration_events.json');
const elements = read('current_plan_element.json');
const shapes = read('current_plan_drawnShapes.json');
// Scene 3D du modele (05-scene3d.sql) : absente si le banc de l'extension
// date d'avant l'etape 6.
const scene3d = fs.existsSync(path.join(src, 'current_plan_scene3d.json')) ? read('current_plan_scene3d.json') : null;

const avecElement = (events.events || []).filter((e) => e.element_id != null);
const sansElement = (events.events || []).filter((e) => e.element_id == null);
const retenus = avecElement.concat(sansElement).slice(0, MAX_EVENTS);

const cle = elements.node_id + ':' + elements.planIndex;
const cleShapes = shapes.node_id + ':' + shapes.planIndex;

const data = {
  config: config,
  events: { events: retenus },
  elementsByPlan: { [cle]: elements.elements || [] },
  shapesByPlan: { [cleShapes]: shapes.shapes || [] },
  scene3dByPlan: scene3d ? { [scene3d.node_id + ':' + scene3d.planIndex]: scene3d } : {},
  eventsTotal: (events.events || []).length,
  generatedAt: new Date().toISOString(),
  source: 'pview.usp_GetPlanConfiguration / usp_GetPlanElements / usp_GetPlanEvents / usp_GetPlanShapes / usp_GetPlanScene3D via MyPnPlanViewerExtension'
};

// ASCII pur : les caracteres non ASCII sont echappes \uXXXX par JSON.stringify
const json = JSON.stringify(data).replace(/[^\x00-\x7F]/g, (c) => '\\u' + c.charCodeAt(0).toString(16).toUpperCase().padStart(4, '0'));
fs.writeFileSync(out,
  '/* Echantillons SQL (extension .NET) pour demo.html?data=server - genere par make-samples.js, ne pas editer. */\n'
  + 'window.demoSamples = ' + json + ';\n', 'utf8');

const noeuds = (function compte(liste) {
  return (liste || []).reduce((n, x) => n + 1 + compte(x.nodes), 0);
})(config.tree);

console.log('samples.js : ' + noeuds + ' noeuds, '
  + retenus.length + '/' + data.eventsTotal + ' alarmes, '
  + (data.elementsByPlan[cle].length) + ' capteurs (plan ' + cle + '), '
  + (data.shapesByPlan[cleShapes].length) + ' formes, '
  + (scene3d ? 'scene 3D du noeud ' + scene3d.node_id + ' (' + (scene3d.zones || []).length + ' zones), ' : 'sans scene 3D, ')
  + json.length + ' car.');
