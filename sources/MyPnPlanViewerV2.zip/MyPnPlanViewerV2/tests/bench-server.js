// Banc puppeteer MyPnPlanViewerV2 « donnees SQL » : ouvre demo.html?data=server
// en file:// dans Chrome local et verifie que l'objet affiche bien les donnees
// reelles du schema pview (arbre sched.Location, plans, capteurs positionnes,
// formes libres, alarmes en cours) servies par l'extension .NET.
// Pre-requis : tests/samples.js a jour (node tests/make-samples.js apres une
// execution de MyPnPlanViewerExtension\tests\bench-extension.ps1).
// Usage : node tests/bench-server.js
const path = require('path');
const fs = require('fs');

const NM = process.env.VD4_BANCS || path.resolve(__dirname, '..', '..', '..', '.bancs', 'node_modules');
const puppeteer = require(path.join(NM, 'puppeteer-core'));
const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';

const DEMO = 'file:///' + path.resolve(__dirname, '..', 'demo.html').replace(/\\/g, '/') + '?data=server';
const OUT = __dirname;

let pass = 0, fail = 0;
function check(label, cond, detail) {
  if (cond) { pass++; console.log('  OK   ' + label); }
  else { fail++; console.log('  FAIL ' + label + (detail ? ' -- ' + detail : '')); }
}

(async () => {
  if (!fs.existsSync(path.join(__dirname, 'samples.js'))) {
    console.error('tests/samples.js absent : lancer d abord node tests/make-samples.js');
    process.exit(1);
  }

  const browser = await puppeteer.launch({
    executablePath: CHROME,
    headless: 'new',
    args: ['--allow-file-access-from-files', '--window-size=1600,1000']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1600, height: 1000 });
  const erreurs = [];
  page.on('pageerror', (e) => erreurs.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') erreurs.push(m.text()); });

  await page.goto(DEMO, { waitUntil: 'load' });
  await page.waitForFunction('window.PanoDemo && window.PanoDemo.JEUX');

  console.log('--- chargement du jeu SQL');
  const info = await page.evaluate(() => ({
    samples: Boolean(window.demoSamples),
    premierJeu: window.PanoDemo.JEUX[0].cle,
    eventsTotal: window.demoSamples ? window.demoSamples.eventsTotal : 0,
    source: window.demoSamples ? window.demoSamples.source : ''
  }));
  check('tests/samples.js charge par ?data=server', info.samples);
  check('le jeu \u00ab serveur \u00bb est en tete et charge par defaut', info.premierJeu === 'serveur', info.premierJeu);
  check('origine des donnees : procedures pview', /pview\.usp_GetPlanConfiguration/.test(info.source), info.source);
  // Le nombre d'alarmes en cours du schema elem evolue avec l'exploitation.
  check('alarmes reelles denombrees (' + info.eventsTotal + ')', info.eventsTotal > 1000, String(info.eventsTotal));

  console.log('--- bandeau et arbre');
  const titre = await page.$eval('#siteTitle', (el) => el.textContent.trim()).catch(() => '');
  check('titre du bandeau issu de pview.Setting : \u00ab ' + titre + ' \u00bb', /VisioDEF/.test(titre) || titre.length > 0, titre);

  // Ouverture du drawer de navigation
  await page.click('#demoDrawer');
  await new Promise((r) => setTimeout(r, 300));
  const arbre = await page.evaluate(() => {
    const lignes = document.querySelectorAll('#siteTree .row[data-id]');
    return { lignes: lignes.length };
  });
  check('arbre de navigation affiche (' + arbre.lignes + ' lignes visibles)', arbre.lignes >= 15, String(arbre.lignes));

  const pastilles = await page.evaluate(() =>
    document.querySelectorAll('#siteTree .event-dot').length);
  check('pastilles d alarmes sur l arbre (' + pastilles + ')', pastilles > 0, String(pastilles));
  // Jeu 03-sample-data : le premier batiment n'a qu'un modele 3D, un niveau
  // sur dix n'a aucune representation (indicateurs de l'arbre).
  const indic = await page.evaluate(() => ({
    model: document.querySelectorAll('#siteTree .model-indicator').length,
    noPlan: document.querySelectorAll('#siteTree .no-plan-indicator').length,
    badges: document.querySelectorAll('#siteTree .plans-badge').length
  }));
  check('indicateur \u00ab representation 3D \u00bb sur le premier batiment', indic.model === 1, String(indic.model));
  check('indicateur \u00ab sans plan \u00bb sur les 48 niveaux sans representation', indic.noPlan === 48, String(indic.noPlan));
  check('aucun badge \u00ab n plans \u00bb (une representation par lieu)', indic.badges === 0, String(indic.badges));

  await page.screenshot({ path: path.join(OUT, 'shot-server-01-arbre.png') });

  console.log('--- selection d un plan porteur de capteurs');
  // Le jeu SQL connait un plan garni : on le selectionne par son id.
  const cible = await page.evaluate(() => Object.keys(window.demoSamples.elementsByPlan)[0]);
  const [nodeId] = cible.split(':').map(Number);

  // CLIC REEL sur la ligne du noeud : c'est l'objet qui ecrit alors
  // selectedNodePath, et la reponse automatique du banc pousse en retour
  // current_plan_element_json et current_plan_drawnShapes_json. Pousser
  // selectedNodePath depuis le banc n'aurait aucun effet : c'est une propriete
  // ECRITE par l'objet, jamais relue.
  const clique = await page.evaluate((id) => {
    const ligne = document.querySelector('#siteTree .row[data-id="' + id + '"]');
    if (!ligne) { return false; }
    ligne.scrollIntoView();
    ligne.click();
    return true;
  }, nodeId);
  check('ligne du noeud ' + nodeId + ' trouvee et cliquee dans l arbre', clique);
  await new Promise((r) => setTimeout(r, 900));

  const selection = await page.evaluate(() => {
    const el = document.getElementById('outNode');
    return el ? el.textContent : '';
  });
  // La restitution du banc est indentee : la comparaison ignore les espaces.
  check('selectedNodePath ecrit par l objet',
    selection.replace(/\s+/g, '').indexOf('"id":' + nodeId) >= 0,
    selection.replace(/\s+/g, ' ').slice(0, 140));

  const capteurs = await page.evaluate(() =>
    document.querySelectorAll('#planViewport .plan-element, #planViewport [data-element-id], #planViewport .element').length);
  check('capteurs poses sur le plan ' + cible + ' (' + capteurs + ' affiches)', capteurs > 50, String(capteurs));

  const formes = await page.evaluate(() =>
    document.querySelectorAll('#planEditLayer *').length);
  check('formes libres tracees (' + formes + ' elements SVG)', formes > 0, String(formes));

  const enAlarme = await page.evaluate(() =>
    document.querySelectorAll('#planViewport [class*=\"alarm\"]').length);
  check('capteurs en alarme signales (' + enAlarme + ')', enAlarme >= 0, String(enAlarme));

  await page.screenshot({ path: path.join(OUT, 'shot-server-02-plan.png') });

  console.log('--- coherence du contrat');
  const contrat = await page.evaluate(() => {
    const s = window.demoSamples;
    const cle = Object.keys(s.elementsByPlan)[0];
    const els = s.elementsByPlan[cle];
    const sh = s.shapesByPlan[cle] || [];
    return {
      capteurs: els.length,
      horsBornes: els.filter((e) => e.x < 0 || e.x > 1 || e.y < 0 || e.y > 1).length,
      sansIcone: els.filter((e) => !e.icon).length,
      formes: sh.length,
      types: Array.from(new Set(sh.map((f) => f.type))).length,
      elementsEntiers: sh.every((f) => !f.elements || f.elements.every((v) => Number.isInteger(v))),
      sites: s.config.tree.length,
      avecPlan: s.config.tree.filter((n) => n.plans && n.plans.length).length
    };
  });
  check('capteurs du plan : ' + contrat.capteurs + ', tous dans 0..1', contrat.horsBornes === 0);
  check('chaque capteur porte une icone', contrat.sansIcone === 0, String(contrat.sansIcone));
  check('formes : ' + contrat.formes + ' couvrant ' + contrat.types + ' types', contrat.formes === 14 && contrat.types === 14);
  check('cle elements = tableau d entiers', contrat.elementsEntiers);
  check('arbre : ' + contrat.sites + ' sites, tous avec une representation', contrat.sites === 15 && contrat.avecPlan === 15);

  console.log('--- scene 3D du modele (usp_GetPlanScene3D)');
  const scKey = await page.evaluate(() => Object.keys((window.demoSamples && window.demoSamples.scene3dByPlan) || {})[0] || '');
  check('echantillon current_plan_scene3d.json present (' + scKey + ')', /^\d+:1$/.test(scKey), scKey);
  if (scKey) {
    const scNode = Number(scKey.split(':')[0]);
    const ouvert = await page.evaluate((id) => {
      const NS = window.MyPnPlanViewerV2NS;
      const node = NS.state.currentConfig.byId.get(id);
      if (!node) return false;
      const parent = NS.state.currentConfig.byId.get(node.parent_id);
      const rowOf = (n) => document.querySelector('#siteTree .row[data-id="' + n + '"]');
      if (parent && rowOf(parent.id) && !rowOf(parent.id).parentElement.classList.contains('expanded')) rowOf(parent.id).click();
      const row = rowOf(id);
      if (!row) return false;
      row.click();
      return true;
    }, scNode);
    check('noeud du modele 3D (' + scNode + ') selectionne dans l arbre', ouvert);
    await page.waitForFunction(() => document.getElementById('threeLoading').hidden && window.ThreeViewer && window.ThreeViewer.isActive(), { timeout: 30000 }).catch(() => {});
    await page.waitForFunction(() => { const d = window.MyPnPlanViewerV2NS.scene3dRender.debug(); return d.objects[0] && d.objects[0].loaded && d.labels.length >= 3; }, { timeout: 10000 }).catch(() => {});
    const sc = await page.evaluate(() => {
      const NS = window.MyPnPlanViewerV2NS;
      const d = NS.scene3dRender.debug();
      return { status: NS.state.propertyStatus.current_plan_scene3d_json || '', labels: d.labels, zones: d.zones.length, objet: d.objects[0] && d.objects[0].loaded, pick: d.pickables, cam: window.ThreeViewer.getCameraState() };
    });
    check('scene SQL appliquee : statut \u00ab vue par defaut enregistree, emprise, fond de plan, 2 mesures, 1 objet, 2 zones \u00bb', /enregistr/.test(sc.status) && /emprise 4 sommets/.test(sc.status) && /2 mesure/.test(sc.status) && /1 objet/.test(sc.status) && /2 zone/.test(sc.status), sc.status);
    check('camera placee sur la vue par defaut SQL (x 150, z -170)', Math.abs(sc.cam.position[0] - 150) < 0.5 && Math.abs(sc.cam.position[2] + 170) < 0.5, JSON.stringify(sc.cam));
    check('etalon et mesures etiquetes (' + sc.labels.join(' | ') + ')', sc.labels.length === 3 && sc.labels.some((t) => /60,00 m/.test(t)), sc.labels.join());
    check('objet cuve.obj charge, 2 zones construites', sc.objet && sc.zones === 2, JSON.stringify([sc.objet, sc.zones]));
  }

  console.log('--- ecriture des formes (mode edition)');
  const ecrit = await page.evaluate(() => {
    const sortie = document.getElementById('outShapes');
    return sortie ? sortie.textContent.length : -1;
  });
  check('zone de restitution des formes ecrites presente', ecrit >= 0, String(ecrit));

  check('aucune erreur JavaScript', erreurs.length === 0, erreurs.slice(0, 3).join(' | '));

  await browser.close();
  console.log('');
  console.log(pass + '/' + (pass + fail) + ' assertions OK');
  process.exit(fail > 0 ? 1 : 0);
})();
