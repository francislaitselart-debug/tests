/* Banc de test de l'impression du plan (viewer-print.js) de MyPnPlanViewerV2 :
   puppeteer-core + Chrome local, contre tests/server.js (lance
   automatiquement, port 8171, bouchon Panorama poussant
   configuration_plan_json).
     node tests/bench-print.js [--keep]   (--keep : laisse Chrome ouvert)
   Captures dans tests/out/. window.print() est BOUCHONNE : Chrome headless
   n'ouvre pas de dialogue. Le bouchon rejoue la sequence beforeprint ->
   (capture de l'etat) -> afterprint de facon synchrone, comme Chrome ;
   le cas « sandbox sans allow-modals » est simule par un print() muet :
   l'objet doit alors produire un PDF et le telecharger (le clic du
   <a download> est capture par un bouchon). Le VRAI bac a sable est joue
   par tests/bench-print-sandbox.js.
   V2 : un noeud = une representation, la navigation entre plans passe par
   l'arbre (lignes .row[data-id]). */
'use strict';
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');

const PORT = 8171;
const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const PUPPETEER_DIRS = [
  require('path').join(process.env.VD4_BANCS || require('path').resolve(__dirname, '..', '..', '..', '.bancs', 'node_modules'), 'puppeteer-core'),
  'C:/Users/F676A~1.LAI/AppData/Local/Temp/claude/c--Projets-VisioDEF4-Sources-Vd4AppCU-WEB/303017af-1d6a-4ea9-a752-4071fc9cf83b/scratchpad/node_modules/puppeteer-core',
  'C:/Users/F676A~1.LAI/AppData/Local/Temp/claude/c--Projets-VisioDEF4-Sources-Vd4AppCU-WEB/23caafc4-c6d7-44c1-a48b-1cc65de36ef9/scratchpad/node_modules/puppeteer-core',
];
let puppeteer = null;
for (const dir of PUPPETEER_DIRS) {
  try { puppeteer = require(dir); break; } catch (e) { /* suivant */ }
}
if (!puppeteer) { console.error('puppeteer-core introuvable'); process.exit(2); }

const OUT = path.join(__dirname, 'out');
fs.mkdirSync(OUT, { recursive: true });

const CONFIG = {
  title: 'Site Sud',
  shapeEditing: true,
  tree: [
    { id: 1, label: 'Site Sud',
      plans: [{ filename: 'Images/plan_site_hopital_face_nu.svg', label: 'Vue du site' }],
      nodes: [
        { id: 2, label: 'B\u00e2timent A',
          plans: [{ filename: 'Images/planA.jpg', label: 'Plan du b\u00e2timent',
            scale: { value: 120, unit: 'm' },
            layers: [{ label: 'Zone \u00e0 risque', kind: 'image', filename: 'Images/planA-zone-risque.png' }] }] },
        { id: 3, label: 'Niveau paysage',
          plans: [{ filename: 'Images/PlanB.jpg', label: 'Plan paysage' }] },
        { id: 4, label: 'Maquette',
          plans: [{ label: 'Mod\u00e8le 3D', type: 'model', filename: 'Images/RB_SP_MD_011.obj' }] },
      ] },
  ],
};

let passed = 0, failed = 0;
function check(cond, label, detail) {
  if (cond) { passed++; console.log('  OK   ' + label); }
  else { failed++; console.log('  FAIL ' + label + (detail !== undefined ? ' -> ' + JSON.stringify(detail) : '')); }
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
/* Mise en page attendue (memes regles que viewer-print.js) : plus petite
   zone commune A4/Letter, marges 10 mm, en-tete 12 mm. */
const PX = 96 / 25.4;
function expectLayout(w, h) {
  const landscape = w >= h;
  const pageW = (landscape ? 259.4 : 190) * PX;
  const pageH = ((landscape ? 190 : 259.4) - 12) * PX;
  return { landscape, k: Math.min(pageW / w, pageH / h), pageW, pageH };
}

const PRINT_STUB = `
  window.__prints = [];
  window.__printBlocked = false;
  window.__downloads = [];
  const anchorClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (this.download) { window.__downloads.push({ name: this.download, href: this.href }); return; }
    return anchorClick.call(this);
  };
  window.print = function () {
    if (window.__printBlocked) return;
    window.dispatchEvent(new Event('beforeprint'));
    const root = document.getElementById('viewerRoot');
    const cs = getComputedStyle(root);
    window.__prints.push({
      classes: root.className,
      w: cs.getPropertyValue('--print-w').trim(),
      h: cs.getPropertyValue('--print-h').trim(),
      k: cs.getPropertyValue('--print-k').trim(),
      page: (document.getElementById('printPageStyle') || {}).textContent || '',
      path: document.getElementById('printHeaderPath').textContent,
      plan: document.getElementById('printHeaderPlan').textContent,
      date: document.getElementById('printHeaderDate').textContent,
      menuHidden: document.getElementById('printMenu').hidden,
    });
    window.dispatchEvent(new Event('afterprint'));
  };
`;

async function main() {
  const keep = process.argv.includes('--keep');
  const server = spawn(process.execPath, [path.join(__dirname, 'server.js'), String(PORT)], { stdio: 'inherit' });
  await sleep(600);

  const browser = await puppeteer.launch({ executablePath: CHROME, headless: !keep, args: ['--no-sandbox'] });
  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1400, height: 900 });
    const errors = [];
    page.on('pageerror', (e) => errors.push(String(e)));
    page.on('console', (m) => { if (m.type() === 'error' && !/favicon/.test(m.text())) errors.push(m.text()); });
    await page.evaluateOnNewDocument((cfg, stub) => {
      window.__initialConfig = cfg;
      // eslint-disable-next-line no-new-func
      new Function(stub)();
    }, CONFIG, PRINT_STUB);
    await page.goto('http://localhost:' + PORT + '/index.html', { waitUntil: 'networkidle0' });
    await page.waitForFunction(() => window.MyPnPlanViewerV2NS && MyPnPlanViewerV2NS.state.currentConfig.tree.length > 0);

    /* Ouvre le drawer, deplie « Site Sud » et clique le noeud demande. */
    async function selectNode(id) {
      const drawerOpen = await page.$eval('#siteNav', (el) => el.getAttribute('aria-hidden') !== 'true');
      if (!drawerOpen) { await page.click('#drawerBtn'); await sleep(350); }
      const visible = await page.$eval('.row[data-id="' + id + '"]', (el) => el.offsetParent !== null).catch(() => false);
      if (!visible) { await page.click('.row[data-id="1"] .caret'); await sleep(100); }
      await page.click('.row[data-id="' + id + '"]');
      await sleep(400);
    }

    console.log('\n1. Etat initial (aucune selection)');
    check(await page.$eval('#zoomToolbar', (el) => el.hidden), 'barre de zoom masquee');
    check(await page.$eval('#printBtn', (el) => el.hidden), 'bouton imprimante masque');
    check(await page.$eval('#printHeader', (el) => getComputedStyle(el).display === 'none'), 'en-tete d\'impression invisible a l\'ecran');

    console.log('\n2. Selection d\'un plan 2D (noeud 2)');
    await selectNode(2);
    await page.waitForFunction(() => /planA/.test(document.getElementById('planImage').src) && document.getElementById('planImage').complete && document.getElementById('planImage').naturalWidth > 0);
    await sleep(300);
    check(!(await page.$eval('#zoomToolbar', (el) => el.hidden)), 'barre de zoom affichee');
    check(!(await page.$eval('#printBtn', (el) => el.hidden)), 'bouton imprimante affiche');
    check(!(await page.$eval('#printSep', (el) => el.hidden)), 'separateur affiche');
    const btnBox = await page.$eval('#printBtn', (el) => { const r = el.getBoundingClientRect(); return { w: r.width, h: r.height, right: innerWidth - r.right, bottom: innerHeight - r.bottom }; });
    check(btnBox.w === 28 && btnBox.h === 28, 'bouton 28 x 28 px', btnBox);
    check(btnBox.right < 30 && btnBox.bottom < 30, 'bouton en bas a droite', btnBox);

    console.log('\n3. Menu de choix sans zoom');
    await page.click('#printBtn');
    await sleep(50);
    check(!(await page.$eval('#printMenu', (el) => el.hidden)), 'menu ouvert');
    check(await page.$eval('#printBtn', (el) => el.getAttribute('aria-expanded') === 'true'), 'aria-expanded=true');
    check(await page.$eval('#printMenuView', (el) => el.disabled), '« Vue affichee » inactive sans zoom');
    check(!(await page.$eval('#printMenuFull', (el) => el.disabled)), '« Plan entier » active');
    check(await page.$eval('#printMenuHint', (el) => /Aucun zoom/.test(el.textContent)), 'indication « Aucun zoom en cours »');
    check(await page.evaluate(() => document.activeElement.id === 'printMenuFull'), 'focus sur « Plan entier »');
    const menuBox = await page.$eval('#printMenu', (el) => { const r = el.getBoundingClientRect(); return { right: innerWidth - r.right, bottom: innerHeight - r.bottom, w: r.width }; });
    check(menuBox.right < 30 && menuBox.bottom > 40 && menuBox.bottom < 80, 'menu au-dessus de la barre de zoom', menuBox);
    await page.screenshot({ path: path.join(OUT, 'print-01-menu.png') });
    await page.keyboard.press('Escape');
    await sleep(50);
    check(await page.$eval('#printMenu', (el) => el.hidden), 'Echap ferme le menu');
    await page.click('#printBtn');
    await sleep(50);
    await page.mouse.click(700, 450);
    await sleep(50);
    check(await page.$eval('#printMenu', (el) => el.hidden), 'clic a l\'exterieur ferme le menu');
    await page.click('#printBtn');
    await sleep(50);
    await page.click('#printBtn');
    await sleep(50);
    check(await page.$eval('#printMenu', (el) => el.hidden), 'second clic sur le bouton ferme le menu');

    console.log('\n4. Impression « Plan entier »');
    const imgBox = await page.$eval('#planImage', (el) => ({ w: el.offsetWidth, h: el.offsetHeight }));
    const layoutFull = await page.evaluate(() => MyPnPlanViewerV2NS.computePrintLayout('full'));
    check(layoutFull.w === imgBox.w && layoutFull.h === imgBox.h, 'cadre = plan affiche a 100 %', { layoutFull, imgBox });
    check(imgBox.h > imgBox.w, 'planA.jpg (1600 x 1621) est affiche en portrait', imgBox);
    check(layoutFull.landscape === false, 'orientation portrait retenue', layoutFull);
    const exp1 = expectLayout(imgBox.w, imgBox.h);
    const expectK = exp1.k;
    check(Math.abs(layoutFull.k - expectK) < 1e-9, 'facteur k = ajustement A4/Letter (portrait)', { k: layoutFull.k, expectK });
    check(layoutFull.w * layoutFull.k <= exp1.pageW + 0.01 && layoutFull.h * layoutFull.k <= exp1.pageH + 0.01, 'cadre reduit tient dans la zone imprimable');

    await page.click('#printBtn');
    await sleep(50);
    await page.click('#printMenuFull');
    await sleep(50);
    const prints = await page.evaluate(() => window.__prints);
    check(prints.length === 1, 'window.print() appele une fois', prints.length);
    const p1 = prints[0] || {};
    check(/\bis-printing\b/.test(p1.classes) && /\bprint-full\b/.test(p1.classes) && !/\bprint-view\b/.test(p1.classes), 'classes is-printing + print-full pendant l\'impression', p1.classes);
    check(p1.w === imgBox.w + 'px' && p1.h === imgBox.h + 'px', 'variables --print-w/--print-h = cadre', { w: p1.w, h: p1.h });
    check(Math.abs(parseFloat(p1.k) - expectK) < 1e-6, 'variable --print-k', p1.k);
    check(/@page \{ size: portrait; margin: 10mm; \}/.test(p1.page), 'regle @page portrait', p1.page);
    check(p1.path === 'Site Sud \u2014 B\u00e2timent A', 'en-tete : fil d\'Ariane', p1.path);
    check(p1.plan === 'Plan du b\u00e2timent', 'en-tete : libelle de la representation', p1.plan);
    check(/^\d{2}\/\d{2}\/\d{4} \d{2}:\d{2}$/.test(p1.date), 'en-tete : date jj/mm/aaaa hh:mm', p1.date);
    check(p1.menuHidden === true, 'menu referme avant l\'impression');
    const after = await page.$eval('#viewerRoot', (el) => ({ cls: el.className, w: el.style.getPropertyValue('--print-w'), page: document.getElementById('printPageStyle').textContent }));
    check(!/is-printing|print-full/.test(after.cls) && after.w === '' && after.page === '', 'etat restaure apres impression', after);
    check(await page.$eval('#printNotice', (el) => el.hidden), 'aucun message de blocage');

    console.log('\n5. Impression « Vue affichee » apres zoom');
    await page.click('#zoomInBtn');
    await page.click('#zoomInBtn');
    await sleep(50);
    await page.mouse.move(700, 450);
    await page.mouse.down();
    await page.mouse.move(600, 400, { steps: 5 });
    await page.mouse.up();
    await sleep(50);
    const z = await page.evaluate(() => MyPnPlanViewerV2NS.getZoomState());
    check(z.zoom > 1.6 && (z.panX !== 0 || z.panY !== 0), 'zoom et deplacement effectifs', z);
    await page.click('#printBtn');
    await sleep(50);
    check(!(await page.$eval('#printMenuView', (el) => el.disabled)), '« Vue affichee » active avec zoom');
    check(await page.$eval('#printMenuHint', (el) => /Zoom actuel : 169 %/.test(el.textContent)), 'indication « Zoom actuel : 169 % »', await page.$eval('#printMenuHint', (el) => el.textContent));
    await page.screenshot({ path: path.join(OUT, 'print-02-menu-zoom.png') });
    const vp = await page.$eval('#planViewport', (el) => ({ w: el.clientWidth, h: el.clientHeight }));
    const transformBefore = await page.$eval('#planImage', (el) => el.style.transform);
    await page.click('#printMenuView');
    await sleep(50);
    const prints2 = await page.evaluate(() => window.__prints);
    const p2 = prints2[1] || {};
    check(prints2.length === 2, 'second appel a window.print()');
    check(/\bprint-view\b/.test(p2.classes) && !/\bprint-full\b/.test(p2.classes), 'classe print-view', p2.classes);
    check(p2.w === vp.w + 'px' && p2.h === vp.h + 'px', 'cadre = cadre ecran', { p2w: p2.w, p2h: p2.h, vp });
    const exp2 = expectLayout(vp.w, vp.h);
    const expectK2 = exp2.k;
    check(exp2.landscape, 'cadre ecran 1400 x 900 : paysage');
    check(/size: landscape/.test(p2.page), 'regle @page paysage pour la vue affichee', p2.page);
    check(Math.abs(parseFloat(p2.k) - expectK2) < 1e-6, 'facteur k du cadre ecran', { k: p2.k, expectK2 });
    check(await page.$eval('#planImage', (el) => el.style.transform) === transformBefore, 'transformation de zoom intacte apres impression');
    check(await page.evaluate(() => { const s = MyPnPlanViewerV2NS.getZoomState(); return s.zoom > 1.6; }), 'zoom conserve apres impression');

    console.log('\n6. Rendu sous media print (emulation) : plan entier');
    await page.click('#zoomResetBtn');
    await sleep(50);
    await page.evaluate(() => MyPnPlanViewerV2NS.beginPrint('full', new Date(2026, 7, 29, 10, 30)));
    await page.emulateMediaType('print');
    await sleep(100);
    const printed = await page.evaluate(() => {
      const r = (id) => { const b = document.getElementById(id).getBoundingClientRect(); return { x: b.left, y: b.top, w: b.width, h: b.height }; };
      const vis = (sel) => { const el = document.querySelector(sel); return el ? getComputedStyle(el).display !== 'none' : null; };
      return {
        header: r('printHeader'), zone: r('planZone'), viewport: r('planViewport'), image: r('planImage'),
        headerText: document.getElementById('printHeader').textContent,
        topbar: vis('.site-topbar'), nav: vis('.site-nav'), toolbar: vis('#zoomToolbar'), lock: vis('#shapeEditLock'),
        layersDial: vis('#layersDialAnchor'),
        headerDisplay: getComputedStyle(document.getElementById('printHeader')).display,
      };
    });
    check(printed.headerDisplay === 'flex', 'en-tete affiche sous media print');
    check(printed.topbar === false && printed.nav === false && printed.toolbar === false && printed.lock === false && printed.layersDial === false, 'bandeau, drawer, barre de zoom, cadenas et SpeedDial des calques masques', printed);
    check(printed.headerText.indexOf('Site Sud \u2014 B\u00e2timent A') >= 0 && printed.headerText.indexOf('29/08/2026 10:30') >= 0, 'texte de l\'en-tete', printed.headerText);
    check(Math.abs(printed.zone.w - imgBox.w * expectK) < 1 && Math.abs(printed.zone.h - imgBox.h * expectK) < 1, 'zone du plan reduite a w*k x h*k', { zone: printed.zone, expect: { w: imgBox.w * expectK, h: imgBox.h * expectK } });
    check(Math.abs(printed.image.w - printed.zone.w) < 1.5 && Math.abs(printed.image.h - printed.zone.h) < 1.5, 'image du plan remplit la zone reduite', { image: printed.image, zone: printed.zone });
    check(printed.image.y >= printed.header.y + printed.header.h - 0.5, 'plan sous l\'en-tete', { image: printed.image, header: printed.header });
    await page.screenshot({ path: path.join(OUT, 'print-03-media-print-full.png'), fullPage: true });
    const pdfFull = path.join(OUT, 'print-04-full.pdf');
    await page.pdf({ path: pdfFull, format: 'A4', landscape: false, margin: { top: '10mm', right: '10mm', bottom: '10mm', left: '10mm' }, printBackground: true });
    const pagesFull = (fs.readFileSync(pdfFull, 'latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
    check(pagesFull === 1, 'PDF A4 portrait : une seule page', pagesFull);
    await page.evaluate(() => MyPnPlanViewerV2NS.endPrint());

    console.log('\n7. Rendu sous media print : vue affichee (zoom 169 %)');
    await page.emulateMediaType('screen');
    await page.click('#zoomInBtn');
    await page.click('#zoomInBtn');
    await sleep(50);
    await page.evaluate(() => MyPnPlanViewerV2NS.beginPrint('view'));
    await page.emulateMediaType('print');
    await sleep(100);
    const printedView = await page.evaluate(() => {
      const r = (id) => { const b = document.getElementById(id).getBoundingClientRect(); return { x: b.left, y: b.top, w: b.width, h: b.height }; };
      return { zone: r('planZone'), image: r('planImage'), imgTransform: document.getElementById('planImage').style.transform };
    });
    check(Math.abs(printedView.zone.w - vp.w * expectK2) < 1 && Math.abs(printedView.zone.h - vp.h * expectK2) < 1, 'zone = cadre ecran reduit', { zone: printedView.zone, expect: { w: vp.w * expectK2, h: vp.h * expectK2 } });
    check(/scale\(1\.69/.test(printedView.imgTransform), 'zoom conserve dans le rendu imprime', printedView.imgTransform);
    check(printedView.image.w > printedView.zone.w, 'plan zoome deborde du cadre (rogne par overflow)', { image: printedView.image, zone: printedView.zone });
    await page.screenshot({ path: path.join(OUT, 'print-05-media-print-view.png'), fullPage: true });
    const pdfView = path.join(OUT, 'print-06-view.pdf');
    await page.pdf({ path: pdfView, format: 'A4', landscape: true, margin: { top: '10mm', right: '10mm', bottom: '10mm', left: '10mm' }, printBackground: true });
    const pagesView = (fs.readFileSync(pdfView, 'latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
    check(pagesView === 1, 'PDF vue affichee : une seule page', pagesView);
    await page.evaluate(() => MyPnPlanViewerV2NS.endPrint());
    await page.emulateMediaType('screen');
    await page.click('#zoomResetBtn');

    console.log('\n8. Plan paysage (noeud 3, PlanB.jpg) : orientation paysage');
    await selectNode(3);
    await page.waitForFunction(() => /PlanB/.test(document.getElementById('planImage').src) && document.getElementById('planImage').complete);
    await sleep(200);
    const imgD = await page.$eval('#planImage', (el) => ({ w: el.offsetWidth, h: el.offsetHeight }));
    const layoutD = await page.evaluate(() => MyPnPlanViewerV2NS.computePrintLayout('full'));
    check(imgD.w > imgD.h, 'PlanB.jpg (2048 x 1448) est affiche en paysage', imgD);
    check(layoutD.landscape === true, 'orientation paysage retenue', layoutD);
    const expectKD = expectLayout(imgD.w, imgD.h).k;
    check(Math.abs(layoutD.k - expectKD) < 1e-9, 'facteur k paysage', { k: layoutD.k, expectKD });
    await page.click('#printBtn');
    await sleep(50);
    await page.click('#printMenuFull');
    await sleep(50);
    const p3 = (await page.evaluate(() => window.__prints))[2] || {};
    check(/size: landscape/.test(p3.page), 'regle @page paysage', p3.page);
    check(p3.path === 'Site Sud \u2014 Niveau paysage', 'en-tete : fil d\'Ariane du noeud 3', p3.path);
    check(p3.plan === 'Plan paysage', 'en-tete : libelle du second plan', p3.plan);

    console.log('\n9. Representation 3D (noeud 4) : pas d\'impression');
    await selectNode(4);
    await sleep(300);
    check(await page.evaluate(() => MyPnPlanViewerV2NS.state.activeMode === 'three'), 'mode 3D actif');
    check(!(await page.$eval('#zoomToolbar', (el) => el.hidden)), 'barre de zoom toujours affichee en 3D');
    check(await page.$eval('#printBtn', (el) => el.hidden), 'bouton imprimante masque en 3D');
    check(await page.$eval('#printSep', (el) => el.hidden), 'separateur masque en 3D');
    check(await page.evaluate(() => MyPnPlanViewerV2NS.printPlan('full')) === false, 'printPlan refuse en 3D');
    check((await page.evaluate(() => window.__prints.length)) === 3, 'aucun appel a window.print() en 3D');

    console.log('\n10. Retour au plan 2D, puis window.print() ignore (sandbox simule) -> repli PDF');
    await selectNode(2);
    check(!(await page.$eval('#printBtn', (el) => el.hidden)), 'bouton imprimante de retour sur le plan 2D');
    check(await page.evaluate(() => MyPnPlanViewerV2NS.isPrintSandboxed() === false), 'hors bac a sable (origine http) : window.print() tente d\'abord');
    await page.evaluate(() => { window.__printBlocked = true; });
    await page.click('#printBtn');
    await sleep(50);
    await page.click('#printMenuFull');
    await page.waitForFunction(() => window.__downloads.length === 1, { timeout: 20000 }).catch(() => {});
    const dl = await page.evaluate(() => window.__downloads);
    check(dl.length === 1 && /^plan-site-sud-batiment-a-\d{8}-\d{4}\.pdf$/.test(dl[0].name), 'PDF telecharge : plan-<chemin>-<date>.pdf', dl);
    const pdfBytes = await page.evaluate(async (href) => {
      const buf = await (await fetch(href)).arrayBuffer();
      const b = new Uint8Array(buf);
      let s = '';
      for (let i = 0; i < b.length; i++) s += String.fromCharCode(b[i]);
      return { size: b.length, header: s.slice(0, 5), pages: (s.match(/\/Type\s*\/Page[^s]/g) || []).length, portrait: /MediaBox\s*\[\s*0\s+0\s+595\.\d+\s+841\.\d+\s*\]/.test(s) };
    }, (dl[0] || {}).href || '');
    check(pdfBytes.header === '%PDF-' && pdfBytes.size > 20000 && pdfBytes.pages === 1 && pdfBytes.portrait, 'PDF valide : une page A4 portrait (' + pdfBytes.size + ' octets)', pdfBytes);
    const notice10 = await page.$eval('#printNotice', (el) => ({ hidden: el.hidden, info: el.classList.contains('is-info'), text: el.textContent }));
    check(!notice10.hidden && notice10.info && /enregistr\u00e9 en PDF/.test(notice10.text), 'message informatif « enregistre en PDF »', notice10);
    check(!(await page.$eval('#viewerRoot', (el) => /is-printing/.test(el.className))), 'etat d\'impression retire malgre le blocage');
    await page.screenshot({ path: path.join(OUT, 'print-07-bloque.png') });
    await page.click('#printBtn');
    await sleep(50);
    check(await page.$eval('#printNotice', (el) => el.hidden), 'ouverture du menu efface le message');
    await page.keyboard.press('Escape');
    await page.evaluate(() => { window.__printBlocked = false; });
    // Appel direct du repli (mode vue), hors blocage.
    await page.click('#zoomInBtn');
    await sleep(50);
    const viewName = await page.evaluate(() => MyPnPlanViewerV2NS.exportPlanPdf('view'));
    const dl2 = await page.evaluate(() => window.__downloads);
    check(typeof viewName === 'string' && dl2.length === 2 && dl2[1].name === viewName, 'NS.exportPlanPdf(\'view\') : second PDF', { viewName, dl2 });
    await page.click('#zoomResetBtn');

    console.log('\n11. Cle showPrintButton: false');
    await page.evaluate((cfg) => window.__pushConfig(Object.assign({}, cfg, { showPrintButton: false })), CONFIG);
    await sleep(300);
    await selectNode(2);
    check(!(await page.$eval('#zoomToolbar', (el) => el.hidden)), 'barre de zoom affichee');
    check(await page.$eval('#printBtn', (el) => el.hidden), 'bouton imprimante masque par showPrintButton=false');
    check(await page.evaluate(() => MyPnPlanViewerV2NS.state.currentConfig.showPrintButton === false), 'cle normalisee a false');
    await page.evaluate((cfg) => window.__pushConfig(Object.assign({}, cfg, { showPrintButton: 'true' })), CONFIG);
    await sleep(300);
    check(await page.$eval('#zoomToolbar', (el) => el.hidden), 'objet reconstruit (aucune selection)');
    await selectNode(2);
    check(!(await page.$eval('#printBtn', (el) => el.hidden)), 'bouton de retour avec showPrintButton "true" (chaine)');

    console.log('\n12. Erreurs de page');
    check(errors.length === 0, 'aucune erreur console/page', errors);

    console.log('\n' + passed + ' OK, ' + failed + ' FAIL');
    if (keep) { console.log('Chrome laisse ouvert (--keep) ; Ctrl+C pour terminer.'); await new Promise(() => {}); }
  } finally {
    if (!keep) await browser.close();
    server.kill();
  }
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error(e); process.exit(1); });
