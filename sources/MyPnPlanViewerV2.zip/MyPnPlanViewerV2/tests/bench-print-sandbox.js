/* Banc de l'impression en VRAI bac a sable (viewer-print.js, repli PDF) :
   tests/sandbox-host.html insere index.html dans un iframe
   sandbox="allow-forms allow-scripts allow-downloads", exactement comme le
   serveur d'IHM Web Panorama. window.print() y est reellement ignore par
   Chrome : l'objet doit generer un PDF du plan et le telecharger
   (allow-downloads). Les telechargements sont captures par le protocole
   DevTools dans tests/out/.
     node tests/bench-print-sandbox.js [--keep]
   Pre-requis : Chrome local, puppeteer-core (scratchpad), tests/server.js. */
'use strict';
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');

const PORT = 8172;
const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const PUPPETEER_DIRS = [
  require('path').join(process.env.VD4_BANCS || require('path').resolve(__dirname, '..', '..', '..', '.bancs', 'node_modules'), 'puppeteer-core'),
  'C:/Users/F676A~1.LAI/AppData/Local/Temp/claude/c--Projets-VisioDEF4-Sources-Vd4AppCU-WEB/303017af-1d6a-4ea9-a752-4071fc9cf83b/scratchpad/node_modules/puppeteer-core',
  'C:/Users/F676A~1.LAI/AppData/Local/Temp/claude/c--Projets-VisioDEF4-Sources-Vd4AppCU-WEB/23caafc4-c6d7-44c1-a48b-1cc65de36ef9/scratchpad/node_modules/puppeteer-core',
];
let puppeteer = null;
for (const dir of PUPPETEER_DIRS) {
  try { puppeteer = require(dir); break; } catch (e) { /* suivant */ }
}
if (!puppeteer) { console.error('puppeteer-core introuvable'); process.exit(2); }

const OUT = path.join(__dirname, 'out');
fs.mkdirSync(OUT, { recursive: true });
for (const f of fs.readdirSync(OUT)) if (/^plan-.*\.pdf$/.test(f)) fs.unlinkSync(path.join(OUT, f));

const CONFIG = {
  title: 'Site Sud',
  shapeEditing: true,
  tree: [
    { id: 1, label: 'Site Sud',
      plans: [{ filename: 'Images/plan_site_hopital_face_nu.svg', label: 'Vue du site' }],
      nodes: [
        { id: 2, label: 'B\u00e2timent A',
          plans: [{ filename: 'Images/planA.jpg', label: 'Plan du b\u00e2timent',
            scale: { value: 120, unit: 'm' },
            layers: [{ label: 'Zone \u00e0 risque', kind: 'image', filename: 'Images/planA-zone-risque.png' }] }] },
      ] },
  ],
};

let passed = 0, failed = 0;
function check(cond, label, detail) {
  if (cond) { passed++; console.log('  OK   ' + label); }
  else { failed++; console.log('  FAIL ' + label + (detail !== undefined ? ' -> ' + JSON.stringify(detail) : '')); }
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function pdfInfo(file) {
  const buf = fs.readFileSync(file);
  const txt = buf.toString('latin1');
  const box = /MediaBox\s*\[\s*0\s+0\s+([\d.]+)\s+([\d.]+)\s*\]/.exec(txt);
  return {
    size: buf.length,
    header: buf.slice(0, 5).toString('latin1'),
    pages: (txt.match(/\/Type\s*\/Page[^s]/g) || []).length,
    w: box ? parseFloat(box[1]) : 0,
    h: box ? parseFloat(box[2]) : 0,
    jpeg: /\/Filter\s*\/DCTDecode/.test(txt),
  };
}

async function main() {
  const keep = process.argv.includes('--keep');
  const server = spawn(process.execPath, [path.join(__dirname, 'server.js'), String(PORT)], { stdio: 'inherit' });
  await sleep(600);

  const browser = await puppeteer.launch({ executablePath: CHROME, headless: !keep, args: ['--no-sandbox'] });
  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1400, height: 900 });
    const errors = [];
    page.on('pageerror', (e) => errors.push(String(e)));
    // (le refus de window.open, teste plus bas, est attendu)
    page.on('console', (m) => { if (m.type() === 'error' && !/favicon|allow-popups/.test(m.text())) errors.push(m.text()); });
    // Configuration poussee par le bouchon Panorama : dans TOUS les cadres.
    await page.evaluateOnNewDocument((cfg) => { window.__initialConfig = cfg; }, CONFIG);

    // Capture des telechargements (protocole DevTools).
    const downloads = [];
    const client = await page.target().createCDPSession();
    await client.send('Browser.setDownloadBehavior', { behavior: 'allow', downloadPath: OUT, eventsEnabled: true });
    client.on('Browser.downloadWillBegin', (e) => downloads.push({ guid: e.guid, name: e.suggestedFilename, state: 'begin' }));
    client.on('Browser.downloadProgress', (e) => {
      const d = downloads.find((x) => x.guid === e.guid);
      if (d) d.state = e.state;
    });
    const waitDownload = async (n, ms) => {
      const t0 = Date.now();
      while (Date.now() - t0 < ms) {
        if (downloads.filter((d) => d.state === 'completed').length >= n) return true;
        await sleep(100);
      }
      return false;
    };

    console.log('\n1. Hote en bac a sable (sandbox="allow-forms allow-scripts allow-downloads")');
    await page.goto('http://localhost:' + PORT + '/tests/sandbox-host.html', { waitUntil: 'networkidle0' });
    const frame = page.frames().find((f) => /\/index\.html$/.test(f.url()));
    check(Boolean(frame), 'iframe de l\'objet trouve', page.frames().map((f) => f.url()));
    await frame.waitForFunction(() => window.MyPnPlanViewerV2NS && MyPnPlanViewerV2NS.state.currentConfig.tree.length > 0, { timeout: 15000 });
    const env = await frame.evaluate(() => ({
      origin: String(window.origin), sandboxed: MyPnPlanViewerV2NS.isPrintSandboxed(),
      pdfLib: typeof window.PDFLib === 'object', opened: (() => { try { return window.open('about:blank') !== null; } catch (e) { return 'erreur'; } })(),
    }));
    check(env.origin === 'null', 'origine opaque "null" dans le bac a sable', env);
    check(env.sandboxed === true, 'NS.isPrintSandboxed() vrai', env);
    // pdf-lib n'est plus charge par index.html : viewer-loader.js le demande
    // au premier PDF produit (etape 4). L'enjeu est qu'un <script> injecte
    // passe dans le bac a sable, ou fetch et XHR sont refuses.
    check(env.pdfLib === false, 'pdf-lib PAS charge au demarrage (chargement differe)', env);
    check(env.opened === false, 'window.open refuse (pas de allow-popups)', env);

    console.log('\n2. Selection du plan 2D (noeud 2)');
    await frame.click('#drawerBtn');
    await sleep(350);
    await frame.click('.row[data-id="1"] .caret');
    await sleep(100);
    await frame.click('.row[data-id="2"]');
    await frame.waitForFunction(() => /planA/.test(document.getElementById('planImage').src) && document.getElementById('planImage').complete && document.getElementById('planImage').naturalWidth > 0);
    await sleep(300);
    check(!(await frame.$eval('#printBtn', (el) => el.hidden)), 'bouton imprimante affiche');
    // Un capteur en alarme et un sans image, pour le raster.
    await frame.evaluate(() => {
      const NS = MyPnPlanViewerV2NS;
      NS.applyElements(JSON.stringify({ node_id: 2, planIndex: 1, elements: [
        { id: 1001, label: 'D1', x: 0.3, y: 0.3, icon: 'Images/elements/detecteur.png', size: 28 },
        { id: 1002, label: 'D2', x: 0.6, y: 0.5 },
      ] }));
      NS.applyEvents(JSON.stringify({ events: [{ id: 1, element_id: 1001, node_id: 2, priority: 1, color: 'red', count: 1 }] }));
    }).catch(() => {});

    console.log('\n3. Menu : indication du repli PDF');
    await frame.click('#printBtn');
    await sleep(80);
    const hint = await frame.$eval('#printMenuHint', (el) => el.textContent);
    check(/PDF/.test(hint), 'indication « le plan sera enregistre en PDF »', hint);
    await page.screenshot({ path: path.join(OUT, 'sandbox-01-menu.png') });

    console.log('\n4. « Plan entier » -> PDF telecharge');
    await frame.click('#printMenuFull');
    const got1 = await waitDownload(1, 30000);
    check(got1, 'un telechargement termine', downloads);
    const d1 = downloads[0] || {};
    check(/^plan-site-sud-batiment-a-\d{8}-\d{4}\.pdf$/.test(d1.name || ''), 'nom du fichier plan-<chemin>-<date>.pdf', d1.name);
    const f1 = path.join(OUT, d1.name || 'x');
    const i1 = fs.existsSync(f1) ? pdfInfo(f1) : null;
    check(i1 && i1.header === '%PDF-' && i1.size > 20000, 'fichier PDF valide (' + (i1 ? i1.size : 0) + ' octets)', i1);
    check(i1 && i1.pages === 1 && i1.jpeg, 'une page, image JPEG embarquee', i1);
    const pdfLibApres = await frame.evaluate(() => typeof window.PDFLib === 'object');
    check(pdfLibApres, 'pdf-lib charge a la demande dans le bac a sable', pdfLibApres);
    check(i1 && i1.w < i1.h, 'planA.jpg (portrait) : page A4 portrait', i1);
    const notice1 = await frame.$eval('#printNotice', (el) => ({ hidden: el.hidden, info: el.classList.contains('is-info'), text: el.textContent }));
    check(!notice1.hidden && notice1.info && /enregistr\u00e9 en PDF/.test(notice1.text) && notice1.text.indexOf(d1.name) >= 0, 'message informatif avec le nom du fichier', notice1);
    check(!(await frame.$eval('#viewerRoot', (el) => /is-printing/.test(el.className))), 'aucun etat d\'impression residuel');
    await page.screenshot({ path: path.join(OUT, 'sandbox-02-pdf.png') });

    console.log('\n5. « Vue affichee » apres zoom -> PDF paysage');
    await frame.click('#zoomInBtn');
    await frame.click('#zoomInBtn');
    await sleep(80);
    await frame.click('#printBtn');
    await sleep(80);
    check(!(await frame.$eval('#printMenuView', (el) => el.disabled)), '« Vue affichee » active');
    await frame.click('#printMenuView');
    const got2 = await waitDownload(2, 30000);
    check(got2, 'second telechargement termine', downloads);
    const d2 = downloads[1] || {};
    const f2 = path.join(OUT, d2.name || 'x');
    const i2 = fs.existsSync(f2) ? pdfInfo(f2) : null;
    check(i2 && i2.header === '%PDF-' && i2.pages === 1, 'second PDF valide', i2);
    check(i2 && i2.w > i2.h, 'cadre ecran (paysage) : page A4 paysage', i2);
    check(await frame.evaluate(() => MyPnPlanViewerV2NS.getZoomState().zoom > 1.6), 'zoom conserve');

    console.log('\n6. Erreurs de page');
    check(errors.length === 0, 'aucune erreur console/page', errors);

    console.log('\n' + passed + ' OK, ' + failed + ' FAIL');
    if (keep) { console.log('Chrome laisse ouvert (--keep) ; Ctrl+C pour terminer.'); await new Promise(() => {}); }
  } finally {
    if (!keep) await browser.close();
    server.kill();
  }
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error(e); process.exit(1); });
