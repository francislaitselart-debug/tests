/* Serveur HTTP de test de MyPnPlanViewerV2 : sert le dossier de l'objet et
   un bouchon de la bibliotheque Panorama sous
   /static/fr/pn-insertable-object-lib.umd.js (chemin charge par index.html).
   Le bouchon pousse window.__initialConfig dans configuration_plan_json a
   l'abonnement et journalise les ecritures de l'objet dans window.__writes.
     node tests/server.js [port]      (defaut 8171) */
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const PORT = Number(process.argv[2]) || 8171;

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml',
  '.obj': 'text/plain', '.txt': 'text/plain; charset=utf-8',
};

const STUB = `(function (global) {
  'use strict';
  var listeners = [];
  global.__writes = [];
  function PanoInterface() {}
  PanoInterface.prototype.addEventListener = function (type, cb) {
    if (type === 'properties') listeners.push(cb);
  };
  PanoInterface.prototype.subscribeProperties = function (names) {
    setTimeout(function () {
      listeners.forEach(function (cb) {
        cb({ properties: names.map(function (n) {
          return { name: n, value: n === 'configuration_plan_json'
            ? JSON.stringify(global.__initialConfig || {}) : '' };
        }) });
      });
    }, 0);
    return Promise.resolve(true);
  };
  PanoInterface.prototype.writeProperty = function (name, value) {
    global.__writes.push({ name: name, value: value });
    return Promise.resolve(true);
  };
  global.__pushConfig = function (cfg) {
    listeners.forEach(function (cb) {
      cb({ properties: [{ name: 'configuration_plan_json', value: JSON.stringify(cfg) }] });
    });
  };
  global['pn-insertable-object-lib'] = { PanoInterface: PanoInterface };
})(globalThis);`;

http.createServer((req, res) => {
  const url = decodeURIComponent(req.url.split('?')[0]);
  if (url === '/static/fr/pn-insertable-object-lib.umd.js') {
    res.writeHead(200, { 'Content-Type': TYPES['.js'] });
    res.end(STUB);
    return;
  }
  if (url === '/favicon.ico') { res.writeHead(204); res.end(); return; }
  const file = path.join(ROOT, url === '/' ? 'index.html' : url);
  if (!file.startsWith(ROOT) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    console.log('404', url);
    res.writeHead(404); res.end('404 ' + url); return;
  }
  // Comme Servin (fichiers statiques) : autorise les lectures CORS depuis
  // l'origine opaque d'un iframe sandbox (canvas du repli PDF, masques CSS).
  res.writeHead(200, { 'Content-Type': TYPES[path.extname(file).toLowerCase()] || 'application/octet-stream',
    'Access-Control-Allow-Origin': '*' });
  fs.createReadStream(file).pipe(res);
}).listen(PORT, () => console.log('MyPnPlanViewerV2 test server : http://localhost:' + PORT + '/'));
