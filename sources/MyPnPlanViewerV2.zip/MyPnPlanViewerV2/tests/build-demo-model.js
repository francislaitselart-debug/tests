// Genere Images/RB_SP_MD_011.obj.js : le modele 3D de demonstration enregistre
// dans window.ThreeViewerModels sous forme de texte, pour demo.html ouverte en
// double-clic (file://). Le navigateur refuse alors tout fetch/XHR de fichier
// local (CORS), mais accepte une balise <script> : three-viewer.js charge ce
// .obj.js a la demande au lieu du .obj. Sous Panorama (HTTP), le .obj est lu
// directement et ce fichier n'est pas utilise.
// Les coordonnees sont arrondies a 4 decimales et les commentaires retires
// (45 Mo -> ~ 30 Mo, sans effet visible sur le rendu).
// Usage : node tests/build-demo-model.js [Images/autre.obj]
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const rel = (process.argv[2] || 'Images/RB_SP_MD_011.obj').replace(/\\/g, '/');
const src = path.join(ROOT, rel);
const out = src + '.js';

const lines = fs.readFileSync(src, 'latin1').split(/\r?\n/);
const kept = [];
for (const line of lines) {
  if (!line || line[0] === '#') continue;
  if (/^v[nt]? /.test(line)) {
    kept.push(line.split(/\s+/).map((t, i) => (i === 0 ? t : String(Math.round(parseFloat(t) * 1e4) / 1e4))).join(' '));
  } else {
    kept.push(line.trim());
  }
}
const text = kept.join('\n');
const js = '/* GENERE par tests/build-demo-model.js a partir de ' + rel + ' : modele 3D de\n' +
  '   demonstration pour demo.html en file:// (voir three-viewer.js). */\n' +
  '(window.ThreeViewerModels = window.ThreeViewerModels || {})[' + JSON.stringify(rel) + '] = ' +
  JSON.stringify(text) + ';\n';
fs.writeFileSync(out, js, 'utf8');
console.log(path.basename(out) + ' : ' + kept.length + ' lignes, ' + Math.round(js.length / 1048576) + ' Mo');
