// Genere three-viewer.bundle.js : un SCRIPT CLASSIQUE (pas de module ES)
// regroupant Three.js (vendor/three/build/three.module.min.js), les modules
// d'exemple utilises (BufferGeometryUtils, OBJLoader, GLTFLoader,
// OrbitControls) et three-viewer.js. Un module ES ne peut pas etre charge
// depuis file:// (demo.html en double-clic) : le bundle, lui, fonctionne
// partout, y compris sous Panorama/Servin, sans import map.
// Aucun bundler externe : les "import ... from ..." deviennent des lectures
// de window.THREE et les "export" des affectations dessus (les modules
// d'exemple sont donc exposes sur window.THREE, comme le coeur).
// A relancer apres toute modification de three-viewer.js ou de vendor/three.
// Usage : node tests/build-three-bundle.js
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const OUT = path.join(ROOT, 'three-viewer.bundle.js');
const read = (rel) => fs.readFileSync(path.join(ROOT, rel), 'utf8').replace(/^﻿/, '');

/* Three.js minifie : un unique "export{a as B,...};" en fin de fichier. */
function threeCore() {
  const src = read('vendor/three/build/three.module.min.js');
  if (/import\s*\(|import\.meta|^\s*import\s/m.test(src)) throw new Error('three.module.min.js : import inattendu');
  const m = src.match(/export\s*\{([^}]*)\}\s*;?\s*$/);
  if (!m) throw new Error('three.module.min.js : export final introuvable');
  const body = src.slice(0, m.index);
  const pairs = m[1].split(',').map((s) => s.trim()).filter(Boolean).map((s) => {
    const p = s.split(/\s+as\s+/);
    return p.length === 2 ? p[1] + ':' + p[0] : s + ':' + s;
  });
  return '(function(){\n' + body + '\nwindow.THREE={' + pairs.join(',') + '};\n})();\n';
}

/* Module ES (exemple Three.js ou three-viewer.js) -> IIFE classique :
   - "import { a, b as c } from '...'"  -> "const { a, b: c } = window.THREE;"
   - "import * as THREE from 'three'"   -> "const THREE = window.THREE;"
   - "export { a, b }"                  -> "window.THREE.a = a; ..."
   - "export function f" / "export class C" -> declaration + affectation.
   names : exports attendus (verification). */
function toClassic(rel, names) {
  let src = read(rel);
  const exported = [];
  src = src.replace(/import\s+\*\s+as\s+THREE\s+from\s+['"][^'"]+['"]\s*;?/g, 'const THREE = window.THREE;');
  src = src.replace(/import\s*\{([^}]*)\}\s*from\s*['"][^'"]+['"]\s*;?/g, (all, list) => {
    const items = list.split(',').map((s) => s.trim()).filter(Boolean).map((s) => {
      const p = s.split(/\s+as\s+/);
      return p.length === 2 ? p[0] + ': ' + p[1] : s;
    });
    return 'const { ' + items.join(', ') + ' } = window.THREE;';
  });
  src = src.replace(/export\s*\{([^}]*)\}\s*;?/g, (all, list) => {
    const items = list.split(',').map((s) => s.trim()).filter(Boolean);
    return items.map((s) => {
      const p = s.split(/\s+as\s+/);
      const local = p[0], name = p.length === 2 ? p[1] : p[0];
      exported.push(name);
      return 'window.THREE.' + name + ' = ' + local + ';';
    }).join('\n');
  });
  src = src.replace(/export\s+(function|class|const|let)\s+([A-Za-z0-9_$]+)/g, (all, kw, name) => {
    exported.push(name);
    return kw + ' ' + name;
  });
  if (/^\s*import\s|^\s*export\s/m.test(src)) throw new Error(rel + ' : import/export restant');
  // Declarations "export function" : affectees en fin de module.
  const tail = exported.map((n) => 'window.THREE.' + n + ' = ' + n + ';').join('\n');
  for (const n of names || []) {
    if (!exported.includes(n)) throw new Error(rel + ' : export ' + n + ' introuvable');
  }
  return '(function(){\n' + src + '\n' + tail + '\n})();\n';
}

const header = '/* three-viewer.bundle.js - GENERE par tests/build-three-bundle.js, ne pas' +
  ' editer a la main.\n   Three.js r160 (MIT, vendor/three/LICENSE) + BufferGeometryUtils +' +
  ' OBJLoader + GLTFLoader + OrbitControls\n   + three-viewer.js, en script classique' +
  ' (charge par index.html et demo.html, sans module ES). */\n';
const out = header + threeCore() +
  toClassic('vendor/three/examples/jsm/utils/BufferGeometryUtils.js', ['toTrianglesDrawMode']) +
  toClassic('vendor/three/examples/jsm/loaders/OBJLoader.js', ['OBJLoader']) +
  toClassic('vendor/three/examples/jsm/loaders/GLTFLoader.js', ['GLTFLoader']) +
  toClassic('vendor/three/examples/jsm/controls/OrbitControls.js', ['OrbitControls']) +
  toClassic('three-viewer.js', []);
fs.writeFileSync(OUT, out, 'utf8');
console.log('three-viewer.bundle.js : ' + out.length + ' car.');
