﻿/* ============================================================
   MyPnPlanViewerV2 — module « edit-tools »
   ============================================================
   Barre d'outils, cadenas d'activation et interactions au pointeur et au
   clavier du mode d'édition. La barre se déplace à la souris par sa
   poignée (position retenue dans ed.toolbarPos, bornée à la zone des
   plans) ; ses boutons ne montrent que leur icône, le libellé s'affichant
   en info-bulle au survol (app.css). Trois familles d'outils :

     - au clic (label, icon, pin) : la forme est posée puis sélectionnée.
       L'outil « icône » ouvre d'abord une galerie de vignettes (clé
       editIcons) où choisir visuellement l'image à poser ;
     - au cliquer-glisser (rect, ellipse, sector, line, arrow, measure,
       scale, callout) : aperçu pendant le glisser, forme créée au
       relâchement. Ctrl GAUCHE maintenu contraint l'ellipse en cercle, le
       rectangle en carré, et l'angle des tracés en ligne (ligne, flèche,
       cote, étalon) sur un multiple de 45° — au tracé comme à
       l'ajustement par poignée. L'étalon d'échelle (scale) est unique par
       plan : le nouveau remplace l'ancien, et sa longueur réelle est
       saisie dans le panneau (section « Échelle ») ;
     - au clic par sommet (polygon, polyline) : fermeture/fin par
       double-clic, Entrée, ou clic sur le premier sommet (polygone) ;
       Ctrl GAUCHE contraint de même chaque segment sur le précédent.

   La forme sélectionnée s'ajuste par ses poignées (codes posés par
   viewer-edit-render.js), se tourne par sa poignée de rotation (glisser
   autour du pivot ; Ctrl GAUCHE : angle contraint sur un multiple de
   15° ; géométrie rejouée depuis l'état de départ à chaque mouvement,
   cf. NS.rotateShape) et se supprime par le bouton de la barre ou la
   touche Suppr. Les poignées de coins d'un rectangle tourné et de
   demi-axes d'une ellipse tournée travaillent dans le repère de la forme
   (le coin d'ancrage opposé reste immobile à l'écran). Complète
   viewer-edit-core.js (ordre : readme § 1).

   NOTE ENCODAGE : chaînes affichées en ASCII pur (\uXXXX), commentaires
   accentués, BOM UTF-8, fins de ligne CRLF (readme.txt § 14).
   ============================================================ */
(function (global) {
  'use strict';

  const NS = global.MyPnPlanViewerV2NS = global.MyPnPlanViewerV2NS || {};
  const ed = NS.edit;
  const state = NS.state;
  const clampNum = NS.clampNum;

  // Familles d'outils (cf. en-tête).
  const CLICK_TOOLS = ['label', 'icon', 'pin'];
  const VERTEX_TOOLS = ['polygon', 'polyline'];

  // Marge minimale entre la barre d'outils, déplaçable par sa poignée, et
  // les bords de la zone des plans (px) : la barre reste toujours
  // entièrement visible.
  const TOOLBAR_MARGIN = 8;

  /* Dimensions écran du plan (px), zoom compris (rect) et hors zoom
     (offset) — cf. viewer-plan.js pour la convention. */
  function planRect() {
    return NS.dom.planImage.getBoundingClientRect();
  }

  /* ---------------- Cadenas d'activation et barre d'outils --------------- */

  function updateLockUi() {
    const lock = NS.dom.shapeEditLock;
    lock.classList.toggle('unlocked', ed.unlocked);
    lock.setAttribute('aria-pressed', String(ed.unlocked));
    const scene3d = typeof NS.sceneEditAvailable === 'function' && NS.sceneEditAvailable();
    lock.title = (ed.unlocked ? 'Verrouiller l\u2019\u00e9dition ' : 'Activer l\u2019\u00e9dition ') +
      (scene3d ? 'de la sc\u00e8ne 3D' : 'de formes');
  }

  /* Recharge le cadenas, la barre et les formes du plan courant. Appelé à
     chaque changement de représentation, d'emplacement, de configuration
     ou d'état du cadenas. Les formes mémorisées sont rechargées dès que le
     mode est DISPONIBLE : elles restent affichées cadenas fermé. */
  function refreshShapeEditing() {
    const { shapeEditToolbar, shapeEditLock, planViewport } = NS.dom;
    ed.draft = null;
    ed.drag = null;
    ed.selected = null;

    // Représentation 3D : le cadenas et la barre sont partagés avec le mode
    // d'édition de la scène 3D (viewer-scene3d.js) ; la barre bascule sur
    // ses outils 3D par la classe mode-3d (app.css).
    const scene3d = typeof NS.sceneEditAvailable === 'function' && NS.sceneEditAvailable();
    shapeEditLock.hidden = !(NS.editAvailable() || scene3d);
    shapeEditToolbar.classList.toggle('mode-3d', scene3d);
    updateLockUi();
    // Les formes du plan sont chargées dès qu'il est affiché — clé
    // shapeEditing ou non : celles reçues de l'application s'affichent
    // aussi hors mode édition (readme § 10).
    if (NS.shapesAvailable()) {
      const key = NS.drawnShapesKey();
      let list = ed.store.get(key);
      if (!list) {
        list = [];
        ed.store.set(key, list);
      }
      ed.shapes = list;
    }

    if (!NS.editActive()) {
      // Scène 3D en édition : la barre reste affichée, avec ses outils 3D.
      shapeEditToolbar.hidden = !(scene3d && ed.unlocked);
      closeIconPicker();
      planViewport.classList.remove('shape-drawing');
      NS.renderEditLayer();
      if (!shapeEditToolbar.hidden) applyToolbarPos();
      if (typeof NS.refreshScene3dEditing === 'function') NS.refreshScene3dEditing();
      return;
    }
    shapeEditToolbar.hidden = false;
    // La barre est mesurable une fois affichée : sa position déplacée peut
    // être bornée à la zone des plans.
    applyToolbarPos();
    setEditTool('select');
    if (typeof NS.refreshScene3dEditing === 'function') NS.refreshScene3dEditing();
  }

  function setEditTool(tool) {
    const { shapeEditToolbar, planViewport } = NS.dom;
    ed.tool = tool;
    ed.draft = null;
    if (tool !== 'select') ed.selected = null;
    for (const btn of shapeEditToolbar.querySelectorAll('button[data-tool]')) {
      btn.classList.toggle('active', btn.dataset.tool === tool);
    }
    // L'outil « icône » ouvre la galerie de choix visuel de l'image ; tout
    // autre outil la referme.
    if (tool === 'icon') openIconPicker();
    else closeIconPicker();
    planViewport.classList.toggle('shape-drawing',
      NS.editActive() && tool !== 'select');
    NS.renderEditLayer();
  }

  NS.dom.shapeEditLock.addEventListener('click', () => {
    ed.unlocked = !ed.unlocked;
    // Un bouton focalisé re-cliquerait sur Entrée/Espace au prochain appui.
    NS.dom.shapeEditLock.blur();
    refreshShapeEditing();
  });

  /* ---------------- Déplacement de la barre d'outils --------------------- */

  /* Applique la position retenue par l'opérateur (ed.toolbarPos, en pixels
     depuis le coin haut-gauche de la zone des plans), bornée pour que la
     barre reste entièrement dans la zone — y compris après un
     redimensionnement de la fenêtre. Sans position retenue, la barre garde
     son placement par défaut (centrée en haut, cf. app.css). */
  function applyToolbarPos() {
    const bar = NS.dom.shapeEditToolbar;
    const pos = ed.toolbarPos;
    if (!pos) {
      bar.classList.remove('moved', 'tip-above');
      bar.style.left = '';
      bar.style.top = '';
      return;
    }
    // Barre masquée : offsetWidth vaut 0 et le bornage n'aurait pas de
    // sens ; la position sera appliquée à la réouverture du cadenas.
    const bw = bar.offsetWidth, bh = bar.offsetHeight;
    if (!bw || !bh) return;
    const zone = NS.dom.planZone.getBoundingClientRect();
    pos.x = clampNum(pos.x, TOOLBAR_MARGIN,
      Math.max(TOOLBAR_MARGIN, zone.width - bw - TOOLBAR_MARGIN));
    pos.y = clampNum(pos.y, TOOLBAR_MARGIN,
      Math.max(TOOLBAR_MARGIN, zone.height - bh - TOOLBAR_MARGIN));
    bar.classList.add('moved');
    bar.style.left = pos.x + 'px';
    bar.style.top = pos.y + 'px';
    // Barre descendue dans la zone : les info-bulles des outils basculent
    // au-dessus pour ne pas sortir du cadre.
    bar.classList.toggle('tip-above', pos.y + bh > zone.height * 0.6);
  }

  /* Glisser de la barre par sa poignée. Le pointeur est capturé par la
     poignée : le tracé et le déplacement du plan ne sont pas concernés
     (stopPropagation), et le glisser survit à une sortie de la barre. */
  let toolbarDrag = null;

  NS.dom.shapeToolbarGrip.addEventListener('pointerdown', (e) => {
    const bar = NS.dom.shapeEditToolbar;
    const zone = NS.dom.planZone.getBoundingClientRect();
    const rect = bar.getBoundingClientRect();
    toolbarDrag = {
      zone,
      dx: e.clientX - rect.left,
      dy: e.clientY - rect.top,
    };
    ed.toolbarPos = { x: rect.left - zone.left, y: rect.top - zone.top };
    bar.classList.add('dragging');
    NS.dom.shapeToolbarGrip.setPointerCapture(e.pointerId);
    e.preventDefault();
    e.stopPropagation();
    applyToolbarPos();
  });

  NS.dom.shapeToolbarGrip.addEventListener('pointermove', (e) => {
    if (!toolbarDrag) return;
    ed.toolbarPos = {
      x: e.clientX - toolbarDrag.zone.left - toolbarDrag.dx,
      y: e.clientY - toolbarDrag.zone.top - toolbarDrag.dy,
    };
    applyToolbarPos();
    positionIconPicker(); // la galerie d'images suit la barre
  });

  function endToolbarDrag() {
    if (!toolbarDrag) return;
    toolbarDrag = null;
    NS.dom.shapeEditToolbar.classList.remove('dragging');
  }
  NS.dom.shapeToolbarGrip.addEventListener('pointerup', endToolbarDrag);
  NS.dom.shapeToolbarGrip.addEventListener('pointercancel', endToolbarDrag);

  /* Zone des plans redimensionnée : la barre déplacée est ramenée dans le
     cadre, et la galerie d'images repositionnée sous elle. */
  function syncFloatingUi() {
    applyToolbarPos();
    positionIconPicker();
  }
  if (typeof ResizeObserver === 'function') {
    new ResizeObserver(syncFloatingUi).observe(NS.dom.planZone);
  } else {
    window.addEventListener('resize', syncFloatingUi);
  }

  /* ------- Galerie de choix visuel de l'outil « icône / image » ---------- */

  /* (Re)construit les vignettes de la clé editIcons. Un clic retient
     l'image : c'est elle que posera le prochain clic sur le plan. */
  function buildIconPicker() {
    const grid = NS.dom.shapeIconPickerGrid;
    grid.textContent = '';
    for (const icon of state.currentConfig.editIcons) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.style.backgroundImage = 'url("' + icon.filename + '")';
      btn.title = icon.label || icon.filename;
      btn.setAttribute('aria-label', btn.title);
      btn.classList.toggle('selected', icon.filename === ed.pendingIcon);
      btn.addEventListener('click', () => {
        ed.pendingIcon = icon.filename;
        buildIconPicker();
      });
      grid.appendChild(btn);
    }
  }

  /* Place la galerie sous le bouton de l'outil « icône » de la barre (ou
     au-dessus si elle déborderait en bas), sans sortir de la zone. */
  function positionIconPicker() {
    const picker = NS.dom.shapeIconPicker;
    if (picker.hidden) return;
    const zone = NS.dom.planZone.getBoundingClientRect();
    const bar = NS.dom.shapeEditToolbar.getBoundingClientRect();
    const btn = NS.dom.shapeEditToolbar.querySelector('button[data-tool="icon"]');
    const anchor = btn ? btn.getBoundingClientRect() : bar;
    const w = picker.offsetWidth, h = picker.offsetHeight;
    const x = anchor.left - zone.left + anchor.width / 2 - w / 2;
    let y = bar.bottom - zone.top + 8;
    if (y + h > zone.height - TOOLBAR_MARGIN) y = bar.top - zone.top - h - 8;
    picker.style.left = clampNum(x, TOOLBAR_MARGIN,
      Math.max(TOOLBAR_MARGIN, zone.width - w - TOOLBAR_MARGIN)) + 'px';
    picker.style.top = clampNum(y, TOOLBAR_MARGIN,
      Math.max(TOOLBAR_MARGIN, zone.height - h - TOOLBAR_MARGIN)) + 'px';
  }

  /* Ouverture à l'activation de l'outil « icône ». Sans icône déclarée
     (clé editIcons vide), il n'y a rien à proposer : la galerie reste
     fermée et le chemin libre du panneau prend le relais. */
  function openIconPicker() {
    const icons = state.currentConfig.editIcons;
    if (icons.length === 0) return;
    if (!icons.some((icon) => icon.filename === ed.pendingIcon)) {
      ed.pendingIcon = icons[0].filename;
    }
    buildIconPicker();
    NS.dom.shapeIconPicker.hidden = false;
    positionIconPicker();
  }

  function closeIconPicker() {
    NS.dom.shapeIconPicker.hidden = true;
  }

  /* --------------------- Création des formes au clic --------------------- */

  /* Apparence courante appliquée à toute forme terminée (commitShape). */
  function applyCurrentStyle(shape) {
    shape.fillColor = ed.style.fillColor;
    shape.fillOpacity = ed.style.fillOpacity;
    shape.fillNone = ed.style.fillNone;
    shape.strokeColor = ed.style.strokeColor;
    shape.strokeNone = ed.style.strokeNone;
    shape.strokeWidth = ed.style.strokeWidth;
    shape.label = '';
    shape.props = [];
  }

  /* Étalon d'échelle : un seul par plan (le nouveau remplace l'ancien).
     La longueur réelle est préremplie avec la distance mesurée selon
     l'échelle en vigueur (étalon précédent, calque ou clé scale du
     plan) — l'opérateur la corrige aussitôt dans le panneau, où le champ
     est présélectionné (pointerup). Sans échelle en vigueur, 1 « m ». */
  function prepareScaleShape(shape) {
    const scale = NS.effectiveScale();
    for (let i = ed.shapes.length - 1; i >= 0; i--) {
      if (ed.shapes[i].type === 'scale') ed.shapes.splice(i, 1);
    }
    const lenFrac = Math.hypot(shape.x2 - shape.x1,
      (shape.y2 - shape.y1) * NS.planRatio());
    shape.value = scale && lenFrac > 0
      ? Number((lenFrac * scale.value).toPrecision(3))
      : 1;
    shape.unit = scale ? scale.unit : 'm';
    shape.shown = true;
  }

  /* Ajoute la forme terminée — avec le style d'apparence courant et des
     propriétés vierges — la sélectionne et repasse sur l'outil
     « sélectionner » pour permettre son ajustement immédiat. */
  function commitShape(shape) {
    applyCurrentStyle(shape);
    if (shape.type === 'scale') prepareScaleShape(shape);
    // Identité V2 de la forme : id unique dans le plan, règle d'affichage
    // par défaut, aucune liaison (writeDrawnShapes recalcule elements pour
    // les formes fermées).
    shape.id = NS.nextShapeId();
    shape.show_mode = NS.SHAPE_SHOW_MODE_DEFAULT;
    shape.elements = [];
    ed.shapes.push(shape);
    ed.draft = null;
    ed.selected = shape;
    setEditTool('select');
    NS.writeDrawnShapes(shape);
  }

  /* Outils « au clic » : libellé, icône/image, punaise. La forme est posée
     au point cliqué avec des dimensions par défaut, puis sélectionnée —
     le panneau permet aussitôt d'en régler texte, fichier ou apparence. */
  function placeClickShape(tool, p) {
    const planImage = NS.dom.planImage;
    if (tool === 'label') {
      commitShape({
        type: 'label', x: p.x, y: p.y,
        text: 'Libell\u00e9',
        fontSize: ed.style.fontSize || 14,
        bold: ed.style.bold,
        italic: ed.style.italic,
        boxed: ed.style.boxed,
      });
      // Le texte est la raison d'être du libellé : saisie immédiate.
      NS.dom.shapeTextInput.select();
      return;
    }
    if (tool === 'icon') {
      const w = planImage.offsetWidth || 1;
      const h = planImage.offsetHeight || 1;
      const icons = state.currentConfig.editIcons;
      // Image retenue dans la galerie ouverte par l'outil ; à défaut, la
      // première déclarée par la clé editIcons.
      const filename = ed.pendingIcon ||
        (icons.length > 0 ? icons[0].filename : '');
      commitShape({
        type: 'icon',
        x: clampNum(p.x - 14 / w, 0, 1),
        y: clampNum(p.y - 14 / h, 0, 1),
        w: 28 / w,
        h: 28 / h,
        filename,
      });
      return;
    }
    // Punaise / marqueur ponctuel.
    commitShape({ type: 'pin', x: p.x, y: p.y });
  }

  /* ----------------- Tracés au cliquer-glisser (aperçu) ------------------ */

  /* Angle écran en degrés (sens horaire, 0 = est) du point p vu du centre
     c, corrigé du ratio du plan (fractions -> pixels). */
  function screenAngleDeg(c, p) {
    const rect = planRect();
    const ang = Math.atan2((p.y - c.y) * rect.height, (p.x - c.x) * rect.width);
    return (ang * 180 / Math.PI + 360) % 360;
  }

  /* Contrainte d'angle des tracés en ligne (Ctrl GAUCHE) : le point p est
     ramené sur la direction multiple de 45° la plus proche, vue de l'ancre
     a — d'où des segments parfaitement horizontaux, verticaux ou en
     diagonale, et donc perpendiculaires entre eux. Le calcul est mené en
     pixels écran (un plan n'est pas carré), la longueur du glisser est
     conservée, et le point est raccourci si la direction sort du plan. */
  function snapToAxis(a, p) {
    const rect = planRect();
    if (!rect.width || !rect.height) return p;
    const dxPx = (p.x - a.x) * rect.width;
    const dyPx = (p.y - a.y) * rect.height;
    const len = Math.hypot(dxPx, dyPx);
    if (len < 1) return p;
    const step = Math.PI / 4;
    const ang = Math.round(Math.atan2(dyPx, dxPx) / step) * step;
    // Direction unitaire, en fraction du plan par pixel écran.
    const ux = Math.cos(ang) / rect.width;
    const uy = Math.sin(ang) / rect.height;
    // Longueur maximale (px) gardant le point dans le plan (0..1 en x et y).
    let max = len;
    if (ux > 0) max = Math.min(max, (1 - a.x) / ux);
    else if (ux < 0) max = Math.min(max, -a.x / ux);
    if (uy > 0) max = Math.min(max, (1 - a.y) / uy);
    else if (uy < 0) max = Math.min(max, -a.y / uy);
    const t = Math.max(0, Math.min(len, max));
    return {
      x: clampNum(a.x + ux * t, 0, 1),
      y: clampNum(a.y + uy * t, 0, 1),
    };
  }

  /* Sommet suivant d'un polygone / d'une polyligne : contraint sur le
     sommet précédent quand Ctrl GAUCHE est maintenu. */
  function vertexPoint(p) {
    const pts = ed.draft ? ed.draft.points : null;
    return ed.ctrl && pts && pts.length > 0
      ? snapToAxis(pts[pts.length - 1], p)
      : p;
  }

  /* Forme finale d'un tracé au cliquer-glisser ; null si la forme est trop
     petite pour être volontaire (sauf en aperçu). Ctrl GAUCHE contraint
     l'ellipse en cercle, le rectangle en carré, et l'angle des tracés en
     ligne (ligne, flèche, cote, étalon). */
  function draftToShape(d, preview) {
    const rect = planRect();
    if (!rect.width || !rect.height) return null;
    const minPx = NS.MIN_SHAPE_PX;

    if (d.type === 'rect') {
      let bx = d.b.x, by = d.b.y;
      if (ed.ctrl) {
        // Carré à l'écran : le plus grand côté (en pixels) fait foi.
        const dxPx = (d.b.x - d.a.x) * rect.width;
        const dyPx = (d.b.y - d.a.y) * rect.height;
        const size = Math.max(Math.abs(dxPx), Math.abs(dyPx));
        bx = d.a.x + (dxPx < 0 ? -size : size) / rect.width;
        by = d.a.y + (dyPx < 0 ? -size : size) / rect.height;
      }
      const x = Math.min(d.a.x, bx), y = Math.min(d.a.y, by);
      const w = Math.abs(bx - d.a.x), h = Math.abs(by - d.a.y);
      if (!preview &&
          (w * rect.width < minPx || h * rect.height < minPx)) {
        return null;
      }
      return { type: 'rect', x, y, w, h };
    }

    if (d.type === 'ellipse') {
      let rx = Math.abs(d.b.x - d.a.x);
      let ry = Math.abs(d.b.y - d.a.y);
      if (ed.ctrl) {
        // Cercle à l'écran : rayon = distance du centre au pointeur.
        const rPx = NS.planPxDistance(d.a, d.b);
        rx = rPx / rect.width;
        ry = rPx / rect.height;
      }
      if (!preview &&
          (rx * rect.width < minPx || ry * rect.height < minPx)) {
        return null;
      }
      return { type: 'ellipse', cx: d.a.x, cy: d.a.y, rx, ry };
    }

    if (d.type === 'sector') {
      const rPx = NS.planPxDistance(d.a, d.b);
      if (!preview && rPx < minPx) return null;
      // Le glisser fixe le rayon et la direction ; ouverture de 60° de
      // part et d'autre, ajustable ensuite par les poignées a0/a1.
      const ang = screenAngleDeg(d.a, d.b);
      return {
        type: 'sector', cx: d.a.x, cy: d.a.y,
        r: clampNum(rPx / rect.width, 0.002, 1),
        startAngle: (ang - 30 + 360) % 360,
        endAngle: (ang + 30) % 360,
      };
    }

    if (d.type === 'line' || d.type === 'arrow' || d.type === 'measure' ||
        d.type === 'scale') {
      const b = ed.ctrl ? snapToAxis(d.a, d.b) : d.b;
      if (!preview && NS.planPxDistance(d.a, b) < minPx) return null;
      const seg = { type: d.type, x1: d.a.x, y1: d.a.y, x2: b.x, y2: b.y };
      // Sens des pointes retenu dans le panneau, repris par les flèches
      // suivantes (comme l'apparence).
      if (d.type === 'arrow') seg.heads = ed.style.arrowHeads;
      return seg;
    }

    if (d.type === 'callout') {
      let bx = d.b.x, by = d.b.y;
      // Glisser trop court : boîte posée en décalé par défaut, la pointe
      // reste sur la cible cliquée.
      if (NS.planPxDistance(d.a, d.b) < 20) {
        bx = clampNum(d.a.x + 70 / rect.width, 0, 1);
        by = clampNum(d.a.y - 50 / rect.height, 0, 1);
      }
      return {
        type: 'callout', tx: d.a.x, ty: d.a.y, x: bx, y: by,
        text: 'Commentaire',
        fontSize: ed.style.fontSize || 14,
        bold: ed.style.bold,
        italic: ed.style.italic,
      };
    }

    return null;
  }

  function commitVertexDraft() {
    const d = ed.draft;
    if (!d || VERTEX_TOOLS.indexOf(d.type) === -1) return;
    const min = d.type === 'polygon' ? 3 : 2;
    if (d.points.length < min) return;
    commitShape({ type: d.type, points: d.points });
  }

  function deleteSelectedShape() {
    const index = ed.shapes.indexOf(ed.selected);
    if (index === -1) return;
    ed.shapes.splice(index, 1);
    ed.selected = null;
    NS.renderEditLayer();
    NS.writeDrawnShapes();
  }

  /* --------------- Déplacement et ajustement par les poignées ------------ */

  /* Géométrie de départ d'un déplacement, pour appliquer le delta du
     glisser depuis l'origine (et borner par la boîte englobante). */
  function moveSnapshot(s) {
    if (s.type === 'polygon' || s.type === 'polyline') {
      const xs = s.points.map((p) => p.x);
      const ys = s.points.map((p) => p.y);
      return {
        points: s.points.map((p) => ({ x: p.x, y: p.y })),
        minX: Math.min.apply(null, xs), maxX: Math.max.apply(null, xs),
        minY: Math.min.apply(null, ys), maxY: Math.max.apply(null, ys),
      };
    }
    if (s.type === 'line' || s.type === 'arrow' || s.type === 'measure' ||
        s.type === 'scale') {
      return { x1: s.x1, y1: s.y1, x2: s.x2, y2: s.y2 };
    }
    if (s.type === 'rect' || s.type === 'icon' || s.type === 'label' ||
        s.type === 'pin' || s.type === 'callout') {
      return { x: s.x, y: s.y };
    }
    // circle, ellipse, sector : centre.
    return { cx: s.cx, cy: s.cy };
  }

  function applyMove(s, d, dx, dy) {
    if (s.type === 'rect' || s.type === 'icon') {
      s.x = clampNum(d.orig.x + dx, 0, 1 - s.w);
      s.y = clampNum(d.orig.y + dy, 0, 1 - s.h);
    } else if (s.type === 'polygon' || s.type === 'polyline') {
      const tx = clampNum(dx, -d.orig.minX, 1 - d.orig.maxX);
      const ty = clampNum(dy, -d.orig.minY, 1 - d.orig.maxY);
      s.points = d.orig.points.map((q) => ({ x: q.x + tx, y: q.y + ty }));
    } else if (s.type === 'line' || s.type === 'arrow' ||
               s.type === 'measure' || s.type === 'scale') {
      const tx = clampNum(dx, -Math.min(d.orig.x1, d.orig.x2),
        1 - Math.max(d.orig.x1, d.orig.x2));
      const ty = clampNum(dy, -Math.min(d.orig.y1, d.orig.y2),
        1 - Math.max(d.orig.y1, d.orig.y2));
      s.x1 = d.orig.x1 + tx;
      s.y1 = d.orig.y1 + ty;
      s.x2 = d.orig.x2 + tx;
      s.y2 = d.orig.y2 + ty;
    } else if (s.type === 'label' || s.type === 'pin' || s.type === 'callout') {
      // Étiquette de rappel : seule la boîte suit, la pointe reste ancrée
      // sur la cible (poignée tip pour la déplacer).
      s.x = clampNum(d.orig.x + dx, 0, 1);
      s.y = clampNum(d.orig.y + dy, 0, 1);
    } else {
      s.cx = clampNum(d.orig.cx + dx, 0, 1);
      s.cy = clampNum(d.orig.cy + dy, 0, 1);
    }
  }

  /* Copie / restauration de la géométrie d'une forme : la rotation par la
     poignée est rejouée à chaque mouvement depuis la géométrie de départ
     (pas de dérive, contrainte Ctrl absolue). Une clé absente au départ
     (rotation cumulée d'un polygone) est retirée à la restauration. */
  const GEOMETRY_KEYS = ['x', 'y', 'w', 'h', 'cx', 'cy', 'r', 'rx', 'ry',
    'x1', 'y1', 'x2', 'y2', 'startAngle', 'endAngle', 'rotation'];

  function geometrySnapshot(s) {
    const out = {};
    for (const key of GEOMETRY_KEYS) {
      if (s[key] !== undefined) out[key] = s[key];
    }
    if (s.points) out.points = s.points.map((p) => ({ x: p.x, y: p.y }));
    return out;
  }

  function restoreGeometry(s, orig) {
    for (const key of GEOMETRY_KEYS) {
      if (orig[key] !== undefined) s[key] = orig[key];
      else if (s[key] !== undefined) delete s[key];
    }
    if (orig.points) s.points = orig.points.map((p) => ({ x: p.x, y: p.y }));
  }

  function applyEditDrag(p) {
    const d = ed.drag;
    const s = ed.selected;
    if (!s) return;
    const rect = planRect();
    const dx = p.x - d.start.x;
    const dy = p.y - d.start.y;
    d.moved = true;

    if (d.kind === 'move') {
      applyMove(s, d, dx, dy);
    } else if (d.kind === 'vertex') {
      // Ctrl GAUCHE : sommet contraint sur le sommet voisin (le précédent,
      // ou le suivant pour le premier de la suite).
      let q = p;
      if (ed.ctrl && s.points.length > 1) {
        q = snapToAxis(s.points[d.index > 0 ? d.index - 1 : 1], p);
      }
      s.points[d.index] = { x: q.x, y: q.y };
    } else if (d.kind === 'corner') {
      // Rectangle tourné : le pointeur est ramené dans le repère du
      // rectangle (rotation inverse autour du centre de départ), où le
      // coin d'ancrage est fixe.
      const q = d.rot ? NS.rotatePoint(p, d.pivot, -d.rot) : p;
      let px = clampNum(q.x, 0, 1), py = clampNum(q.y, 0, 1);
      if (ed.ctrl && s.type === 'rect') {
        // Carré à l'écran depuis le coin d'ancrage.
        const dxPx = (px - d.anchor.x) * rect.width;
        const dyPx = (py - d.anchor.y) * rect.height;
        const size = Math.max(Math.abs(dxPx), Math.abs(dyPx));
        px = d.anchor.x + (dxPx < 0 ? -size : size) / rect.width;
        py = d.anchor.y + (dyPx < 0 ? -size : size) / rect.height;
      }
      s.x = Math.min(px, d.anchor.x);
      s.y = Math.min(py, d.anchor.y);
      s.w = Math.max(0.002, Math.abs(px - d.anchor.x));
      s.h = Math.max(0.002, Math.abs(py - d.anchor.y));
      if (d.rot) {
        // Le rectangle tourne autour de son propre centre, qui vient de
        // changer : il est décalé de (R - I)(C' - C) pour que le coin
        // d'ancrage reste immobile à l'écran.
        const nc = NS.rectCenter(s);
        const r = NS.rotatePoint(nc, d.pivot, d.rot);
        s.x = clampNum(s.x + r.x - nc.x, 0, 1 - s.w);
        s.y = clampNum(s.y + r.y - nc.y, 0, 1 - s.h);
      }
    } else if (d.kind === 'radius') {
      if (rect.width) {
        s.r = clampNum(
          NS.planPxDistance({ x: s.cx, y: s.cy }, p) / rect.width, 0.002, 1);
      }
    } else if (d.kind === 'axis-x' || d.kind === 'axis-y') {
      // Ellipse tournée : le pointeur est ramené dans le repère de
      // l'ellipse (rotation inverse autour du centre).
      const rot = NS.shapeRotation(s);
      const q = rot ? NS.rotatePoint(p, { x: s.cx, y: s.cy }, -rot) : p;
      if (d.kind === 'axis-x') {
        s.rx = clampNum(Math.abs(q.x - s.cx), 0.002, 1);
        if (ed.ctrl && rect.height) {
          s.ry = clampNum(s.rx * rect.width / rect.height, 0.002, 1);
        }
      } else {
        s.ry = clampNum(Math.abs(q.y - s.cy), 0.002, 1);
        if (ed.ctrl && rect.width) {
          s.rx = clampNum(s.ry * rect.height / rect.width, 0.002, 1);
        }
      }
    } else if (d.kind === 'rotate') {
      // Delta angulaire du pointeur autour du pivot depuis le début du
      // glisser, rejoué depuis la géométrie de départ. Ctrl GAUCHE :
      // angle final contraint sur un multiple de 15°.
      let delta = NS.pointAngleDeg(d.pivot, p) - d.startAngle;
      if (ed.ctrl) {
        delta = Math.round((d.baseAngle + delta) / 15) * 15 - d.baseAngle;
      }
      restoreGeometry(s, d.orig);
      NS.rotateShape(s, delta);
    } else if (d.kind === 'angle') {
      const ang = screenAngleDeg({ x: s.cx, y: s.cy }, p);
      if (d.which === 'a0') s.startAngle = ang;
      else s.endAngle = ang;
    } else if (d.kind === 'endpoint') {
      // Ctrl GAUCHE : extrémité contrainte sur l'extrémité opposée, qui ne
      // bouge pas — le segment reste droit ou perpendiculaire.
      if (d.which === 'p1') {
        const q = ed.ctrl ? snapToAxis({ x: s.x2, y: s.y2 }, p) : p;
        s.x1 = q.x;
        s.y1 = q.y;
      } else {
        const q = ed.ctrl ? snapToAxis({ x: s.x1, y: s.y1 }, p) : p;
        s.x2 = q.x;
        s.y2 = q.y;
      }
    } else if (d.kind === 'tip') {
      s.tx = p.x;
      s.ty = p.y;
    }
  }

  /* Descripteur de glisser correspondant à une poignée (dataset.handle des
     cercles posés par viewer-edit-render.js). */
  function dragFromHandle(handle, p) {
    if (handle === 'r') return { kind: 'radius', start: p, moved: false };
    if (handle === 'rx') return { kind: 'axis-x', start: p, moved: false };
    if (handle === 'ry') return { kind: 'axis-y', start: p, moved: false };
    if (handle === 'a0' || handle === 'a1') {
      return { kind: 'angle', which: handle, start: p, moved: false };
    }
    if (handle === 'p1' || handle === 'p2') {
      return { kind: 'endpoint', which: handle, start: p, moved: false };
    }
    if (handle === 'tip') return { kind: 'tip', start: p, moved: false };
    if (handle === 'rot') {
      const s = ed.selected;
      const pivot = NS.shapePivot(s);
      const angle = NS.shapeAngle(s);
      return {
        kind: 'rotate', start: p, moved: false, pivot,
        startAngle: NS.pointAngleDeg(pivot, p),
        // Angle de référence de la contrainte Ctrl (multiples de 15°) :
        // celui du panneau, ou l'angle de début du secteur.
        baseAngle: angle !== null ? angle : s.startAngle,
        orig: geometrySnapshot(s),
      };
    }
    if (handle.charAt(0) === 'v') {
      return { kind: 'vertex', index: Number(handle.slice(1)), start: p, moved: false };
    }
    if (handle.charAt(0) === 'c') {
      const s = ed.selected;
      const corners = NS.rectCorners(s);
      return {
        kind: 'corner',
        // Coin d'ancrage opposé et centre dans le repère du rectangle
        // (avant rotation) : le glisser y est ramené (applyEditDrag).
        anchor: corners[(Number(handle.slice(1)) + 2) % 4],
        pivot: NS.rectCenter(s),
        rot: NS.shapeRotation(s),
        start: p,
        moved: false,
      };
    }
    return null;
  }

  /* ---------------- Interactions au pointeur et au clavier ---------------- */
  const { planEditLayer, planViewport, shapeEditToolbar, shapeDeleteBtn } = NS.dom;

  /* Sélection et ajustement au pointeur : les formes et poignées du calque
     d'édition (seuls éléments SVG à pointer-events actifs) arrêtent la
     propagation pour ne pas déclencher le déplacement du plan ; le suivi
     du glisser est capturé par planViewport (pointermove/pointerup). Les
     formes composites (groupes <g>) sont retrouvées par closest, l'élément
     cliqué pouvant être un de leurs enfants. */
  planEditLayer.addEventListener('pointerdown', (e) => {
    if (!NS.editActive() || ed.tool !== 'select') return;
    const p = NS.planPointFromEvent(e);
    if (!p) return;
    const target = e.target;
    const handle = target.dataset ? target.dataset.handle : undefined;
    const shapeEl = target.closest ? target.closest('[data-shape-index]') : null;

    if (handle && ed.selected) {
      const drag = dragFromHandle(handle, p);
      if (!drag) return;
      ed.drag = drag;
    } else if (shapeEl) {
      ed.selected = ed.shapes[Number(shapeEl.dataset.shapeIndex)] || null;
      if (!ed.selected) return;
      ed.drag = { kind: 'move', start: p, moved: false, orig: moveSnapshot(ed.selected) };
    } else {
      return;
    }

    e.stopPropagation();
    e.preventDefault();
    ed.lastPoint = p;
    planViewport.setPointerCapture(e.pointerId);
    NS.renderEditLayer();
  });

  /* Tracé des nouvelles formes. Le déplacement du plan est suspendu pendant
     ce temps (garde dans le pointerdown de déplacement, module plan). */
  planViewport.addEventListener('pointerdown', (e) => {
    if (!NS.editActive()) return;
    if (ed.tool === 'select') {
      // Clic hors de toute forme : désélection (le plan reste déplaçable).
      if (ed.selected && !ed.drag) {
        ed.selected = null;
        NS.renderEditLayer();
      }
      return;
    }
    const p = NS.planPointFromEvent(e);
    if (!p) return;
    e.preventDefault();

    if (CLICK_TOOLS.indexOf(ed.tool) !== -1) {
      placeClickShape(ed.tool, p);
      return;
    }

    if (VERTEX_TOOLS.indexOf(ed.tool) !== -1) {
      if (!ed.draft) {
        ed.draft = { type: ed.tool, points: [p], cursor: null, cursorRaw: null };
      } else if (ed.draft.type === 'polygon' && ed.draft.points.length >= 3 &&
                 NS.planPxDistance(p, ed.draft.points[0]) < 10) {
        // Clic sur le premier sommet : ferme le polygone (pas la
        // polyligne, tracé ouvert terminé par Entrée ou double-clic).
        commitVertexDraft();
        return;
      } else {
        ed.draft.points.push(vertexPoint(p));
      }
      NS.renderEditLayer();
      return;
    }

    ed.draft = { type: ed.tool, a: p, b: p };
    ed.lastPoint = p;
    planViewport.setPointerCapture(e.pointerId);
    NS.renderEditLayer();
  });

  planViewport.addEventListener('pointermove', (e) => {
    if (ed.draft && VERTEX_TOOLS.indexOf(ed.draft.type) !== -1) {
      // Aperçu du côté suivant, du dernier sommet posé vers le curseur
      // (contraint par Ctrl GAUCHE). La position brute est conservée pour
      // réappliquer la contrainte au seul appui de la touche.
      const p = NS.planPointFromEvent(e);
      ed.draft.cursorRaw = p;
      ed.draft.cursor = p ? vertexPoint(p) : null;
      NS.renderEditLayer();
      return;
    }
    if (ed.draft) {
      const p = NS.planPointFromEvent(e);
      if (p) {
        ed.draft.b = p;
        ed.lastPoint = p;
        NS.renderEditLayer();
      }
      return;
    }
    if (!ed.drag) return;
    const p = NS.planPointFromEvent(e);
    if (!p) return;
    ed.lastPoint = p;
    applyEditDrag(p);
    NS.renderEditLayer();
  });

  planViewport.addEventListener('pointerup', () => {
    if (ed.draft && VERTEX_TOOLS.indexOf(ed.draft.type) === -1) {
      const shape = draftToShape(ed.draft, false);
      ed.draft = null;
      if (shape) {
        commitShape(shape);
        // Le commentaire est la raison d'être de l'étiquette de rappel :
        // saisie immédiate, comme pour le libellé.
        if (shape.type === 'callout') NS.dom.shapeTextInput.select();
        // La longueur réelle est la raison d'être de l'étalon d'échelle :
        // saisie immédiate de la valeur préremplie.
        if (shape.type === 'scale') NS.dom.shapeScaleValue.select();
      } else {
        NS.renderEditLayer();
      }
      return;
    }
    if (ed.drag) {
      const changed = ed.drag.moved;
      ed.drag = null;
      // Fin d'un glisser (déplacement, poignée, rotation) : géométrie de
      // la forme sélectionnée changée — sa liaison elements est recalculée.
      if (changed) NS.writeDrawnShapes(ed.selected);
    }
  });

  planViewport.addEventListener('pointercancel', () => {
    if (ed.draft && VERTEX_TOOLS.indexOf(ed.draft.type) === -1) ed.draft = null;
    ed.drag = null;
    NS.renderEditLayer();
  });

  /* Double-clic : ferme le polygone ou termine la polyligne en cours. Le
     double-clic a d'abord ajouté un sommet quasi confondu avec le
     précédent : il est retiré. */
  planViewport.addEventListener('dblclick', (e) => {
    if (!ed.draft || VERTEX_TOOLS.indexOf(ed.draft.type) === -1) return;
    e.preventDefault();
    const pts = ed.draft.points;
    if (pts.length >= 2 &&
        NS.planPxDistance(pts[pts.length - 2], pts[pts.length - 1]) < 6) {
      pts.pop();
    }
    if (pts.length >= (ed.draft.type === 'polygon' ? 3 : 2)) {
      commitVertexDraft();
    } else {
      NS.renderEditLayer();
    }
  });

  /* Ctrl GAUCHE : contraintes cercle/carré et angle des tracés en ligne,
     appliquées à la volée au tracé ou au redimensionnement en cours
     (l'aperçu suit l'appui et le relâchement de la touche sans attendre un
     mouvement de souris). */
  function refreshCtrlConstraint() {
    if (ed.draft) {
      // Polygone / polyligne : le côté suivant est recalculé depuis la
      // dernière position brute connue du curseur ; les autres tracés
      // rejouent draftToShape au redessin.
      if (VERTEX_TOOLS.indexOf(ed.draft.type) !== -1 && ed.draft.cursorRaw) {
        ed.draft.cursor = vertexPoint(ed.draft.cursorRaw);
      }
      NS.renderEditLayer();
    } else if (ed.drag && ed.lastPoint) {
      applyEditDrag(ed.lastPoint);
      NS.renderEditLayer();
    }
  }

  document.addEventListener('keydown', (e) => {
    if (!NS.editActive()) return;

    if (e.key === 'Control' && e.location === 1 && !ed.ctrl) {
      ed.ctrl = true;
      refreshCtrlConstraint();
      return;
    }

    const tag = e.target && e.target.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') return;

    if (e.key === 'Escape') {
      if (!NS.dom.shapeIconPicker.hidden) {
        // La galerie d'images se referme d'abord, l'outil reste actif.
        closeIconPicker();
      } else if (ed.draft) {
        ed.draft = null;
        NS.renderEditLayer();
      } else if (ed.selected) {
        ed.selected = null;
        NS.renderEditLayer();
      }
    } else if (e.key === 'Enter') {
      commitVertexDraft();
    } else if ((e.key === 'Delete' || e.key === 'Backspace') && !ed.drag) {
      deleteSelectedShape();
    }
  });

  document.addEventListener('keyup', (e) => {
    if (e.key === 'Control' && ed.ctrl) {
      ed.ctrl = false;
      refreshCtrlConstraint();
    }
  });

  // Fenêtre quittée pendant l'appui : la contrainte ne doit pas rester collée.
  window.addEventListener('blur', () => {
    if (!ed.ctrl) return;
    ed.ctrl = false;
    refreshCtrlConstraint();
  });

  for (const btn of shapeEditToolbar.querySelectorAll('button[data-tool]')) {
    btn.addEventListener('click', () => {
      setEditTool(btn.dataset.tool);
      // Un bouton focalisé re-cliquerait sur Entrée (fermeture d'un
      // polygone au clavier) : le focus est rendu au document.
      btn.blur();
    });
  }
  shapeDeleteBtn.addEventListener('click', deleteSelectedShape);

  /* ------------------- Exposition sur l'espace de noms ------------------- */
  NS.refreshShapeEditing = refreshShapeEditing;
  NS.setEditTool = setEditTool;
  NS.draftToShape = draftToShape;
})(globalThis);
