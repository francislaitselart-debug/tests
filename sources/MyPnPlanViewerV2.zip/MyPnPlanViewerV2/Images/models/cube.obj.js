/* GENERE par tests/build-demo-models.js : objet 3D de demonstration pour
   demo.html en file:// (voir three-viewer.js loadModel). */
(window.ThreeViewerModels = window.ThreeViewerModels || {})["Images/models/cube.obj"] = "# cube - genere par tests/build-demo-models.js\no cube\nv 0 0 0\nv 1 0 0\nv 1 0 1\nv 0 0 1\nv 0 1 0\nv 1 1 0\nv 1 1 1\nv 0 1 1\nf 1 4 3 2\nf 5 6 7 8\nf 1 2 6 5\nf 2 3 7 6\nf 3 4 8 7\nf 4 1 5 8\n";
