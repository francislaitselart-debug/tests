﻿/*!
 * MyPnSpeedDial — composant SpeedDial en JavaScript pur (sans dépendance)
 * Composant « speed dial » : bouton d'action flottant qui déploie une
 * liste d'actions, dispositions linéaires (up / down / left / right) et
 * radiales (circle, semi-circle, quarter-circle) avec rayon paramétrable,
 * apparition en cascade (transitionDelay), rotation de l'icône principale,
 * masque de fond (mask), fermeture au clic extérieur (hideOnClickOutside),
 * info-bulle par action (tooltip) et sur le bouton principal (buttonTooltip),
 * état actif par action (active : fond de couleur distinct, cf. variable
 * --mpsd-action-bg-active), événements onShow / onHide et command par
 * élément.
 *
 * Les icônes sont des PNG (noir sur transparent) teintés via CSS mask +
 * currentColor.
 *
 * Le conteneur est l'ancre : positionnez-le (absolute…) dans un parent
 * positionné ; les actions se déploient autour.
 *
 * Usage :
 *   new MyPnSpeedDial('#ancre', {
 *     items: [
 *       { icon: 'pencil', label: 'Modifier', command: () => … },
 *       { icon: 'trash',  label: 'Supprimer', command: () => … },
 *     ],
 *     direction: 'up',
 *   });
 */
(function (global) {
  'use strict';

  const DEFAULTS = {
    items: [],                 // [{ icon, label, command, disabled, active }]
    direction: 'up',           // up | down | left | right (type linear)
    type: 'linear',            // linear | circle | semi-circle | quarter-circle
    radius: 80,                // rayon (px) des dispositions radiales
    mask: false,               // voile derrière les actions (dans le parent positionné)
    visible: false,            // état initial
    hideOnClickOutside: true,
    transitionDelay: 30,       // délai en cascade entre actions (ms)
    showIcon: 'plus',          // icône bouton principal fermé
    hideIcon: 'times',         // icône bouton principal ouvert
    rotateAnimation: true,     // rotation de l'icône à l'ouverture
    buttonSize: 52,            // taille du bouton principal (px)
    actionSize: 42,            // taille des boutons d'action (px)
    spacing: 10,               // espacement entre actions (type linear)
    tooltip: null,             // position des info-bulles : left | right | top | bottom | null
    buttonTooltip: null,       // info-bulle du bouton principal (masquée quand ouvert)
    styleClass: null,
    iconPath: 'Images/',
    onShow: null,              // fn({ speeddial })
    onHide: null,              // fn({ speeddial })
  };

  class MyPnSpeedDial {
    constructor(container, options) {
      if (typeof container === 'string') container = document.querySelector(container);
      if (!container) throw new Error('MyPnSpeedDial : conteneur introuvable');
      this.container = container;
      this.options = Object.assign({}, DEFAULTS, options || {});
      this.visible = !!this.options.visible;
      this._build();
      this._onDocClick = (e) => {
        if (!this.options.hideOnClickOutside || !this.visible) return;
        if (!this.el.contains(e.target)) this.hide();
      };
      document.addEventListener('click', this._onDocClick);
    }

    /* ----------------------------- Rendu ----------------------------- */

    _icon(name, cls) {
      const s = document.createElement('span');
      s.className = cls;
      s.setAttribute('aria-hidden', 'true');
      const url = 'url("' + this.options.iconPath + name + '.png")';
      s.style.webkitMaskImage = url;
      s.style.maskImage = url;
      return s;
    }

    // Décalage (x, y) de l'action i suivant le type et la direction.
    _offset(i) {
      const o = this.options;
      const n = o.items.length;
      const step = o.actionSize + o.spacing;
      const first = o.buttonSize / 2 + o.actionSize / 2 + o.spacing;
      const dist = first + i * step;

      if (o.type === 'linear') {
        switch (o.direction) {
          case 'down': return [0, dist];
          case 'left': return [-dist, 0];
          case 'right': return [dist, 0];
          default: return [0, -dist]; // up
        }
      }

      // Dispositions radiales : répartition angulaire selon le type.
      let start, span;
      if (o.type === 'circle') {
        start = -90; span = 360 * (n - 1) / n; // répartition complète
      } else if (o.type === 'semi-circle') {
        // Demi-cercle ouvert dans la direction donnée
        const base = { up: 180, down: 0, left: 90, right: -90 }[o.direction] || 180;
        start = base; span = 180;
      } else { // quarter-circle
        const base = { up: 180, down: 0, left: 90, right: 270 }[o.direction] || 180;
        start = base; span = 90;
      }
      const angle = n > 1 ? start + (span * i) / (n - 1) : start + span / 2;
      const rad = (angle * Math.PI) / 180;
      return [Math.cos(rad) * o.radius, Math.sin(rad) * o.radius];
    }

    _build() {
      const o = this.options;
      const el = document.createElement('div');
      this.el = el;
      el.className = 'mpsd mpsd-' + o.type + ' mpsd-dir-' + o.direction
        + (o.styleClass ? ' ' + o.styleClass : '');

      // Voile optionnel dans le parent positionné du conteneur.
      if (o.mask) {
        const mask = document.createElement('div');
        mask.className = 'mpsd-mask';
        this.maskEl = mask;
        (this.container.parentElement || document.body).appendChild(mask);
      }

      // Liste des actions
      const list = document.createElement('ul');
      list.className = 'mpsd-list';
      list.setAttribute('role', 'menu');
      this.actionEls = [];
      o.items.forEach((item, i) => {
        const li = document.createElement('li');
        li.className = 'mpsd-item';
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'mpsd-action';
        btn.setAttribute('role', 'menuitem');
        btn.style.width = o.actionSize + 'px';
        btn.style.height = o.actionSize + 'px';
        if (item.label) btn.setAttribute('aria-label', item.label);
        if (item.disabled) btn.disabled = true;
        if (item.active) btn.classList.add('mpsd-action-active');
        if (item.icon) btn.appendChild(this._icon(item.icon, 'mpsd-action-icon'));
        if (item.label && o.tooltip) {
          const tip = document.createElement('span');
          tip.className = 'mpsd-tooltip mpsd-tooltip-' + o.tooltip;
          tip.textContent = item.label;
          btn.appendChild(tip);
        }
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          if (typeof item.command === 'function') item.command({ originalEvent: e, item });
          this.hide();
        });
        li.appendChild(btn);
        list.appendChild(li);
        this.actionEls.push(li);
      });
      el.appendChild(list);

      // Bouton principal
      const main = document.createElement('button');
      main.type = 'button';
      main.className = 'mpsd-button';
      main.style.width = o.buttonSize + 'px';
      main.style.height = o.buttonSize + 'px';
      main.setAttribute('aria-haspopup', 'true');
      main.setAttribute('aria-label', 'Ouvrir les actions');
      this.mainIcon = this._icon(o.showIcon, 'mpsd-button-icon');
      main.appendChild(this.mainIcon);
      if (o.buttonTooltip) {
        const tip = document.createElement('span');
        tip.className = 'mpsd-tooltip mpsd-tooltip-' + (o.tooltip || 'top');
        tip.textContent = o.buttonTooltip;
        main.appendChild(tip);
      }
      main.addEventListener('click', (e) => {
        e.stopPropagation();
        this.toggle();
      });
      this.mainBtn = main;
      el.appendChild(main);

      this._applyState(false);
      this.container.appendChild(el);
      if (this.visible) this._applyState(true);
    }

    _applyState(open) {
      const o = this.options;
      this.el.classList.toggle('mpsd-open', open);
      this.el.setAttribute('aria-expanded', open ? 'true' : 'false');

      // Icône principale : swap + rotation
      const name = open ? o.hideIcon : o.showIcon;
      const url = 'url("' + o.iconPath + name + '.png")';
      this.mainIcon.style.webkitMaskImage = url;
      this.mainIcon.style.maskImage = url;
      if (o.rotateAnimation) {
        this.mainBtn.classList.toggle('mpsd-rotated', open);
      }

      // Position et transition en cascade des actions
      this.actionEls.forEach((li, i) => {
        const [dx, dy] = this._offset(i);
        const delay = open ? i * o.transitionDelay : (this.actionEls.length - 1 - i) * o.transitionDelay;
        li.style.transitionDelay = delay + 'ms';
        li.style.transform = open
          ? 'translate(' + dx + 'px, ' + dy + 'px) scale(1)'
          : 'translate(0px, 0px) scale(0)';
      });

      if (this.maskEl) this.maskEl.classList.toggle('mpsd-mask-visible', open);
    }

    /* ---------------------------- Méthodes ---------------------------- */

    show() {
      if (this.visible) return;
      this.visible = true;
      this._applyState(true);
      if (typeof this.options.onShow === 'function') this.options.onShow({ speeddial: this });
    }

    hide() {
      if (!this.visible) return;
      this.visible = false;
      this._applyState(false);
      if (typeof this.options.onHide === 'function') this.options.onHide({ speeddial: this });
    }

    toggle() { this.visible ? this.hide() : this.show(); }
    isVisible() { return this.visible; }

    destroy() {
      document.removeEventListener('click', this._onDocClick);
      if (this.maskEl && this.maskEl.parentNode) this.maskEl.parentNode.removeChild(this.maskEl);
      if (this.el && this.el.parentNode) this.el.parentNode.removeChild(this.el);
      this.el = this.maskEl = this.mainBtn = this.mainIcon = null;
      this.actionEls = [];
    }
  }

  global.MyPnSpeedDial = MyPnSpeedDial;
})(typeof window !== 'undefined' ? window : this);
