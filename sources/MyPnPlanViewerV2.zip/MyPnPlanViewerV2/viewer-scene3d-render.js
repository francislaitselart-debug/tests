﻿/* ============================================================
   MyPnPlanViewerV2 — module « scene3d-render »
   ============================================================
   Rendu Three.js de la scène 3D du plan affiché (current_plan_scene3d_json,
   readme § 10 bis), au-dessus du modèle .obj : emprise au sol (remplissage
   + ruban de contour, plein ou en pointillés), fond de plan image posé au
   sol, étalon d'échelle et mesures (distances, surfaces) avec leurs
   étiquettes, objets 3D ajoutés (fichiers .obj / .glb de la bibliothèque
   editModels, ramenés à leur taille réelle), flèche nord au sol (clé
   north), poignées d'édition (sphères à
   taille écran constante) et tracé en cours des outils au sol. Les zones
   viennent avec le module suivant.

   Tout est regroupé dans un THREE.Group « scene3d » ajouté une fois à la
   scène du visualiseur (window.ThreeViewer.getContext()) et RECONSTRUIT
   entièrement à chaque changement (rebuild) : la scène est petite, c'est
   plus simple et plus sûr qu'une mise à jour incrémentale. Les coordonnées
   sont celles du fichier .obj (x, z au sol ; y = sol du modèle + altitude).
   Le sol est la face inférieure de la boîte englobante du modèle.

   Les traits (contours, étalon, mesures) sont des RUBANS posés au sol (un
   quadrilatère par segment ou par tiret) : WebGL ne trace les lignes qu'à
   un pixel, et un ruban se lit sous tout angle. Les étiquettes sont des
   sprites (texte sur canvas) à taille écran constante. Le fond de plan est
   texturé par un canvas (Image -> CanvasTexture) : les SVG y sont
   rastérisés, et un échec (fichier absent, ou image locale refusée par
   WebGL en file://) laisse un plan gris à la bonne place. Les fichiers
   d'objets sont chargés une fois par page (gabarit normalisé : centré au
   sol, posé sur y = 0) puis clonés par instance ; en attendant, ou en cas
   d'échec, un pavé gris tient la place.

   NOTE ENCODAGE : chaînes affichées en ASCII pur (\uXXXX), commentaires
   accentués, BOM UTF-8, fins de ligne CRLF (readme.txt § 14).
   ============================================================ */
(function (global) {
  'use strict';

  const NS = global.MyPnPlanViewerV2NS = global.MyPnPlanViewerV2NS || {};
  const sc = NS.scene3d;

  // Décalages au-dessus du sol (unités du modèle) pour éviter le
  // scintillement entre surfaces coplanaires.
  const LIFT_FILL = 0.02;
  const LIFT_FLOOR = 0.04;
  const LIFT_STROKE = 0.06;
  const LIFT_PICK = 0.08;
  const LIFT_HANDLE = 0.12;

  // Couleurs : poignées (bleu), rotation (ambre), étalon (ambre), mesures
  // (violet), taille (vert).
  const HANDLE_COLOR = 0x1d4ed8;
  const HANDLE_ROTATE_COLOR = 0xf59e0b;
  const HANDLE_SCALE_COLOR = 0x10b981;
  const SCALE_COLOR = '#f59e0b';
  const MEASURE_COLOR = '#7c3aed';
  const NORTH_COLOR = '#dc2626';
  const OBJECT_DEFAULT_COLOR = 0x64748b;
  // Rayon des poignées et hauteur des étiquettes, en fraction de la
  // distance caméra-cible.
  const HANDLE_RADIUS_K = 0.008;
  const LABEL_HEIGHT_K = 0.028;

  const r = NS.scene3dRender = {
    ctx: null,          // contexte Three.js du visualiseur (getContext)
    group: null,        // THREE.Group « scene3d »
    handles: [],        // poignées d'édition affichées
    labels: [],         // étiquettes (sprites)
    pickables: [],      // maillages sélectionnables
    floorMesh: null,    // maillage du fond de plan (worldToLocal des poignées)
    objectGroups: [],   // groupe Three.js de chaque objet ajouté (par rang)
    draft: null,        // tracé en cours : { kind, points: [[x,z]…], cursor: [x,z]|null }
    exporting: false,   // reconstruction pour un export (viewer-scene3d-export.js) :
                        // sans poignées ni tracé, entités masquées non estompées, zones visibles
    textures: new Map(),// url -> { tex, aspect } (cache de la page)
    models: new Map(),  // url -> { object, maxDim, error, pending } (gabarits)
  };

  function THREE() { return r.ctx.THREE; }

  /* Contexte du visualiseur, initialisé au premier appel (le bundle
     Three.js est différé comme ce module). */
  function ctx() {
    if (r.ctx) return r.ctx;
    const v = global.ThreeViewer;
    if (!v || typeof v.getContext !== 'function') return null;
    r.ctx = v.getContext();
    r.group = new r.ctx.THREE.Group();
    r.group.name = 'scene3d';
    r.ctx.scene.add(r.group);
    // Poignées et étiquettes à taille écran constante : recalées avant
    // chaque rendu.
    if (typeof v.onBeforeRender === 'function') v.onBeforeRender(rescale);
    // Le sol et la taille du modèle ne sont connus qu'une fois le fichier
    // chargé : la scène est alors (re)construite.
    if (typeof v.onModelLoaded === 'function') v.onModelLoaded(rebuild);
    return r.ctx;
  }

  /* Mode édition effectif pour le rendu : pendant un export, la scène est
     construite comme en consultation (ni poignées, ni tracé, ni entités
     estompées). */
  function editActive() {
    return Boolean(NS.sceneEditActive && NS.sceneEditActive()) && !r.exporting;
  }

  /* ---------------------- Repère du modèle ---------------------- */

  function bounds() {
    const v = global.ThreeViewer;
    return v && typeof v.getModelBounds === 'function' ? v.getModelBounds() : null;
  }

  function groundY() {
    const b = bounds();
    return b ? b.min[1] : 0;
  }

  /* Plus grande dimension au sol du modèle (référence des tailles par
     défaut : épaisseur des traits, largeur d'un fond de plan…). */
  function modelSize() {
    const b = bounds();
    return b ? Math.max(b.size[0], b.size[2], 1) : 100;
  }

  function defaultStrokeWidth() {
    return Math.round(modelSize() * 0.004 * 100) / 100;
  }

  function defaultFloorWidth() {
    return Math.round(modelSize() * 0.5);
  }

  /* ---------------------- Construction ---------------------- */

  function disposeObject(obj) {
    obj.traverse((o) => {
      if (o.geometry && !o.userData.shared) o.geometry.dispose();
      if (o.material) {
        // Les textures des fonds de plan sont en cache ; celles des
        // étiquettes sont propres au sprite.
        if (o.isSprite && o.material.map) o.material.map.dispose();
        if (!(o.material.map && !o.isSprite) && !o.userData.shared) o.material.dispose();
      }
    });
  }

  function clearGroup() {
    for (const child of r.group.children.slice()) {
      r.group.remove(child);
      disposeObject(child);
    }
    r.handles = [];
    r.labels = [];
    r.pickables = [];
    r.floorMesh = null;
    r.objectGroups = [];
  }

  /* Reconstruit tout le groupe depuis la scène courante (sc.scene) et
     l'état d'édition (sélection, tracé en cours), puis redessine. */
  function rebuild() {
    const c = ctx();
    if (!c) return;
    clearGroup();
    const scene = sc.scene;
    if (scene && bounds()) {
      const y0 = groundY();
      if (scene.footprint) buildFootprint(scene.footprint, y0);
      if (scene.floorImage) buildFloorImage(scene.floorImage, y0);
      if (scene.scale && scene.scale.x1 !== null) buildScale(scene.scale, y0);
      (scene.measures || []).forEach((m, i) => buildMeasure(m, i, y0));
      (scene.objects || []).forEach((o, i) => buildObject(o, i, y0));
      if (NS.scene3dZones) NS.scene3dZones.build(scene, y0);
      if (scene.north) buildNorth(scene.north, y0);
      if (editActive()) {
        buildHandles(scene, y0);
        if (r.draft) buildDraft(r.draft, y0);
      }
    }
    c.render();
    // Le repère de coin suit la scène (rose des vents selon la clé north).
    if (NS.scene3dHelper) NS.scene3dHelper.refresh();
  }

  /* Opacité d'une entité selon sa clé shown : masquée hors édition,
     estompée cadenas ouvert. Retourne null si elle ne doit pas être
     construite du tout. */
  function shownAlpha(shown) {
    if (shown) return 1;
    return editActive() ? 0.35 : null;
  }

  function basicMaterial(color, opacity) {
    const T = THREE();
    return new T.MeshBasicMaterial({
      color: new T.Color(color), transparent: opacity < 1, opacity,
      side: T.DoubleSide, depthWrite: false,
    });
  }

  /* Ruban invisible mais sélectionnable, plus large que le trait : c'est
     lui qui reçoit les clics des traits fins (étalon, mesures). */
  function addPickRibbon(points, closed, width, y, data) {
    const T = THREE();
    const mesh = new T.Mesh(
      ribbonGeometry(points, Math.max(width * 5, modelSize() * 0.012), false, closed, y),
      new T.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false, side: T.DoubleSide }));
    mesh.userData = data;
    r.group.add(mesh);
    r.pickables.push(mesh);
    return mesh;
  }

  /* Emprise : remplissage (ShapeGeometry au sol) + ruban de contour. La
     forme est décrite dans le plan XY de THREE.Shape puis couchée au sol
     (rotateX -90° : y devient -z, d'où le signe des ordonnées). */
  function buildFootprint(fp, y0) {
    const T = THREE();
    const y = y0 + (fp.altitude || 0);
    const alpha = shownAlpha(fp.shown);
    // Remplissage (toujours présent en édition : c'est lui qui est cliquable).
    const fill = new T.Mesh(shapeGeometry(fp.points), basicMaterial(fp.fill, fp.fillOpacity * (alpha || 0)));
    fill.position.y = y + LIFT_FILL;
    fill.userData = { kind: 'footprint' };
    fill.visible = alpha !== null;
    r.group.add(fill);
    r.pickables.push(fill);
    if (alpha === null) return;
    const width = fp.strokeWidth || defaultStrokeWidth();
    const stroke = new T.Mesh(
      ribbonGeometry(fp.points, width, fp.dashed, true, y + LIFT_STROKE),
      basicMaterial(fp.stroke, alpha));
    stroke.userData = { kind: 'footprint' };
    r.group.add(stroke);
    r.pickables.push(stroke);
  }

  function shapeGeometry(points) {
    const T = THREE();
    const shape = new T.Shape(points.map((p) => new T.Vector2(p[0], -p[1])));
    const geom = new T.ShapeGeometry(shape);
    geom.rotateX(-Math.PI / 2);
    return geom;
  }

  /* Ruban d'une polyligne (closed : polygone fermé) : un quadrilatère
     (deux triangles) par segment, ou par tiret en pointillés ; un disque à
     chaque sommet en trait plein pour fermer les angles. */
  function ribbonGeometry(points, width, dashed, closed, y) {
    const T = THREE();
    const pos = [];
    const hw = width / 2;
    const n = points.length;
    const quad = (ax, az, bx, bz, nx, nz) => {
      pos.push(ax - nx, y, az - nz, bx - nx, y, bz - nz, bx + nx, y, bz + nz,
        ax - nx, y, az - nz, bx + nx, y, bz + nz, ax + nx, y, az + nz);
    };
    const disc = (cx, cz) => {
      const segs = 10;
      for (let k = 0; k < segs; k++) {
        const t0 = (k / segs) * Math.PI * 2, t1 = ((k + 1) / segs) * Math.PI * 2;
        pos.push(cx, y, cz, cx + Math.cos(t0) * hw, y, cz + Math.sin(t0) * hw,
          cx + Math.cos(t1) * hw, y, cz + Math.sin(t1) * hw);
      }
    };
    const last = closed ? n : n - 1;
    for (let i = 0; i < last; i++) {
      const a = points[i], b = points[(i + 1) % n];
      const dx = b[0] - a[0], dz = b[1] - a[1];
      const len = Math.hypot(dx, dz);
      if (len < 1e-6) continue;
      const ux = dx / len, uz = dz / len;
      const nx = -uz * hw, nz = ux * hw;
      if (dashed) {
        const dash = width * 5, gap = width * 3;
        for (let s = 0; s < len; s += dash + gap) {
          const e = Math.min(len, s + dash);
          quad(a[0] + ux * s, a[1] + uz * s, a[0] + ux * e, a[1] + uz * e, nx, nz);
        }
      } else {
        quad(a[0], a[1], b[0], b[1], nx, nz);
        disc(b[0], b[1]);
        if (!closed && i === 0) disc(a[0], a[1]);
      }
    }
    const geom = new T.BufferGeometry();
    geom.setAttribute('position', new T.Float32BufferAttribute(pos, 3));
    return geom;
  }

  /* Fond de plan : plan texturé couché au sol, centré en (x, z), tourné
     de rotation degrés (sens horaire vu de dessus). Le haut de l'image
     regarde vers -z. La texture arrive de façon asynchrone : le plan est
     d'abord gris, puis reconstruit à la réception (avec le bon rapport
     hauteur / largeur si height est automatique). */
  function buildFloorImage(fi, y0) {
    const T = THREE();
    const alpha = shownAlpha(fi.shown);
    if (alpha === null) return;
    const entry = r.textures.get(fi.filename);
    const w = fi.width || defaultFloorWidth();
    const h = w * floorAspect(fi, w);
    const geom = new T.PlaneGeometry(w, h);
    geom.rotateX(-Math.PI / 2);
    const mat = new T.MeshBasicMaterial({
      color: 0xffffff, transparent: true, side: T.DoubleSide, depthWrite: false,
      opacity: fi.opacity * alpha,
    });
    if (entry && entry.tex) mat.map = entry.tex;
    else mat.color.set(0xcbd5e1);
    const mesh = new T.Mesh(geom, mat);
    mesh.position.set(fi.x, y0 + (fi.altitude || 0) + LIFT_FLOOR, fi.z);
    mesh.rotation.y = -(fi.rotation || 0) * Math.PI / 180;
    mesh.userData = { kind: 'floorImage' };
    r.group.add(mesh);
    r.pickables.push(mesh);
    r.floorMesh = mesh;
    if (!entry) loadTexture(fi.filename, () => { if (sc.scene && sc.scene.floorImage === fi) rebuild(); });
  }

  function floorAspect(fi, w) {
    if (fi.height && w) return fi.height / w;
    const entry = r.textures.get(fi.filename);
    return entry && entry.aspect ? entry.aspect : 0.7;
  }

  /* Image -> canvas -> CanvasTexture. Une seule tentative par fichier ;
     l'échec (introuvable, ou canvas « souillé » par une image locale en
     file://) est mémorisé : plan gris, avertissement en console. */
  function loadTexture(url, done) {
    if (r.textures.has(url)) { done(); return; }
    r.textures.set(url, { tex: null, aspect: 0, pending: true });
    const T = THREE();
    const img = new Image();
    img.onload = () => {
      const W = img.naturalWidth || 1024, H = img.naturalHeight || 768;
      const entry = { tex: null, aspect: H / W };
      try {
        const k = Math.min(1, 2048 / Math.max(W, H));
        const cv = document.createElement('canvas');
        cv.width = Math.max(1, Math.round(W * k));
        cv.height = Math.max(1, Math.round(H * k));
        cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
        const tex = new T.CanvasTexture(cv);
        tex.colorSpace = T.SRGBColorSpace;
        tex.anisotropy = Math.min(4, r.ctx.renderer.capabilities.getMaxAnisotropy());
        // Envoi immédiat au GPU : c'est ici qu'une image locale est refusée.
        r.ctx.renderer.initTexture(tex);
        entry.tex = tex;
      } catch (cause) {
        console.warn('MyPnPlanViewerV2 : fond de plan non texturable (' + url + ')', cause);
      }
      r.textures.set(url, entry);
      done();
    };
    img.onerror = () => {
      console.warn('MyPnPlanViewerV2 : fond de plan introuvable (' + url + ')');
      r.textures.set(url, { tex: null, aspect: 0 });
      done();
    };
    img.src = url;
  }

  /* Étalon d'échelle : segment au sol (ruban ambre à bouts perpendiculaires)
     et étiquette de sa longueur réelle. */
  function buildScale(s, y0) {
    const T = THREE();
    const alpha = shownAlpha(s.shown);
    if (alpha === null) return;
    const y = y0 + LIFT_STROKE;
    const pts = [[s.x1, s.z1], [s.x2, s.z2]];
    const width = defaultStrokeWidth();
    const mesh = new T.Mesh(ribbonGeometry(pts, width, false, false, y), basicMaterial(SCALE_COLOR, alpha));
    mesh.userData = { kind: 'scale' };
    r.group.add(mesh);
    // Bouts perpendiculaires.
    const dx = s.x2 - s.x1, dz = s.z2 - s.z1;
    const len = Math.hypot(dx, dz) || 1;
    const nx = -dz / len * width * 2.5, nz = dx / len * width * 2.5;
    for (const p of pts) {
      const tick = new T.Mesh(
        ribbonGeometry([[p[0] - nx, p[1] - nz], [p[0] + nx, p[1] + nz]], width, false, false, y),
        basicMaterial(SCALE_COLOR, alpha));
      r.group.add(tick);
    }
    addPickRibbon(pts, false, width, y0 + LIFT_PICK, { kind: 'scale' });
    addLabel(NS.formatLength(len), (s.x1 + s.x2) / 2, y + LIFT_HANDLE, (s.z1 + s.z2) / 2, SCALE_COLOR, alpha);
  }

  /* Mesure : distance (polyligne, longueur cumulée à l'extrémité) ou
     surface (polygone : remplissage, contour en pointillés, aire au centre). */
  function buildMeasure(m, index, y0) {
    const T = THREE();
    const alpha = shownAlpha(m.shown);
    if (alpha === null) return;
    const y = y0 + LIFT_STROKE;
    const width = defaultStrokeWidth();
    const data = { kind: 'measure', index };
    if (m.type === 'area') {
      const fill = new T.Mesh(shapeGeometry(m.points), basicMaterial(MEASURE_COLOR, 0.15 * alpha));
      fill.position.y = y0 + LIFT_FILL + 0.005;
      fill.userData = data;
      r.group.add(fill);
      r.pickables.push(fill);
      const outline = new T.Mesh(ribbonGeometry(m.points, width, true, true, y), basicMaterial(MEASURE_COLOR, alpha));
      outline.userData = data;
      r.group.add(outline);
      const c = centroid(m.points);
      const text = (m.label ? m.label + ' : ' : '') + NS.formatArea(NS.polygonArea(m.points));
      addLabel(text, c[0], y + LIFT_HANDLE, c[1], MEASURE_COLOR, alpha);
    } else {
      const line = new T.Mesh(ribbonGeometry(m.points, width, false, false, y), basicMaterial(MEASURE_COLOR, alpha));
      line.userData = data;
      r.group.add(line);
      addPickRibbon(m.points, false, width, y0 + LIFT_PICK, data);
      const end = m.points[m.points.length - 1];
      const text = (m.label ? m.label + ' : ' : '') + NS.formatLength(NS.polylineLength(m.points, false));
      addLabel(text, end[0], y + LIFT_HANDLE, end[1], MEASURE_COLOR, alpha);
    }
  }

  /* ---------------------- Flèche nord au sol ---------------------- */

  /* Position au sol de la flèche nord : celle enregistrée (x, z), sinon
     le coin nord-est de la boîte du modèle (x max, z min), en retrait —
     en haut à droite d une vue de dessus, loin du repère de coin. */
  function northPosition(n) {
    if (n && n.x !== null && n.z !== null) return [n.x, n.z];
    const b = bounds();
    const m = modelSize() * 0.1;
    return b ? [Math.round((b.max[0] + m) * 100) / 100, Math.round((b.min[2] - m) * 100) / 100] : [0, 0];
  }

  function northLength() {
    return modelSize() * 0.08;
  }

  /* Sommets au sol de la flèche (pointe vers le nord) : pointe, aile
     droite, encoche, aile gauche, tournés de l'angle (sens horaire vu de
     dessus, 0 = -z). */
  function northPoints(n) {
    const [cx, cz] = northPosition(n);
    const L = northLength();
    const th = n.angle * Math.PI / 180;
    const rot = (x, z) => [cx + x * Math.cos(th) - z * Math.sin(th), cz + x * Math.sin(th) + z * Math.cos(th)];
    return [rot(0, -L), rot(L * 0.38, L * 0.35), rot(0, L * 0.12), rot(-L * 0.38, L * 0.35)];
  }

  function buildNorth(n, y0) {
    const T = THREE();
    const alpha = shownAlpha(n.shown);
    if (alpha === null) return;
    const pts = northPoints(n);
    const mesh = new T.Mesh(shapeGeometry(pts), basicMaterial(NORTH_COLOR, alpha));
    mesh.position.y = y0 + LIFT_STROKE;
    mesh.userData = { kind: 'north' };
    r.group.add(mesh);
    r.pickables.push(mesh);
    const [cx, cz] = northPosition(n);
    const tip = pts[0];
    addLabel('N', cx + (tip[0] - cx) * 1.3, y0 + LIFT_HANDLE, cz + (tip[1] - cz) * 1.3, NORTH_COLOR, alpha);
  }

  function centroid(points) {
    let x = 0, z = 0;
    for (const p of points) { x += p[0]; z += p[1]; }
    return [x / points.length, z / points.length];
  }

  /* ---------------------- Objets ajoutés ---------------------- */

  /* Gabarit d'un fichier d'objet : chargé une fois (ThreeViewer.loadModel),
     normalisé — centré en x / z, posé sur y = 0 — et mesuré (plus grande
     dimension). En attendant ou en cas d'échec : pavé gris. */
  function loadTemplate(url, done) {
    if (r.models.has(url)) { done(); return; }
    const entry = { object: null, maxDim: 1, error: false, pending: true };
    r.models.set(url, entry);
    const v = global.ThreeViewer;
    if (!v || typeof v.loadModel !== 'function') { entry.pending = false; entry.error = true; done(); return; }
    v.loadModel(url).then((obj) => {
      const T = THREE();
      const box = new T.Box3().setFromObject(obj);
      const size = box.getSize(new T.Vector3());
      const center = box.getCenter(new T.Vector3());
      const wrap = new T.Group();
      obj.position.set(-center.x, -box.min.y, -center.z);
      wrap.add(obj);
      obj.traverse((o) => {
        if (!o.isMesh) return;
        o.userData.shared = true;
        // Fichier sans normales (glTF minimal) : éclairage plat sinon.
        if (o.geometry && !o.geometry.attributes.normal) o.geometry.computeVertexNormals();
      });
      entry.object = wrap;
      entry.maxDim = Math.max(size.x, size.y, size.z, 1e-6);
      entry.pending = false;
      done();
    }).catch((cause) => {
      console.warn('MyPnPlanViewerV2 : objet 3D non charg\u00e9 (' + url + ')', cause);
      entry.pending = false;
      entry.error = true;
      done();
    });
  }

  /* Taille réelle (clé size, en unit) -> unités du modèle. */
  function objectSizeUnits(o) {
    const k = NS.scaleFactor();
    return k ? o.size / k : o.size;
  }

  /* Rayon au sol de l'objet (poignées), en unités du modèle. */
  function objectRadius(o) {
    return objectSizeUnits(o) * o.scale * 0.7;
  }

  function buildObject(o, index, y0) {
    const T = THREE();
    const alpha = shownAlpha(o.shown);
    r.objectGroups[index] = null;
    if (alpha === null) return;
    const entry = r.models.get(o.filename);
    const group = new T.Group();
    const sizeUnits = objectSizeUnits(o);
    const data = { kind: 'object', index };
    if (entry && entry.object) {
      const inst = entry.object.clone(true);
      inst.traverse((m) => {
        if (!m.isMesh) return;
        m.userData = Object.assign({}, data);
        if (o.color) {
          m.material = new T.MeshStandardMaterial({ color: new T.Color(o.color), metalness: 0.05, roughness: 0.85 });
        } else if (Array.isArray(m.material)) {
          m.material = m.material.map((mat) => mat.clone());
        } else {
          m.material = m.material.clone();
        }
        const mats = Array.isArray(m.material) ? m.material : [m.material];
        for (const mat of mats) {
          if (alpha < 1) { mat.transparent = true; mat.opacity = alpha; }
        }
        r.pickables.push(m);
      });
      const k = sizeUnits / entry.maxDim * o.scale;
      inst.scale.setScalar(k);
      group.add(inst);
    } else {
      // Pavé provisoire (chargement en cours, ou fichier illisible).
      const s = sizeUnits * o.scale;
      const box = new T.Mesh(new T.BoxGeometry(s, s * 0.6, s),
        new T.MeshStandardMaterial({ color: entry && entry.error ? 0xef4444 : 0x94a3b8, transparent: true, opacity: 0.5 * alpha }));
      box.position.y = s * 0.3;
      box.userData = Object.assign({}, data);
      group.add(box);
      r.pickables.push(box);
      if (!entry) loadTemplate(o.filename, () => { if (sc.scene && sc.scene.objects.includes(o)) rebuild(); });
    }
    group.position.set(o.x, y0 + (o.altitude || 0), o.z);
    group.rotation.y = -(o.rotation || 0) * Math.PI / 180;
    group.userData = data;
    r.group.add(group);
    r.objectGroups[index] = group;
  }

  /* ---------------------- Étiquettes ---------------------- */

  /* Sprite « texte sur canvas » (fond blanc, liseré de la couleur de
     l'entité), ancré par le bas du cadre sur le point donné, à taille
     écran constante (rescale). */
  function addLabel(text, x, y, z, color, alpha) {
    const T = THREE();
    const cv = document.createElement('canvas');
    const g = cv.getContext('2d');
    const font = '600 26px "Segoe UI", system-ui, sans-serif';
    g.font = font;
    const tw = Math.ceil(g.measureText(text).width);
    cv.width = tw + 28;
    cv.height = 44;
    g.font = font;
    g.fillStyle = 'rgba(255, 255, 255, 0.92)';
    roundRect(g, 1.5, 1.5, cv.width - 3, cv.height - 3, 8);
    g.fill();
    g.lineWidth = 3;
    g.strokeStyle = color;
    g.stroke();
    g.fillStyle = '#0f172a';
    g.textBaseline = 'middle';
    g.fillText(text, 14, cv.height / 2 + 1);
    const tex = new T.CanvasTexture(cv);
    tex.colorSpace = T.SRGBColorSpace;
    const sprite = new T.Sprite(new T.SpriteMaterial({
      map: tex, depthTest: false, transparent: true, opacity: alpha === undefined ? 1 : alpha,
    }));
    sprite.center.set(0.5, 0);
    sprite.position.set(x, y, z);
    sprite.renderOrder = 11;
    sprite.userData = { text, aspect: cv.width / cv.height };
    r.labels.push(sprite);
    r.group.add(sprite);
    return sprite;
  }

  function roundRect(g, x, y, w, h, rad) {
    g.beginPath();
    g.moveTo(x + rad, y);
    g.arcTo(x + w, y, x + w, y + h, rad);
    g.arcTo(x + w, y + h, x, y + h, rad);
    g.arcTo(x, y + h, x, y, rad);
    g.arcTo(x, y, x + w, y, rad);
    g.closePath();
  }

  /* ---------------------- Poignées et tracé ---------------------- */

  /* Distance de référence des tailles écran constantes : en vue en plan
     (caméra orthographique), la taille apparente suit le zoom. */
  function cameraDistance() {
    const c = r.ctx;
    const d = c.camera.position.distanceTo(c.controls.target);
    return c.camera.isOrthographicCamera ? d / (c.camera.zoom || 1) : d;
  }

  function addHandle(x, y, z, data, color) {
    const T = THREE();
    const mesh = new T.Mesh(
      new T.SphereGeometry(1, 12, 10),
      new T.MeshBasicMaterial({ color: color || HANDLE_COLOR, depthTest: false, transparent: true, opacity: 0.95 }));
    mesh.renderOrder = 10;
    mesh.position.set(x, y, z);
    mesh.scale.setScalar(cameraDistance() * HANDLE_RADIUS_K);
    mesh.userData = data;
    r.handles.push(mesh);
    r.group.add(mesh);
    return mesh;
  }

  /* Poignées et étiquettes à taille écran constante (avant chaque rendu). */
  function rescale() {
    if (!r.handles.length && !r.labels.length) return;
    const d = cameraDistance();
    const k = d * HANDLE_RADIUS_K;
    for (const h of r.handles) h.scale.setScalar(k);
    const lh = d * LABEL_HEIGHT_K;
    for (const s of r.labels) s.scale.set(lh * s.userData.aspect, lh, 1);
  }

  /* Positions au sol des poignées d'un objet : rotation (ambre) au nord de
     l'objet dans son repère, taille (verte) à l'est. */
  function objectHandlePoints(o) {
    const R = objectRadius(o);
    const th = (o.rotation || 0) * Math.PI / 180;
    return {
      rotate: [o.x + Math.sin(th) * R, o.z - Math.cos(th) * R],
      scale: [o.x + Math.cos(th) * R, o.z + Math.sin(th) * R],
      radius: R,
    };
  }

  /* Poignées de l'entité sélectionnée : sommets de l'emprise, de l'étalon
     ou de la mesure ; coins et poignée de rotation du fond de plan (dans
     son repère) ; rotation et taille d'un objet. */
  function buildHandles(scene, y0) {
    const y = y0 + LIFT_HANDLE;
    if (sc.selected === 'footprint' && scene.footprint) {
      const fp = scene.footprint;
      fp.points.forEach((p, i) => addHandle(p[0], y + (fp.altitude || 0), p[1], { kind: 'fpVertex', index: i }));
    } else if (sc.selected === 'scale' && scene.scale && scene.scale.x1 !== null) {
      const s = scene.scale;
      addHandle(s.x1, y, s.z1, { kind: 'sVertex', index: 0 });
      addHandle(s.x2, y, s.z2, { kind: 'sVertex', index: 1 });
    } else if (sc.selected === 'measure' && scene.measures[sc.selectedIndex]) {
      scene.measures[sc.selectedIndex].points.forEach((p, i) => addHandle(p[0], y, p[1], { kind: 'mVertex', index: i }));
    } else if (sc.selected === 'object' && scene.objects[sc.selectedIndex]) {
      const o = scene.objects[sc.selectedIndex];
      const hp = objectHandlePoints(o);
      const yo = y + (o.altitude || 0);
      addHandle(hp.rotate[0], yo, hp.rotate[1], { kind: 'oRotate' }, HANDLE_ROTATE_COLOR);
      addHandle(hp.scale[0], yo, hp.scale[1], { kind: 'oScale' }, HANDLE_SCALE_COLOR);
      // Cercle de pied : ruban fin autour de l'objet sélectionné.
      const T = THREE();
      const ring = [];
      for (let k = 0; k < 40; k++) {
        const a = (k / 40) * Math.PI * 2;
        ring.push([o.x + Math.cos(a) * hp.radius, o.z + Math.sin(a) * hp.radius]);
      }
      const mesh = new T.Mesh(ribbonGeometry(ring, defaultStrokeWidth() * 0.6, true, true, yo - LIFT_HANDLE + LIFT_STROKE),
        basicMaterial('#1d4ed8', 0.9));
      r.group.add(mesh);
    } else if (sc.selected === 'floorImage' && scene.floorImage && r.floorMesh) {
      const T = THREE();
      const fi = scene.floorImage;
      const mesh = r.floorMesh;
      const w = fi.width || defaultFloorWidth();
      const h = w * floorAspect(fi, w);
      const local = (lx, lz) => mesh.localToWorld(new T.Vector3(lx, LIFT_HANDLE, lz));
      [[-1, -1], [1, -1], [1, 1], [-1, 1]].forEach((s, i) => {
        const p = local(s[0] * w / 2, s[1] * h / 2);
        addHandle(p.x, p.y, p.z, { kind: 'fiCorner', index: i });
      });
      const rot = local(0, -h / 2 - Math.max(w, h) * 0.12);
      addHandle(rot.x, rot.y, rot.z, { kind: 'fiRotate' }, HANDLE_ROTATE_COLOR);
    } else if (sc.selected === 'zone' && NS.scene3dZones) {
      NS.scene3dZones.buildHandles(scene, y);
    } else if (sc.selected === 'north' && scene.north) {
      // Poignée de rotation (ambre) au-delà de la pointe.
      const pts = northPoints(scene.north);
      const [cx, cz] = northPosition(scene.north);
      const tip = pts[0];
      addHandle(cx + (tip[0] - cx) * 1.7, y, cz + (tip[1] - cz) * 1.7, { kind: 'nRotate' }, HANDLE_ROTATE_COLOR);
    }
  }

  /* Tracé en cours des outils au sol : sommets posés (poignées, la
     première refermant un polygone) et ligne élastique vers le curseur,
     avec la longueur / l'aire courante en étiquette. */
  function buildDraft(draft, y0) {
    const T = THREE();
    const y = y0 + LIFT_HANDLE;
    const all = draft.points.slice();
    if (draft.cursor) all.push(draft.cursor);
    const pts = all.map((p) => new T.Vector3(p[0], y, p[1]));
    const color = draft.kind === 'scale' ? 0xf59e0b : (draft.kind === 'footprint' ? HANDLE_COLOR : 0x7c3aed);
    if (pts.length >= 2) {
      const closed = (draft.kind === 'footprint' || draft.kind === 'area') && pts.length >= 3;
      const line = new (closed ? T.LineLoop : T.Line)(
        new T.BufferGeometry().setFromPoints(pts),
        new T.LineBasicMaterial({ color, depthTest: false }));
      line.renderOrder = 9;
      r.group.add(line);
      let text = null;
      const end = all[all.length - 1];
      if (draft.kind === 'measure' || draft.kind === 'scale') text = NS.formatLength(NS.polylineLength(all, false));
      else if (draft.kind === 'area' && all.length >= 3) text = NS.formatArea(NS.polygonArea(all));
      if (text) addLabel(text, end[0], y, end[1], '#' + color.toString(16).padStart(6, '0'));
    }
    draft.points.forEach((p, i) => addHandle(p[0], y, p[1], { kind: 'draftVertex', index: i },
      i === 0 ? 0xffffff : color));
  }

  function setDraft(draft) {
    r.draft = draft;
  }

  /* ---------------------- Sélection et projection ---------------------- */

  function ndc(clientX, clientY) {
    const rect = r.ctx.canvas.getBoundingClientRect();
    return {
      x: ((clientX - rect.left) / rect.width) * 2 - 1,
      y: -((clientY - rect.top) / rect.height) * 2 + 1,
    };
  }

  function raycaster(clientX, clientY) {
    const T = THREE();
    const rc = new T.Raycaster();
    const p = ndc(clientX, clientY);
    rc.setFromCamera(new T.Vector2(p.x, p.y), r.ctx.camera);
    return rc;
  }

  /* Lancer de rayon sur des objets quelconques (maillages du modèle liés
     à des zones) : intersections triées, ou []. */
  function raycast(clientX, clientY, objects) {
    const c = ctx();
    if (!c || !objects.length) return [];
    return raycaster(clientX, clientY).intersectObjects(objects, false);
  }

  /* Poignée ou entité sous le pointeur : userData du premier objet touché
     (poignées d'abord), ou null. Les prismes des zones restent
     sélectionnables même invisibles : hors édition, une zone n'est rendue
     qu'au survol (ou en alarme), et c'est ce survol qui la fait apparaître. */
  function pick(clientX, clientY) {
    const c = ctx();
    if (!c || !bounds()) return null;
    const rc = raycaster(clientX, clientY);
    const hits = rc.intersectObjects(r.handles, false);
    if (hits.length) return hits[0].object.userData;
    const entities = rc.intersectObjects(r.pickables.filter((m) => m.visible || (m.userData && m.userData.kind === 'zone')), false);
    if (entities.length) return entities[0].object.userData;
    return null;
  }

  /* Point du sol (plan y = sol du modèle) sous le pointeur : [x, z] ou null. */
  function groundPoint(clientX, clientY) {
    const c = ctx();
    if (!c || !bounds()) return null;
    const T = THREE();
    const rc = raycaster(clientX, clientY);
    const plane = new T.Plane(new T.Vector3(0, 1, 0), -groundY());
    const out = new T.Vector3();
    if (!rc.ray.intersectPlane(plane, out)) return null;
    return [Math.round(out.x * 100) / 100, Math.round(out.z * 100) / 100];
  }

  /* Coordonnées client (px) d'un point du modèle (bancs de test, info-bulles). */
  function project(x, y, z) {
    const c = ctx();
    if (!c) return null;
    const T = THREE();
    const v = new T.Vector3(x, y, z).project(c.camera);
    const rect = c.canvas.getBoundingClientRect();
    return {
      x: rect.left + (v.x + 1) / 2 * rect.width,
      y: rect.top + (1 - v.y) / 2 * rect.height,
    };
  }

  /* Coordonnées locales (repère du fond de plan) d'un point du sol. */
  function floorLocal(x, z) {
    if (!r.floorMesh) return null;
    const T = THREE();
    const v = r.floorMesh.worldToLocal(new T.Vector3(x, r.floorMesh.position.y, z));
    return [v.x, v.z];
  }

  /* État du rendu pour les bancs de test. */
  function debug() {
    const fi = r.floorMesh;
    return {
      children: r.group ? r.group.children.length : 0,
      handles: r.handles.length,
      labels: r.labels.map((s) => s.userData.text),
      pickables: r.pickables.length,
      floor: fi ? { map: Boolean(fi.material.map), visible: fi.visible,
        w: fi.geometry.parameters.width, h: fi.geometry.parameters.height,
        x: fi.position.x, z: fi.position.z, rotY: fi.rotation.y } : null,
      textures: Array.from(r.textures.entries()).map(([k, v]) => k + ':' + (v.tex ? 'ok' : 'none')),
      objects: r.objectGroups.map((g, i) => {
        if (!g) return null;
        const o = sc.scene && sc.scene.objects[i];
        const entry = o ? r.models.get(o.filename) : null;
        let meshes = 0, color = null;
        g.traverse((m) => {
          if (m.isMesh) {
            meshes++;
            const mat = Array.isArray(m.material) ? m.material[0] : m.material;
            if (!color && mat && mat.color) color = '#' + mat.color.getHexString();
          }
        });
        return {
          loaded: Boolean(entry && entry.object), error: Boolean(entry && entry.error), meshes,
          scale: g.children[0] ? g.children[0].scale.x : null, rotY: g.rotation.y,
          x: g.position.x, z: g.position.z, color,
        };
      }),
      zones: NS.scene3dZones ? NS.scene3dZones.debug() : [],
      north: sc.scene && sc.scene.north ? { angle: sc.scene.north.angle, pos: northPosition(sc.scene.north) } : null,
      groundY: groundY(),
    };
  }

  /* ------------------- Exposition sur l'espace de noms ------------------- */
  r.rebuild = rebuild;
  r.setDraft = setDraft;
  r.pick = pick;
  r.groundPoint = groundPoint;
  r.project = project;
  r.floorLocal = floorLocal;
  r.groundY = groundY;
  r.modelSize = modelSize;
  r.defaultStrokeWidth = defaultStrokeWidth;
  r.defaultFloorWidth = defaultFloorWidth;
  r.objectSizeUnits = objectSizeUnits;
  r.objectRadius = objectRadius;
  r.objectHandlePoints = objectHandlePoints;
  r.northPosition = northPosition;
  r.northPoints = northPoints;
  r.addHandle = addHandle;
  r.raycast = raycast;
  r.debug = debug;
})(globalThis);
