﻿/* ============================================================
   MyPnPlanViewerV2 — objet d'IHM Web Panorama « pure JS »
   Point d'entrée : raccordement aux propriétés partagées Panorama.

   Visualiseur de plans avec navigation (bandeau, arbre repliable, vues
   épinglées), représentations 2D (image + calques image) et 3D (Three.js),
   zoom, SpeedDial, capteurs positionnés sur le plan, formes libres et mode
   d'édition. Reprise de MyPnPlanViewer avec un dialogue par identifiants
   (readme.txt § 1 et § 6).

   L'implémentation est répartie en modules par domaine — scripts
   classiques chargés dans l'ordre imposé par index.html, qui communiquent
   par l'espace de noms global MyPnPlanViewerV2NS (readme.txt § 1) :

     viewer-config.js       normalisation des propriétés lues + état partagé
     viewer-dom.js          références vers les éléments de la page
     viewer-edit-core.js    mode édition : état, géométrie, capteurs couverts,
                            écriture de current_plan_drawnShapes_json
     viewer-edit-render.js  mode édition : rendu du calque
     viewer-edit-panel.js   mode édition : panneau « Apparence / Propriétés »
     viewer-edit-tools.js   mode édition : palette d'outils + interactions
     viewer-plan.js         zone des plans 2D/3D, calques, SpeedDial, zoom
     viewer-print.js        impression du plan 2D (bouton, menu, en-tête)
     viewer-nav.js          drawer, arbre, vues épinglées, applyConfig,
                            applyEvents, writeSelectedNode
     app.js                 ce fichier : propriétés partagées Panorama

   NOTE ENCODAGE : toutes les chaînes destinées à l'affichage sont écrites en
   ASCII pur (échappements \uXXXX pour les caractères accentués), afin de
   rester correctes même si le serveur livre le fichier avec un mauvais
   charset. Seuls les commentaires utilisent des caractères accentués.
   Les fichiers portent un BOM UTF-8 et des fins de ligne CRLF.

   Sept propriétés sont partagées avec l'application Panorama hôte (toutes
   de type chaîne ; schémas détaillés dans readme.txt § 7 à § 11) :

     LUES
     configuration_plan_json        arbre de navigation (nœuds avec id),
                                    options, représentations et calques
                                    image. Reconstruction à chaque
                                    changement (badges fixes seuls : à chaud).
     configuration_events_json      alarmes en cours { id, element_id,
                                    node_id, priority, color, count } :
                                    pastilles de l'arbre et badges du bandeau
                                    par remontée le long des parent_id, état
                                    d'alarme des capteurs et des formes. À
                                    chaud.
     current_plan_element_json      capteurs du plan affiché { id, label, x,
                                    y, show_mode, icon, icon_alarm, size,
                                    props }, mémorisés par plan (node_id +
                                    planIndex).
     current_plan_drawnShapes_json  formes libres du plan affiché (lecture :
                                    l'application fait foi ; garde anti-écho
                                    contre la relecture de ce que l'objet
                                    vient d'écrire).
     current_plan_scene3d_json      scène de la représentation 3D affichée
                                    (vue par défaut, emprise, fond de plan,
                                    objets, zones) : même mémorisation par
                                    plan et même garde anti-écho.

     ÉCRITES
     selectedNodePath               { id, parent_id, path, labels, planIndex,
                                    filename, serial } à chaque sélection,
                                    changement de représentation ou
                                    reconstruction.
     current_plan_drawnShapes_json  toutes les formes du plan affiché, à
                                    chaque modification de l'opérateur.
     current_plan_scene3d_json      toute la scène du plan 3D affiché, à
                                    chaque modification de l'opérateur.
     eventsDetailRequest_json       { source: "element" | "badge", ... ,
                                    serial } à chaque clic sur un capteur du
                                    plan ou un badge du bandeau.

   Aucun Back end C# : la classe utilisateur ne sert qu'à porter ces
   propriétés.
   ============================================================ */
(function (global) {
  'use strict';

  const NS = global.MyPnPlanViewerV2NS;
  const state = NS.state;

  // Noms des propriétés partagées. Les modifier ici impose de les modifier à
  // l'identique dans le descripteur de la classe utilisateur (readme.txt, § 5).
  const CONFIG_PROPERTY = 'configuration_plan_json';
  const EVENTS_PROPERTY = 'configuration_events_json';
  const ELEMENTS_PROPERTY = 'current_plan_element_json';
  const DRAWN_SHAPES_PROPERTY = 'current_plan_drawnShapes_json';
  const SCENE3D_PROPERTY = 'current_plan_scene3d_json';
  const SELECTED_NODE_PROPERTY = 'selectedNodePath';
  const EVENTS_DETAIL_PROPERTY = 'eventsDetailRequest_json';

  // Propriétés lues, dans l'ordre d'affichage de l'état de réception.
  const READ_PROPERTIES = [
    CONFIG_PROPERTY, EVENTS_PROPERTY, ELEMENTS_PROPERTY, DRAWN_SHAPES_PROPERTY,
    SCENE3D_PROPERTY,
  ];

  // Le rang des représentations (planIndex) est en base 1 ; les tableaux
  // JavaScript en base 0.
  const SELECTED_PLAN_BASE = 1;

  NS.CONFIG_PROPERTY = CONFIG_PROPERTY;
  NS.EVENTS_PROPERTY = EVENTS_PROPERTY;
  NS.ELEMENTS_PROPERTY = ELEMENTS_PROPERTY;
  NS.DRAWN_SHAPES_PROPERTY = DRAWN_SHAPES_PROPERTY;
  NS.SCENE3D_PROPERTY = SCENE3D_PROPERTY;
  NS.SELECTED_NODE_PROPERTY = SELECTED_NODE_PROPERTY;
  NS.EVENTS_DETAIL_PROPERTY = EVENTS_DETAIL_PROPERTY;
  NS.SELECTED_PLAN_BASE = SELECTED_PLAN_BASE;

  /* ====================== Raccordement à Panorama ====================== */

  // Objet d'interfaçage fourni par /static/fr/pn-insertable-object-lib.umd.js,
  // chargé par index.html avant ce fichier.
  const { PanoInterface } = globalThis['pn-insertable-object-lib'];
  const panoInterface = new PanoInterface();

  /* Dernière valeur écrite par l'objet, par propriété : sert de garde
     anti-écho à la relecture de current_plan_drawnShapes_json (Panorama
     renvoie aux abonnés ce que l'objet vient d'écrire). */
  const lastWritten = {};

  async function writeProperty(name, value) {
    lastWritten[name] = typeof value === 'string' ? value : String(value);
    try {
      const ok = await panoInterface.writeProperty(name, value);

      if (!ok) {
        // Écriture acheminée mais refusée : propriété absente du descripteur
        // de classe, ou déclarée en lecture seule.
        console.error('MyPnPlanViewerV2 : \u00e9criture refus\u00e9e sur ' + name);
      }
    } catch (cause) {
      console.error('MyPnPlanViewerV2 : \u00e9criture impossible sur ' + name, cause);
    }
  }
  NS.writeProperty = writeProperty;

  /* ================= Info-bulle « i » du pied du drawer ================= */

  /* Contenu de l'info-bulle : état de réception de chaque propriété lue
     (state.propertyStatus), avertissements de normalisation (par propriété),
     puis la configuration JSON reçue, remise en forme si elle est analysable,
     telle quelle sinon (une configuration invalide reste ainsi consultable
     pour la mise au point). */
  const propertyWarnings = {};
  let configText = '';

  function updateConfigTooltip() {
    const lines = [];
    for (const name of READ_PROPERTIES) {
      lines.push(name + ' : ' + (state.propertyStatus[name] || 'en attente'));
      for (const w of propertyWarnings[name] || []) lines.push('  ! ' + w);
    }
    lines.push('');
    let pretty = configText;
    try {
      pretty = JSON.stringify(JSON.parse(configText), null, 2);
    } catch (ignored) { /* JSON invalide : texte brut */ }
    lines.push(pretty || CONFIG_PROPERTY + ' est vide.');
    NS.dom.configTooltipText.textContent = lines.join('\n');
  }

  /* État de réception et avertissements d'une propriété lue : info-bulle
     + console (console.warn pour les avertissements, une fois par valeur). */
  function setStatus(name, status, warnings) {
    state.propertyStatus[name] = status;
    propertyWarnings[name] = warnings || [];
    for (const w of propertyWarnings[name]) {
      console.warn('MyPnPlanViewerV2 : ' + name + ' : ' + w);
    }
    updateConfigTooltip();
  }

  /* Analyse d'une valeur de propriété : { empty } si vide, { value } si le
     JSON est analysable, { error } sinon (l'erreur est tracée). */
  function parseValue(name, value) {
    const text = typeof value === 'string' ? value.trim() : '';
    if (text.length === 0) return { empty: true, text };
    try {
      return { value: JSON.parse(text), text };
    } catch (cause) {
      console.error('MyPnPlanViewerV2 : ' + name + ' : JSON invalide', cause);
      return { error: cause.message, text };
    }
  }

  /* =================== configuration_plan_json =================== */

  // Nouvelle valeur : l'objet est reconstruit (ou mis à jour à chaud si
  // seuls les badges fixes changent — viewer-nav.js). Il n'y a
  // volontairement aucune configuration de repli embarquée, la propriété
  // fait seule foi.
  function applyConfiguration(value) {
    const parsed = parseValue(CONFIG_PROPERTY, value);
    configText = parsed.text;

    if (parsed.empty) {
      const empty = NS.normalizeConfig(null);
      empty.error = CONFIG_PROPERTY + ' est vide.';
      setStatus(CONFIG_PROPERTY, 'vide', []);
      NS.applyConfig(empty);
      return;
    }
    if (parsed.error) {
      const invalid = NS.normalizeConfig(null);
      invalid.error = CONFIG_PROPERTY + ' : JSON invalide \u2014 ' + parsed.error;
      setStatus(CONFIG_PROPERTY, 'JSON invalide \u2014 ' + parsed.error, []);
      NS.applyConfig(invalid);
      return;
    }

    const config = NS.normalizeConfig(parsed.value);
    setStatus(CONFIG_PROPERTY,
      config.byId.size + ' n\u0153ud(s), ' + config.pinned.length + ' vue(s) \u00e9pingl\u00e9e(s)' +
      (config.tree.length === 0 && config.plans.length > 0
        ? ', mode sans navigation (' + config.plans.length + ' plan(s))' : '') +
      (config.warnings.length ? ', ' + config.warnings.length + ' avertissement(s)' : ''),
      config.warnings);
    NS.applyConfig(config);
  }

  /* =================== configuration_events_json =================== */

  // Nouvelle valeur : mise à jour à chaud des pastilles, badges, capteurs et
  // formes (viewer-nav.js applyEvents). Vide = plus aucune alarme. JSON
  // invalide = état précédent CONSERVÉ (une valeur illisible ne doit pas
  // effacer des alarmes réelles), erreur tracée.
  function applyEvents(value) {
    const parsed = parseValue(EVENTS_PROPERTY, value);
    if (parsed.error) {
      setStatus(EVENTS_PROPERTY,
        'JSON invalide \u2014 ' + parsed.error + ' (\u00e9tat pr\u00e9c\u00e9dent conserv\u00e9)', []);
      return;
    }
    const events = NS.normalizeEventList(parsed.empty ? [] : parsed.value);
    const onNodes = events.list.filter((ev) => ev.node_id !== null).length;
    const onElements = events.list.filter((ev) => ev.element_id !== null).length;
    setStatus(EVENTS_PROPERTY,
      parsed.empty ? 'vide (aucune alarme)'
        : events.list.length + ' \u00e9v\u00e9nement(s) \u2014 ' + onNodes + ' sur un n\u0153ud, ' +
          onElements + ' sur un capteur' +
          (events.warnings.length ? ', ' + events.warnings.length + ' avertissement(s)' : ''),
      events.warnings);
    NS.applyEvents(events);
  }

  /* =================== current_plan_element_json =================== */

  // Nouvelle valeur : les capteurs sont mémorisés pour le plan visé
  // (node_id + planIndex, ou le plan affiché s'ils sont absents) et, si ce
  // plan est celui à l'écran, affichés (module elements, phase 3 : pour
  // l'instant ils alimentent la couverture des formes du mode édition).
  function applyElements(value) {
    const parsed = parseValue(ELEMENTS_PROPERTY, value);
    if (parsed.error) {
      setStatus(ELEMENTS_PROPERTY, 'JSON invalide \u2014 ' + parsed.error, []);
      return;
    }
    const result = NS.normalizeElements(parsed.empty ? [] : parsed.value);
    const plan = state.currentPlan;
    const currentKey = plan ? NS.elementsKey(plan) : null;
    let key = currentKey;
    let target = 'plan affich\u00e9';
    const explicit = result.node_id !== null && result.planIndex !== null;
    if (explicit) {
      // Plan désigné explicitement (recommandé) : mémorisé sous sa clé, et
      // affiché seulement s'il est celui à l'écran. node_id et planIndex ne
      // désignent un plan que fournis ENSEMBLE (readme § 8) ; l'un des deux
      // seul est ignoré, comme s'ils étaient absents.
      key = NS.elementsKeyFor(result.node_id, result.planIndex);
      if (key !== currentKey) {
        target = 'n\u0153ud ' + result.node_id + ' / plan ' + result.planIndex +
          ' (non affich\u00e9 : m\u00e9moris\u00e9)';
      }
    } else if (!plan) {
      setStatus(ELEMENTS_PROPERTY,
        'ignor\u00e9 : ni node_id / planIndex ni plan affich\u00e9', result.warnings);
      return;
    }
    state.elementsCache.set(key, result.elements);
    if (key === currentKey) {
      state.currentElements = result.elements;
      if (typeof NS.renderElements === 'function') NS.renderElements();
      // L'indicateur « Capteurs couverts » du mode édition et l'anneau des
      // capteurs couverts dépendent des capteurs du plan : retracés.
      if (typeof NS.renderEditLayer === 'function') NS.renderEditLayer();
    }
    setStatus(ELEMENTS_PROPERTY,
      result.elements.length + ' capteur(s) pour ' + target +
      (result.warnings.length ? ', ' + result.warnings.length + ' avertissement(s)' : ''),
      result.warnings);
  }

  /* =================== current_plan_drawnShapes_json =================== */

  // Nouvelle valeur : les formes REMPLACENT celles que l'objet connaissait
  // pour le plan visé (node_id + planIndex fournis ensemble, sinon le plan
  // affiché) — l'application fait foi, y compris sur les formes dessinées
  // par l'opérateur. GARDE ANTI-ÉCHO : une valeur identique à la dernière
  // écriture de l'objet est ignorée (Panorama renvoie aux abonnés ce que
  // l'objet vient d'écrire ; sans cette garde, la forme en cours de
  // retouche serait désélectionnée à chaque modification).
  function applyDrawnShapes(value) {
    const text = typeof value === 'string' ? value : '';
    if (text === lastWritten[DRAWN_SHAPES_PROPERTY]) {
      setStatus(DRAWN_SHAPES_PROPERTY, '\u00e9cho de la derni\u00e8re \u00e9criture (ignor\u00e9)', []);
      return;
    }
    const parsed = parseValue(DRAWN_SHAPES_PROPERTY, value);
    if (parsed.error) {
      setStatus(DRAWN_SHAPES_PROPERTY, 'JSON invalide \u2014 ' + parsed.error, []);
      return;
    }
    const result = NS.normalizeDrawnShapes(parsed.empty ? [] : parsed.value);
    const plan = state.currentPlan;
    const currentKey = plan ? NS.elementsKey(plan) : null;
    let key = currentKey;
    let target = 'plan affich\u00e9';
    const explicit = result.node_id !== null && result.planIndex !== null;
    if (explicit) {
      key = NS.elementsKeyFor(result.node_id, result.planIndex);
      if (key !== currentKey) {
        target = 'n\u0153ud ' + result.node_id + ' / plan ' + result.planIndex +
          ' (non affich\u00e9 : m\u00e9moris\u00e9)';
      }
    } else if (!plan) {
      setStatus(DRAWN_SHAPES_PROPERTY,
        parsed.empty ? 'vide' : 'ignor\u00e9 : ni node_id / planIndex ni plan affich\u00e9',
        result.warnings);
      return;
    }
    NS.setPlanShapes(key, result.shapes);
    setStatus(DRAWN_SHAPES_PROPERTY,
      result.shapes.length + ' forme(s) pour ' + target +
      (result.warnings.length ? ', ' + result.warnings.length + ' avertissement(s)' : ''),
      result.warnings);
  }

  /* =================== current_plan_scene3d_json =================== */

  // Nouvelle valeur : la scène 3D (vue par défaut, emprise, fond de plan,
  // objets, zones) REMPLACE celle que l'objet connaissait pour le plan visé
  // (node_id + planIndex fournis ensemble, sinon le plan affiché) —
  // l'application fait foi. Vide = scène vide (vue automatique). Même garde
  // anti-écho que les formes (viewer-scene3d.js).
  function applyScene3d(value) {
    const text = typeof value === 'string' ? value : '';
    if (text === lastWritten[SCENE3D_PROPERTY]) {
      setStatus(SCENE3D_PROPERTY, '\u00e9cho de la derni\u00e8re \u00e9criture (ignor\u00e9)', []);
      return;
    }
    const parsed = parseValue(SCENE3D_PROPERTY, value);
    if (parsed.error) {
      setStatus(SCENE3D_PROPERTY, 'JSON invalide \u2014 ' + parsed.error, []);
      return;
    }
    const result = NS.normalizeScene3d(parsed.empty ? {} : parsed.value);
    const plan = state.currentPlan;
    const currentKey = plan ? NS.elementsKey(plan) : null;
    let key = currentKey;
    let target = 'plan affich\u00e9';
    const explicit = result.node_id !== null && result.planIndex !== null;
    if (explicit) {
      key = NS.elementsKeyFor(result.node_id, result.planIndex);
      if (key !== currentKey) {
        target = 'n\u0153ud ' + result.node_id + ' / plan ' + result.planIndex +
          ' (non affich\u00e9 : m\u00e9moris\u00e9)';
      }
    } else if (!plan) {
      setStatus(SCENE3D_PROPERTY,
        parsed.empty ? 'vide' : 'ignor\u00e9 : ni node_id / planIndex ni plan affich\u00e9',
        result.warnings);
      return;
    }
    NS.setPlanScene3d(key, result.scene);
    setStatus(SCENE3D_PROPERTY,
      (parsed.empty ? 'vide (sc\u00e8ne vide)' : NS.describeScene3d(result.scene)) +
      ' pour ' + target +
      (result.warnings.length ? ', ' + result.warnings.length + ' avertissement(s)' : ''),
      result.warnings);
  }

  /* ============================ Démarrage ============================ */

  // Visualiseur vide en attendant la première notification de
  // configuration_plan_json.
  const waiting = NS.normalizeConfig(null);
  waiting.error = 'En attente de ' + CONFIG_PROPERTY + '\u2026';
  NS.applyConfig(waiting);
  updateConfigTooltip();

  const HANDLERS = {
    [CONFIG_PROPERTY]: applyConfiguration,
    [EVENTS_PROPERTY]: applyEvents,
    [ELEMENTS_PROPERTY]: applyElements,
    [DRAWN_SHAPES_PROPERTY]: applyDrawnShapes,
    [SCENE3D_PROPERTY]: applyScene3d,
  };

  // L'écouteur est posé AVANT subscribeProperties : l'abonnement déclenche une
  // notification initiale immédiate, qui serait perdue dans l'ordre inverse.
  // Dans un même lot, la configuration est appliquée avant les autres
  // propriétés (elles se rapportent à l'arbre et aux plans qu'elle décrit).
  panoInterface.addEventListener('properties', (notification) => {
    const props = notification.properties.slice().sort((a, b) =>
      READ_PROPERTIES.indexOf(a.name) - READ_PROPERTIES.indexOf(b.name));
    for (const property of props) {
      const handler = HANDLERS[property.name];
      if (handler) handler(property.value);
    }
  });

  // Pendant une coupure, aucune notification n'est émise : l'objet est estompé
  // pour que l'opérateur sache que l'affichage n'est plus rafraîchi.
  panoInterface.addEventListener('connectionstatus', (notification) => {
    NS.dom.viewerRoot.classList.toggle(
      'is-disconnected',
      Boolean(notification.connectionLost),
    );
    NS.dom.viewerRoot.title = notification.connectionLost
      ? 'Connexion au serveur d\u2019IHM Web perdue'
      : '';
  });

  panoInterface.subscribeProperties(READ_PROPERTIES).catch((cause) => {
    console.error(
      'MyPnPlanViewerV2 : abonnement aux propri\u00e9t\u00e9s impossible',
      cause,
    );
  });
})(globalThis);
