﻿/* ============================================================
   MyPnPlanViewerV2 — module « scene3d-tools »
   ============================================================
   Interactions au pointeur et au clavier du mode d'édition 3D
   (viewer-scene3d.js), sur le canvas du visualiseur Three.js :

     - outil « Navigation » (orbit) : la caméra tourne / zoome / se déplace
       (OrbitControls) ; un CLIC (sans glisser) sur une entité de la scène
       (emprise, fond de plan, étalon, mesure) la sélectionne, ailleurs
       désélectionne ; l'entité sélectionnée se déplace en la faisant
       glisser et s'ajuste par ses poignées ;
     - outils de tracé au sol, un clic par sommet :
         Emprise (footprint)  polygone, 3 sommets au moins, fermé par clic
                              sur le premier sommet, double-clic ou Entrée ;
         Étalon (scale)       segment : le second clic termine ;
         Distance (measure)   polyligne, 2 sommets au moins, terminée par
                              double-clic ou Entrée ;
         Surface (area)       polygone, comme l'emprise.
       Échap annule le tracé. L'emprise et l'étalon sont uniques par plan
       (remplacés) ; les mesures s'accumulent ;
     - flèche nord (clé north, viewer-scene3d-render.js) : sélectionnée
       par clic, déplacée en la faisant glisser, orientée par sa poignée
       ambre ;
     - outil « Fond de plan » (floorimage) : un clic sur le sol pose
       l'image (fichier de la galerie editFloorImages, ou saisi) centrée à
       cet endroit ; une seule par plan.

   Pendant un glisser de poignée ou d'entité, OrbitControls est suspendu
   (écouteur en phase de CAPTURE sur le cadre, donc avant OrbitControls qui
   écoute le canvas). Chaque modification est écrite dans
   current_plan_scene3d_json (NS.writeScene3d).

   NOTE ENCODAGE : chaînes affichées en ASCII pur (\uXXXX), commentaires
   accentués, BOM UTF-8, fins de ligne CRLF (readme.txt § 14).
   ============================================================ */
(function (global) {
  'use strict';

  const NS = global.MyPnPlanViewerV2NS = global.MyPnPlanViewerV2NS || {};
  const sc = NS.scene3d;
  const r = NS.scene3dRender;

  const CLICK_SLOP_PX = 5;   // au-delà, le pointeur a glissé (pas un clic)
  const DRAFT_TOOLS = ['footprint', 'scale', 'measure', 'area', 'zone'];
  const MIN_POINTS = { footprint: 3, scale: 2, measure: 2, area: 3, zone: 3 };
  const CLOSED = { footprint: true, area: true, zone: true };

  const viewport = NS.dom.threeViewport;

  let pointer = null;   // pointeur enfoncé : { x, y, hit, drag, moved }
  let draft = null;     // tracé en cours : { kind, points, cursor }

  function active() {
    return NS.sceneEditActive();
  }

  function controls() {
    const v = global.ThreeViewer;
    const c = v && v.getContext ? v.getContext() : null;
    return c ? c.controls : null;
  }

  function round2(v) {
    return Math.round(v * 100) / 100;
  }

  /* ---------------------- Tracés au sol ---------------------- */

  function setDraft(d) {
    draft = d;
    r.setDraft(d);
    r.rebuild();
  }

  function cancelDraft() {
    if (!draft) return;
    setDraft(null);
  }

  function addDraftPoint(p) {
    if (!draft) draft = { kind: sc.tool, points: [], cursor: null };
    draft.points.push(p);
    draft.cursor = null;
    if (draft.kind === 'scale' && draft.points.length >= 2) {
      closeDraft();
      return;
    }
    setDraft(draft);
  }

  /* Termine le tracé en cours : crée l'entité correspondante, la
     sélectionne, revient à l'outil Navigation et écrit la scène. */
  function closeDraft() {
    if (!draft || draft.points.length < MIN_POINTS[draft.kind]) return;
    const scene = sc.scene;
    const points = draft.points.map((p) => p.slice());
    const kind = draft.kind;
    draft = null;
    r.setDraft(null);
    if (kind === 'footprint') {
      const style = sc.style3d;
      scene.footprint = {
        points, stroke: style.stroke, strokeWidth: style.strokeWidth, dashed: style.dashed,
        fill: style.fill, fillOpacity: style.fillOpacity, altitude: 0, shown: true,
      };
      NS.selectScene3d('footprint');
    } else if (kind === 'scale') {
      // Longueur réelle préremplie selon l'échelle en vigueur (ou la
      // longueur en unités du modèle sans échelle), à corriger dans le
      // panneau.
      const d = NS.polylineLength(points, false);
      const value = scene.scale && scene.scale.value ? scene.scale.value : 1;
      scene.scale = {
        value, x1: points[0][0], z1: points[0][1], x2: points[1][0], z2: points[1][1],
        length: round2(d * value), shown: true,
      };
      NS.selectScene3d('scale');
    } else if (kind === 'zone') {
      let next = 0;
      for (const z of scene.zones) if (z.id > next) next = z.id;
      scene.zones.push({
        id: next + 1, label: 'Zone ' + (next + 1), description: '', points, baseHeight: 0,
        height: NS.scene3dZones ? NS.scene3dZones.defaultHeight() : 10, color: '#f59e0b', opacity: 0.35,
        group: null, show_mode: 'always_without_animation', elements: [], shown: true,
      });
      NS.selectScene3d('zone', scene.zones.length - 1);
    } else {
      let next = 0;
      for (const m of scene.measures) if (m.id > next) next = m.id;
      scene.measures.push({
        id: next + 1, type: kind === 'area' ? 'area' : 'distance', points, label: '', shown: true,
      });
      NS.selectScene3d('measure', scene.measures.length - 1);
    }
    NS.setSceneTool('orbit');
    NS.commitScene3d();
  }

  /* ---------------------- Outil Objet ---------------------- */

  /* Pose l'objet choisi dans la galerie (sc.pendingModel, sinon le premier
     de la clé editModels) au point cliqué, à sa taille réelle déclarée. */
  function placeObject(p) {
    const library = NS.state.currentConfig.editModels || [];
    const entry = library.find((m) => m.filename === sc.pendingModel) || library[0];
    if (!entry) return;
    const scene = sc.scene;
    let next = 0;
    for (const o of scene.objects) if (o.id > next) next = o.id;
    scene.objects.push({
      id: next + 1, filename: entry.filename, label: entry.label, x: p[0], z: p[1],
      altitude: 0, rotation: 0, size: entry.size, scale: 1, color: entry.color, shown: true,
    });
    NS.selectScene3d('object', scene.objects.length - 1);
    NS.setSceneTool('orbit');
    NS.commitScene3d();
  }

  /* ---------------------- Outil Fond de plan ---------------------- */

  function placeFloorImage(p) {
    const gallery = NS.state.currentConfig.editFloorImages || [];
    const filename = sc.pendingFloorImage || (gallery.length ? gallery[0].filename : '');
    sc.scene.floorImage = {
      filename,
      x: p[0], z: p[1],
      width: null, height: null,
      rotation: 0, opacity: 0.85, altitude: 0, shown: true,
    };
    NS.selectScene3d('floorImage');
    NS.setSceneTool('orbit');
    NS.commitScene3d();
    if (!filename) {
      // Aucune galerie : l'opérateur saisit le fichier dans le panneau.
      NS.dom.sceneFloorFile.focus();
    }
  }

  /* ---------------------- Glissers ---------------------- */

  /* Démarre un glisser selon ce qui est sous le pointeur (poignée, ou
     entité sélectionnée). Retourne l'objet drag, ou null. */
  function startDrag(hit, ground) {
    const scene = sc.scene;
    if (!hit || !ground) return null;
    const sel = sc.selected;
    switch (hit.kind) {
      case 'fpVertex':
        return scene.footprint ? { kind: 'fpVertex', index: hit.index } : null;
      case 'sVertex':
        return scene.scale ? { kind: 'sVertex', index: hit.index } : null;
      case 'mVertex':
        return scene.measures[sc.selectedIndex] ? { kind: 'mVertex', index: hit.index } : null;
      case 'fiCorner':
        return scene.floorImage ? { kind: 'fiCorner' } : null;
      case 'fiRotate':
        return scene.floorImage ? { kind: 'fiRotate' } : null;
      case 'footprint':
        return sel === 'footprint' && scene.footprint
          ? { kind: 'move', start: ground, points: scene.footprint.points.map((p) => p.slice()),
            apply: (pts) => { scene.footprint.points = pts; } }
          : null;
      case 'scale':
        return sel === 'scale' && scene.scale
          ? { kind: 'move', start: ground, points: [[scene.scale.x1, scene.scale.z1], [scene.scale.x2, scene.scale.z2]],
            apply: (pts) => { Object.assign(scene.scale, { x1: pts[0][0], z1: pts[0][1], x2: pts[1][0], z2: pts[1][1] }); } }
          : null;
      case 'measure':
        return sel === 'measure' && hit.index === sc.selectedIndex && scene.measures[hit.index]
          ? { kind: 'move', start: ground, points: scene.measures[hit.index].points.map((p) => p.slice()),
            apply: (pts) => { scene.measures[hit.index].points = pts; } }
          : null;
      case 'floorImage':
        return sel === 'floorImage' && scene.floorImage
          ? { kind: 'fiMove', start: ground, x: scene.floorImage.x, z: scene.floorImage.z }
          : null;
      case 'zVertex':
        return scene.zones[sc.selectedIndex] ? { kind: 'zVertex', index: hit.index } : null;
      case 'zone':
        return sel === 'zone' && hit.index === sc.selectedIndex && scene.zones[hit.index] && !scene.zones[hit.index].group
          ? { kind: 'move', start: ground, points: scene.zones[hit.index].points.map((p) => p.slice()),
            apply: (pts) => { scene.zones[hit.index].points = pts; } }
          : null;
      case 'nRotate':
        return scene.north ? { kind: 'nRotate' } : null;
      case 'north': {
        if (sel !== 'north' || !scene.north) return null;
        const p = r.northPosition(scene.north);
        return { kind: 'nMove', start: ground, x: p[0], z: p[1] };
      }
      case 'oRotate':
        return scene.objects[sc.selectedIndex] ? { kind: 'oRotate' } : null;
      case 'oScale': {
        const o = scene.objects[sc.selectedIndex];
        return o ? { kind: 'oScale', scale0: o.scale, r0: r.objectRadius(o) } : null;
      }
      case 'object':
        return sel === 'object' && hit.index === sc.selectedIndex && scene.objects[hit.index]
          ? { kind: 'oMove', start: ground, x: scene.objects[hit.index].x, z: scene.objects[hit.index].z }
          : null;
      default:
        return null;
    }
  }

  function applyDrag(drag, ground) {
    const scene = sc.scene;
    if (!ground) return;
    if (drag.kind === 'fpVertex') {
      scene.footprint.points[drag.index] = ground.slice();
    } else if (drag.kind === 'sVertex') {
      const s = scene.scale;
      if (drag.index === 0) { s.x1 = ground[0]; s.z1 = ground[1]; } else { s.x2 = ground[0]; s.z2 = ground[1]; }
      // La longueur réelle suit le facteur d'échelle en vigueur.
      s.length = round2(Math.hypot(s.x2 - s.x1, s.z2 - s.z1) * s.value);
    } else if (drag.kind === 'mVertex') {
      scene.measures[sc.selectedIndex].points[drag.index] = ground.slice();
    } else if (drag.kind === 'zVertex') {
      scene.zones[sc.selectedIndex].points[drag.index] = ground.slice();
    } else if (drag.kind === 'move') {
      const dx = ground[0] - drag.start[0], dz = ground[1] - drag.start[1];
      drag.apply(drag.points.map((p) => [round2(p[0] + dx), round2(p[1] + dz)]));
    } else if (drag.kind === 'fiMove') {
      scene.floorImage.x = round2(drag.x + ground[0] - drag.start[0]);
      scene.floorImage.z = round2(drag.z + ground[1] - drag.start[1]);
    } else if (drag.kind === 'oMove') {
      const o = scene.objects[sc.selectedIndex];
      o.x = round2(drag.x + ground[0] - drag.start[0]);
      o.z = round2(drag.z + ground[1] - drag.start[1]);
    } else if (drag.kind === 'nMove') {
      scene.north.x = round2(drag.x + ground[0] - drag.start[0]);
      scene.north.z = round2(drag.z + ground[1] - drag.start[1]);
    } else if (drag.kind === 'nRotate') {
      // Angle horaire vu de dessus depuis -z : atan2(dx, -dz).
      const p = r.northPosition(scene.north);
      const a = Math.atan2(ground[0] - p[0], -(ground[1] - p[1])) * 180 / Math.PI;
      scene.north.angle = Math.round(((a % 360) + 360) % 360);
    } else if (drag.kind === 'oRotate') {
      const o = scene.objects[sc.selectedIndex];
      const a = Math.atan2(ground[1] - o.z, ground[0] - o.x) * 180 / Math.PI + 90;
      o.rotation = Math.round(((a % 360) + 360) % 360);
    } else if (drag.kind === 'oScale') {
      const o = scene.objects[sc.selectedIndex];
      const d = Math.hypot(ground[0] - o.x, ground[1] - o.z);
      o.scale = Math.round(Math.min(100, Math.max(0.05, drag.scale0 * d / drag.r0)) * 100) / 100;
    } else if (drag.kind === 'fiCorner') {
      // Largeur = deux fois l'abscisse locale du curseur (hauteur suivant
      // le rapport de l'image, ou le rapport fixé par height).
      const local = r.floorLocal(ground[0], ground[1]);
      if (!local) return;
      const fi = scene.floorImage;
      const w = Math.max(r.modelSize() * 0.01, Math.abs(local[0]) * 2);
      if (fi.height && fi.width) fi.height = round2(fi.height * w / fi.width);
      fi.width = round2(w);
    } else if (drag.kind === 'fiRotate') {
      const fi = scene.floorImage;
      const a = Math.atan2(ground[1] - fi.z, ground[0] - fi.x) * 180 / Math.PI + 90;
      fi.rotation = Math.round(((a % 360) + 360) % 360);
    }
    r.rebuild();
  }

  /* ---------------------- Pointeur ---------------------- */

  /* Consultation (cadenas fermé ou mode édition absent) : un clic sans
     glisser sur une zone demande son détail à l'application. */
  let consultClick = null;

  /* Le repère de coin (SVG superposé au canvas) gère ses propres clics. */
  function onHelper(e) {
    const h = NS.dom.threeHelper;
    return Boolean(h && e.target && h.contains(e.target));
  }

  viewport.addEventListener('pointerdown', (e) => {
    if (onHelper(e)) return;
    if (e.button === 0 && !active() && NS.sceneAvailable()) {
      consultClick = { x: e.clientX, y: e.clientY };
      return;
    }
    if (!active() || e.button !== 0) return;
    const hit = r.pick(e.clientX, e.clientY);
    const ground = r.groundPoint(e.clientX, e.clientY);
    pointer = { x: e.clientX, y: e.clientY, hit, drag: null, moved: false };
    if (sc.tool === 'orbit') {
      pointer.drag = startDrag(hit, ground);
      if (pointer.drag) {
        const c = controls();
        if (c) c.enabled = false;
        viewport.setPointerCapture(e.pointerId);
        e.stopPropagation();
      }
    }
  }, true);

  viewport.addEventListener('pointermove', (e) => {
    const zones = NS.scene3dZones;
    if (!active()) {
      // Survol des zones en consultation (pas pendant un glisser d'orbite).
      if (zones && NS.sceneAvailable() && !(e.buttons & 1)) zones.setHover(zones.pick(e.clientX, e.clientY), e.clientX, e.clientY);
      return;
    }
    if (zones && !pointer && !draft && !(e.buttons & 1)) {
      zones.setHover(sc.tool === 'orbit' ? zones.pick(e.clientX, e.clientY) : -1, e.clientX, e.clientY);
    } else if (zones && (pointer || draft)) {
      zones.clearHover();
    }
    if (pointer && pointer.drag) {
      if (Math.hypot(e.clientX - pointer.x, e.clientY - pointer.y) > CLICK_SLOP_PX) pointer.moved = true;
      if (pointer.moved) applyDrag(pointer.drag, r.groundPoint(e.clientX, e.clientY));
      return;
    }
    if (draft && !(e.buttons & 1)) {
      const g = r.groundPoint(e.clientX, e.clientY);
      if (g) { draft.cursor = g; setDraft(draft); }
    }
  }, true);

  viewport.addEventListener('pointerleave', () => {
    if (NS.scene3dZones) NS.scene3dZones.clearHover();
  });

  function endPointer(e) {
    if (consultClick) {
      const c = consultClick;
      consultClick = null;
      if (e.type === 'pointerup' && !active() && NS.scene3dZones &&
          Math.hypot(e.clientX - c.x, e.clientY - c.y) <= CLICK_SLOP_PX) {
        const idx = NS.scene3dZones.pick(e.clientX, e.clientY);
        if (idx >= 0) NS.scene3dZones.requestDetail(idx);
      }
      return;
    }
    if (!pointer) return;
    if (onHelper(e) && !pointer.drag) { pointer = null; return; }
    const p = pointer;
    pointer = null;
    const c = controls();
    if (c && !c.enabled) c.enabled = true;
    if (p.drag) {
      if (viewport.hasPointerCapture && viewport.hasPointerCapture(e.pointerId)) {
        viewport.releasePointerCapture(e.pointerId);
      }
      if (p.moved) NS.commitScene3d();
      return;
    }
    if (e.type !== 'pointerup' || Math.hypot(e.clientX - p.x, e.clientY - p.y) > CLICK_SLOP_PX) return;
    // Clic sans glisser.
    const ground = r.groundPoint(e.clientX, e.clientY);
    if (sc.tool === 'orbit') {
      const hit = p.hit;
      if (hit && (hit.kind === 'footprint' || hit.kind === 'floorImage' || hit.kind === 'scale' || hit.kind === 'north')) {
        NS.selectScene3d(hit.kind);
      } else if (hit && (hit.kind === 'measure' || hit.kind === 'object' || hit.kind === 'zone')) {
        NS.selectScene3d(hit.kind, hit.index);
      } else {
        // Zone liée à un groupe du modèle : sélectionnée par son maillage.
        const zi = NS.scene3dZones ? NS.scene3dZones.pick(e.clientX, e.clientY) : -1;
        NS.selectScene3d(zi >= 0 ? 'zone' : null, zi);
      }
    } else if (DRAFT_TOOLS.includes(sc.tool)) {
      if (draft && CLOSED[draft.kind] && p.hit && p.hit.kind === 'draftVertex' && p.hit.index === 0 &&
          draft.points.length >= MIN_POINTS[draft.kind]) {
        closeDraft();
      } else if (ground) {
        addDraftPoint(ground);
      }
    } else if (sc.tool === 'floorimage') {
      if (ground) placeFloorImage(ground);
    } else if (sc.tool === 'object') {
      if (ground) placeObject(ground);
    }
  }
  viewport.addEventListener('pointerup', endPointer, true);
  viewport.addEventListener('pointercancel', endPointer, true);

  viewport.addEventListener('dblclick', () => {
    if (!active()) return;
    if (draft) closeDraft();
  });

  /* ---------------------- Clavier ---------------------- */

  document.addEventListener('keydown', (e) => {
    if (!active()) return;
    const tag = e.target && e.target.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
    if (e.key === 'Escape') {
      if (draft) cancelDraft();
      else if (sc.selected) NS.selectScene3d(null);
      else if (sc.tool !== 'orbit') NS.setSceneTool('orbit');
    } else if (e.key === 'Enter') {
      if (draft) closeDraft();
    } else if ((e.key === 'Delete' || e.key === 'Backspace') && !pointer) {
      NS.deleteSelectedScene3d();
    }
  });

  /* Changement d'outil : le tracé en cours est abandonné. */
  function onToolChange() {
    if (draft) cancelDraft();
  }

  /* ------------------- Exposition sur l'espace de noms ------------------- */
  NS.scene3dTools = { closeDraft, cancelDraft, onToolChange, hasDraft: () => Boolean(draft) };
})(globalThis);
