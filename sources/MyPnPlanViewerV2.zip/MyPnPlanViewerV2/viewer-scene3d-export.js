﻿/* ============================================================
   MyPnPlanViewerV2 — module « scene3d-export »
   ============================================================
   Export PNG de la vue en plan d'une représentation 3D (menu du bouton
   « Vue en plan », viewer-scene3d-planview.js). Le SVG est produit par
   viewer-scene3d-export-svg.js, qui réutilise ce module.

   PNG : l'objet passe en vue en plan (sans transition) s'il n'y est pas,
   reconstruit la scène en MODE EXPORT (r.exporting : sans poignées ni
   tracé en cours, entités masquées non estompées, zones visibles comme en
   édition), capture le rendu WebGL à planExport.pngScale pixels par pixel
   écran (ThreeViewer.snapshot) après avoir cadré TOUTE LA SCÈNE (modèle et
   entités : ThreeViewer.fitPlanView sur sceneBounds, cadrage rendu ensuite
   à l'opérateur), pose au-dessus un en-tête (fil d'Ariane,
   représentation, « vue en plan », date et heure — comme l'impression)
   et télécharge le fichier plan-<lieu>-<date>.png (NS.downloadBytes,
   autorisé par le bac à sable de l'IHM Web). Le repère de coin, la puce
   de mode et les barres ne font pas partie du canvas : ils ne figurent
   jamais dans l'export. La vue en plan reste affichée après l'export.

   Chargé après viewer-scene3d-planview.js et avant viewer-scene3d-tools.js
   (ordre imposé par index.html, readme.txt § 1).

   NOTE ENCODAGE : chaînes affichées en ASCII pur (\uXXXX), commentaires
   accentués, BOM UTF-8, fins de ligne CRLF (readme.txt § 14).
   ============================================================ */
(function (global) {
  'use strict';

  const NS = global.MyPnPlanViewerV2NS = global.MyPnPlanViewerV2NS || {};
  const state = NS.state;

  const HEADER_PX = 46;     // hauteur de l'en-tête à l'échelle 1
  const BACKGROUND = '#f6f8fb';
  let busy = false;         // un export à la fois

  function viewer() {
    return global.ThreeViewer || null;
  }

  function available() {
    const v = viewer();
    return Boolean(NS.sceneAvailable && NS.sceneAvailable() && v && v.isActive && v.isActive() && v.snapshot);
  }

  /* Passe en vue en plan sans transition si besoin ; vrai si elle est
     effective (modèle chargé). */
  function ensurePlanView() {
    const v = viewer();
    if (!v.isPlanView()) NS.scene3dPlanView.setPlanView(true, { animate: false });
    return v.isPlanView();
  }

  /* Reconstruit la scène en mode export, exécute fn, restaure. */
  function withExportScene(fn) {
    const r = NS.scene3dRender;
    r.exporting = true;
    try {
      r.rebuild();
      return fn();
    } finally {
      r.exporting = false;
      r.rebuild();
    }
  }

  /* Boîte au sol { minX, maxX, minZ, maxZ } de tout ce qui se voit en vue
     en plan : modèle, emprise, fond de plan, étalon, mesures, objets, zones
     tracées, flèche nord (et son étiquette). */
  function sceneBounds() {
    const v = viewer();
    const r = NS.scene3dRender;
    const b = v.getModelBounds();
    const box = b ? { minX: b.min[0], maxX: b.max[0], minZ: b.min[2], maxZ: b.max[2] }
      : { minX: Infinity, maxX: -Infinity, minZ: Infinity, maxZ: -Infinity };
    const add = (x, z) => {
      if (!Number.isFinite(x) || !Number.isFinite(z)) return;
      box.minX = Math.min(box.minX, x); box.maxX = Math.max(box.maxX, x);
      box.minZ = Math.min(box.minZ, z); box.maxZ = Math.max(box.maxZ, z);
    };
    const pts = (list) => { for (const p of list || []) add(p[0], p[1]); };
    const scene = NS.scene3d.scene;
    if (scene) {
      if (scene.footprint) pts(scene.footprint.points);
      if (scene.scale && scene.scale.x1 !== null) { add(scene.scale.x1, scene.scale.z1); add(scene.scale.x2, scene.scale.z2); }
      for (const m of scene.measures) pts(m.points);
      for (const z of scene.zones) if (!z.group) pts(z.points);
      for (const o of scene.objects) {
        const rad = r.objectRadius(o);
        add(o.x - rad, o.z - rad); add(o.x + rad, o.z + rad);
      }
      if (scene.floorImage) {
        const fi = scene.floorImage;
        const w = fi.width || r.defaultFloorWidth();
        const h = fi.height || w * 0.75;
        const th = (fi.rotation || 0) * Math.PI / 180;
        for (const s of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) {
          const lx = s[0] * w / 2, lz = s[1] * h / 2;
          add(fi.x + lx * Math.cos(th) - lz * Math.sin(th), fi.z + lx * Math.sin(th) + lz * Math.cos(th));
        }
      }
      if (scene.north && scene.north.shown) {
        const p = r.northPosition(scene.north);
        const L = r.modelSize() * 0.08 * 1.6;   // pointe + étiquette
        add(p[0] - L, p[1] - L); add(p[0] + L, p[1] + L);
      }
    }
    return Number.isFinite(box.minX) ? box : null;
  }

  function pngScale() {
    const cfg = state.currentConfig && state.currentConfig.planExport;
    return cfg && cfg.pngScale ? cfg.pngScale : 2;
  }

  /* Libellé de la ligne secondaire de l'en-tête : représentation, mode,
     orientation. */
  function subtitle() {
    const plan = state.currentPlan ? state.currentPlan.label : '';
    const north = NS.northAngle ? NS.northAngle() : null;
    return plan + ' \u2014 vue en plan' +
      (north === null ? ' (haut : axe \u2212Z du mod\u00e8le, nord inconnu)' : ' (nord en haut, ' + NS.formatNumber(north) + '\u00b0)');
  }

  /* En-tête dessiné sur un canvas 2D (largeur w, échelle k). */
  function drawHeader(g, w, k, now) {
    g.fillStyle = '#ffffff';
    g.fillRect(0, 0, w, HEADER_PX * k);
    g.textBaseline = 'middle';
    g.textAlign = 'left';
    g.fillStyle = '#0f172a';
    g.font = '600 ' + Math.round(13 * k) + 'px "Segoe UI", system-ui, sans-serif';
    g.fillText(state.currentLocation || '', 14 * k, 16 * k);
    g.fillStyle = '#64748b';
    g.font = Math.round(11 * k) + 'px "Segoe UI", system-ui, sans-serif';
    g.fillText(subtitle(), 14 * k, 33 * k);
    g.textAlign = 'right';
    g.fillText(NS.formatPrintDateTime(now), w - 14 * k, 16 * k);
    g.textAlign = 'left';
    g.fillStyle = '#e2e8f0';
    g.fillRect(0, Math.round(HEADER_PX * k) - Math.max(1, Math.round(k)), w, Math.max(1, Math.round(k)));
  }

  /* Canvas complet de l'export PNG (en-tête + rendu de la vue en plan),
     à l'échelle de la configuration (ou k). */
  function renderPng(now, k) {
    const v = viewer();
    const scale = k || pngScale();
    const shot = withExportScene(() => {
      const box = sceneBounds();
      const restore = box ? v.fitPlanView(box) : () => {};
      try {
        return v.snapshot(scale);
      } finally {
        restore();
      }
    });
    const headerH = Math.round(HEADER_PX * scale);
    const out = document.createElement('canvas');
    out.width = shot.width;
    out.height = shot.height + headerH;
    const g = out.getContext('2d');
    g.fillStyle = BACKGROUND;
    g.fillRect(0, 0, out.width, out.height);
    drawHeader(g, out.width, scale, now || new Date());
    g.drawImage(shot, 0, headerH);
    return out;
  }

  function canvasToBlob(c) {
    return new Promise((resolve, reject) => {
      c.toBlob((b) => (b ? resolve(b) : reject(new Error('conversion PNG refus\u00e9e'))), 'image/png');
    });
  }

  /* Export PNG : promesse du nom du fichier téléchargé, ou null (un message
     l'explique). Le résultat est mémorisé dans NS.lastPlanExport (bancs). */
  async function exportPng() {
    if (!available() || busy) return null;
    busy = true;
    const now = new Date();
    try {
      if (!ensurePlanView()) throw new Error('vue en plan indisponible (mod\u00e8le non charg\u00e9)');
      const canvas = renderPng(now);
      const blob = await canvasToBlob(canvas);
      const name = NS.exportFileName('png', now);
      NS.downloadBytes(blob, name, 'image/png');
      NS.lastPlanExport = { kind: 'png', name, blob, width: canvas.width, height: canvas.height };
      NS.showPrintNotice('Vue en plan enregistr\u00e9e en PNG (' + name + ').', 'info', 8000);
      return name;
    } catch (cause) {
      console.error('MyPnPlanViewer : export PNG impossible', cause);
      NS.showPrintNotice('Export PNG impossible : ' + (cause && cause.message ? cause.message : cause));
      return null;
    } finally {
      busy = false;
    }
  }

  /* ------------------- Exposition sur l'espace de noms ------------------- */
  NS.scene3dExport = Object.assign(NS.scene3dExport || {}, {
    exportPng, renderPng, withExportScene, ensurePlanView, subtitle, drawHeader, pngScale, sceneBounds,
    HEADER_PX, isBusy: () => busy,
  });
})(globalThis);
