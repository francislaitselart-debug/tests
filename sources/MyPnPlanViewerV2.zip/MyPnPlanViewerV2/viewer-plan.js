﻿/* ============================================================
   MyPnPlanViewerV2 — module « plan »
   ============================================================
   Zone des plans : représentations 2D (image + calques superposables :
   image PNG, marqueurs, formes vectorielles SVG), bascule vers le rendu
   3D (three-viewer.js), SpeedDial de sélection de la représentation et
   des calques, carte de détails des marqueurs, zoom et déplacement.

   Mute l'état partagé NS.state (activeMode, currentPlan(s),
   layerElements) et notifie le mode édition (NS.refreshShapeEditing /
   NS.renderEditLayer), capteurs du plan (current_plan_element_json :
   rendu, show_mode, état d'alarme, carte au survol, clic -> demande de
   détail). Ordre de chargement : readme § 1.

   NOTE ENCODAGE : chaînes affichées en ASCII pur (\uXXXX), commentaires
   accentués, BOM UTF-8, fins de ligne CRLF (readme.txt § 14).
   ============================================================ */
(function (global) {
  'use strict';

  const NS = global.MyPnPlanViewerV2NS = global.MyPnPlanViewerV2NS || {};
  const state = NS.state;
  const clampNum = NS.clampNum;
  const {
    planZone, planEmpty, planEmptyTitle, planLocation, planViewport,
    planImage, planEditLayer, threeViewport,
    layersDialAnchor, markerCard, zoomToolbar, zoomLevelEl, zoomInBtn,
    zoomOutBtn, zoomResetBtn,
  } = NS.dom;

  /* ---------- Formes géométriques vectorielles (calques "shapes") ---------- */

  const SVG_NS = 'http://www.w3.org/2000/svg';

  /* Largeur du viewBox des calques SVG de formes ; la hauteur suit le ratio
     du plan de base, si bien qu'une unité horizontale et une unité verticale
     ont la même taille écran (les cercles restent ronds). */
  const SHAPES_VIEW_W = 1000;
  const SHAPE_LAYER_FILL = 'rgba(220, 38, 38, 0.18)';
  const SHAPE_LAYER_STROKE = '#dc2626';

  /* ---- Aides de construction des éléments SVG des formes ----
     Les coordonnées des formes sont en fraction du plan, converties en
     unités du viewBox (largeur SHAPES_VIEW_W, hauteur vbH au ratio du
     plan : une unité horizontale = une unité verticale à l'écran). Les
     tailles « écran » (pointes de flèche, textes, punaises) sont
     converties par pxToVb sur la LARGEUR AFFICHÉE HORS ZOOM du plan
     (offsetWidth, insensible au transform) : elles suivent donc le zoom
     comme la géométrie, et restent cohérentes entre calques de
     configuration et calque d'édition. */

  function pxToVb(px) {
    const w = planImage.offsetWidth;
    return w ? px * SHAPES_VIEW_W / w : px;
  }

  const DEG = Math.PI / 180;

  /* Point sur le cercle de centre (cx, cy) — fractions — et de rayon r
     (fraction de la largeur), à l'angle a en degrés (sens horaire, 0 = est),
     en unités du viewBox. */
  function sectorPoint(shape, a, vbH) {
    return {
      x: shape.cx * SHAPES_VIEW_W + shape.r * SHAPES_VIEW_W * Math.cos(a * DEG),
      y: shape.cy * vbH + shape.r * SHAPES_VIEW_W * Math.sin(a * DEG),
    };
  }

  /* Ouverture d'un secteur en degrés, dans ]0, 360] (mesurée de startAngle
     vers endAngle dans le sens horaire). */
  function sectorOpening(shape) {
    const o = ((shape.endAngle - shape.startAngle) % 360 + 360) % 360;
    return o === 0 ? 360 : o;
  }

  function sectorPathD(shape, vbH) {
    const cx = shape.cx * SHAPES_VIEW_W;
    const cy = shape.cy * vbH;
    const r = shape.r * SHAPES_VIEW_W;
    const p0 = sectorPoint(shape, shape.startAngle, vbH);
    const opening = sectorOpening(shape);
    if (opening >= 360) {
      // Disque complet : deux demi-arcs (un arc SVG ne peut pas faire 360°).
      const p180 = sectorPoint(shape, shape.startAngle + 180, vbH);
      return 'M ' + p0.x + ' ' + p0.y +
        ' A ' + r + ' ' + r + ' 0 1 1 ' + p180.x + ' ' + p180.y +
        ' A ' + r + ' ' + r + ' 0 1 1 ' + p0.x + ' ' + p0.y + ' Z';
    }
    const p1 = sectorPoint(shape, shape.endAngle, vbH);
    return 'M ' + cx + ' ' + cy +
      ' L ' + p0.x + ' ' + p0.y +
      ' A ' + r + ' ' + r + ' 0 ' + (opening > 180 ? 1 : 0) + ' 1 ' +
      p1.x + ' ' + p1.y + ' Z';
  }

  /* Encombrement estimé d'un texte (une seule ligne) en unités du viewBox,
     sans mesure DOM : les calques peuvent être construits masqués
     (display none), où getBBox ne répond pas. */
  function estimateTextVb(text, fontVb) {
    return {
      w: Math.max(fontVb * 0.65, String(text).length * fontVb * 0.62),
      h: fontVb * 1.4,
    };
  }

  function svgEl(tag) {
    return document.createElementNS(SVG_NS, tag);
  }

  function strokeAttrs(el, stroke, sw) {
    el.setAttribute('stroke', stroke);
    el.setAttribute('stroke-width', sw);
    el.setAttribute('vector-effect', 'non-scaling-stroke');
  }

  /* Longueur d'un segment (x1,y1)-(x2,y2) en fraction de la LARGEUR du
     plan : l'écart vertical, en fraction de hauteur, est ramené dans la
     même unité par le ratio hauteur/largeur affiché. */
  function segmentWidthFrac(shape) {
    const w = planImage.offsetWidth, h = planImage.offsetHeight;
    const ratio = w ? h / w : 1;
    return Math.hypot(shape.x2 - shape.x1, (shape.y2 - shape.y1) * ratio);
  }

  /* Échelle équivalente « largeur totale du plan » d'un étalon dessiné
     (forme "scale" : segment + longueur réelle value/unit) ; null si
     l'étalon est dégénéré. Même sémantique que la clé scale du plan. */
  function scaleShapeToPlanScale(shape) {
    const lenFrac = segmentWidthFrac(shape);
    return lenFrac > 0 && shape.value > 0
      ? { value: shape.value / lenFrac, unit: shape.unit || 'm' }
      : null;
  }

  /* Échelle effective du plan courant, utilisée par les cotes : étalon
     d'échelle dessiné par l'opérateur (mode édition), sinon étalon d'un
     calque "shapes" de la configuration, sinon clé scale de la
     représentation ; null si aucune (les cotes affichent alors un % de
     la largeur du plan). */
  function effectiveScale() {
    if (NS.editAvailable()) {
      for (const s of NS.edit.shapes) {
        if (s.type !== 'scale') continue;
        const sc = scaleShapeToPlanScale(s);
        if (sc) return sc;
      }
    }
    if (!state.currentPlan) return null;
    for (const layer of state.currentPlan.layers) {
      if (layer.kind !== 'shapes') continue;
      for (const s of layer.shapes) {
        if (s.type !== 'scale') continue;
        const sc = scaleShapeToPlanScale(s);
        if (sc) return sc;
      }
    }
    return state.currentPlan.scale || null;
  }

  /* Distance mise en forme : décimales selon l'ordre de grandeur. */
  function formatDistance(dist, unit) {
    const digits = dist >= 100 ? 0 : dist >= 10 ? 1 : 2;
    return dist.toFixed(digits) + ' ' + unit;
  }

  /* Texte de la distance d'une cote : selon l'échelle effective du plan
     courant (effectiveScale, readme § 10), sinon en % de la largeur du
     plan. Exposé pour la sérialisation (writeDrawnShapes). */
  function measureLabel(shape) {
    const lenFrac = segmentWidthFrac(shape);
    const scale = effectiveScale();
    if (!scale) return (lenFrac * 100).toFixed(1) + ' %';
    return formatDistance(lenFrac * scale.value, scale.unit);
  }

  /* Élément SVG d'une forme (types : readme § 10). L'épaisseur du trait est
     en pixels écran (vector-effect), constante à tout niveau de zoom. Les
     types composites (flèche, cote, libellé, étiquette, icône, punaise)
     sont des groupes <g> : leurs enfants héritent du fill/stroke posé sur
     le groupe, sauf réglage explicite. */
  function shapeSvgNode(shape, vbH, defaultFill, defaultStroke) {
    const fill = shape.fill || defaultFill;
    const stroke = shape.stroke || defaultStroke;
    const sw = shape.strokeWidth || 2;
    const X = (v) => v * SHAPES_VIEW_W;
    const Y = (v) => v * vbH;
    let el;

    if (shape.type === 'polygon' || shape.type === 'polyline') {
      el = svgEl(shape.type);
      el.setAttribute('points',
        shape.points.map((p) => X(p.x) + ',' + Y(p.y)).join(' '));
      // Une polyligne est un tracé ouvert, jamais rempli.
      el.setAttribute('fill', shape.type === 'polyline' ? 'none' : fill);
      strokeAttrs(el, stroke, sw);
    } else if (shape.type === 'rect') {
      el = svgEl('rect');
      el.setAttribute('x', X(shape.x));
      el.setAttribute('y', Y(shape.y));
      el.setAttribute('width', X(shape.w));
      el.setAttribute('height', Y(shape.h));
      el.setAttribute('fill', fill);
      strokeAttrs(el, stroke, sw);
    } else if (shape.type === 'circle') {
      el = svgEl('circle');
      el.setAttribute('cx', X(shape.cx));
      el.setAttribute('cy', Y(shape.cy));
      el.setAttribute('r', X(shape.r));
      el.setAttribute('fill', fill);
      strokeAttrs(el, stroke, sw);
    } else if (shape.type === 'ellipse') {
      el = svgEl('ellipse');
      el.setAttribute('cx', X(shape.cx));
      el.setAttribute('cy', Y(shape.cy));
      el.setAttribute('rx', X(shape.rx));
      el.setAttribute('ry', Y(shape.ry));
      el.setAttribute('fill', fill);
      strokeAttrs(el, stroke, sw);
    } else if (shape.type === 'sector') {
      el = svgEl('path');
      el.setAttribute('d', sectorPathD(shape, vbH));
      el.setAttribute('fill', fill);
      strokeAttrs(el, stroke, sw);
    } else if (shape.type === 'line') {
      el = svgEl('line');
      el.setAttribute('x1', X(shape.x1));
      el.setAttribute('y1', Y(shape.y1));
      el.setAttribute('x2', X(shape.x2));
      el.setAttribute('y2', Y(shape.y2));
      el.setAttribute('fill', 'none');
      strokeAttrs(el, stroke, sw);
    } else if (shape.type === 'arrow') {
      el = svgEl('g');
      el.setAttribute('fill', 'none');
      const line = svgEl('line');
      line.setAttribute('x1', X(shape.x1));
      line.setAttribute('y1', Y(shape.y1));
      line.setAttribute('x2', X(shape.x2));
      line.setAttribute('y2', Y(shape.y2));
      strokeAttrs(line, stroke, sw);
      el.appendChild(line);
      // Pointes : triangles pleins orientés selon la ligne, dimensionnés
      // en pixels écran au zoom 100 % (ils grossissent avec le zoom, comme
      // la ligne). La clé heads dit laquelle des extrémités en porte une :
      // « end » l'arrivée (défaut), « start » le départ, « both » les deux.
      const ang = Math.atan2(
        (shape.y2 - shape.y1) * vbH, (shape.x2 - shape.x1) * SHAPES_VIEW_W);
      const headLen = pxToVb(sw * 3 + 7);
      const headW = headLen * 0.55;
      const heads = NS.normalizeArrowHeads(shape.heads);
      // [pointe, orientation] de chaque extrémité fléchée.
      const tips = [];
      if (heads !== 'start') tips.push([X(shape.x2), Y(shape.y2), ang]);
      if (heads !== 'end') tips.push([X(shape.x1), Y(shape.y1), ang + Math.PI]);
      for (const [hx, hy, a] of tips) {
        const bx = hx - headLen * Math.cos(a);
        const by = hy - headLen * Math.sin(a);
        const ox = headW * Math.sin(a), oy = -headW * Math.cos(a);
        const head = svgEl('polygon');
        head.setAttribute('points',
          hx + ',' + hy + ' ' + (bx + ox) + ',' + (by + oy) + ' ' +
          (bx - ox) + ',' + (by - oy));
        head.setAttribute('fill', stroke);
        head.setAttribute('stroke', 'none');
        el.appendChild(head);
      }
    } else if (shape.type === 'measure' || shape.type === 'scale') {
      // Cote / mesure, et étalon d'échelle (même construction : ligne,
      // pattes d'extrémité, texte au milieu) — l'étalon affiche sa
      // longueur réelle (clés value/unit) précédée de « Échelle : ».
      el = svgEl('g');
      el.setAttribute('fill', 'none');
      const x1 = X(shape.x1), y1 = Y(shape.y1);
      const x2 = X(shape.x2), y2 = Y(shape.y2);
      const line = svgEl('line');
      line.setAttribute('x1', x1);
      line.setAttribute('y1', y1);
      line.setAttribute('x2', x2);
      line.setAttribute('y2', y2);
      strokeAttrs(line, stroke, sw);
      el.appendChild(line);
      // Pattes d'extrémité perpendiculaires (style cote de dessin technique).
      const ang = Math.atan2(y2 - y1, x2 - x1);
      const tick = pxToVb(6);
      const tx = tick * Math.sin(ang), ty = -tick * Math.cos(ang);
      for (const [px, py] of [[x1, y1], [x2, y2]]) {
        const t = svgEl('line');
        t.setAttribute('x1', px - tx);
        t.setAttribute('y1', py - ty);
        t.setAttribute('x2', px + tx);
        t.setAttribute('y2', py + ty);
        strokeAttrs(t, stroke, sw);
        el.appendChild(t);
      }
      // Distance au milieu de la cote, halo blanc pour la lisibilité.
      const label = svgEl('text');
      label.setAttribute('x', (x1 + x2) / 2);
      label.setAttribute('y', (y1 + y2) / 2 - pxToVb(6));
      label.setAttribute('text-anchor', 'middle');
      label.setAttribute('font-size', pxToVb(12));
      label.setAttribute('font-weight', '600');
      // Contour transparent : la distance reste lisible en gris ardoise.
      label.setAttribute('fill', stroke === 'none' ? '#334155' : stroke);
      label.setAttribute('stroke', '#ffffff');
      label.setAttribute('stroke-width', 3);
      label.setAttribute('vector-effect', 'non-scaling-stroke');
      label.setAttribute('style', 'paint-order: stroke');
      // L'étalon affiche sa longueur réelle telle que saisie (sans
      // décimales forcées). En cours de tracé (aperçu, value pas encore
      // saisie), la distance mesurée selon l'échelle en vigueur aide à
      // viser.
      label.textContent = shape.type === 'scale' && shape.value > 0
        ? '\u00c9chelle : ' + shape.value + ' ' + (shape.unit || 'm')
        : measureLabel(shape);
      el.appendChild(label);
    } else if (shape.type === 'label') {
      el = svgEl('g');
      const fontVb = pxToVb(shape.fontSize || 14);
      const x = X(shape.x), y = Y(shape.y);
      if (shape.boxed) {
        const size = estimateTextVb(shape.text, fontVb);
        const pad = fontVb * 0.35;
        const box = svgEl('rect');
        box.setAttribute('x', x - pad);
        box.setAttribute('y', y - fontVb * 1.05 - pad);
        box.setAttribute('width', size.w + 2 * pad);
        box.setAttribute('height', size.h + 2 * pad);
        box.setAttribute('rx', pxToVb(3));
        box.setAttribute('fill', fill);
        strokeAttrs(box, stroke, Math.min(sw, 2));
        el.appendChild(box);
      }
      const text = svgEl('text');
      text.setAttribute('x', x);
      text.setAttribute('y', y);
      text.setAttribute('font-size', fontVb);
      if (shape.bold) text.setAttribute('font-weight', '700');
      if (shape.italic) text.setAttribute('font-style', 'italic');
      text.setAttribute('fill', stroke === 'none' ? '#0f172a' : stroke);
      text.setAttribute('stroke', 'none');
      text.textContent = shape.text;
      el.appendChild(text);
    } else if (shape.type === 'callout') {
      el = svgEl('g');
      const fontVb = pxToVb(shape.fontSize || 14);
      const size = estimateTextVb(shape.text, fontVb);
      const pad = fontVb * 0.45;
      const cx = X(shape.x), cy = Y(shape.y);
      const tx = X(shape.tx), ty = Y(shape.ty);
      // Ligne de rappel de la cible vers la boîte (dessinée dessous).
      const leader = svgEl('line');
      leader.setAttribute('x1', tx);
      leader.setAttribute('y1', ty);
      leader.setAttribute('x2', cx);
      leader.setAttribute('y2', cy);
      strokeAttrs(leader, stroke, Math.min(sw, 2));
      el.appendChild(leader);
      const dot = svgEl('circle');
      dot.setAttribute('cx', tx);
      dot.setAttribute('cy', ty);
      dot.setAttribute('r', pxToVb(3));
      dot.setAttribute('fill', stroke === 'none' ? '#0f172a' : stroke);
      dot.setAttribute('stroke', 'none');
      el.appendChild(dot);
      const box = svgEl('rect');
      box.setAttribute('x', cx - size.w / 2 - pad);
      box.setAttribute('y', cy - size.h / 2 - pad);
      box.setAttribute('width', size.w + 2 * pad);
      box.setAttribute('height', size.h + 2 * pad);
      box.setAttribute('rx', pxToVb(4));
      // Boîte blanche par défaut : le commentaire doit rester lisible.
      box.setAttribute('fill', shape.fill || 'rgba(255, 255, 255, 0.92)');
      strokeAttrs(box, stroke, Math.min(sw, 2));
      el.appendChild(box);
      const text = svgEl('text');
      text.setAttribute('x', cx);
      text.setAttribute('y', cy + fontVb * 0.35);
      text.setAttribute('text-anchor', 'middle');
      text.setAttribute('font-size', fontVb);
      if (shape.bold) text.setAttribute('font-weight', '700');
      if (shape.italic) text.setAttribute('font-style', 'italic');
      text.setAttribute('fill', stroke === 'none' ? '#0f172a' : stroke);
      text.setAttribute('stroke', 'none');
      text.textContent = shape.text;
      el.appendChild(text);
    } else if (shape.type === 'icon') {
      el = svgEl('g');
      if (shape.filename) {
        const img = svgEl('image');
        img.setAttribute('href', shape.filename);
        img.setAttribute('x', X(shape.x));
        img.setAttribute('y', Y(shape.y));
        img.setAttribute('width', X(shape.w));
        img.setAttribute('height', Y(shape.h));
        img.setAttribute('preserveAspectRatio', 'xMidYMid meet');
        el.appendChild(img);
      } else {
        // Aucun fichier choisi : emplacement en pointillé avec un « ? ».
        const box = svgEl('rect');
        box.setAttribute('x', X(shape.x));
        box.setAttribute('y', Y(shape.y));
        box.setAttribute('width', X(shape.w));
        box.setAttribute('height', Y(shape.h));
        box.setAttribute('fill', 'rgba(148, 163, 184, 0.15)');
        box.setAttribute('stroke-dasharray', '4 3');
        strokeAttrs(box, '#64748b', 1.5);
        el.appendChild(box);
        const q = svgEl('text');
        q.setAttribute('x', X(shape.x) + X(shape.w) / 2);
        q.setAttribute('y', Y(shape.y) + Y(shape.h) / 2);
        q.setAttribute('text-anchor', 'middle');
        q.setAttribute('dominant-baseline', 'central');
        q.setAttribute('font-size', Math.min(X(shape.w), Y(shape.h)) * 0.6);
        q.setAttribute('fill', '#64748b');
        q.textContent = '?';
        el.appendChild(q);
      }
    } else if (shape.type === 'pin') {
      el = svgEl('g');
      const x = X(shape.x), y = Y(shape.y);
      const h = pxToVb(26);
      const hw = pxToVb(9);
      const color = stroke === 'none' ? '#dc2626' : stroke;
      const body = svgEl('path');
      body.setAttribute('d',
        'M ' + x + ' ' + y +
        ' C ' + (x - hw * 0.7) + ' ' + (y - h * 0.38) + ' ' +
        (x - hw) + ' ' + (y - h * 0.52) + ' ' + (x - hw) + ' ' + (y - h * 0.68) +
        ' A ' + hw + ' ' + hw + ' 0 1 1 ' + (x + hw) + ' ' + (y - h * 0.68) +
        ' C ' + (x + hw) + ' ' + (y - h * 0.52) + ' ' +
        (x + hw * 0.7) + ' ' + (y - h * 0.38) + ' ' + x + ' ' + y + ' Z');
      body.setAttribute('fill', color);
      strokeAttrs(body, '#ffffff', 1.5);
      el.appendChild(body);
      const eye = svgEl('circle');
      eye.setAttribute('cx', x);
      eye.setAttribute('cy', y - h * 0.68);
      eye.setAttribute('r', pxToVb(3.2));
      eye.setAttribute('fill', '#ffffff');
      eye.setAttribute('stroke', 'none');
      el.appendChild(eye);
    } else {
      // Type inconnu (sécurité) : groupe vide, sans rendu.
      el = svgEl('g');
    }

    // Rotation (clé rotation, degrés, sens horaire) des types qui la
    // portent : rectangle, icône et ellipse autour de leur centre, libellé
    // autour de son point d'ancrage (NS.shapePivot). Le viewBox étant
    // isotrope, rotate() y donne l'angle exact à l'écran ; les autres
    // types sont tournés dans leurs coordonnées mêmes (edit-core).
    const rotation = NS.shapeRotation(shape);
    if (rotation) {
      const c = NS.shapePivot(shape);
      el.setAttribute('transform',
        'rotate(' + rotation + ' ' + X(c.x) + ' ' + Y(c.y) + ')');
    }

    if (shape.label) {
      const title = svgEl('title');
      title.textContent = shape.label;
      el.appendChild(title);
    }
    return el;
  }

  /* (Re)dessine un calque "shapes" : viewBox au ratio du plan de base puis
     une forme par entrée. Appelé par syncLayerSizing, une fois les
     dimensions affichées du plan connues. */
  function drawShapesLayer(svg, wPx, hPx) {
    const vbH = SHAPES_VIEW_W * hPx / wPx;
    svg.setAttribute('viewBox', '0 0 ' + SHAPES_VIEW_W + ' ' + vbH);
    svg.textContent = '';
    for (const shape of svg._shapes || []) {
      // Étalon d'échelle déclaré masqué (shown false) : il étalonne les
      // cotes du plan sans être affiché.
      if (shape.type === 'scale' && shape.shown === false) continue;
      svg.appendChild(shapeSvgNode(shape, vbH, SHAPE_LAYER_FILL, SHAPE_LAYER_STROKE));
    }
  }

  /* Retrace les calques "shapes" quand l'échelle effective a changé
     (étalon dessiné, retouché, supprimé ou recalibré) : leurs cotes
     affichent la distance calculée au moment du tracé. Appelé par
     writeDrawnShapes (edit-core) après chaque modification de
     l'opérateur ; sans changement d'échelle, ne retrace rien. */
  let renderedScaleKey = null;
  function syncScaleDependents() {
    const scale = effectiveScale();
    const key = scale ? scale.value + '\u0000' + scale.unit : '';
    if (key === renderedScaleKey) return;
    renderedScaleKey = key;
    const w = planImage.offsetWidth, h = planImage.offsetHeight;
    if (!w || !h) return;
    for (const el of state.layerElements) {
      if (el.classList.contains('plan-layer-shapes')) drawShapesLayer(el, w, h);
    }
  }

  /* Construit les calques d'un plan (image de base) : un élément par calque,
     superposé à planImage. Masqués par défaut ; affichés/masqués via les
     actions correspondantes du SpeedDial (rebuildLayersDial). */
  function renderLayers(plan) {
    hideMarkerCard();
    renderedScaleKey = null; // échelle du plan précédent : sans objet ici
    for (const el of state.layerElements) el.remove();
    state.layerElements = [];

    for (const layer of plan.layers || []) {
      // V2 : seuls les calques kind "image" existent dans la configuration
      // (viewer-config.js) ; capteurs et formes ont leurs propres calques,
      // alimentés par current_plan_element_json et
      // current_plan_drawnShapes_json.
      const el = document.createElement('img');
      el.className = 'plan-layer-image';
      el.src = layer.filename;
      el.alt = layer.label;
      el.draggable = false;
      setLayerHidden(el, true);
      el.dataset.layerLabel = layer.label;
      planViewport.appendChild(el);
      state.layerElements.push(el);
    }

    syncLayerSizing();
    renderElements();
  }

  /* Visibilité d'un calque : par l'ATTRIBUT hidden (et non la propriété),
     car la propriété hidden n'existe pas sur les éléments SVG (calques
     "shapes") ; la règle CSS [hidden] { display:none } s'applique aux deux
     familles d'éléments. */
  function isLayerHidden(el) {
    return el.hasAttribute('hidden');
  }

  function setLayerHidden(el, hidden) {
    if (hidden) el.setAttribute('hidden', '');
    else el.removeAttribute('hidden');
    // Un calque de marqueurs masqué peut emporter le marqueur survolé :
    // la carte de détails ne doit pas rester affichée sans lui.
    if (hidden) hideMarkerCard();
  }

  /* ---- Carte de détails d'un marqueur (survol d'un point "markers") ----
     Petite carte affichant le libellé du capteur et ses propriétés libres
     (clé props du point). Posée dans la zone des plans (hors calques
     transformés par le zoom) et positionnée près du marqueur survolé,
     bornée aux limites de la zone. */
  function showMarkerCard(dot, pt) {
    if (!pt.label && pt.props.length === 0) return;
    markerCard.textContent = '';
    if (pt.label) {
      const title = document.createElement('div');
      title.className = 'marker-card-title';
      title.textContent = pt.label;
      markerCard.appendChild(title);
    }
    for (const prop of pt.props) {
      const row = document.createElement('div');
      row.className = 'marker-card-row';
      const name = document.createElement('span');
      name.className = 'marker-card-name';
      name.textContent = prop.name;
      const value = document.createElement('span');
      value.className = 'marker-card-value';
      value.textContent = prop.value;
      row.appendChild(name);
      row.appendChild(value);
      markerCard.appendChild(row);
    }
    // Affichée avant mesure : les dimensions ne sont connues qu'une fois
    // l'élément rendu. Au-dessus du marqueur, centrée ; en dessous si la
    // place manque en haut.
    markerCard.hidden = false;
    const zone = planZone.getBoundingClientRect();
    const rect = dot.getBoundingClientRect();
    const cw = markerCard.offsetWidth;
    const ch = markerCard.offsetHeight;
    let left = rect.left - zone.left + rect.width / 2 - cw / 2;
    left = clampNum(left, 4, Math.max(4, zone.width - cw - 4));
    let top = rect.top - zone.top - ch - 8;
    if (top < 4) top = rect.bottom - zone.top + 8;
    markerCard.style.left = left + 'px';
    markerCard.style.top = top + 'px';
  }

  function hideMarkerCard() {
    markerCard.hidden = true;
  }

  /* ============================================================
     Capteurs du plan (current_plan_element_json, readme § 8)
     ============================================================
     Un calque dédié, TOUJOURS affiché (pas d'entrée au SpeedDial des
     calques), au-dessus des calques image : renderElements le replace en
     fin de planViewport à chaque reconstruction des calques. Dimensionné
     (syncLayerSizing) et transformé (applyZoomTransform) comme les autres
     calques : les capteurs suivent le zoom et le déplacement du plan. */
  const elementsLayer = document.createElement('div');
  elementsLayer.className = 'plan-layer-markers plan-layer-elements';
  planViewport.appendChild(elementsLayer);

  /* Événements en cours du capteur (configuration_events_json, index
     byElement), du plus important au moins important selon la clé
     eventPriorityOrder ; tableau vide hors alarme. */
  function elementAlarms(el) {
    const list = state.events.byElement.get(el.id) || [];
    const desc = state.currentConfig.eventPriorityOrder === 'desc';
    return list.slice().sort((a, b) =>
      desc ? b.priority - a.priority : a.priority - b.priority);
  }

  // Couleur CSS d'un événement : nom admis -> variable de sévérité,
  // couleur hexadécimale telle quelle (même règle que les badges).
  function alarmColorCss(color) {
    return color.charAt(0) === '#' ? color : 'var(--sev-' + color + ')';
  }

  /* Applique au capteur sa représentation selon son état d'alarme et sa
     règle show_mode (readme § 6.3) — EN PLACE, pour la mise à jour à chaud
     (refreshAlarms) sans reconstruire le calque :
       - always_without_animation : représentation par défaut, inchangée ;
       - always_with_animation (défaut) : en alarme, image icon_alarm si
         fournie, sinon la représentation par défaut soulignée d'un halo
         animé de la couleur de l'événement le plus important.
     (masked : jamais rendu, filtré par renderElements.) */
  function applyElementAlarm(wrap) {
    const el = wrap._point;
    const animated = el.show_mode === 'always_with_animation';
    const alarms = animated ? elementAlarms(el) : [];
    const inAlarm = alarms.length > 0;
    const img = wrap.firstChild.tagName === 'IMG' ? wrap.firstChild : null;
    if (img) img.src = inAlarm && el.icon_alarm ? el.icon_alarm : el.icon || el.icon_alarm;
    wrap.classList.toggle('in-alarm', inAlarm);
    wrap.classList.toggle('alarm-halo', inAlarm && !el.icon_alarm);
    if (inAlarm) wrap.style.setProperty('--alarm-color', alarmColorCss(alarms[0].color));
    else wrap.style.removeProperty('--alarm-color');
  }

  /* Clic sur un capteur (cadenas du mode édition fermé, ou mode inactif) :
     demande de détail écrite dans eventsDetailRequest_json (readme § 11),
     compteur serial commun avec les badges du bandeau. Cadenas ouvert, les
     clics servent aux outils d'édition. */
  function requestElementDetail(el) {
    if (NS.editActive()) return;
    state.eventsDetailSerial += 1;
    NS.writeProperty(NS.EVENTS_DETAIL_PROPERTY, JSON.stringify({
      source: 'element',
      element_id: el.id,
      node_id: state.selectedNode ? state.selectedNode.id : 0,
      planIndex: state.currentPlans.indexOf(state.currentPlan) + NS.SELECTED_PLAN_BASE,
      label: el.label,
      serial: state.eventsDetailSerial,
    }));
  }

  /* (Re)construit le calque des capteurs depuis state.currentElements :
     un point par capteur non "masked" — image (clé icon / icon_alarm, côté
     size en pixels à 100 % de zoom) ou pastille ronde par défaut —, carte
     de détails au survol (libellé + props, comme les marqueurs V1), état
     d'alarme appliqué. Appelé par renderLayers (changement de plan) et par
     app.js (nouvelle valeur de current_plan_element_json). */
  function renderElements() {
    hideMarkerCard();
    elementsLayer.textContent = '';
    // Toujours au-dessus des calques d'information (re-)créés par
    // renderLayers : replacé en fin de planViewport.
    planViewport.appendChild(elementsLayer);
    if (state.activeMode !== 'image' || !state.currentPlan) return;

    for (const el of state.currentElements) {
      if (el.show_mode === 'masked') continue;
      const wrap = document.createElement('div');
      wrap.className = 'plan-element';
      wrap.style.left = (el.x * 100) + '%';
      wrap.style.top = (el.y * 100) + '%';
      // _point : carte de détails et mise en évidence de la couverture du
      // mode édition (updateShapeCoverage, viewer-edit-core.js).
      wrap._point = el;

      if (el.icon || el.icon_alarm) {
        const img = document.createElement('img');
        img.draggable = false;
        img.alt = el.label;
        img.style.width = el.size + 'px';
        img.style.height = el.size + 'px';
        wrap.appendChild(img);
      } else {
        const dot = document.createElement('span');
        dot.className = 'plan-element-dot';
        dot.style.width = el.size + 'px';
        dot.style.height = el.size + 'px';
        wrap.appendChild(dot);
      }
      applyElementAlarm(wrap);

      wrap.addEventListener('pointerenter', () => showMarkerCard(wrap, el));
      wrap.addEventListener('pointerleave', hideMarkerCard);
      // Pas de listener click ici : la capture du pointeur par
      // planViewport (glisser du plan) retargette click vers lui. Le clic
      // est reconstitué par les gestionnaires de glisser (plus bas).
      elementsLayer.appendChild(wrap);
    }
  }

  /* Mise à jour à chaud de l'état d'alarme des capteurs affichés (nouvelle
     valeur de configuration_events_json — applyEvents, viewer-nav.js) :
     appliquée en place, sans reconstruire le calque (le survol en cours et
     le zoom ne bougent pas). */
  function refreshAlarms() {
    for (const wrap of elementsLayer.children) applyElementAlarm(wrap);
    // La visibilité et le halo des formes « sur alarme » (show_mode
    // always_with_animation) dépendent aussi des événements en cours.
    NS.renderEditLayer();
  }

  /* Points des capteurs affichés, pour l'anneau de couverture du mode
     édition (viewer-edit-core.js). */
  function elementDots() {
    return Array.from(elementsLayer.children);
  }

  /* Un calque « marqueurs » n'a pas de dimension propre (contrairement à un
     calque image) : on la cale explicitement sur la taille affichée du plan
     de base pour que les positions en % de ses points tombent au bon endroit. */
  function syncLayerSizing() {
    const w = planImage.offsetWidth, h = planImage.offsetHeight;
    for (const el of state.layerElements) {
      if (el.classList.contains('plan-layer-markers')) {
        el.style.width = w + 'px';
        el.style.height = h + 'px';
      } else if (el.classList.contains('plan-layer-shapes')) {
        el.style.width = w + 'px';
        el.style.height = h + 'px';
        if (w && h) drawShapesLayer(el, w, h);
      }
    }
    // Le calque des capteurs et celui du mode d'édition suivent les mêmes
    // dimensions que les autres.
    elementsLayer.style.width = w + 'px';
    elementsLayer.style.height = h + 'px';
    planEditLayer.style.width = w + 'px';
    planEditLayer.style.height = h + 'px';
    NS.renderEditLayer();
  }
  planImage.addEventListener('load', syncLayerSizing);

  /* SpeedDial des calques d'information du plan 2D courant — reconstruit à
     chaque bascule pour refléter le fond de couleur des calques actifs
     (mpsd-action-active). Masqué si le plan n'a aucun calque. */
  let layersDial = null;

  function rebuildLayersDial() {
    if (layersDial) { layersDial.destroy(); layersDial = null; }

    if (!state.layerElements.length) {
      layersDialAnchor.hidden = true;
      return;
    }
    layersDialAnchor.hidden = false;

    const items = state.layerElements.map((el) => ({
      icon: 'layers',
      label: el.dataset.layerLabel,
      active: !isLayerHidden(el),
      command: () => {
        setLayerHidden(el, !isLayerHidden(el));
        // Reconstruction différée : ce SpeedDial est encore en train de
        // traiter le clic (erreur « classList of null » sinon).
        setTimeout(rebuildLayersDial, 0);
      },
    }));

    layersDial = new MyPnSpeedDial(layersDialAnchor, {
      items,
      direction: 'up',
      buttonSize: 40,
      actionSize: 34,
      tooltip: 'right',
      buttonTooltip: state.layerElements.length +
        (state.layerElements.length > 1 ? ' calques' : ' calque'),
      iconPath: 'Images/speeddial/',
      showIcon: 'layers',
      hideIcon: 'times',
      styleClass: 'layers-dial',
    });
  }

  function showImagePlan(plan) {
    state.activeMode = 'image';
    threeViewport.hidden = true;
    window.ThreeViewer && window.ThreeViewer.hide();
    planViewport.hidden = false;
    planImage.src = plan.filename;
    planImage.alt = plan.label +
      (state.currentLocation ? NS.PATH_SEPARATOR + state.currentLocation : '');
    state.currentPlan = plan;
    // Capteurs déjà reçus pour ce plan (current_plan_element_json,
    // mémorisés par plan le temps de la page) ; sinon aucun, en attendant
    // la réponse de l'application à selectedNodePath.
    state.currentElements = state.elementsCache.get(NS.elementsKey(plan)) || [];
    renderLayers(plan);
    rebuildLayersDial();
    resetZoom();
    NS.refreshShapeEditing();
  }

  /* Affiche une représentation 3D (fichier .obj) avec Three.js. */
  function showModelPlan(plan) {
    state.activeMode = 'three';
    planViewport.hidden = true;
    if (layersDial) { layersDial.destroy(); layersDial = null; }
    layersDialAnchor.hidden = true;
    state.currentPlan = plan;
    state.currentElements = [];
    renderElements();
    threeViewport.hidden = false;
    /* Le moteur 3D (three-viewer.bundle.js) n'est pas chargé par
       index.html : il arrive ICI, à la première représentation 3D affichée
       (viewer-loader.js). Le temps du téléchargement, la zone porte déjà
       le message « Chargement du modèle 3D… » de son gabarit. */
    NS.ensureThreeViewer().then(function (viewer) {
      // Un autre plan a pu être demandé pendant le chargement.
      if (state.currentPlan !== plan) return;
      if (!viewer) {
        console.error('MyPnPlanViewerV2 : visualiseur Three.js indisponible');
        return;
      }
      viewer.show(plan.filename);
      /* Après show() : le mode édition 3D (viewer-scene3d.js) redonne au
         visualiseur la scène du plan (vue par défaut…) ; les boutons du
         repère et de la vue en plan se réévaluent, moteur présent. */
      NS.refreshShapeEditing();
      if (NS.refreshHelperButton) NS.refreshHelperButton();
      if (NS.refreshPlanViewButton) NS.refreshPlanViewButton();
    }, function (cause) {
      console.error('MyPnPlanViewerV2 : moteur 3D non chargé', cause);
    });
    NS.refreshShapeEditing();
  }

  /* Affiche la représentation (image ou modèle 3D) de l'élément courant. */
  function setActivePlan(plan) {
    if (plan.type === 'model') {
      showModelPlan(plan);
    } else {
      showImagePlan(plan);
    }
    // Bouton imprimante : plans 2D seulement (viewer-print.js).
    NS.refreshPrintButton();
    // Bouton du repère d'orientation : modèles 3D seulement
    // (viewer-scene3d-helper.js).
    if (NS.refreshHelperButton) NS.refreshHelperButton();
    if (NS.refreshPlanViewButton) NS.refreshPlanViewButton();
  }

  /* Affiche la représentation d'un emplacement (2D ou 3D ; la liste reçue
     est réduite à une entrée par viewer-config.js), ou le repère « Aucune
     représentation disponible » s'il n'y en a pas.
     detail est la ligne affichée sous le repère (chemin de l'élément,
     invite de sélection ou message d'erreur). */
  function showPlans(plans, detail) {
    if (plans && plans.length) {
      planEmpty.hidden = true;
      zoomToolbar.hidden = false;
      state.currentPlans = plans;
      setActivePlan(plans[0]);
      return;
    }

    state.currentPlans = [];
    state.currentPlan = null;
    state.currentElements = [];
    renderElements();
    if (layersDial) { layersDial.destroy(); layersDial = null; }
    layersDialAnchor.hidden = true;
    for (const el of state.layerElements) el.remove();
    state.layerElements = [];
    planViewport.hidden = true;
    threeViewport.hidden = true;
    window.ThreeViewer && window.ThreeViewer.hide();
    zoomToolbar.hidden = true;
    NS.refreshShapeEditing();
    if (NS.refreshPlanViewButton) NS.refreshPlanViewButton();
    planEmpty.hidden = false;
    planEmptyTitle.textContent = 'Aucune repr\u00e9sentation disponible';
    planLocation.textContent = detail || '';
  }

  /* ---------- Zoom et déplacement dans le plan 2D affiché ---------- */
  const ZOOM_MIN = 1;
  const ZOOM_MAX = 6;
  const ZOOM_STEP = 1.3;
  let zoom = 1;
  let panX = 0;
  let panY = 0;

  function clampPan() {
    /* Empêche de faire glisser le plan au-delà de ses propres bords */
    const maxPanX = Math.max(0, (planImage.offsetWidth * zoom - planViewport.clientWidth) / 2);
    const maxPanY = Math.max(0, (planImage.offsetHeight * zoom - planViewport.clientHeight) / 2);
    panX = Math.min(maxPanX, Math.max(-maxPanX, panX));
    panY = Math.min(maxPanY, Math.max(-maxPanY, panY));
  }

  function applyZoomTransform() {
    // Le marqueur survolé bouge avec le plan : la carte de détails, elle,
    // est posée hors calques et deviendrait orpheline.
    hideMarkerCard();
    const t = 'translate(-50%, -50%) translate(' + panX + 'px, ' + panY + 'px) scale(' + zoom + ')';
    planImage.style.transform = t;
    for (const el of state.layerElements) el.style.transform = t;
    elementsLayer.style.transform = t;
    planEditLayer.style.transform = t;
    // La taille écran des poignées d'édition dépend du zoom : redessin au
    // premier changement de niveau (pas pendant un simple déplacement).
    if (zoom !== NS.edit.renderedZoom) {
      NS.edit.renderedZoom = zoom;
      NS.renderEditLayer();
    }
    zoomLevelEl.textContent = Math.round(zoom * 100) + '%';
    zoomInBtn.disabled = zoom >= ZOOM_MAX - 0.001;
    zoomOutBtn.disabled = zoom <= ZOOM_MIN + 0.001;
    zoomResetBtn.disabled = zoom === ZOOM_MIN && panX === 0 && panY === 0;
  }

  function resetZoom() {
    zoom = ZOOM_MIN;
    panX = 0;
    panY = 0;
    applyZoomTransform();
  }

  /* Zoom centré sur un point donné (coordonnées relatives au centre du
     cadre), en conservant ce point sous le curseur après le changement. */
  function zoomAt(cx, cy, targetZoom) {
    const newZoom = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, targetZoom));
    if (newZoom === zoom) return;
    panX = cx - (newZoom / zoom) * (cx - panX);
    panY = cy - (newZoom / zoom) * (cy - panY);
    zoom = newZoom;
    clampPan();
    applyZoomTransform();
  }

  planViewport.addEventListener('wheel', (e) => {
    e.preventDefault();
    const rect = planViewport.getBoundingClientRect();
    const cx = e.clientX - rect.left - rect.width / 2;
    const cy = e.clientY - rect.top - rect.height / 2;
    zoomAt(cx, cy, zoom * (e.deltaY < 0 ? ZOOM_STEP : 1 / ZOOM_STEP));
  }, { passive: false });

  zoomInBtn.addEventListener('click', () => {
    if (state.activeMode === 'three') window.ThreeViewer.zoomIn();
    else zoomAt(0, 0, zoom * ZOOM_STEP);
  });
  zoomOutBtn.addEventListener('click', () => {
    if (state.activeMode === 'three') window.ThreeViewer.zoomOut();
    else zoomAt(0, 0, zoom / ZOOM_STEP);
  });
  zoomResetBtn.addEventListener('click', () => {
    if (state.activeMode === 'three') window.ThreeViewer.reset();
    else resetZoom();
  });

  /* Déplacement (pan) à la souris/au doigt lorsque l'image dépasse le cadre */
  let dragging = false;
  let dragStartX = 0, dragStartY = 0, panStartX = 0, panStartY = 0;

  /* Capteur présent sous le pointerdown : clic potentiel, confirmé au
     relâchement si le pointeur n'a presque pas bougé (sinon c'est un
     glisser du plan, qui reste possible depuis un capteur). */
  let elementClickTarget = null;
  const ELEMENT_CLICK_SLOP_PX = 5;

  planViewport.addEventListener('pointerdown', (e) => {
    // Mode édition avec un outil de tracé actif : le pointeur dessine, le
    // déplacement du plan est suspendu (l'outil « sélectionner » le garde ;
    // les formes et poignées arrêtent elles-mêmes la propagation).
    if (NS.editBlocksPan()) return;
    elementClickTarget = e.target && e.target.closest
      ? e.target.closest('.plan-element')
      : null;
    dragging = true;
    planViewport.classList.add('dragging');
    planViewport.setPointerCapture(e.pointerId);
    dragStartX = e.clientX;
    dragStartY = e.clientY;
    panStartX = panX;
    panStartY = panY;
  });

  planViewport.addEventListener('pointermove', (e) => {
    if (!dragging) return;
    panX = panStartX + (e.clientX - dragStartX);
    panY = panStartY + (e.clientY - dragStartY);
    clampPan();
    applyZoomTransform();
  });

  function endDrag() {
    dragging = false;
    elementClickTarget = null;
    planViewport.classList.remove('dragging');
  }
  planViewport.addEventListener('pointerup', (e) => {
    // Clic sur un capteur : relâchement quasi sur place (sinon glisser).
    if (dragging && elementClickTarget &&
        Math.hypot(e.clientX - dragStartX, e.clientY - dragStartY) < ELEMENT_CLICK_SLOP_PX) {
      requestElementDetail(elementClickTarget._point);
    }
    endDrag();
  });
  planViewport.addEventListener('pointercancel', endDrag);

  resetZoom();

  /* L'objet est librement redimensionné dans le synoptique : recale les
     calques sur la nouvelle taille (le visualiseur Three.js se recale de
     lui-même, cf. three-viewer.js). */
  window.addEventListener('resize', () => {
    if (state.activeMode === 'image') {
      syncLayerSizing();
      clampPan();
      applyZoomTransform();
    }
  });

  /* ------------------- Exposition sur l'espace de noms ------------------- */
  NS.SVG_NS = SVG_NS;
  NS.SHAPES_VIEW_W = SHAPES_VIEW_W;
  NS.shapeSvgNode = shapeSvgNode;
  NS.pxToVb = pxToVb;
  NS.sectorOpening = sectorOpening;
  NS.sectorPoint = sectorPoint;
  NS.measureLabel = measureLabel;
  NS.effectiveScale = effectiveScale;
  NS.syncScaleDependents = syncScaleDependents;
  NS.showPlans = showPlans;
  NS.syncLayerSizing = syncLayerSizing;
  /* Niveau de zoom et déplacement courants (lecture seule) : le menu
     d'impression s'en sert pour savoir si la vue affichée diffère du plan
     entier (viewer-print.js). */
  NS.getZoomState = () => ({ zoom, panX, panY });
  NS.renderElements = renderElements;
  NS.refreshAlarms = refreshAlarms;
  NS.elementDots = elementDots;
})(globalThis);
