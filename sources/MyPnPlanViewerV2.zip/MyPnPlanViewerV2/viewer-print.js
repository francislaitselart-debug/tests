﻿/* ============================================================
   MyPnPlanViewerV2 — module « print »
   ============================================================
   Impression du plan 2D consulté : bouton imprimante dans la barre de
   zoom, menu de choix « Plan entier (ajusté à la page) » / « Vue affichée
   (zoom et cadrage actuels) », en-tête imprimé (fil d'Ariane, libellé de
   la représentation, date et heure) et détection du blocage de
   window.print() par le bac à sable de l'IHM Web (iframe sandbox sans
   allow-modals).

   Principe : rien n'est recalculé ni redessiné pour le papier. Le cadre du
   plan (#planViewport) est imprimé PIXEL POUR PIXEL comme à l'écran —
   mêmes tailles de calques, mêmes transformations de zoom — et c'est ce
   cadre entier qui est réduit (transform: scale) pour tenir dans la page.
   Ce module ne fait que poser, sur la racine de l'objet, les classes
   is-printing + print-full | print-view et les variables CSS --print-w /
   --print-h / --print-k que la feuille @media print d'app.css exploite :
     - print-full : cadre ramené à la taille du plan affiché à 100 %
       (planImage.offsetWidth × offsetHeight), transformations de zoom
       annulées ;
     - print-view : cadre à sa taille écran, transformations conservées.
   Le facteur --print-k ajuste le cadre à la plus petite zone imprimable
   commune aux formats A4 et Letter (marges de 10 mm déduites, en-tête
   compris), en portrait ou en paysage selon le ratio du cadre — une règle
   @page injectée dans <head> demande l'orientation correspondante.

   Seuls les plans 2D s'impriment : le bouton est masqué sur une
   représentation 3D et quand la clé showPrintButton de la configuration
   est fausse.

   REPLI « PDF TÉLÉCHARGÉ » : sous Panorama, le serveur d'IHM Web insère
   l'objet dans un iframe sandbox="allow-forms allow-scripts
   allow-downloads" (codé en dur dans WebServerApplication) : sans
   allow-modals, window.print() est ignoré et sans allow-popups aucune
   fenêtre ne peut s'ouvrir — mais un téléchargement déclenché par un clic
   de l'opérateur aboutit. Dans ce cas (origine opaque « null », ou
   window.print() resté sans effet), le cadre du plan est rastérisé sur un
   canvas (image de base, calques image visibles, capteurs, formes) puis
   remis dans un PDF A4 (pdf-lib, vendor/pdf-lib) avec le même en-tête,
   et ce PDF est téléchargé : l'opérateur l'ouvre et l'imprime depuis son
   lecteur PDF. Voir readme.txt § 14.

   Chargé après viewer-plan.js (NS.getZoomState) et avant viewer-nav.js,
   ordre imposé par index.html (readme.txt § 1).

   NOTE ENCODAGE : chaînes affichées en ASCII pur (\uXXXX), commentaires
   accentués, BOM UTF-8, fins de ligne CRLF (readme.txt § 9).
   ============================================================ */
(function (global) {
  'use strict';

  const NS = global.MyPnPlanViewerV2NS = global.MyPnPlanViewerV2NS || {};
  const state = NS.state;
  const {
    viewerRoot, planViewport, planImage,
    printBtn, printSep, printMenu, printMenuFull, printMenuView, printMenuHint,
    printHeaderPath, printHeaderPlan, printHeaderDate, printNotice,
  } = NS.dom;

  /* ---- Zone imprimable retenue : la plus petite commune à A4 (210 × 297)
     et Letter (215,9 × 279,4), marges déduites. Un papier plus grand laisse
     un peu de blanc ; aucun ne rogne. HEADER_MM = hauteur de l'en-tête +
     son espacement (doit rester cohérent avec .print-header, app.css). */
  const PAGE_MARGIN_MM = 10;
  const PAGE_SHORT_MM = Math.min(210, 215.9) - 2 * PAGE_MARGIN_MM;   // 190
  const PAGE_LONG_MM = Math.min(297, 279.4) - 2 * PAGE_MARGIN_MM;    // 259,4
  const HEADER_MM = 12;
  const PX_PER_MM = 96 / 25.4;
  const NOTICE_MS = 6000;

  const PRINT_MODES = ['full', 'view'];

  let printingMode = null;   // mode en cours d'impression, null sinon
  let pageStyle = null;      // <style> portant la règle @page
  let noticeTimer = null;
  let pdfBusy = false;       // génération d'un PDF en cours (un seul à la fois)

  /* Bac à sable sans allow-same-origin : l'origine du document est opaque
     (window.origin vaut la chaîne "null"). C'est le cas de l'IHM Web
     Panorama ; ce n'est PAS le cas de demo.html en file:// (origine "null"
     aussi, mais window.print() y fonctionne). Surchargeable par les bancs
     (NS.printSandboxOverride). */
  function isSandboxed() {
    if (typeof NS.printSandboxOverride === 'boolean') return NS.printSandboxOverride;
    return String(global.origin) === 'null' && global.location.protocol !== 'file:';
  }

  /* ------------------------------------------------------------------ */
  /* Bouton de la barre de zoom                                          */
  /* ------------------------------------------------------------------ */

  /* Un plan 2D est affiché (les représentations 3D ne s'impriment pas). */
  function isPrintable() {
    return state.activeMode === 'image' && !planViewport.hidden &&
      Boolean(state.currentPlan);
  }

  /* Visibilité du bouton : plan 2D affiché ET clé showPrintButton vraie.
     Appelée à chaque changement de représentation (viewer-plan.js) et de
     configuration (viewer-nav.js) ; referme le menu au passage. */
  function refreshPrintButton() {
    const show = isPrintable() && state.currentConfig.showPrintButton !== false;
    printBtn.hidden = !show;
    printSep.hidden = !show;
    closeMenu();
    hideNotice();
  }

  /* ------------------------------------------------------------------ */
  /* Menu de choix                                                       */
  /* ------------------------------------------------------------------ */

  function isMenuOpen() {
    return !printMenu.hidden;
  }

  function openMenu() {
    if (!isPrintable()) return;
    hideNotice();
    const z = NS.getZoomState();
    const zoomed = z.zoom > 1.001 || z.panX !== 0 || z.panY !== 0;
    // Sans zoom ni déplacement, la vue affichée EST le plan entier.
    printMenuView.disabled = !zoomed;
    printMenuHint.textContent = (zoomed
      ? 'Zoom actuel : ' + Math.round(z.zoom * 100) + ' %'
      : 'Aucun zoom en cours : la vue affich\u00e9e est le plan entier.') +
      (isSandboxed()
        ? ' \u2014 IHM Web : le plan sera enregistr\u00e9 en PDF, \u00e0 imprimer ' +
          'depuis le lecteur PDF.'
        : '');
    printMenu.hidden = false;
    printBtn.setAttribute('aria-expanded', 'true');
    printMenuFull.focus();
  }

  function closeMenu() {
    if (!isMenuOpen()) return;
    printMenu.hidden = true;
    printBtn.setAttribute('aria-expanded', 'false');
  }

  printBtn.addEventListener('click', () => {
    if (isMenuOpen()) closeMenu();
    else openMenu();
    // Un bouton focalisé rejouerait le clic sur Entrée (cf. outils d'édition).
    printBtn.blur();
  });

  printMenuFull.addEventListener('click', () => printPlan('full'));
  printMenuView.addEventListener('click', () => printPlan('view'));

  // Clic hors du menu (et hors du bouton, qui gère lui-même la bascule).
  document.addEventListener('pointerdown', (e) => {
    if (!isMenuOpen()) return;
    if (printMenu.contains(e.target) || printBtn.contains(e.target)) return;
    closeMenu();
  }, true);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && isMenuOpen()) {
      closeMenu();
      e.stopPropagation();
    }
  }, true);

  /* ------------------------------------------------------------------ */
  /* Message d'impossibilité (bac à sable)                               */
  /* ------------------------------------------------------------------ */

  function showNotice(text, kind, ms) {
    printNotice.textContent = text;
    printNotice.classList.toggle('is-info', kind === 'info');
    printNotice.hidden = false;
    clearTimeout(noticeTimer);
    noticeTimer = ms === 0 ? null : setTimeout(hideNotice, ms || NOTICE_MS);
  }

  function hideNotice() {
    clearTimeout(noticeTimer);
    noticeTimer = null;
    printNotice.hidden = true;
  }

  /* ------------------------------------------------------------------ */
  /* Mise en page d'impression                                           */
  /* ------------------------------------------------------------------ */

  function pad2(n) {
    return (n < 10 ? '0' : '') + n;
  }

  function formatDateTime(d) {
    return pad2(d.getDate()) + '/' + pad2(d.getMonth() + 1) + '/' + d.getFullYear() +
      ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes());
  }

  function fillHeader(now) {
    printHeaderPath.textContent = state.currentLocation || '';
    printHeaderPlan.textContent = state.currentPlan ? state.currentPlan.label : '';
    printHeaderDate.textContent = formatDateTime(now || new Date());
  }

  /* Dimensions (px CSS) du cadre imprimé, facteur de réduction et
     orientation de la page, pour un mode donné :
       full  cadre = plan affiché à 100 % (taille écran hors zoom) ;
       view  cadre = cadre écran (zoom et cadrage conservés). */
  function computePrintLayout(mode) {
    let w, h;
    if (mode === 'full') {
      w = planImage.offsetWidth || planImage.naturalWidth || 4;
      h = planImage.offsetHeight || planImage.naturalHeight || 3;
    } else {
      w = planViewport.clientWidth || 4;
      h = planViewport.clientHeight || 3;
    }
    const landscape = w >= h;
    const pageW = (landscape ? PAGE_LONG_MM : PAGE_SHORT_MM) * PX_PER_MM;
    const pageH = ((landscape ? PAGE_SHORT_MM : PAGE_LONG_MM) - HEADER_MM) * PX_PER_MM;
    const k = Math.min(pageW / w, pageH / h);
    return { mode, w, h, k, landscape };
  }

  function ensurePageStyle() {
    if (!pageStyle) {
      pageStyle = document.createElement('style');
      pageStyle.id = 'printPageStyle';
      document.head.appendChild(pageStyle);
    }
    return pageStyle;
  }

  /* Pose l'état d'impression (classes, variables CSS, en-tête, @page).
     Séparée de printPlan pour être rejouable par un banc de test sous
     émulation du média print. */
  function beginPrint(mode, now) {
    if (PRINT_MODES.indexOf(mode) < 0) mode = 'full';
    const layout = computePrintLayout(mode);
    fillHeader(now);
    viewerRoot.style.setProperty('--print-w', layout.w + 'px');
    viewerRoot.style.setProperty('--print-h', layout.h + 'px');
    viewerRoot.style.setProperty('--print-k', String(layout.k));
    viewerRoot.classList.add('is-printing');
    viewerRoot.classList.toggle('print-full', mode === 'full');
    viewerRoot.classList.toggle('print-view', mode === 'view');
    ensurePageStyle().textContent =
      '@page { size: ' + (layout.landscape ? 'landscape' : 'portrait') +
      '; margin: ' + PAGE_MARGIN_MM + 'mm; }';
    printingMode = mode;
    return layout;
  }

  function endPrint() {
    if (printingMode === null) return;
    printingMode = null;
    viewerRoot.classList.remove('is-printing', 'print-full', 'print-view');
    viewerRoot.style.removeProperty('--print-w');
    viewerRoot.style.removeProperty('--print-h');
    viewerRoot.style.removeProperty('--print-k');
    if (pageStyle) pageStyle.textContent = '';
  }

  /* Impression : prépare la page, appelle window.print() (synchrone dans
     Chrome et Firefox : le retour signifie que le dialogue est fermé) puis
     restaure l'affichage. Dans un iframe sandbox sans allow-modals, le
     navigateur ignore print() SANS émettre beforeprint : l'absence de cet
     événement, émis sinon de façon synchrone pendant l'appel, signale le
     blocage à l'opérateur. Renvoie true si l'impression a été lancée. */
  function printPlan(mode) {
    if (!isPrintable()) return false;
    closeMenu();
    if (PRINT_MODES.indexOf(mode) < 0) mode = 'full';
    // Bac à sable connu d'avance : inutile d'appeler window.print() (ignoré
    // avec un avertissement console) — PDF directement.
    if (isSandboxed()) {
      exportPlanPdf(mode);
      return false;
    }
    beginPrint(mode);
    let fired = false;
    const onBeforePrint = () => { fired = true; };
    window.addEventListener('beforeprint', onBeforePrint);
    try {
      window.print();
    } catch (cause) {
      console.error('MyPnPlanViewer : impression impossible', cause);
    } finally {
      window.removeEventListener('beforeprint', onBeforePrint);
      endPrint();
    }
    if (!fired) {
      console.warn('MyPnPlanViewer : window.print() ignor\u00e9 (sandbox sans allow-modals) : PDF');
      exportPlanPdf(mode);
    }
    return fired;
  }

  /* ------------------------------------------------------------------ */
  /* Repli : PDF du plan téléchargé                                      */
  /* ------------------------------------------------------------------ */

  const PT_PER_MM = 72 / 25.4;
  const A4_PT = [210 * PT_PER_MM, 297 * PT_PER_MM];
  const PDF_MAX_SIDE = 2600;   // côté maximal du raster (px), taille du fichier

  /* Couleur CSS effective d'une valeur pouvant être var(--sev-xxx). */
  function resolveCssColor(value) {
    const m = /^var\((--[a-z0-9-]+)\)$/i.exec((value || '').trim());
    if (!m) return value || '';
    return getComputedStyle(viewerRoot).getPropertyValue(m[1]).trim() || '#dc2626';
  }

  /* Chargement d'une image pour le canvas. Dans le bac à sable (origine
     opaque), TOUTE image du serveur est cross-origin : dessinée telle
     quelle, elle « souille » le canvas et toDataURL est refusé. Rechargée
     en mode CORS (crossOrigin anonymous) elle ne le souille pas — Servin
     répond Access-Control-Allow-Origin: * sur les fichiers statiques. Si
     ce rechargement échoue (file://, serveur sans en-tête CORS), l'image
     du DOM est reprise telle quelle (fallback), avec le risque ci-dessus. */
  function loadImage(src, cors, fallback) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      if (cors) img.crossOrigin = 'anonymous';
      img.onload = () => resolve(img);
      img.onerror = () => {
        if (fallback) resolve(fallback);
        else reject(new Error('image introuvable : ' + src));
      };
      img.src = src;
    });
  }

  /* Calque d'édition (formes libres) rendu en image : copie du SVG sans les
     éléments propres à l'édition (poignées, fantômes, brouillons, formes
     masquées par show_mode) ; les <image> (formes « icône ») sont retirées
     et dessinées à part (un SVG chargé comme image ne peut charger aucune
     ressource externe). */
  function shapesToImage(w, h) {
    const svg = NS.dom.planEditLayer;
    if (!svg || svg.hidden || !svg.childNodes.length) return Promise.resolve({ img: null, icons: [] });
    const clone = svg.cloneNode(true);
    clone.removeAttribute('hidden');
    clone.removeAttribute('style');
    clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    clone.setAttribute('width', String(w));
    clone.setAttribute('height', String(h));
    for (const el of Array.from(clone.querySelectorAll(
      '.pe-handle, .pe-rotate, .pe-rotate-link, .pe-draft, .pe-ghost, .pe-hidden-mode'))) {
      el.remove();
    }
    const icons = [];
    const vb = (clone.getAttribute('viewBox') || '0 0 1000 1000').split(/\s+/).map(Number);
    const kx = w / (vb[2] || 1), ky = h / (vb[3] || 1);
    for (const im of Array.from(clone.querySelectorAll('image'))) {
      const href = im.getAttribute('href') || im.getAttribute('xlink:href');
      if (href) {
        icons.push({
          src: href,
          x: parseFloat(im.getAttribute('x') || '0') * kx,
          y: parseFloat(im.getAttribute('y') || '0') * ky,
          w: parseFloat(im.getAttribute('width') || '0') * kx,
          h: parseFloat(im.getAttribute('height') || '0') * ky,
        });
      }
      im.remove();
    }
    const xml = new XMLSerializer().serializeToString(clone);
    return loadImage('data:image/svg+xml;charset=utf-8,' + encodeURIComponent(xml))
      .then((img) => ({ img, icons }), () => ({ img: null, icons }));
  }

  /* Raster du cadre du plan à l'échelle s (px du plan affiché à 100 % ->
     px du canvas) : image de base, calques image visibles, formes,
     capteurs (image ou pastille, anneau d'alarme). */
  async function rasterizePlan(s) {
    const w = planImage.offsetWidth, h = planImage.offsetHeight;
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(w * s));
    canvas.height = Math.max(1, Math.round(h * s));
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(await loadImage(planImage.currentSrc || planImage.src, true, planImage),
      0, 0, canvas.width, canvas.height);
    for (const layer of state.layerElements) {
      if (layer.tagName === 'IMG' && !layer.hasAttribute('hidden') && layer.complete && layer.naturalWidth) {
        ctx.drawImage(await loadImage(layer.currentSrc || layer.src, true, layer),
          0, 0, canvas.width, canvas.height);
      }
    }
    const shapes = await shapesToImage(canvas.width, canvas.height);
    if (shapes.img) ctx.drawImage(shapes.img, 0, 0, canvas.width, canvas.height);
    for (const ic of shapes.icons) {
      try {
        const img = await loadImage(ic.src, true);
        ctx.drawImage(img, ic.x, ic.y, ic.w, ic.h);
      } catch (e) { /* icône absente : ignorée */ }
    }
    for (const wrap of NS.elementDots()) {
      const el = wrap._point;
      const cx = el.x * canvas.width, cy = el.y * canvas.height;
      const size = (el.size || 24) * s;
      const node = wrap.firstChild;
      if (node && node.tagName === 'IMG' && node.complete && node.naturalWidth) {
        const icon = await loadImage(node.currentSrc || node.src, true, node);
        ctx.drawImage(icon, cx - size / 2, cy - size / 2, size, size);
      } else {
        ctx.beginPath();
        ctx.arc(cx, cy, size / 2, 0, Math.PI * 2);
        ctx.fillStyle = resolveCssColor('var(--sev-amber)');
        ctx.fill();
        ctx.lineWidth = Math.max(1, 2 * s);
        ctx.strokeStyle = '#ffffff';
        ctx.stroke();
      }
      if (wrap.classList.contains('alarm-halo')) {
        ctx.beginPath();
        ctx.arc(cx, cy, size / 2 + 6 * s, 0, Math.PI * 2);
        ctx.lineWidth = Math.max(1, 3 * s);
        ctx.strokeStyle = resolveCssColor(wrap.style.getPropertyValue('--alarm-color')) || '#dc2626';
        ctx.stroke();
      }
    }
    return canvas;
  }

  /* Raster à imprimer selon le mode : plan entier, ou région visible du
     cadre écran (zoom et cadrage actuels, fond blanc hors plan). */
  async function rasterForMode(mode) {
    const w = planImage.offsetWidth || 4, h = planImage.offsetHeight || 3;
    const z = NS.getZoomState();
    const natural = planImage.naturalWidth ? planImage.naturalWidth / w : 1;
    let s = Math.min(Math.max(natural, z.zoom, 1), PDF_MAX_SIDE / Math.max(w, h));
    const full = await rasterizePlan(s);
    if (mode !== 'view') return full;
    const vw = planViewport.clientWidth || 4, vh = planViewport.clientHeight || 3;
    // Région du plan (px à 100 %) visible dans le cadre : le plan est centré
    // dans le cadre, déplacé de (panX, panY) puis agrandi de zoom.
    const left = w / 2 - (vw / 2 + z.panX) / z.zoom;
    const top = h / 2 - (vh / 2 + z.panY) / z.zoom;
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(vw / z.zoom * s));
    canvas.height = Math.max(1, Math.round(vh / z.zoom * s));
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(full, -left * s, -top * s, full.width, full.height);
    return canvas;
  }

  /* Texte encodable en WinAnsi (polices standard de pdf-lib). */
  function pdfText(text) {
    return String(text || '')
      .replace(/[\u2014\u2013]/g, '-').replace(/[\u2018\u2019]/g, '\'')
      .replace(/[\u201c\u201d]/g, '"').replace(/\u2026/g, '...')
      .replace(/\u2192/g, '->').replace(/\u00a0/g, ' ')
      .replace(/[^\u0000-\u00ff]/g, '?');
  }

  /* Nom d'un fichier exporté (PDF, PNG, SVG) : plan-<lieu>-<aaaammjj>-<hhmm>.<ext>.
     Sans accents (NFD puis retrait des diacritiques) : « Bâtiment » -> batiment. */
  function exportFileName(ext, now) {
    const base = String(state.currentLocation || 'plan')
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60) || 'plan';
    return 'plan-' + base + '-' + now.getFullYear() + pad2(now.getMonth() + 1) + pad2(now.getDate()) +
      '-' + pad2(now.getHours()) + pad2(now.getMinutes()) + '.' + ext;
  }

  function pdfFileName(now) {
    return exportFileName('pdf', now);
  }

  function dataUrlToBytes(dataUrl) {
    const bin = atob(dataUrl.slice(dataUrl.indexOf(',') + 1));
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  /* Construit le PDF : page A4 (portrait ou paysage selon le raster),
     marges PAGE_MARGIN_MM, en-tête (fil d'Ariane, représentation, date)
     puis le raster ajusté à la zone restante. Renvoie les octets. */
  async function buildPdf(canvas, now) {
    // pdf-lib n'est pas charge par index.html : il arrive ici, au premier
    // PDF demande (viewer-loader.js).
    const lib = await NS.ensurePdfLib();
    if (!lib) throw new Error('pdf-lib absent (vendor/pdf-lib/pdf-lib.min.js)');
    const landscape = canvas.width >= canvas.height;
    const pageW = landscape ? A4_PT[1] : A4_PT[0];
    const pageH = landscape ? A4_PT[0] : A4_PT[1];
    const margin = PAGE_MARGIN_MM * PT_PER_MM;
    const headerH = HEADER_MM * PT_PER_MM;
    const doc = await lib.PDFDocument.create();
    doc.setTitle(pdfText(state.currentLocation || 'Plan'));
    doc.setCreator('MyPnPlanViewerV2');
    const font = await doc.embedFont(lib.StandardFonts.Helvetica);
    const bold = await doc.embedFont(lib.StandardFonts.HelveticaBold);
    const page = doc.addPage([pageW, pageH]);
    const dark = lib.rgb(0.06, 0.09, 0.16), muted = lib.rgb(0.39, 0.45, 0.55);
    const top = pageH - margin;
    page.drawText(pdfText(state.currentLocation || ''), { x: margin, y: top - 11, size: 11, font: bold, color: dark });
    const right = pdfText(formatDateTime(now));
    page.drawText(right, { x: pageW - margin - font.widthOfTextAtSize(right, 9), y: top - 11, size: 9, font, color: muted });
    page.drawText(pdfText(state.currentPlan ? state.currentPlan.label : ''), { x: margin, y: top - 24, size: 9, font, color: muted });
    page.drawLine({ start: { x: margin, y: top - headerH + 2 }, end: { x: pageW - margin, y: top - headerH + 2 }, thickness: 0.5, color: lib.rgb(0.8, 0.84, 0.88) });
    const areaW = pageW - 2 * margin, areaH = pageH - 2 * margin - headerH;
    const k = Math.min(areaW / canvas.width, areaH / canvas.height);
    const imgW = canvas.width * k, imgH = canvas.height * k;
    const image = await doc.embedJpg(dataUrlToBytes(canvas.toDataURL('image/jpeg', 0.88)));
    page.drawImage(image, { x: margin + (areaW - imgW) / 2, y: margin + (areaH - imgH) / 2, width: imgW, height: imgH });
    // Sans flux d'objets : structure lisible par les lecteurs les plus simples
    // (et par les bancs, qui comptent les pages dans le fichier).
    return doc.save({ useObjectStreams: false });
  }

  /* Téléchargement d'un fichier (octets ou Blob) sous le nom donné : un
     clic sur un lien de téléchargement, autorisé par le bac à sable de
     l'IHM Web (allow-downloads). Partagé avec les exports de la vue en
     plan (viewer-scene3d-export.js). */
  function downloadBytes(bytes, name, mime) {
    const blob = bytes instanceof Blob ? bytes : new Blob([bytes], { type: mime || 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { a.remove(); URL.revokeObjectURL(url); }, 1500);
    return { blob, name };
  }

  /* Enregistre le plan affiché en PDF et le télécharge (repli du bac à
     sable, ou appel direct). Renvoie une promesse du nom du fichier, ou
     null si rien n'a pu être produit (un message l'explique). */
  async function exportPlanPdf(mode) {
    if (!isPrintable() || pdfBusy) return null;
    pdfBusy = true;
    const now = new Date();
    showNotice('Pr\u00e9paration du PDF du plan\u2026', 'info', 0);
    try {
      const canvas = await rasterForMode(mode === 'view' ? 'view' : 'full');
      const bytes = await buildPdf(canvas, now);
      const name = pdfFileName(now);
      const result = downloadBytes(bytes, name);
      NS.lastPdf = result;
      showNotice('Impression indisponible dans l\u2019IHM Web : le plan a \u00e9t\u00e9 ' +
        'enregistr\u00e9 en PDF (' + name + '). Ouvrez-le pour l\u2019imprimer.', 'info', 12000);
      return name;
    } catch (cause) {
      console.error('MyPnPlanViewer : PDF du plan impossible', cause);
      showNotice('Impression et PDF impossibles : ' + (cause && cause.message ? cause.message : cause));
      return null;
    } finally {
      pdfBusy = false;
    }
  }

  // Sécurité : si afterprint survient hors de printPlan (navigateur qui
  // rendrait print() asynchrone), l'affichage est restauré quand même.
  window.addEventListener('afterprint', endPrint);

  /* ------------------- Exposition sur l'espace de noms ------------------- */
  NS.PRINT_MODES = PRINT_MODES;
  NS.refreshPrintButton = refreshPrintButton;
  NS.openPrintMenu = openMenu;
  NS.closePrintMenu = closeMenu;
  NS.computePrintLayout = computePrintLayout;
  NS.beginPrint = beginPrint;
  NS.endPrint = endPrint;
  NS.printPlan = printPlan;
  NS.exportPlanPdf = exportPlanPdf;
  NS.isPrintSandboxed = isSandboxed;
  NS.formatPrintDateTime = formatDateTime;
  /* Partagés avec les exports de la vue en plan (viewer-scene3d-export.js). */
  NS.downloadBytes = downloadBytes;
  NS.exportFileName = exportFileName;
  NS.showPrintNotice = showNotice;
  NS.hidePrintNotice = hideNotice;
})(globalThis);
