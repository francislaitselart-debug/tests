﻿/* ============================================================
   MyPnPlanViewerV2 — module « edit-core »
   ============================================================
   Socle du mode d'édition de formes personnalisées (clé shapeEditing) :
   état partagé NS.edit, constantes et helpers géométriques (dont la
   rotation des formes), capteurs couverts par une forme, et écriture de
   current_plan_drawnShapes_json.

   Les autres modules du mode édition (edit-render, edit-panel,
   edit-tools) complètent ce socle ; le module plan appelle
   NS.refreshShapeEditing / NS.renderEditLayer à chaque changement de
   représentation ou de transformation. Ordre de chargement : readme § 1.

   Les coordonnées des formes sont en fraction (0 à 1) du plan de base,
   comme les points des calques "markers"/"shapes". À chaque modification,
   toutes les formes du plan courant sont écrites dans current_plan_drawnShapes_json
   (writeDrawnShapes). Les formes sont conservées par plan le temps de la
   page (NS.edit.store), sans persistance côté Panorama.

   NOTE ENCODAGE : chaînes affichées en ASCII pur (\uXXXX), commentaires
   accentués, BOM UTF-8, fins de ligne CRLF (readme.txt § 14).
   ============================================================ */
(function (global) {
  'use strict';

  const NS = global.MyPnPlanViewerV2NS = global.MyPnPlanViewerV2NS || {};
  const state = NS.state;
  const clampNum = NS.clampNum;

  const HANDLE_PX = 5;    // rayon des poignées d'ajustement, en pixels écran
  const MIN_SHAPE_PX = 6; // taille écran minimale d'une forme à sa création

  // Apparence par défaut des formes dessinées (assortie à editStyle).
  const DRAWN_SHAPE_FILL = 'rgba(29, 78, 216, 0.16)';
  const DRAWN_SHAPE_STROKE = '#1d4ed8';

  /* ---- État du mode d'édition de formes personnalisées ---- */
  const ed = NS.edit = {
    enabled: false,        // clé shapeEditing de la configuration
    unlocked: false,       // cadenas ouvert : barre d'outils affichée, édition active
    tool: 'select',        // outil actif de la palette d'édition
    shapes: [],            // formes du plan courant (fractions 0..1)
    selected: null,        // forme sélectionnée (référence dans shapes)
    draft: null,           // forme en cours de tracé
    drag: null,            // glisser en cours (déplacement ou poignée)
    ctrl: false,           // touche Ctrl GAUCHE enfoncée (contrainte cercle/carré)
    lastPoint: null,       // dernier point du glisser (réapplication à la volée de Ctrl)
    renderedZoom: null,    // dernier zoom pris en compte par renderEditLayer

    /* Image que posera le prochain clic de l'outil « icône » : choisie
       visuellement dans la galerie ouverte à l'activation de l'outil
       (viewer-edit-tools.js). Vide = première entrée de la clé editIcons. */
    pendingIcon: '',

    /* Position de la barre d'outils déplacée par l'opérateur, en pixels
       depuis le coin haut-gauche de la zone des plans ; null tant qu'elle
       n'a pas été déplacée (elle reste alors centrée en haut). Conservée le
       temps de la page, comme l'état du cadenas. */
    toolbarPos: null,

    /* Apparence des prochaines formes tracées : initialisée aux défauts
       (assortis à DRAWN_SHAPE_FILL / DRAWN_SHAPE_STROKE), puis mise à jour
       à chaque réglage du panneau « Apparence » sur la forme sélectionnée —
       la dernière apparence choisie devient celle des tracés suivants.
       fillNone / strokeNone : cases « Transparent » du panneau.
       fontSize / bold / italic / boxed : réglages de texte des libellés et
       étiquettes de rappel. */
    style: {
      fillColor: '#1d4ed8',
      fillOpacity: 0.16,
      fillNone: false,
      strokeColor: '#1d4ed8',
      strokeNone: false,
      strokeWidth: 2,
      fontSize: 14,
      bold: false,
      italic: false,
      boxed: false,
      // Extrémité(s) fléchée(s) des prochaines flèches : end (arrivée),
      // start (départ) ou both, réglé par la section « Flèche » du panneau.
      arrowHeads: 'end',
    },

    /* Cible actuellement reflétée par le panneau « Apparence / Propriétés » :
       la forme sélectionnée, ou null (panneau masqué). Consultée dès le
       premier renderEditLayer, déclenché par le resetZoom initial au
       chargement du module plan. */
    stylePanelTarget: null,

    /* Formes du plan — reçues par current_plan_drawnShapes_json ou
       dessinées par l'opérateur —, mémorisées par plan (NS.elementsKey :
       node_id:planIndex) jusqu'à la prochaine reconstruction (le magasin
       est vidé par applyConfig). Aucune persistance côté Panorama :
       l'application les reçoit par current_plan_drawnShapes_json et peut
       les renvoyer par la même propriété. */
    store: new Map(),
  };

  /* Le mode édition est DISPONIBLE (cadenas visible, formes dessinées
     affichées) quand la clé shapeEditing est vraie et qu'un plan 2D est
     affiché ; il est ACTIF (barre d'outils, tracés, sélection) une fois le
     cadenas ouvert par l'opérateur. */
  /* Les FORMES du plan (reçues par current_plan_drawnShapes_json ou
     dessinées par l'opérateur) sont affichées dès qu'un plan 2D l'est —
     même sans la clé shapeEditing, qui ne conditionne que l'ÉDITION
     (cadenas, barre, poignées). */
  function shapesAvailable() {
    return state.activeMode === 'image' && Boolean(state.currentPlan);
  }

  function editAvailable() {
    return ed.enabled && shapesAvailable();
  }

  function editActive() {
    return editAvailable() && ed.unlocked;
  }

  /* true quand le pointeur sert au tracé : le déplacement du plan est
     suspendu (garde du pointerdown de déplacement, module plan). */
  function editBlocksPan() {
    return editActive() && ed.tool !== 'select';
  }

  /* Position du pointeur en fraction du plan de base (0..1), quel que soit
     le niveau de zoom/déplacement : le rectangle écran de planImage porte
     déjà la transformation courante. */
  function planPointFromEvent(e) {
    const rect = NS.dom.planImage.getBoundingClientRect();
    if (!rect.width || !rect.height) return null;
    return {
      x: clampNum((e.clientX - rect.left) / rect.width, 0, 1),
      y: clampNum((e.clientY - rect.top) / rect.height, 0, 1),
    };
  }

  /* Distance écran (pixels) entre deux points en fraction du plan. */
  function planPxDistance(a, b) {
    const rect = NS.dom.planImage.getBoundingClientRect();
    return Math.hypot((b.x - a.x) * rect.width, (b.y - a.y) * rect.height);
  }

  /* Clé de mémorisation des formes du plan courant : node_id:planIndex
     (NS.elementsKey, viewer-config.js) — la même clé que les capteurs, et
     que les identifiants renvoyés par l'application. Le magasin ed.store
     est vidé à chaque reconstruction (applyConfig, viewer-nav.js). */
  function drawnShapesKey() {
    return NS.elementsKey(state.currentPlan);
  }

  /* Formes reçues par current_plan_drawnShapes_json pour le plan de clé
     donnée : elles REMPLACENT celles que l'objet connaissait (l'application
     fait foi), y compris celles dessinées par l'opérateur. Si ce plan est
     affiché, le calque est retracé (sélection et tracé en cours annulés :
     la forme visée peut avoir disparu). */
  function setPlanShapes(key, shapes) {
    ed.store.set(key, shapes);
    if (shapesAvailable() && NS.elementsKey(state.currentPlan) === key) {
      ed.shapes = shapes;
      ed.selected = null;
      ed.draft = null;
      ed.drag = null;
      NS.renderEditLayer();
      // Un étalon d'échelle reçu (forme "scale") change l'échelle des cotes.
      NS.syncScaleDependents();
    }
  }

  /* Prochain id de forme du plan courant : le plus grand id présent + 1
     (les ids des formes reçues sont posés par normalizeDrawnShapes ; ceux
     des formes dessinées, par commitShape — viewer-edit-tools.js). */
  function nextShapeId() {
    let max = 0;
    for (const s of ed.shapes) if (s.id > max) max = s.id;
    return max + 1;
  }

  /* Événement le plus important (eventPriorityOrder) des capteurs LIÉS à
     la forme (clé elements) ; null si aucun n'est en alarme. */
  function shapeAlarmEvent(s) {
    const desc = state.currentConfig.eventPriorityOrder === 'desc';
    let best = null;
    for (const id of s.elements || []) {
      for (const ev of state.events.byElement.get(id) || []) {
        if (!best || (desc ? ev.priority > best.priority : ev.priority < best.priority)) {
          best = ev;
        }
      }
    }
    return best;
  }

  /* Visibilité d'une forme cadenas fermé, selon sa règle show_mode
     (readme § 6.3) :
       shown       la forme est affichée ;
       alarmColor  couleur CSS du halo d'alarme (show_mode
                   always_with_animation avec un capteur lié en alarme),
                   sinon null.
     Cadenas ouvert, toutes les formes restent affichées : celles dont
     shown est faux passent en contour fantôme (viewer-edit-render.js). */
  function shapeDisplay(s) {
    const mode = s.show_mode || NS.SHAPE_SHOW_MODE_DEFAULT;
    if (mode === 'masked') return { shown: false, alarmColor: null };
    if (mode === 'always_with_animation') {
      const ev = shapeAlarmEvent(s);
      return ev
        ? { shown: true, alarmColor: ev.color.charAt(0) === '#' ? ev.color : 'var(--sev-' + ev.color + ')' }
        : { shown: false, alarmColor: null };
    }
    return { shown: true, alarmColor: null };
  }

  /* Rayon des poignées en unités du viewBox, pour une taille écran
     constante quel que soit le zoom. */
  function handleRadius() {
    const rect = NS.dom.planImage.getBoundingClientRect();
    return rect.width ? HANDLE_PX * NS.SHAPES_VIEW_W / rect.width : HANDLE_PX;
  }

  /* Coins d'un rectangle / d'une icône dans SON repère (avant rotation),
     dans l'ordre haut-gauche, haut-droit, bas-droit, bas-gauche. */
  function rectCorners(s) {
    return [
      { x: s.x, y: s.y },
      { x: s.x + s.w, y: s.y },
      { x: s.x + s.w, y: s.y + s.h },
      { x: s.x, y: s.y + s.h },
    ];
  }

  function rectCenter(s) {
    return { x: s.x + s.w / 2, y: s.y + s.h / 2 };
  }

  /* ---- Rotation des formes (readme § 10, et readme V1 § 6) ----
     Deux familles :
       - types à CLÉ rotation (ROTATION_KEY_TYPES) : l'angle est mémorisé
         sur la forme, sérialisé dans current_plan_drawnShapes_json et appliqué au rendu
         par une transformation SVG autour du pivot (shapeSvgNode) ;
       - types tournés « dans leurs coordonnées » (BAKED_ROTATION_TYPES) :
         la rotation réécrit les sommets ou extrémités autour du pivot
         (segments : milieu ; polygone, polyligne : centre des sommets),
         ou décale les deux angles du secteur — le schéma sérialisé ne
         change pas. Polygone et polyligne mémorisent en plus la rotation
         cumulée depuis le tracé (clé rotation en mémoire seulement, non
         sérialisée) pour le champ du panneau et la poignée.
     Les calculs sont menés en unités isotropes — fraction de la LARGEUR
     du plan, l'écart vertical étant ramené par planRatio — car un plan
     n'est pas carré. Angles en degrés, sens horaire, 0 = est (convention
     des secteurs). */
  const ROTATION_KEY_TYPES = ['rect', 'ellipse', 'icon', 'label'];
  const BAKED_ROTATION_TYPES = ['polygon', 'polyline', 'sector', 'line',
    'arrow', 'measure', 'scale'];
  const DEG = Math.PI / 180;

  function wrapAngle(a) {
    return ((a % 360) + 360) % 360;
  }

  function isRotatable(s) {
    return Boolean(s) && (ROTATION_KEY_TYPES.indexOf(s.type) !== -1 ||
      BAKED_ROTATION_TYPES.indexOf(s.type) !== -1);
  }

  /* Rotation portée par la clé rotation d'une forme, 0 pour les autres
     types : c'est l'angle appliqué au rendu. */
  function shapeRotation(s) {
    if (!s || ROTATION_KEY_TYPES.indexOf(s.type) === -1) return 0;
    return wrapAngle(Number(s.rotation) || 0);
  }

  /* Pivot de rotation d'une forme, en fractions du plan. */
  function shapePivot(s) {
    switch (s.type) {
      case 'rect':
      case 'icon':
        return rectCenter(s);
      case 'label':
        return { x: s.x, y: s.y };
      case 'polygon':
      case 'polyline': {
        // Centre des sommets (moyenne) : invariant par rotation, à la
        // différence de la boîte englobante.
        let sx = 0, sy = 0;
        for (const p of s.points) { sx += p.x; sy += p.y; }
        return { x: sx / s.points.length, y: sy / s.points.length };
      }
      case 'line':
      case 'arrow':
      case 'measure':
      case 'scale':
        return { x: (s.x1 + s.x2) / 2, y: (s.y1 + s.y2) / 2 };
      default:
        // circle, ellipse, sector : centre.
        return { x: s.cx, y: s.cy };
    }
  }

  /* Point p tourné de deg degrés (sens horaire) autour de c, en fractions
     du plan (calcul isotrope). */
  function rotatePoint(p, c, deg) {
    const k = planRatio();
    const a = deg * DEG;
    const cos = Math.cos(a), sin = Math.sin(a);
    const dx = p.x - c.x;
    const dy = (p.y - c.y) * k;
    return {
      x: c.x + dx * cos - dy * sin,
      y: c.y + (dx * sin + dy * cos) / k,
    };
  }

  /* Angle en degrés (sens horaire, 0 = est) du point p vu du centre c. */
  function pointAngleDeg(c, p) {
    return wrapAngle(
      Math.atan2((p.y - c.y) * planRatio(), p.x - c.x) / DEG);
  }

  /* Point à la distance d (fraction de la largeur du plan) de c dans la
     direction deg (degrés, sens horaire, 0 = est). */
  function offsetPoint(c, deg, d) {
    const a = deg * DEG;
    return {
      x: c.x + d * Math.cos(a),
      y: c.y + d * Math.sin(a) / planRatio(),
    };
  }

  /* Ramène une forme tournée « dans ses coordonnées » à l'intérieur du
     plan : translation si elle y tient (des coordonnées hors de 0..1
     seraient rejetées au réaffichage par un calque "shapes"), sinon
     bornage. */
  function fitInPlan(s) {
    const pts = s.points ||
      [{ x: s.x1, y: s.y1 }, { x: s.x2, y: s.y2 }];
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (const p of pts) {
      minX = Math.min(minX, p.x); maxX = Math.max(maxX, p.x);
      minY = Math.min(minY, p.y); maxY = Math.max(maxY, p.y);
    }
    const dx = minX < 0 ? -minX : maxX > 1 ? 1 - maxX : 0;
    const dy = minY < 0 ? -minY : maxY > 1 ? 1 - maxY : 0;
    for (const p of pts) {
      p.x = clampNum(p.x + dx, 0, 1);
      p.y = clampNum(p.y + dy, 0, 1);
    }
    if (!s.points) {
      s.x1 = pts[0].x; s.y1 = pts[0].y;
      s.x2 = pts[1].x; s.y2 = pts[1].y;
    }
  }

  /* Tourne la forme de delta degrés (sens horaire) autour de son pivot :
     types à clé rotation : l'angle est incrémenté ; segments, polygone et
     polyligne : les points sont réécrits puis ramenés dans le plan ;
     secteur : ses deux angles sont décalés (l'ouverture est conservée). */
  function rotateShape(s, delta) {
    if (!isRotatable(s) || !delta) return;
    if (ROTATION_KEY_TYPES.indexOf(s.type) !== -1) {
      s.rotation = wrapAngle((Number(s.rotation) || 0) + delta);
      return;
    }
    if (s.type === 'sector') {
      s.startAngle = wrapAngle(s.startAngle + delta);
      s.endAngle = wrapAngle(s.endAngle + delta);
      return;
    }
    const c = shapePivot(s);
    if (s.points) {
      s.points = s.points.map((p) => rotatePoint(p, c, delta));
      s.rotation = wrapAngle((Number(s.rotation) || 0) + delta);
    } else {
      const p1 = rotatePoint({ x: s.x1, y: s.y1 }, c, delta);
      const p2 = rotatePoint({ x: s.x2, y: s.y2 }, c, delta);
      s.x1 = p1.x; s.y1 = p1.y; s.x2 = p2.x; s.y2 = p2.y;
    }
    fitInPlan(s);
  }

  /* Angle affiché par le champ « Angle » de la section Rotation du
     panneau : rotation portée (types à clé rotation), orientation du
     segment de (x1, y1) vers (x2, y2) pour ligne, flèche, cote et étalon,
     rotation cumulée depuis le tracé pour polygone et polyligne ; null
     pour les types sans champ (secteur : ses angles propres ; punaise,
     étiquette de rappel, cercle : non orientables). */
  function shapeAngle(s) {
    if (!s) return null;
    if (ROTATION_KEY_TYPES.indexOf(s.type) !== -1) return shapeRotation(s);
    if (s.type === 'polygon' || s.type === 'polyline') {
      return wrapAngle(Number(s.rotation) || 0);
    }
    if (s.type === 'line' || s.type === 'arrow' || s.type === 'measure' ||
        s.type === 'scale') {
      return pointAngleDeg({ x: s.x1, y: s.y1 }, { x: s.x2, y: s.y2 });
    }
    return null;
  }

  /* Amène la forme à l'angle deg (même sens que shapeAngle). */
  function setShapeAngle(s, deg) {
    const current = shapeAngle(s);
    if (current === null) return;
    if (ROTATION_KEY_TYPES.indexOf(s.type) !== -1) {
      s.rotation = wrapAngle(deg);
      return;
    }
    rotateShape(s, wrapAngle(deg) - current);
  }

  /* Types de formes FERMÉES : les seules à pouvoir couvrir des capteurs
     (les tracés ouverts, textes et marqueurs ponctuels écrivent
     sensors: [] dans current_plan_drawnShapes_json). */
  const CLOSED_TYPES = ['polygon', 'rect', 'circle', 'ellipse', 'sector'];

  function isClosedShape(shape) {
    return Boolean(shape) && CLOSED_TYPES.indexOf(shape.type) !== -1;
  }

  /* Ratio hauteur/largeur du plan affiché : ramène un écart vertical en
     fraction de hauteur dans l'unité des rayons (fraction de largeur). */
  function planRatio() {
    const planImage = NS.dom.planImage;
    return planImage.offsetWidth
      ? planImage.offsetHeight / planImage.offsetWidth
      : 1;
  }

  /* ---- Capteurs couverts par une forme du mode édition ----
     Un « capteur » est un point d'un calque "markers" du plan courant
     (visible ou non). L'appartenance est calculée en fraction du plan ;
     pour le cercle et le secteur, dont le rayon est exprimé en fraction
     de la LARGEUR, l'écart vertical est ramené dans la même unité par le
     ratio hauteur/largeur du plan. */
  function pointInShape(pt, shape) {
    if (shape.type === 'rect') {
      // Rectangle tourné : le point est ramené dans le repère du rectangle
      // (rotation inverse autour du centre).
      const rot = shapeRotation(shape);
      const q = rot ? rotatePoint(pt, rectCenter(shape), -rot) : pt;
      return q.x >= shape.x && q.x <= shape.x + shape.w &&
             q.y >= shape.y && q.y <= shape.y + shape.h;
    }
    if (shape.type === 'circle') {
      return Math.hypot(pt.x - shape.cx, (pt.y - shape.cy) * planRatio()) <=
        shape.r;
    }
    if (shape.type === 'ellipse') {
      if (!shape.rx || !shape.ry) return false;
      // Ellipse tournée : point ramené dans le repère de l'ellipse.
      const rot = shapeRotation(shape);
      const q = rot
        ? rotatePoint(pt, { x: shape.cx, y: shape.cy }, -rot)
        : pt;
      const nx = (q.x - shape.cx) / shape.rx;
      const ny = (q.y - shape.cy) / shape.ry;
      return nx * nx + ny * ny <= 1;
    }
    if (shape.type === 'sector') {
      const dx = pt.x - shape.cx;
      const dy = (pt.y - shape.cy) * planRatio();
      if (Math.hypot(dx, dy) > shape.r) return false;
      // Angle du point en degrés (sens horaire, 0 = est, y écran vers le
      // bas), ramené dans l'ouverture mesurée depuis startAngle.
      const ang = (Math.atan2(dy, dx) * 180 / Math.PI + 360) % 360;
      const from = ((ang - shape.startAngle) % 360 + 360) % 360;
      return from <= NS.sectorOpening(shape);
    }
    if (shape.type === 'polygon') {
      // Lancer de rayon (règle pair/impair).
      const pts = shape.points;
      let inside = false;
      for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
        const a = pts[i], b = pts[j];
        if ((a.y > pt.y) !== (b.y > pt.y) &&
            pt.x < a.x + (b.x - a.x) * (pt.y - a.y) / (b.y - a.y)) {
          inside = !inside;
        }
      }
      return inside;
    }
    // Tracés ouverts, textes, icônes, punaises : aucune couverture.
    return false;
  }

  /* Capteurs du plan courant (current_plan_element_json, mémorisés dans
     state.currentElements par le module plan) : objets { id, label, x, y,
     ... } positionnés en fraction du plan. */
  function planSensors() {
    return state.currentPlan ? state.currentElements : [];
  }

  function coveredSensors(shape) {
    return planSensors().filter((pt) => pointInShape(pt, shape));
  }

  /* Forme dont la couverture est indiquée : le tracé en cours (aperçu
     vivant, dès que sa géométrie existe), sinon la forme sélectionnée —
     seulement pour les formes fermées (CLOSED_TYPES). */
  function coverageShape() {
    if (ed.draft) {
      if (ed.draft.type === 'polygon') {
        const pts = ed.draft.cursor
          ? ed.draft.points.concat([ed.draft.cursor])
          : ed.draft.points;
        return pts.length >= 3 ? { type: 'polygon', points: pts } : null;
      }
      const draftShape = NS.draftToShape(ed.draft, true);
      return isClosedShape(draftShape) ? draftShape : null;
    }
    return isClosedShape(ed.selected) ? ed.selected : null;
  }

  /* Indicateur des capteurs couverts : panneau à gauche de la palette
     d'outils, et mise en évidence des marqueurs concernés (si leur calque
     est affiché). Rafraîchi par renderEditLayer, donc à chaque tracé,
     ajustement, sélection ou changement de plan. */
  function updateShapeCoverage() {
    const shapeCoverageInfo = NS.dom.shapeCoverageInfo;
    const shape = editActive() ? coverageShape() : null;
    const covered = shape ? coveredSensors(shape) : [];
    // Anneau bleu sur les capteurs couverts, posés par le calque des
    // capteurs (viewer-plan.js).
    for (const dot of NS.elementDots ? NS.elementDots() : []) {
      dot.classList.toggle('covered', covered.indexOf(dot._point) !== -1);
    }
    if (!shape) {
      shapeCoverageInfo.hidden = true;
      return;
    }
    shapeCoverageInfo.textContent = '';
    const title = document.createElement('div');
    title.className = 'shape-coverage-title';
    title.textContent = 'Capteurs couverts (' + covered.length + ')';
    shapeCoverageInfo.appendChild(title);
    if (covered.length === 0) {
      const none = document.createElement('div');
      none.className = 'shape-coverage-empty';
      none.textContent = 'Aucun capteur couvert';
      shapeCoverageInfo.appendChild(none);
    } else {
      for (const pt of covered) {
        const row = document.createElement('div');
        row.className = 'shape-coverage-item';
        row.textContent = pt.label || '(sans libell\u00e9)';
        shapeCoverageInfo.appendChild(row);
      }
    }
    shapeCoverageInfo.hidden = false;
  }

  /* Écrit dans current_plan_drawnShapes_json l'ensemble des formes du plan
     courant, avec leur contexte (node_id du nœud sélectionné — 0 en mode
     sans navigation —, rang et fichier du plan). Coordonnées arrondies à
     4 décimales — le schéma des formes est celui que l'application renvoie
     par la même propriété, ce qui lui permet de les réafficher telles
     quelles. Chaque forme porte en plus id, show_mode, props et :
       elements ids des capteurs liés. Pour une forme FERMÉE dont la
                GÉOMÉTRIE vient de changer (geomShape : création, glisser,
                poignées, rotation, champs secteur), la liste est
                recalculée = capteurs couverts ; sinon elle est conservée
                telle quelle (une liaison posée par l'application survit
                aux changements d'apparence, de nom ou de propriétés). */
  /* Géométrie sérialisée d'une forme, coordonnées arrondies à 4 décimales
     (angles du secteur à 1 décimale). Le schéma est celui des formes d'un
     calque "shapes" de configuration_plan_json (normalizeShapes). */
  function shapeGeometry(s) {
    const round = (v) => Math.round(v * 10000) / 10000;
    const roundAngle = (v) => Math.round(v * 10) / 10;
    switch (s.type) {
      case 'polygon':
      case 'polyline':
        return { type: s.type, points: s.points.map((p) => [round(p.x), round(p.y)]) };
      case 'rect':
        // rotation : angle en degrés (sens horaire) autour du centre —
        // idem ellipse, icon (centre) et label (point d'ancrage).
        return { type: 'rect', x: round(s.x), y: round(s.y), w: round(s.w), h: round(s.h),
                 rotation: roundAngle(shapeRotation(s)) };
      case 'circle':
        return { type: 'circle', cx: round(s.cx), cy: round(s.cy), r: round(s.r) };
      case 'ellipse':
        return { type: 'ellipse', cx: round(s.cx), cy: round(s.cy),
                 rx: round(s.rx), ry: round(s.ry),
                 rotation: roundAngle(shapeRotation(s)) };
      case 'sector':
        return { type: 'sector', cx: round(s.cx), cy: round(s.cy), r: round(s.r),
                 startAngle: roundAngle(s.startAngle), endAngle: roundAngle(s.endAngle) };
      case 'line':
        return { type: 'line', x1: round(s.x1), y1: round(s.y1),
                 x2: round(s.x2), y2: round(s.y2) };
      case 'arrow':
        // heads : extrémité(s) portant la pointe (end / start / both).
        return { type: 'arrow', x1: round(s.x1), y1: round(s.y1),
                 x2: round(s.x2), y2: round(s.y2),
                 heads: NS.normalizeArrowHeads(s.heads) };
      case 'measure':
        // distance : texte affiché sur la cote (échelle effective du plan
        // ou % de la largeur), fourni à titre informatif ; ignoré au
        // réaffichage.
        return { type: 'measure', x1: round(s.x1), y1: round(s.y1),
                 x2: round(s.x2), y2: round(s.y2), distance: NS.measureLabel(s) };
      case 'scale': {
        // Étalon d'échelle. planWidthValue : longueur réelle équivalente de
        // la LARGEUR totale du plan (même sémantique que la clé scale d'une
        // représentation, où l'application peut la reporter telle quelle) ;
        // ignorée au réaffichage par un calque "shapes".
        const lenFrac = Math.hypot(s.x2 - s.x1,
          (s.y2 - s.y1) * NS.planRatio());
        const out = { type: 'scale', x1: round(s.x1), y1: round(s.y1),
                      x2: round(s.x2), y2: round(s.y2),
                      value: s.value, unit: s.unit || 'm',
                      shown: s.shown !== false };
        if (lenFrac > 0 && s.value > 0) {
          out.planWidthValue = Math.round(s.value / lenFrac * 1000) / 1000;
        }
        return out;
      }
      case 'label':
        return { type: 'label', x: round(s.x), y: round(s.y), text: s.text,
                 fontSize: s.fontSize, bold: Boolean(s.bold),
                 italic: Boolean(s.italic), boxed: Boolean(s.boxed),
                 rotation: roundAngle(shapeRotation(s)) };
      case 'callout':
        return { type: 'callout', tx: round(s.tx), ty: round(s.ty),
                 x: round(s.x), y: round(s.y), text: s.text,
                 fontSize: s.fontSize, bold: Boolean(s.bold),
                 italic: Boolean(s.italic) };
      case 'icon':
        return { type: 'icon', x: round(s.x), y: round(s.y),
                 w: round(s.w), h: round(s.h), filename: s.filename || '',
                 rotation: roundAngle(shapeRotation(s)) };
      case 'pin':
        return { type: 'pin', x: round(s.x), y: round(s.y) };
      default:
        return { type: s.type };
    }
  }

  function writeDrawnShapes(geomShape) {
    if (!state.currentPlan) return;
    if (geomShape && isClosedShape(geomShape)) {
      geomShape.elements = coveredSensors(geomShape).map((pt) => pt.id);
    }
    const shapes = ed.shapes.map((s) => {
      const out = shapeGeometry(s);
      out.fill = NS.drawnShapeFill(s);
      out.stroke = NS.drawnShapeStroke(s);
      out.strokeWidth = s.strokeWidth || 2;
      if (s.label) out.label = s.label;
      const props = {};
      for (const prop of s.props || []) {
        if (prop.name) props[prop.name] = prop.value;
      }
      if (Object.keys(props).length > 0) out.props = props;
      out.id = s.id;
      out.show_mode = s.show_mode || NS.SHAPE_SHOW_MODE_DEFAULT;
      out.elements = s.elements || [];
      return out;
    });
    NS.writeProperty(NS.DRAWN_SHAPES_PROPERTY, JSON.stringify({
      node_id: state.selectedNode ? state.selectedNode.id : 0,
      planIndex: state.currentPlans.indexOf(state.currentPlan) + NS.SELECTED_PLAN_BASE,
      filename: state.currentPlan.filename,
      shapes,
    }));
    // Les cotes des calques "shapes" suivent l'échelle effective : si la
    // modification l'a changée (étalon), elles sont retracées.
    NS.syncScaleDependents();
  }

  /* ------------------- Exposition sur l'espace de noms ------------------- */
  NS.HANDLE_PX = HANDLE_PX;
  NS.MIN_SHAPE_PX = MIN_SHAPE_PX;
  NS.DRAWN_SHAPE_FILL = DRAWN_SHAPE_FILL;
  NS.DRAWN_SHAPE_STROKE = DRAWN_SHAPE_STROKE;
  NS.shapesAvailable = shapesAvailable;
  NS.editAvailable = editAvailable;
  NS.setPlanShapes = setPlanShapes;
  NS.nextShapeId = nextShapeId;
  NS.shapeDisplay = shapeDisplay;
  NS.editActive = editActive;
  NS.editBlocksPan = editBlocksPan;
  NS.isClosedShape = isClosedShape;
  NS.planRatio = planRatio;
  NS.planPointFromEvent = planPointFromEvent;
  NS.planPxDistance = planPxDistance;
  NS.drawnShapesKey = drawnShapesKey;
  NS.handleRadius = handleRadius;
  NS.rectCorners = rectCorners;
  NS.rectCenter = rectCenter;
  NS.ROTATION_KEY_TYPES = ROTATION_KEY_TYPES;
  NS.isRotatable = isRotatable;
  NS.shapeRotation = shapeRotation;
  NS.shapePivot = shapePivot;
  NS.rotatePoint = rotatePoint;
  NS.pointAngleDeg = pointAngleDeg;
  NS.offsetPoint = offsetPoint;
  NS.rotateShape = rotateShape;
  NS.shapeAngle = shapeAngle;
  NS.setShapeAngle = setShapeAngle;
  NS.pointInShape = pointInShape;
  NS.coveredSensors = coveredSensors;
  NS.updateShapeCoverage = updateShapeCoverage;
  NS.writeDrawnShapes = writeDrawnShapes;
})(globalThis);
