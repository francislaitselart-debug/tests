﻿/* ============================================================
   MyPnPlanViewerV2 — module « scene3d-zones »
   ============================================================
   Zones du bâtiment d'une représentation 3D (clé zones de
   current_plan_scene3d_json, readme § 10 bis) : découpage du modèle en
   volumes nommés, pour les mettre en évidence et, à terme, les animer sur
   alarme.

   Une zone est soit un VOLUME TRACÉ (polygone au sol + hauteur de base +
   hauteur : prisme), soit LIÉE À UN GROUPE nommé du fichier .obj (clé
   group : lignes « o » / « g » du fichier, un maillage par groupe) quand
   le modèle en fournit. Rendu :
     - consultation (cadenas fermé) : invisible ; au SURVOL, le prisme (ou
       le maillage du groupe) prend la couleur / l'opacité de la zone et une
       carte contextuelle (libellé, description) suit le pointeur ; un clic
       écrit eventsDetailRequest_json { source: "zone", … } ;
     - alarme : une zone dont un capteur lié (clé elements) est en alarme
       (configuration_events_json) et dont show_mode vaut
       always_with_animation CLIGNOTE dans sa couleur ; masked : jamais
       affichée ni survolable hors édition ;
     - édition (cadenas ouvert) : prismes en fantôme translucide avec
       arêtes, sélection par clic, poignées de sommets.

   Le module est appelé par viewer-scene3d-render.js (build, buildHandles,
   debug) et viewer-scene3d-tools.js (survol, clic, tracé) ; il complète
   viewer-scene3d.js (panneau « Zone »).

   NOTE ENCODAGE : chaînes affichées en ASCII pur (\uXXXX), commentaires
   accentués, BOM UTF-8, fins de ligne CRLF (readme.txt § 14).
   ============================================================ */
(function (global) {
  'use strict';

  const NS = global.MyPnPlanViewerV2NS = global.MyPnPlanViewerV2NS || {};
  const sc = NS.scene3d;
  const r = NS.scene3dRender;
  const state = NS.state;

  const EDIT_ALPHA = 0.12;       // prisme fantôme cadenas ouvert
  const MASKED_EDIT_ALPHA = 0.05;
  const PULSE_MS = 90;           // cadence du clignotement d'alarme
  const CARD_OFFSET = 14;        // décalage de la carte contextuelle (px)

  const Z = NS.scene3dZones = {
    items: [],      // { zone, index, fill, edges, groupMesh, saved, alarm }
    hover: -1,      // rang de la zone survolée
    timer: null,    // clignotement
  };

  function T() { return r.ctx.THREE; }

  function editActive() {
    return Boolean(NS.sceneEditActive && NS.sceneEditActive());
  }

  /* ---------------------- Modèle : groupes nommés ---------------------- */

  function modelObject() {
    const v = global.ThreeViewer;
    return v && typeof v.getModelObject === 'function' ? v.getModelObject() : null;
  }

  /* Noms des maillages du modèle (groupes o / g du .obj, nœuds du glTF). */
  function modelGroupNames() {
    const names = [];
    const obj = modelObject();
    if (obj) obj.traverse((o) => { if (o.isMesh && o.name && !names.includes(o.name)) names.push(o.name); });
    return names;
  }

  function findGroupMesh(name) {
    let found = null;
    const obj = modelObject();
    if (obj) obj.traverse((o) => { if (!found && o.isMesh && o.name === name) found = o; });
    return found;
  }

  /* ---------------------- Alarmes ---------------------- */

  function zoneAlarm(zone) {
    const by = state.events && state.events.byElement;
    return Boolean(by) && zone.elements.some((id) => by.has(id));
  }

  function animated(item) {
    return item.alarm && item.zone.show_mode === 'always_with_animation';
  }

  /* ---------------------- Construction ---------------------- */

  function defaultHeight() {
    const v = global.ThreeViewer;
    const b = v && v.getModelBounds ? v.getModelBounds() : null;
    return b ? Math.round(b.size[1] * 0.5 * 10) / 10 : 10;
  }

  function prismGeometry(zone) {
    const t = T();
    const shape = new t.Shape(zone.points.map((p) => new t.Vector2(p[0], -p[1])));
    const geom = new t.ExtrudeGeometry(shape, { depth: zone.height, bevelEnabled: false });
    geom.rotateX(-Math.PI / 2);
    return geom;
  }

  /* Construit les zones de la scène dans le groupe du rendu (appelé par
     rebuild, avant les poignées). Une zone liée à un groupe n'a pas de
     prisme : son maillage du modèle sert de cible de survol. */
  function build(scene, y0) {
    restoreGroupMaterials();
    Z.items = [];
    Z.hover = -1;
    hideCard();
    const edit = editActive();
    scene.zones.forEach((zone, index) => {
      const item = { zone, index, fill: null, edges: null, groupMesh: null, saved: null, alarm: zoneAlarm(zone) };
      Z.items.push(item);
      const masked = zone.show_mode === 'masked';
      if (masked && !edit) return;
      if (zone.group) {
        item.groupMesh = findGroupMesh(zone.group);
        return;
      }
      if (zone.points.length < 3) return;
      const t = T();
      const geom = prismGeometry(zone);
      const fill = new t.Mesh(geom, new t.MeshBasicMaterial({
        color: new t.Color(zone.color), transparent: true, opacity: 0, depthWrite: false, side: t.DoubleSide,
      }));
      fill.position.y = y0 + zone.baseHeight;
      fill.renderOrder = 2;
      fill.userData = { kind: 'zone', index };
      r.group.add(fill);
      r.pickables.push(fill);
      const edges = new t.LineSegments(new t.EdgesGeometry(geom), new t.LineBasicMaterial({
        color: new t.Color(zone.color), transparent: true, opacity: 0,
      }));
      edges.position.y = fill.position.y;
      edges.renderOrder = 3;
      r.group.add(edges);
      item.fill = fill;
      item.edges = edges;
    });
    for (const item of Z.items) applyVisual(item, 0);
    startOrStopPulse();
  }

  /* Poignées de la zone sélectionnée (appelé par le rendu). */
  function buildHandles(scene, y) {
    if (sc.selected !== 'zone') return;
    const zone = scene.zones[sc.selectedIndex];
    if (!zone || zone.group) return;
    zone.points.forEach((p, i) => r.addHandle(p[0], y + zone.baseHeight, p[1], { kind: 'zVertex', index: i }));
  }

  /* Apparence d'une zone selon survol, alarme (phase 0..1 du
     clignotement) et mode. */
  function applyVisual(item, phase) {
    const zone = item.zone;
    const edit = editActive();
    const hovered = Z.hover === item.index;
    const selected = edit && sc.selected === 'zone' && sc.selectedIndex === item.index;
    let fillAlpha = 0;
    let edgeAlpha = 0;
    if (hovered) {
      fillAlpha = zone.opacity;
      edgeAlpha = 1;
    } else if (animated(item)) {
      fillAlpha = zone.opacity * (0.25 + 0.75 * phase);
      edgeAlpha = 0.9;
    } else if (edit) {
      fillAlpha = zone.show_mode === 'masked' ? MASKED_EDIT_ALPHA : EDIT_ALPHA;
      edgeAlpha = selected ? 1 : 0.7;
    } else if (r.exporting && zone.show_mode !== 'masked') {
      // Export (viewer-scene3d-export.js) : zones visibles comme en édition.
      fillAlpha = EDIT_ALPHA;
      edgeAlpha = 0.7;
    }
    if (item.fill) {
      item.fill.material.opacity = fillAlpha;
      item.fill.visible = fillAlpha > 0 || edit;
      item.edges.material.opacity = edgeAlpha;
      item.edges.visible = edgeAlpha > 0;
    } else if (item.groupMesh) {
      const exported = Boolean(r.exporting) && zone.show_mode !== 'masked';
      applyGroupVisual(item, hovered || animated(item) || selected || exported, hovered ? 1 : (animated(item) ? phase : 0.5));
    }
  }

  /* Zone liée à un groupe : le maillage du modèle prend la couleur de la
     zone (matériau d'origine conservé pour le restaurer). */
  function applyGroupVisual(item, on, strength) {
    const mesh = item.groupMesh;
    if (!on) {
      if (item.saved) { mesh.material = item.saved; item.saved = null; }
      return;
    }
    if (!item.saved) item.saved = mesh.material;
    const t = T();
    const base = new t.Color(item.zone.color);
    if (!item.highlight) {
      item.highlight = new t.MeshStandardMaterial({ metalness: 0.05, roughness: 0.9 });
    }
    item.highlight.color.copy(base).lerp(new t.Color(0xffffff), 0.35 * (1 - strength));
    item.highlight.emissive.copy(base).multiplyScalar(0.25 * strength);
    mesh.material = item.highlight;
  }

  function restoreGroupMaterials() {
    for (const item of Z.items) {
      if (item.groupMesh && item.saved) { item.groupMesh.material = item.saved; item.saved = null; }
    }
  }

  /* ---------------------- Survol et carte ---------------------- */

  /* Zone sous le pointeur : rang, ou -1. Les prismes passent par la
     sélection générale (userData kind "zone") ; les zones liées à un groupe
     par un lancer de rayon sur leurs maillages du modèle. */
  function pick(clientX, clientY) {
    const hit = r.pick(clientX, clientY);
    if (hit && hit.kind === 'zone') return hit.index;
    if (hit && hit.kind !== 'zone' && hit.kind !== 'footprint' && hit.kind !== 'floorImage') return -1;
    const targets = Z.items.filter((it) => it.groupMesh);
    if (!targets.length) return -1;
    const hits = r.raycast(clientX, clientY, targets.map((it) => it.groupMesh));
    if (!hits.length) return -1;
    const item = targets.find((it) => it.groupMesh === hits[0].object);
    return item ? item.index : -1;
  }

  function setHover(index, clientX, clientY) {
    if (index !== Z.hover) {
      const prev = Z.items[Z.hover];
      Z.hover = index;
      if (prev) applyVisual(prev, currentPhase());
      const cur = Z.items[index];
      if (cur) applyVisual(cur, currentPhase());
      if (r.ctx) r.ctx.render();
      NS.dom.threeViewport.classList.toggle('zone-hover', index >= 0);
    }
    const item = Z.items[index];
    if (item) showCard(item, clientX, clientY);
    else hideCard();
  }

  function clearHover() {
    setHover(-1, 0, 0);
  }

  function showCard(item, clientX, clientY) {
    const card = NS.dom.zoneCard;
    const zone = item.zone;
    card.textContent = '';
    const title = document.createElement('div');
    title.className = 'marker-card-title';
    title.textContent = zone.label || ('Zone ' + zone.id);
    card.appendChild(title);
    if (zone.description) {
      const desc = document.createElement('div');
      desc.className = 'zone-card-desc';
      desc.textContent = zone.description;
      card.appendChild(desc);
    }
    if (item.alarm) {
      const al = document.createElement('div');
      al.className = 'zone-card-alarm';
      const n = zone.elements.filter((id) => state.events.byElement.has(id)).length;
      al.textContent = n + (n > 1 ? ' capteurs en alarme' : ' capteur en alarme');
      card.appendChild(al);
    }
    const zoneRect = NS.dom.planZone.getBoundingClientRect();
    card.hidden = false;
    const w = card.offsetWidth, h = card.offsetHeight;
    let left = clientX - zoneRect.left + CARD_OFFSET;
    let top = clientY - zoneRect.top + CARD_OFFSET;
    if (left + w > zoneRect.width - 8) left = Math.max(8, clientX - zoneRect.left - w - CARD_OFFSET);
    if (top + h > zoneRect.height - 8) top = Math.max(8, clientY - zoneRect.top - h - CARD_OFFSET);
    card.style.left = left + 'px';
    card.style.top = top + 'px';
  }

  function hideCard() {
    const card = NS.dom.zoneCard;
    if (card && !card.hidden) card.hidden = true;
  }

  /* Clic (consultation) sur une zone : demande de détail à l'application. */
  function requestDetail(index) {
    const zone = sc.scene && sc.scene.zones[index];
    if (!zone) return;
    state.eventsDetailSerial += 1;
    NS.writeProperty(NS.EVENTS_DETAIL_PROPERTY, JSON.stringify({
      source: 'zone',
      zone_id: zone.id,
      node_id: state.selectedNode ? state.selectedNode.id : 0,
      planIndex: state.currentPlans.indexOf(state.currentPlan) + NS.SELECTED_PLAN_BASE,
      label: zone.label,
      elements: zone.elements,
      serial: state.eventsDetailSerial,
    }));
  }

  /* ---------------------- Alarmes : clignotement ---------------------- */

  function currentPhase() {
    return 0.5 + 0.5 * Math.sin(Date.now() / 250);
  }

  function pulse() {
    const phase = currentPhase();
    let any = false;
    for (const item of Z.items) {
      if (animated(item) && Z.hover !== item.index) { applyVisual(item, phase); any = true; }
    }
    if (any && r.ctx) r.ctx.render();
    if (!any) startOrStopPulse();
  }

  function startOrStopPulse() {
    const needed = Z.items.some(animated) && global.ThreeViewer && global.ThreeViewer.isActive();
    if (needed && !Z.timer) Z.timer = setInterval(pulse, PULSE_MS);
    if (!needed && Z.timer) { clearInterval(Z.timer); Z.timer = null; }
  }

  /* Nouvelles alarmes (configuration_events_json, viewer-nav.js) : état
     d'alarme des zones recalculé sans reconstruire la scène. */
  function refreshAlarms() {
    if (!Z.items.length) return;
    for (const item of Z.items) {
      item.alarm = zoneAlarm(item.zone);
      applyVisual(item, currentPhase());
    }
    startOrStopPulse();
    if (r.ctx) r.ctx.render();
  }

  /* État pour les bancs de test. */
  function debug() {
    return Z.items.map((it) => ({
      id: it.zone.id, alarm: it.alarm, group: it.zone.group,
      prism: Boolean(it.fill), opacity: it.fill ? it.fill.material.opacity : null,
      visible: it.fill ? it.fill.visible : Boolean(it.saved),
      groupBound: Boolean(it.groupMesh), highlighted: Boolean(it.saved),
    }));
  }

  /* ------------------- Exposition sur l'espace de noms ------------------- */
  Z.build = build;
  Z.buildHandles = buildHandles;
  Z.pick = pick;
  Z.setHover = setHover;
  Z.clearHover = clearHover;
  Z.requestDetail = requestDetail;
  Z.refreshAlarms = refreshAlarms;
  Z.modelGroupNames = modelGroupNames;
  Z.defaultHeight = defaultHeight;
  Z.debug = debug;
  NS.refreshZoneAlarms = refreshAlarms;
})(globalThis);
