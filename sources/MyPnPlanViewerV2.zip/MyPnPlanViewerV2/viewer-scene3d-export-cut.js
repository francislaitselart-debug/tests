﻿/* ============================================================
   MyPnPlanViewerV2 — module « scene3d-export-cut »
   ============================================================
   Coupe horizontale vectorielle du modèle pour l'export SVG (menu
   « Exporter en SVG (coupe) ») : à la place de l'image du modèle rendue
   de dessus (viewer-scene3d-export-svg.js), les maillages du fichier .obj
   / .glb sont coupés par le plan horizontal y = sol + hauteur de coupe
   (clé planExport.cutHeight, en unités réelles du plan, défaut 1,2 ; sans
   échelle connue : en unités du modèle) : chaque triangle traversé donne
   un segment, les segments sont chaînés par leurs extrémités en
   polylignes, et le tout devient un <path> (traits fins) dans le groupe
   « model » du SVG — un plan « d'architecte » léger, dont la qualité
   dépend du maillage (un modèle sans murs intérieurs ne donne que son
   contour). Les objets ajoutés à la scène ne sont pas coupés (cercles de
   pied, comme dans le SVG image).

   Chargé après viewer-scene3d-export-svg.js et avant
   viewer-scene3d-tools.js (ordre imposé par index.html, readme.txt § 1).

   NOTE ENCODAGE : chaînes affichées en ASCII pur (\uXXXX), commentaires
   accentués, BOM UTF-8, fins de ligne CRLF (readme.txt § 14).
   ============================================================ */
(function (global) {
  'use strict';

  const NS = global.MyPnPlanViewerV2NS = global.MyPnPlanViewerV2NS || {};
  const state = NS.state;
  const X = NS.scene3dExport;

  const CUT_COLOR = '#334155';
  const CUT_WIDTH = 1.1;
  const KEY_SCALE = 200;        // tolérance de chaînage : 1/200 d'unité du modèle

  function viewer() {
    return global.ThreeViewer || null;
  }

  /* Hauteur de coupe réelle (configuration) et en unités du modèle (selon
     l'échelle ; sans échelle, la valeur vaut en unités), bornée à 90 % de
     la hauteur du modèle. */
  function cutHeightReal() {
    const cfg = state.currentConfig && state.currentConfig.planExport;
    return cfg && cfg.cutHeight ? cfg.cutHeight : 1.2;
  }

  function cutHeightUnits() {
    const s = NS.scaleFactor();
    let h = s ? cutHeightReal() / s : cutHeightReal();
    const b = viewer().getModelBounds();
    if (b) h = Math.min(h, b.size[1] * 0.9);
    return h;
  }

  /* Segments [[x1, z1], [x2, z2]] de l'intersection des maillages du
     modèle avec le plan y = yCut (repère monde). */
  function cutSegments(yCut) {
    const v = viewer();
    const obj = v.getModelObject();
    if (!obj) return [];
    const T = v.getContext().THREE;
    const segs = [];
    const a = new T.Vector3(), b = new T.Vector3(), c = new T.Vector3();
    obj.updateWorldMatrix(true, true);
    obj.traverse((m) => {
      if (!m.isMesh || !m.geometry || !m.geometry.attributes.position) return;
      const pos = m.geometry.attributes.position;
      const idx = m.geometry.index;
      const n = idx ? idx.count : pos.count;
      const get = (i, out) => out.fromBufferAttribute(pos, idx ? idx.getX(i) : i).applyMatrix4(m.matrixWorld);
      const pts = [];
      const edge = (p, q) => {
        const dp = p.y - yCut, dq = q.y - yCut;
        if ((dp > 0) === (dq > 0) || dp === dq) return;
        const t = dp / (dp - dq);
        pts.push([p.x + (q.x - p.x) * t, p.z + (q.z - p.z) * t]);
      };
      for (let i = 0; i + 2 < n; i += 3) {
        get(i, a); get(i + 1, b); get(i + 2, c);
        const lo = Math.min(a.y, b.y, c.y), hi = Math.max(a.y, b.y, c.y);
        if (lo > yCut || hi < yCut) continue;
        pts.length = 0;
        edge(a, b); edge(b, c); edge(c, a);
        if (pts.length >= 2 && (Math.abs(pts[0][0] - pts[1][0]) > 1e-6 || Math.abs(pts[0][1] - pts[1][1]) > 1e-6)) {
          segs.push([pts[0], pts[1]]);
        }
      }
    });
    return segs;
  }

  const key = (p) => Math.round(p[0] * KEY_SCALE) + ',' + Math.round(p[1] * KEY_SCALE);

  /* Retire les segments en double (arêtes partagées par deux faces). */
  function dedupe(segs) {
    const seen = new Set();
    const out = [];
    for (const s of segs) {
      const k0 = key(s[0]), k1 = key(s[1]);
      if (k0 === k1) continue;
      const k = k0 < k1 ? k0 + '|' + k1 : k1 + '|' + k0;
      if (seen.has(k)) continue;
      seen.add(k);
      out.push(s);
    }
    return out;
  }

  /* Chaîne les segments en polylignes par leurs extrémités (table des
     extrémités arrondies). */
  function chain(segs) {
    const map = new Map();
    segs.forEach((s, i) => {
      for (const p of s) {
        const k = key(p);
        if (!map.has(k)) map.set(k, []);
        map.get(k).push(i);
      }
    });
    const used = new Uint8Array(segs.length);
    const lines = [];
    for (let i = 0; i < segs.length; i++) {
      if (used[i]) continue;
      used[i] = 1;
      const line = [segs[i][0], segs[i][1]];
      for (const dir of [1, -1]) {
        let guard = 0;
        while (guard++ < segs.length) {
          const end = dir === 1 ? line[line.length - 1] : line[0];
          const ke = key(end);
          let nextPt = null;
          for (const j of map.get(ke) || []) {
            if (used[j]) continue;
            const s = segs[j];
            if (key(s[0]) === ke) nextPt = s[1];
            else if (key(s[1]) === ke) nextPt = s[0];
            else continue;
            used[j] = 1;
            break;
          }
          if (!nextPt) break;
          if (dir === 1) line.push(nextPt); else line.unshift(nextPt);
        }
      }
      lines.push(line);
    }
    return lines;
  }

  /* Polylignes de la coupe à la hauteur de la configuration (unités du
     modèle). */
  function cutLines() {
    const r = NS.scene3dRender;
    const y = r.groundY() + cutHeightUnits() + 1e-4;
    return chain(dedupe(cutSegments(y)));
  }

  /* Couche « model » du SVG : <path> de la coupe (viewer-scene3d-export-svg.js,
     paramètre modelLayer de renderSvg). */
  function cutLayer(F) {
    const f = (n) => String(Math.round(n * 100) / 100);
    const lines = cutLines();
    let d = '';
    let points = 0;
    for (const line of lines) {
      line.forEach((p, i) => {
        const q = F.px(p[0], p[1]);
        d += (i ? 'L' : 'M') + f(q[0]) + ' ' + f(q[1]);
        points++;
      });
      if (line.length > 2 && key(line[0]) === key(line[line.length - 1])) d += 'Z';
    }
    return '<g id="model" class="cut" data-cut-height="' + f(cutHeightUnits()) + '" data-cut-lines="' + lines.length + '" data-cut-points="' + points +
      '" fill="none" stroke="' + CUT_COLOR + '" stroke-width="' + CUT_WIDTH + '" stroke-linejoin="round" stroke-linecap="round"><path d="' + d + '"/></g>';
  }

  function cutLabel() {
    const s = NS.scaleFactor();
    return 'coupe \u00e0 ' + NS.formatNumber(cutHeightReal()) + ' ' + (s ? (NS.scene3d.scene ? NS.scene3d.scene.unit : 'm') : 'u') + ' du sol';
  }

  /* Export SVG avec coupe vectorielle : fichier plan-<lieu>-<date>.coupe.svg. */
  function exportSvgCut() {
    return X.exportSvg({ modelLayer: cutLayer, extra: cutLabel(), suffix: 'coupe' });
  }

  /* ------------------- Exposition sur l'espace de noms ------------------- */
  Object.assign(X, { exportSvgCut, cutLayer, cutLines, cutSegments, cutHeightUnits, cutHeightReal });
})(globalThis);
