﻿/* ============================================================
   MyPnPlanViewerV2 — module « scene3d-helper »
   ============================================================
   Repère d'orientation du cadre 3D : un cadran SVG (#threeHelper) posé en
   bas à gauche du canvas Three.js, redessiné à chaque mouvement de la
   caméra (ThreeViewer.onCameraChange) :
     - trièdre X (rouge) / Y (vert, vertical) / Z (bleu) du fichier .obj,
       demi-axes négatifs en creux, l'arrière estompé ;
     - rose des vents N / E / S / O au sol, calée sur le nord du plan
       (clé north de current_plan_scene3d_json, NS.northAngle) — absente
       si le nord est inconnu ;
     - cliquable : N / E / S / O placent la caméra face à ce côté (vue de
       face légèrement plongeante), X / Z de même, Y = vue de dessus (nord
       en haut). La cible et la distance sont conservées ; transition
       animée (ANIM_MS), immédiate si prefers-reduced-motion.
   Espace écran : jamais dans les exports ni les impressions.

   Affiché / masqué par le bouton #helperBtn de la barre de zoom (visible
   sur une représentation 3D), état initial selon la clé de configuration
   orientationHelper ("shown" défaut, "hidden", "none" = ni repère ni
   bouton). L'état de la bascule vaut pour la page (pas de propriété).

   Chargé après viewer-scene3d-zones.js et avant viewer-scene3d-tools.js
   (ordre imposé par index.html, readme.txt § 1).

   NOTE ENCODAGE : chaînes affichées en ASCII pur (\uXXXX), commentaires
   accentués, BOM UTF-8, fins de ligne CRLF (readme.txt § 14).
   ============================================================ */
(function (global) {
  'use strict';

  const NS = global.MyPnPlanViewerV2NS = global.MyPnPlanViewerV2NS || {};
  const state = NS.state;
  const { threeHelper, helperBtn, helperSep } = NS.dom;

  const SVG_NS = 'http://www.w3.org/2000/svg';
  const C = 54;            // centre du cadran (viewBox 0 0 108 108)
  const R = 40;            // rayon utile
  const ANIM_MS = 400;     // durée des transitions de caméra
  const TOP_TILT = 0.5 * Math.PI / 180;   // vue de dessus : léger dévers (azimut défini)
  const FRONT_ELEVATION = 20 * Math.PI / 180;
  const AXES = [
    { v: [1, 0, 0], t: 'X', c: '#ef4444', snap: 'x', tip: 'Vue depuis +X' },
    { v: [0, 1, 0], t: 'Y', c: '#22c55e', snap: 'top', tip: 'Vue de dessus (nord en haut)' },
    { v: [0, 0, 1], t: 'Z', c: '#3b82f6', snap: 'z', tip: 'Vue depuis +Z' },
  ];

  const h = NS.scene3dHelper = {
    visible: null,     // bascule de la page (null : à initialiser selon la configuration)
    configRef: null,   // configuration pour laquelle visible a été initialisé
    anim: null,        // requestAnimationFrame de la transition en cours
  };

  function ctx() {
    const v = global.ThreeViewer;
    return v && typeof v.getContext === 'function' ? v.getContext() : null;
  }

  /* Le repère a lieu d'être : représentation 3D affichée, clé != none. */
  function available() {
    return Boolean(NS.sceneAvailable && NS.sceneAvailable() &&
      state.currentConfig && state.currentConfig.orientationHelper !== 'none');
  }

  function northAngle() {
    return NS.northAngle ? NS.northAngle() : null;
  }

  /* Vecteurs unitaires au sol du nord et de l'est pour un angle (degrés,
     sens horaire vu de dessus, 0 = -z). */
  function northVec(deg) {
    const t = deg * Math.PI / 180;
    return [Math.sin(t), 0, -Math.cos(t)];
  }
  function eastVec(deg) {
    const t = deg * Math.PI / 180;
    return [Math.cos(t), 0, Math.sin(t)];
  }

  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];

  /* Base de la caméra (colonnes de sa matrice monde) : droite, haut,
     direction de visée. */
  function basis() {
    const c = ctx();
    if (!c) return null;
    c.camera.updateMatrixWorld();
    const e = c.camera.matrixWorld.elements;
    return { right: [e[0], e[1], e[2]], up: [e[4], e[5], e[6]], forward: [-e[8], -e[9], -e[10]] };
  }

  function el(name, attrs, text) {
    const node = document.createElementNS(SVG_NS, name);
    for (const k in attrs) node.setAttribute(k, String(attrs[k]));
    if (text !== undefined) node.textContent = text;
    return node;
  }

  /* ---------------------- Dessin du cadran ---------------------- */

  function draw() {
    threeHelper.textContent = '';
    const b = basis();
    if (!b) return;
    const proj = (v, len) => ({ x: C + dot(v, b.right) * len, y: C - dot(v, b.up) * len, d: dot(v, b.forward) });
    threeHelper.appendChild(el('circle', { cx: C, cy: C, r: R + 12, class: 'helper-bg' }));
    const items = [];
    const north = northAngle();
    if (north !== null) {
      const n = northVec(north), e = eastVec(north);
      // Rose des vents : cercle au sol projeté (ellipse), tracé en polyligne.
      let d = '';
      for (let i = 0; i <= 48; i++) {
        const a = i / 48 * Math.PI * 2;
        const v = [n[0] * Math.cos(a) + e[0] * Math.sin(a), 0, n[2] * Math.cos(a) + e[2] * Math.sin(a)];
        const p = proj(v, R * 0.9);
        d += (i ? 'L' : 'M') + p.x.toFixed(1) + ' ' + p.y.toFixed(1);
      }
      threeHelper.appendChild(el('path', { d: d + 'Z', class: 'helper-ring' }));
      items.push(
        { v: n, t: 'N', snap: 'n', ring: true, north: true, tip: 'Vue vers le nord' },
        { v: e, t: 'E', snap: 'e', ring: true, tip: 'Vue vers l\u2019est' },
        { v: n.map((x) => -x), t: 'S', snap: 's', ring: true, tip: 'Vue vers le sud' },
        { v: e.map((x) => -x), t: 'O', snap: 'w', ring: true, tip: 'Vue vers l\u2019ouest' });
    }
    for (const a of AXES) {
      items.push({ v: a.v, t: a.t, c: a.c, snap: a.snap, tip: a.tip, axis: true });
      items.push({ v: a.v.map((x) => -x), c: a.c, neg: true });
    }
    for (const it of items) it.p = proj(it.v, it.ring ? R * 0.9 : (it.neg ? R * 0.62 : R * 0.74));
    // L'arrière (direction de visée) d'abord, estompé.
    items.sort((a, b) => b.p.d - a.p.d);
    for (const it of items) {
      const cls = ['helper-item'];
      if (it.p.d > 0.2) cls.push('back');
      if (it.snap) cls.push('hit');
      if (it.north) cls.push('north-item');
      const g = el('g', { class: cls.join(' ') });
      if (it.snap) g.dataset.snap = it.snap;
      const x = it.p.x.toFixed(1), y = it.p.y.toFixed(1);
      if (it.axis) {
        g.appendChild(el('line', { x1: C, y1: C, x2: x, y2: y, stroke: it.c, 'stroke-width': 2.2 }));
        g.appendChild(el('circle', { cx: x, cy: y, r: 8.5, fill: it.c }));
        g.appendChild(el('text', { x, y, class: 'helper-axis-label' }, it.t));
      } else if (it.neg) {
        g.appendChild(el('circle', { cx: x, cy: y, r: 4.5, class: 'helper-neg', stroke: it.c }));
      } else {
        g.appendChild(el('circle', { cx: x, cy: y, r: 8, class: 'helper-dir' + (it.north ? ' north' : '') }));
        g.appendChild(el('text', { x, y, class: 'helper-dir-label' }, it.t));
      }
      if (it.snap) {
        g.appendChild(el('title', {}, it.tip));
        g.addEventListener('click', () => snapTo(it.snap));
      }
      threeHelper.appendChild(g);
    }
  }

  /* ---------------------- Vues prédéfinies ---------------------- */

  /* Place la caméra dans la direction donnée (depuis la cible, à la
     distance courante) : 'top' (dessus, nord en haut), 'n' / 'e' / 's' /
     'w' (face à ce côté), 'x' / 'z' (depuis l'axe positif). */
  function snapTo(name) {
    const north = northAngle() || 0;
    const v = global.ThreeViewer;
    if (v && v.isPlanView && v.isPlanView()) {
      // En vue en plan : Y ne fait rien, les autres directions reviennent
      // d'abord à la 3D (sans transition), puis s'orientent.
      if (name === 'top') return;
      v.setPlanView(false, { animate: false });
    }
    let dir;
    if (name === 'top') {
      // Léger dévers vers le sud pour que l'azimut reste défini : le haut
      // de l'écran est alors le nord.
      const az = -north * Math.PI / 180;
      dir = [Math.sin(TOP_TILT) * Math.sin(az), Math.cos(TOP_TILT), Math.sin(TOP_TILT) * Math.cos(az)];
    } else {
      let horiz;
      if (name === 'x') horiz = [1, 0, 0];
      else if (name === 'z') horiz = [0, 0, 1];
      else {
        const n = northVec(north), e = eastVec(north);
        // Regarder vers le nord = caméra au sud, etc.
        horiz = name === 'n' ? n.map((v) => -v) : name === 's' ? n : name === 'e' ? e.map((v) => -v) : e;
      }
      dir = [horiz[0] * Math.cos(FRONT_ELEVATION), Math.sin(FRONT_ELEVATION), horiz[2] * Math.cos(FRONT_ELEVATION)];
    }
    lookFrom(dir);
  }

  function lookFrom(dir) {
    const c = ctx();
    if (!c) return;
    const T = c.THREE;
    const target = c.controls.target.clone();
    const dist = c.camera.position.distanceTo(target);
    const pos = target.clone().add(new T.Vector3(dir[0], dir[1], dir[2]).normalize().multiplyScalar(dist));
    animateCamera(pos, target);
  }

  function reducedMotion() {
    return Boolean(global.matchMedia && global.matchMedia('(prefers-reduced-motion: reduce)').matches);
  }

  /* Transition de la caméra vers (pos, target) — Vector3 — en ms
     millisecondes (ANIM_MS par défaut ; 0, ou NS.helperAnimationMs = 0
     pour les bancs, ou prefers-reduced-motion : immédiate). controls.update
     émet « change » à chaque pas : rendu, panneau, repère. */
  function animateCamera(pos, target, ms, done) {
    const c = ctx();
    if (!c) return;
    if (h.anim) { cancelAnimationFrame(h.anim); h.anim = null; }
    const p0 = c.camera.position.clone(), t0 = c.controls.target.clone();
    const v = global.ThreeViewer;
    const dur = reducedMotion() || NS.helperAnimationMs === 0 || (v && v.getAnimationMs && v.getAnimationMs() === 0) ? 0 : (ms === undefined ? ANIM_MS : ms);
    const start = performance.now();
    const step = (now) => {
      const k = dur ? Math.min(1, (now - start) / dur) : 1;
      const e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
      c.camera.position.lerpVectors(p0, pos, e);
      c.controls.target.lerpVectors(t0, target, e);
      c.controls.update();
      if (k < 1) {
        h.anim = requestAnimationFrame(step);
      } else {
        h.anim = null;
        c.render();
        if (done) done();
      }
    };
    step(start);
  }

  /* ---------------------- Bouton et visibilité ---------------------- */

  function initialVisible() {
    return !(state.currentConfig && state.currentConfig.orientationHelper === 'hidden');
  }

  /* Visibilité du bouton (représentation 3D, clé != none) et du cadran.
     Appelée à chaque changement de représentation (viewer-plan.js) ; la
     bascule est réinitialisée à chaque nouvelle configuration. */
  function refreshButton() {
    const cfg = state.currentConfig;
    if (h.configRef !== cfg) { h.configRef = cfg; h.visible = null; }
    if (h.visible === null) h.visible = initialVisible();
    const show = available();
    helperBtn.hidden = !show;
    helperSep.hidden = !show;
    helperBtn.setAttribute('aria-pressed', String(show && h.visible));
    helperBtn.title = h.visible ? 'Masquer le rep\u00e8re d\u2019orientation' : 'Afficher le rep\u00e8re d\u2019orientation';
    refresh();
  }

  /* Redessine (ou masque) le cadran : à chaque mouvement de caméra,
     reconstruction de la scène, chargement du modèle. */
  function refresh() {
    const v = global.ThreeViewer;
    const show = available() && h.visible === true && Boolean(v && v.isActive && v.isActive());
    // Un element SVG n a pas de propriete IDL hidden : attribut explicite.
    threeHelper.toggleAttribute('hidden', !show);
    if (show) draw();
  }

  function setVisible(on) {
    h.visible = Boolean(on);
    refreshButton();
  }

  helperBtn.addEventListener('click', () => {
    setVisible(!h.visible);
    helperBtn.blur();
  });

  // three-viewer.bundle.js n'est charge qu'a la premiere representation 3D
  // affichee (viewer-loader.js).
  function watch() {
    const v = global.ThreeViewer;
    if (!v || typeof v.onCameraChange !== 'function') return false;
    v.onCameraChange(refresh);
    if (typeof v.onModelLoaded === 'function') v.onModelLoaded(refresh);
    if (typeof v.onPlanViewChange === 'function') v.onPlanViewChange(refresh);
    return true;
  }
  NS.onThreeViewerReady(watch);
  window.addEventListener('resize', refresh);

  /* ------------------- Exposition sur l'espace de noms ------------------- */
  Object.assign(h, { refresh, refreshButton, setVisible, isVisible: () => h.visible === true,
    snapTo, lookFrom, animateCamera, northVec, eastVec });
  NS.refreshHelperButton = refreshButton;
})(globalThis);
