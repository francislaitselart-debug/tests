// =============================================================================
// OnChangeScene3DPlanViewer — enregistre en base la scene 3D editee par
// l'operateur dans le composant MyPnPlanViewer (representation 3D : vue par
// defaut, emprise au sol, fond de plan, etalon et mesures, objets ajoutes,
// zones).
//
//   current_plan_scene3d_json est une propriete a DOUBLE SENS :
//     - l'application y ecrit la scene a afficher (voir
//       OnChangeSelectedNodePathPlanViewer.cs) ;
//     - l'objet la reecrit EN ENTIER a chaque modification de l'operateur
//       (vue par defaut, trace, poignee, panneau, suppression), quand le mode
//       edition est actif et le cadenas ouvert.
//
//   -> MyPnPvSaveScene3D(json, operateur) : la scene du plan est REMPLACEE par
//      celle recue ; la reponse donne { ok, entities, measures, objects,
//      zones, serial }.
//
// GARDE ANTI-ECHO — indispensable : ce script est declenche par tout changement
// de la propriete, y compris par l'ecriture faite par le script de selection.
// La valeur recue est comparee a celle que la base sert pour ce plan : si elles
// sont identiques, il n'y a rien a enregistrer.
//
// A jouer sur le changement de MyPnPlanViewer.current_plan_scene3d_json.
// La propriete n'est PAS remise a "" : elle porte l'etat courant du plan
// affiche, que l'objet relit.
// =============================================================================
const string C_TRACE = "[MyPnPlanViewer] ";

string lScene = (string)MyPnPlanViewer.current_plan_scene3d_json;
if (string.IsNullOrWhiteSpace(lScene) || lScene[0] != '{')
{
	return;
}

int lNodeId = MyPnPvEntier(lScene, "node_id");
int lPlanIndex = MyPnPvEntier(lScene, "planIndex");
if (lPlanIndex < 1)
{
	return;                        // aucun plan affiche : rien a enregistrer
}

// --- garde anti-echo -------------------------------------------------------
string lEnBase = MyPnPvGetPlanScene3D(lNodeId, lPlanIndex);
if (string.Equals(lEnBase, lScene, StringComparison.Ordinal))
{
	PnTrace(C_TRACE + "scene 3D inchangee (noeud " + lNodeId + ", plan " + lPlanIndex + ") : rien a enregistrer.",
		FuncScript.TRACE_LEVEL.DEBUG);
	return;
}

// --- enregistrement --------------------------------------------------------
string lOperateur = MyPnPvUtilisateur();
string lReponse = MyPnPvSaveScene3D(lScene, lOperateur);

if (string.IsNullOrEmpty(lReponse) || lReponse.IndexOf("\"ok\":true", StringComparison.Ordinal) < 0)
{
	PnTrace(C_TRACE + "enregistrement de la scene 3D REFUSE (noeud " + lNodeId + ", plan " + lPlanIndex + ") : "
		+ lReponse + " / " + MyPnPvLastError(), FuncScript.TRACE_LEVEL.ERROR);

	// La base fait foi : on renvoie a l'objet ce qu'elle contient reellement,
	// ce qui annule visuellement la modification refusee.
	string lRetour = MyPnPvGetPlanScene3D(lNodeId, lPlanIndex);
	if (!string.IsNullOrEmpty(lRetour) && lRetour[0] == '{')
	{
		MyPnPlanViewer.current_plan_scene3d_json = lRetour;
	}
	return;
}

PnTrace(C_TRACE + "scene 3D enregistree (noeud " + lNodeId + ", plan " + lPlanIndex + ") : " + lReponse,
	FuncScript.TRACE_LEVEL.INFO);

// Les mesures, objets et zones crees par l'operateur ont recu un identifiant
// provisoire ; la base peut en avoir attribue un autre, et elle arrondit les
// nombres. On renvoie la scene telle qu'elle est enregistree, pour que les
// deux cotes portent les memes ids. Si elle est deja identique, l'objet ignore
// la valeur (sa propre garde anti-echo) et le tour suivant de ce script
// s'arrete sur la garde ci-dessus.
string lConfirme = MyPnPvGetPlanScene3D(lNodeId, lPlanIndex);
if (!string.IsNullOrEmpty(lConfirme) && lConfirme[0] == '{'
	&& !string.Equals(lConfirme, lScene, StringComparison.Ordinal))
{
	MyPnPlanViewer.current_plan_scene3d_json = lConfirme;
}

// ----------------------------------------------------------------------------- utilitaires

// Utilisateur Panorama courant ("" si la session n'en expose pas : l'extension
// journalise alors "panorama").
string MyPnPvUtilisateur()
{
	try
	{
		string lNom = PnUserManager.UserName;
		return string.IsNullOrWhiteSpace(lNom) ? "" : lNom.Trim();
	}
	catch
	{
		return "";
	}
}

// Valeur entiere d'une clef JSON de premier niveau (0 si absente ou illisible).
int MyPnPvEntier(string pJson, string pClef)
{
	if (string.IsNullOrEmpty(pJson)) return 0;
	int lPos = pJson.IndexOf("\"" + pClef + "\":", StringComparison.Ordinal);
	if (lPos < 0) return 0;
	lPos += pClef.Length + 3;
	while (lPos < pJson.Length && pJson[lPos] == ' ') lPos++;
	int lDebut = lPos;
	while (lPos < pJson.Length && (char.IsDigit(pJson[lPos]) || pJson[lPos] == '-')) lPos++;
	if (lPos == lDebut) return 0;
	int lValeur;
	return int.TryParse(pJson.Substring(lDebut, lPos - lDebut), out lValeur) ? lValeur : 0;
}
