// =============================================================================
// OnTimerEventsPlanViewer — rafraichit les alarmes en cours du composant
// MyPnPlanViewer.
//
//   MyPnPvGetPlanEvents(prioriteMin) -> configuration_events_json
//     { "events": [ { id, element_id, node_id, priority, color, count }, ... ] }
//
// L'objet se met a jour A CHAUD : rien n'est reconstruit, la selection, le
// zoom, le drawer et les noeuds deplies sont conserves. Sont rafraichis les
// pastilles de l'arbre (remontee par parent_id), les badges du bandeau, l'etat
// d'alarme des capteurs du plan affiche et celui des formes qui leur sont liees.
//
// Les alarmes portant sur un capteur POSE sur un plan sont detaillees une par
// une (element_id : c'est ce qui met le capteur en alarme) ; les autres sont
// agregees par (node_id, priorite) avec leur cumul dans count — ce que l'objet
// sait additionner. Sur le jeu de test (13 500 alarmes en cours), la reponse
// fait ~ 570 Ko et met ~ 1,1 s a se construire : la periode du timer ne doit
// pas descendre sous 2 s, et C_PRIORITE_MIN allege nettement (~ 190 Ko a
// partir de la priorite 30).
//
// La valeur n'est REECRITE QUE SI ELLE A CHANGE : sans cette comparaison, le
// composant retracerait pastilles et badges a chaque periode pour rien.
//
// A jouer sur un objet periodique de 2 a 5 s.
// =============================================================================
const string C_TRACE = "[MyPnPlanViewer] ";

// Priorite minimale des alarmes remontees (0 = toutes) — meme valeur que dans
// OnOpenLoadPlanViewer.cs.
const int C_PRIORITE_MIN = 0;

string lEvents = MyPnPvGetPlanEvents(C_PRIORITE_MIN);
if (string.IsNullOrEmpty(lEvents) || lEvents[0] != '{')
{
	// Base momentanement injoignable : on CONSERVE l'etat precedent (ecrire ""
	// effacerait toutes les pastilles et ferait croire a un site au repos).
	PnTrace(C_TRACE + "alarmes indisponibles : " + MyPnPvLastError(), FuncScript.TRACE_LEVEL.WARNING);
	return;
}

string lPrecedent = (string)MyPnPlanViewer.configuration_events_json;
if (string.Equals(lPrecedent, lEvents, StringComparison.Ordinal))
{
	return;                        // aucune evolution : rien a reecrire
}

MyPnPlanViewer.configuration_events_json = lEvents;
PnTrace(C_TRACE + "configuration_events_json rafraichi : " + lEvents.Length + " car.",
	FuncScript.TRACE_LEVEL.DEBUG);
