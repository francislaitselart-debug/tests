// =============================================================================
// OnChangeDetailRequestPlanViewer — traite les demandes de detail emises par le
// composant MyPnPlanViewer.
//
//   eventsDetailRequest_json est ecrit par l'objet a chaque clic :
//     sur un CAPTEUR du plan (cadenas ferme ou mode edition inactif) :
//       { "source":"element", "element_id":1001, "node_id":11,
//         "planIndex":1, "label":"...", "serial":3 }
//     sur un BADGE d'evenements du bandeau :
//       { "source":"badge", "node_id":11, "path":"...",
//         "priority":1, "count":3, "serial":4 }
//
//   -> MyPnPvHandleDetailRequest(json) aiguille sur la bonne procedure et
//      renvoie { "source", "serial", "detail" } :
//        source "element" : detail = elementDetail_json (le meme objet que le
//                           panneau de MyPnListeElements : evenements,
//                           historique, elements lies, commentaires,
//                           commandes, proprietes) ;
//        source "badge"   : detail = tableau des alarmes en cours du sous-arbre
//                           du noeud (200 au plus, priorite decroissante).
//
// C'EST A L'APPLICATION D'OUVRIR LE DETAIL : l'objet ne fait que transmettre la
// demande. Les deux points d'accroche ci-dessous (C_VUE_DETAIL_ELEMENT et
// C_VUE_LISTE_EVENEMENTS) sont a adapter aux vues du projet ; par defaut le
// script se contente de tracer la reponse.
//
// A jouer sur le changement de MyPnPlanViewer.eventsDetailRequest_json.
// La propriete n'est PAS remise a "" : elle porte un compteur serial qui
// distingue deux demandes identiques successives.
// =============================================================================
const string C_TRACE = "[MyPnPlanViewer] ";

// Vues ouvertes par l'application (vide = simple trace).
const string C_VUE_DETAIL_ELEMENT = "";      // ex. "Fonctions\\Elements\\Detail"
const string C_VUE_LISTE_EVENEMENTS = "";    // ex. "Fonctions\\Evenements\\Liste"

string lDemande = (string)MyPnPlanViewer.eventsDetailRequest_json;
if (string.IsNullOrWhiteSpace(lDemande) || lDemande[0] != '{')
{
	return;
}

// Zone d'une representation 3D (source "zone", readme sec. 10 bis) : l'objet
// transmet l'id de la zone, son libelle et les capteurs lies (cle elements).
// L'extension ne porte pas de detail dedie : point d'accroche applicatif
// (ouvrir la liste des capteurs lies, le synoptique de la zone...).
if (MyPnPvTexte(lDemande, "source") == "zone")
{
	PnTrace(C_TRACE + "zone 3D " + MyPnPvTexte(lDemande, "zone_id") + " (" + MyPnPvTexte(lDemande, "label")
		+ ") du noeud " + MyPnPvTexte(lDemande, "node_id") + " : " + lDemande, FuncScript.TRACE_LEVEL.INFO);
	return;
}

string lReponse = MyPnPvHandleDetailRequest(lDemande);
if (string.IsNullOrEmpty(lReponse))
{
	PnTrace(C_TRACE + "demande de detail non traitee : " + lDemande + " / " + MyPnPvLastError(),
		FuncScript.TRACE_LEVEL.WARNING);
	return;
}

string lSource = MyPnPvTexte(lDemande, "source");

if (lSource == "element")
{
	string lElementId = MyPnPvTexte(lDemande, "element_id");
	PnTrace(C_TRACE + "detail du capteur " + lElementId + " : " + lReponse.Length + " car.",
		FuncScript.TRACE_LEVEL.INFO);

	// --- point d'accroche applicatif -------------------------------------
	// Alimenter ici le panneau de detail du projet. Exemple avec le composant
	// MyPnListeElements present sur une autre vue :
	//     MyPnListeElements.elementDetail_json = MyPnPvExtraitDetail(lReponse);
	// ou ouverture d'une vue dediee :
	//     if (C_VUE_DETAIL_ELEMENT != "") PnOpenView(C_VUE_DETAIL_ELEMENT);
}
else if (lSource == "badge")
{
	string lNodeId = MyPnPvTexte(lDemande, "node_id");
	string lPriorite = MyPnPvTexte(lDemande, "priority");
	PnTrace(C_TRACE + "alarmes du noeud " + lNodeId + " (priorite " + lPriorite + ") : "
		+ lReponse.Length + " car.", FuncScript.TRACE_LEVEL.INFO);

	// --- point d'accroche applicatif -------------------------------------
	// Ouvrir la liste des evenements filtree sur ce noeud et cette priorite :
	//     if (C_VUE_LISTE_EVENEMENTS != "") PnOpenView(C_VUE_LISTE_EVENEMENTS);
}

// ----------------------------------------------------------------------------- utilitaires

// Contenu de la clef "detail" de la reponse (objet ou tableau JSON), a recopier
// tel quel dans la propriete du composant qui affiche le detail.
string MyPnPvExtraitDetail(string pReponse)
{
	if (string.IsNullOrEmpty(pReponse)) return "";
	int lPos = pReponse.IndexOf("\"detail\":", StringComparison.Ordinal);
	if (lPos < 0) return "";
	lPos += 9;
	while (lPos < pReponse.Length && pReponse[lPos] == ' ') lPos++;
	if (lPos >= pReponse.Length) return "";
	// La clef "detail" est la DERNIERE de la reponse : le contenu va jusqu'a
	// l'accolade fermante de l'enveloppe.
	int lFin = pReponse.LastIndexOf('}');
	return lFin > lPos ? pReponse.Substring(lPos, lFin - lPos).Trim() : "";
}

// Valeur brute d'une clef JSON de premier niveau (nombre ou chaine, sans les
// guillemets).
string MyPnPvTexte(string pJson, string pClef)
{
	if (string.IsNullOrEmpty(pJson)) return "";
	int lPos = pJson.IndexOf("\"" + pClef + "\":", StringComparison.Ordinal);
	if (lPos < 0) return "";
	lPos += pClef.Length + 3;
	while (lPos < pJson.Length && pJson[lPos] == ' ') lPos++;
	bool lChaine = lPos < pJson.Length && pJson[lPos] == '"';
	if (lChaine) lPos++;
	int lDebut = lPos;
	while (lPos < pJson.Length)
	{
		char lC = pJson[lPos];
		if (lChaine ? (lC == '"') : (lC == ',' || lC == '}' || lC == ']')) break;
		lPos++;
	}
	return pJson.Substring(lDebut, lPos - lDebut).Trim();
}
