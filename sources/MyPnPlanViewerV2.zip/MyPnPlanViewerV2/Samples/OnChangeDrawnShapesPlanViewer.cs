// =============================================================================
// OnChangeDrawnShapesPlanViewer — enregistre en base les formes libres
// dessinees par l'operateur dans le composant MyPnPlanViewer.
//
//   current_plan_drawnShapes_json est une propriete a DOUBLE SENS :
//     - l'application y ecrit les formes a afficher (voir
//       OnChangeSelectedNodePathPlanViewer.cs) ;
//     - l'objet la reecrit avec TOUTES les formes du plan affiche a chaque
//       modification de l'operateur (ajout, deplacement, retouche, rotation,
//       apparence, nom, proprietes, suppression), quand le mode edition est
//       actif et le cadenas ouvert.
//
//   -> MyPnPvSaveShapes(json, operateur) : les formes du plan sont REMPLACEES
//      par celles recues ; la reponse donne { ok, created, updated, removed }.
//
// GARDE ANTI-ECHO — indispensable : ce script est declenche par tout changement
// de la propriete, y compris par l'ecriture faite par le script de selection.
// Sans garde, chaque selection de plan reecrirait en base ce qu'elle vient d'en
// lire (journal pollue, ModifieLe fausse). La valeur recue est donc comparee a
// celle que la base sert pour ce plan : si elles sont identiques, il n'y a rien
// a enregistrer. La comparaison coute une lecture (~ 40 ms) ; une variable de
// travail memorisant la derniere valeur SERVIE ferait la meme chose sans aller
// SQL, au prix d'un objet Panorama supplementaire.
//
// A jouer sur le changement de MyPnPlanViewer.current_plan_drawnShapes_json.
// La propriete n'est PAS remise a "" : elle porte l'etat courant du plan
// affiche, que l'objet relit.
// =============================================================================
const string C_TRACE = "[MyPnPlanViewer] ";

string lFormes = (string)MyPnPlanViewer.current_plan_drawnShapes_json;
if (string.IsNullOrWhiteSpace(lFormes) || lFormes[0] != '{')
{
	return;
}

int lNodeId = MyPnPvEntier(lFormes, "node_id");
int lPlanIndex = MyPnPvEntier(lFormes, "planIndex");
if (lPlanIndex < 1)
{
	return;                        // aucun plan affiche : rien a enregistrer
}

// --- garde anti-echo -------------------------------------------------------
string lEnBase = MyPnPvGetPlanShapes(lNodeId, lPlanIndex);
if (string.Equals(lEnBase, lFormes, StringComparison.Ordinal))
{
	PnTrace(C_TRACE + "formes inchangees (noeud " + lNodeId + ", plan " + lPlanIndex + ") : rien a enregistrer.",
		FuncScript.TRACE_LEVEL.DEBUG);
	return;
}

// --- enregistrement --------------------------------------------------------
string lOperateur = MyPnPvUtilisateur();
string lReponse = MyPnPvSaveShapes(lFormes, lOperateur);

if (string.IsNullOrEmpty(lReponse) || lReponse.IndexOf("\"ok\":true", StringComparison.Ordinal) < 0)
{
	PnTrace(C_TRACE + "enregistrement des formes REFUSE (noeud " + lNodeId + ", plan " + lPlanIndex + ") : "
		+ lReponse + " / " + MyPnPvLastError(), FuncScript.TRACE_LEVEL.ERROR);

	// La base fait foi : on renvoie a l'objet ce qu'elle contient reellement,
	// ce qui annule visuellement la modification refusee.
	string lRetour = MyPnPvGetPlanShapes(lNodeId, lPlanIndex);
	if (!string.IsNullOrEmpty(lRetour) && lRetour[0] == '{')
	{
		MyPnPlanViewer.current_plan_drawnShapes_json = lRetour;
	}
	return;
}

PnTrace(C_TRACE + "formes enregistrees (noeud " + lNodeId + ", plan " + lPlanIndex + ") : " + lReponse,
	FuncScript.TRACE_LEVEL.INFO);

// Les formes creees par l'operateur ont recu un identifiant provisoire (plus
// grand id du plan + 1) ; la base peut en avoir attribue un autre. On renvoie
// la liste telle qu'elle est enregistree, pour que les deux cotes portent les
// memes ids. Si elle est deja identique, l'objet ignore la valeur (sa propre
// garde anti-echo) et le tour suivant de ce script s'arrete sur la garde
// ci-dessus.
string lConfirme = MyPnPvGetPlanShapes(lNodeId, lPlanIndex);
if (!string.IsNullOrEmpty(lConfirme) && lConfirme[0] == '{'
	&& !string.Equals(lConfirme, lFormes, StringComparison.Ordinal))
{
	MyPnPlanViewer.current_plan_drawnShapes_json = lConfirme;
}

// ----------------------------------------------------------------------------- utilitaires

// Utilisateur Panorama courant ("" si la session n'en expose pas : l'extension
// journalise alors "panorama").
string MyPnPvUtilisateur()
{
	try
	{
		string lNom = PnUserManager.UserName;
		return string.IsNullOrWhiteSpace(lNom) ? "" : lNom.Trim();
	}
	catch
	{
		return "";
	}
}

// Valeur entiere d'une clef JSON de premier niveau (0 si absente ou illisible).
int MyPnPvEntier(string pJson, string pClef)
{
	if (string.IsNullOrEmpty(pJson)) return 0;
	int lPos = pJson.IndexOf("\"" + pClef + "\":", StringComparison.Ordinal);
	if (lPos < 0) return 0;
	lPos += pClef.Length + 3;
	while (lPos < pJson.Length && pJson[lPos] == ' ') lPos++;
	int lDebut = lPos;
	while (lPos < pJson.Length && (char.IsDigit(pJson[lPos]) || pJson[lPos] == '-')) lPos++;
	if (lPos == lDebut) return 0;
	int lValeur;
	return int.TryParse(pJson.Substring(lDebut, lPos - lDebut), out lValeur) ? lValeur : 0;
}
