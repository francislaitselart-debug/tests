// =============================================================================
// OnChangeSelectedNodePathPlanViewer — repond a la selection de l'operateur
// dans le composant MyPnPlanViewer.
//
//   selectedNodePath  { "id": 11, "parent_id": 1, "path": "...",
//                       "labels": [...], "planIndex": 1,
//                       "filename": "Images/planA.jpg", "serial": 4 }
//                     ecrit par l'objet a chaque selection d'un noeud, a chaque
//                     choix d'une representation dans le SpeedDial et a chaque
//                     reconstruction (id 0 / planIndex 0 : desselection).
//
//   -> MyPnPvGetPlanElementsFor(selectedNodePath) -> current_plan_element_json
//   -> MyPnPvGetPlanShapesFor(selectedNodePath)   -> current_plan_drawnShapes_json
//   -> MyPnPvGetPlanScene3DFor(selectedNodePath)  -> current_plan_scene3d_json
//                                                    (scene 3D : vide pour un plan 2D)
//
// Les trois reponses portent node_id et planIndex : l'objet les memorise POUR CE
// PLAN et ne les affiche que s'il est celui a l'ecran. Une reponse tardive a
// une selection precedente n'ecrase donc pas le plan courant.
//
// planIndex 0 (desselection apres une reconstruction) : les deux proprietes
// sont remises a "" et rien n'est demande a la base.
//
// A jouer sur le changement de MyPnPlanViewer.selectedNodePath.
// La propriete n'est PAS remise a "" : elle porte un compteur serial qui
// distingue deja deux selections identiques successives.
// =============================================================================
const string C_TRACE = "[MyPnPlanViewer] ";

string lSelection = (string)MyPnPlanViewer.selectedNodePath;
if (string.IsNullOrWhiteSpace(lSelection))
{
	return;
}

int lPlanIndex = MyPnPvEntier(lSelection, "planIndex");
int lNodeId = MyPnPvEntier(lSelection, "id");

if (lPlanIndex < 1)
{
	// Aucune representation affichee (desselection, ou noeud sans plan).
	MyPnPlanViewer.current_plan_element_json = "";
	MyPnPlanViewer.current_plan_drawnShapes_json = "";
	MyPnPlanViewer.current_plan_scene3d_json = "";
	PnTrace(C_TRACE + "selection vide (noeud " + lNodeId + ") : capteurs, formes et scene 3D effaces.",
		FuncScript.TRACE_LEVEL.DEBUG);
	return;
}

// -----------------------------------------------------------------------------
// 1. Capteurs du plan choisi
// -----------------------------------------------------------------------------
string lElements = MyPnPvGetPlanElementsFor(lSelection);
if (string.IsNullOrEmpty(lElements) || lElements[0] != '{')
{
	PnTrace(C_TRACE + "capteurs du noeud " + lNodeId + " (plan " + lPlanIndex + ") illisibles : "
		+ MyPnPvLastError(), FuncScript.TRACE_LEVEL.ERROR);
	// Reponse vide EXPLICITE, rattachee au bon plan : sans elle, l'objet
	// garderait a l'ecran les capteurs du plan precedent.
	lElements = "{\"node_id\":" + lNodeId + ",\"planIndex\":" + lPlanIndex + ",\"elements\":[]}";
}
MyPnPlanViewer.current_plan_element_json = lElements;

// -----------------------------------------------------------------------------
// 2. Formes libres du plan choisi
// -----------------------------------------------------------------------------
string lFormes = MyPnPvGetPlanShapesFor(lSelection);
if (string.IsNullOrEmpty(lFormes) || lFormes[0] != '{')
{
	PnTrace(C_TRACE + "formes du noeud " + lNodeId + " (plan " + lPlanIndex + ") illisibles : "
		+ MyPnPvLastError(), FuncScript.TRACE_LEVEL.ERROR);
	lFormes = "{\"node_id\":" + lNodeId + ",\"planIndex\":" + lPlanIndex + ",\"shapes\":[]}";
}
MyPnPlanViewer.current_plan_drawnShapes_json = lFormes;

// -----------------------------------------------------------------------------
// 3. Scene 3D du plan choisi (vue par defaut, emprise, fond de plan, etalon,
//    mesures, objets, zones) : document vide pour un plan 2D.
// -----------------------------------------------------------------------------
string lScene = MyPnPvGetPlanScene3DFor(lSelection);
if (string.IsNullOrEmpty(lScene) || lScene[0] != '{')
{
	PnTrace(C_TRACE + "scene 3D du noeud " + lNodeId + " (plan " + lPlanIndex + ") illisible : "
		+ MyPnPvLastError(), FuncScript.TRACE_LEVEL.ERROR);
	lScene = "{\"node_id\":" + lNodeId + ",\"planIndex\":" + lPlanIndex + "}";
}
MyPnPlanViewer.current_plan_scene3d_json = lScene;

PnTrace(C_TRACE + "noeud " + lNodeId + " plan " + lPlanIndex + " : "
	+ lElements.Length + " car. de capteurs, " + lFormes.Length + " car. de formes, "
	+ lScene.Length + " car. de scene 3D.",
	FuncScript.TRACE_LEVEL.DEBUG);

// ----------------------------------------------------------------------------- utilitaires

// Valeur entiere d'une clef JSON de premier niveau (0 si absente ou illisible).
int MyPnPvEntier(string pJson, string pClef)
{
	if (string.IsNullOrEmpty(pJson)) return 0;
	int lPos = pJson.IndexOf("\"" + pClef + "\":", StringComparison.Ordinal);
	if (lPos < 0) return 0;
	lPos += pClef.Length + 3;
	while (lPos < pJson.Length && pJson[lPos] == ' ') lPos++;
	int lDebut = lPos;
	while (lPos < pJson.Length && (char.IsDigit(pJson[lPos]) || pJson[lPos] == '-')) lPos++;
	if (lPos == lDebut) return 0;
	int lValeur;
	return int.TryParse(pJson.Substring(lDebut, lPos - lDebut), out lValeur) ? lValeur : 0;
}
