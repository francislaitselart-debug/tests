﻿================================================================================
MyPnPlanViewerV2 - scripts d'exemple Panorama
================================================================================
Ce dossier contient de quoi faire vivre le visualiseur de plans sous Panorama
avec le jeu de test de la base PostgreSQL VisioDEF4 (schema pview : 601 representations,
57 600 capteurs positionnes, 42 formes libres, et les alarmes en cours du
schema elem), via l'extension MyPnPlanViewerExtension.

  OnOpenLoadPlanViewer.cs               OUVERTURE du synoptique : connexion,
                                        contexte et profondeur, puis
                                        configuration_plan_json (arbre avec id,
                                        plans, calques, echelles, options,
                                        icones d'edition, vues epinglees) et
                                        configuration_events_json (alarmes).
                                        Repli sur une configuration reduite
                                        ecrite en dur si SQL est injoignable.
  OnChangeSelectedNodePathPlanViewer.cs changement de selectedNodePath : envoi
                                        de current_plan_element_json (capteurs
                                        du plan choisi) et de
                                        current_plan_drawnShapes_json (formes
                                        libres du meme plan).
  OnChangeDrawnShapesPlanViewer.cs      changement de
                                        current_plan_drawnShapes_json : les
                                        formes dessinees par l'operateur sont
                                        enregistrees en base. GARDE ANTI-ECHO
                                        (section 4).
  OnChangeScene3DPlanViewer.cs          changement de
                                        current_plan_scene3d_json : la scene
                                        3D editee par l'operateur (vue par
                                        defaut, emprise, fond de plan, etalon,
                                        mesures, objets, zones) est
                                        enregistree en base. GARDE ANTI-ECHO.
  OnChangeDetailRequestPlanViewer.cs    changement de eventsDetailRequest_json :
                                        detail d'un capteur (source "element")
                                        ou alarmes du sous-arbre d'un noeud
                                        (source "badge"), avec les points
                                        d'accroche applicatifs a completer.
  OnTimerEventsPlanViewer.cs            TIMER 2 a 5 s : rafraichissement de
                                        configuration_events_json, reecrit
                                        seulement s'il a change.

1. PRE-REQUIS
--------------------------------------------------------------------------------
  - base PostgreSQL VisioDEF4 a jour : les schemas sched (lieux) et elem (elements,
    evenements) DEJA installes et peuples, puis
    database\MyPnPlanViewerV2\01-schema.sql, 02-procedures.sql et
    03-sample-data.sql ;
  - extension deployee : UserClasses\MyPnPlanViewerExtension\
    MyPnPlanViewerExtension.dll, classe MyPnPlanViewerExtension declaree en
    GLOBALSCRIPT (UserClasses\MyPnPnPlanViewerExtension.CLS) : ses 23 methodes
    MyPnPv* sont alors des fonctions globales de script ;
  - objet Web declare : UserClasses\MyPlanViewer.CLS (classe
    CU_WEB_PlanViewer, $front=MyPnPlanViewerV2, 6 proprietes STRING liees
    <>../#PARENT.*) et classe composant MyPnPlanViewer du module M_PLANVIEWER
    (uf\$_LIBRARY\M_PLANVIEWER\COMPONENT.CLS), qui porte les memes
    6 proprietes plus DbCnxString ;
  - verification hors Panorama :
    powershell -File ..\..\..\..\MyPnPlanViewerExtension\tests\dll-call.ps1
               -Method MyPnPvTestConnection
    doit repondre « OK <serveur> / VisioDEF4 / PostgreSQL … ».

  Les scripts s'adressent a l'INSTANCE nommee MyPnPlanViewer (module
  M_PLANVIEWER, vues VueCompacte et VueLarge). Si l'instance porte un autre
  nom, remplacer le prefixe dans les cinq fichiers.

2. OBJETS PANORAMA A CREER DANS LA VUE
--------------------------------------------------------------------------------
  Six objets CSharpScript (MODULE=FuncScript) places dans la vue, a cote de
  l'objet PlanViewer, avec les declencheurs suivants :

    OnOpenLoadPlanViewer            ouverture de la vue (triggertype = 1)
    OnChangeSelectedNodePath...     trigger = MyPnPlanViewer.selectedNodePath
    OnChangeDrawnShapes...          trigger = MyPnPlanViewer.
                                              current_plan_drawnShapes_json
    OnChangeScene3D...              trigger = MyPnPlanViewer.
                                              current_plan_scene3d_json
    OnChangeDetailRequest...        trigger = MyPnPlanViewer.
                                              eventsDetailRequest_json
    OnTimerEventsPlanViewer         objet periodique de 2 a 5 s

  Contrairement a MyPnListeElements et MyPnParametrage, AUCUNE formule de
  regroupement (STRCAT) n'est necessaire : chacune des quatre proprietes
  ecrites par l'objet a son propre script.

  La chaine de connexion se renseigne dans la propriete DbCnxString du
  composant (le script appelle alors MyPnPvSetConnectionString) ; laissee vide,
  c'est la propriete ConnectionString de l'extension qui s'applique.

3. CYCLE DE VIE ET ORDRE D'ALIMENTATION
--------------------------------------------------------------------------------
  ouverture    configuration_plan_json (l'objet se reconstruit et reecrit
               selectedNodePath avec id 0 / planIndex 0)
               -> configuration_events_json (pastilles et badges a chaud)
  selection    l'operateur clique un noeud ou une vue epinglee
               -> selectedNodePath (planIndex 1 : un noeud n'a qu'UNE
               representation, 2D ou 3D ; les suivantes sont ignorees)
               -> current_plan_element_json + current_plan_drawnShapes_json
               pour CE couple (node_id, planIndex)
  exploitation le timer reecrit les alarmes ; un clic sur un capteur ou un
               badge ecrit eventsDetailRequest_json ; en mode edition, chaque
               modification de forme ecrit current_plan_drawnShapes_json et
               declenche son enregistrement

  Les reponses portent TOUJOURS node_id et planIndex : l'objet les memorise par
  plan et n'affiche que celles du plan a l'ecran. Une reponse tardive a une
  selection precedente n'ecrase donc pas le plan courant, et revenir sur un
  plan deja recu le raffiche aussitot.

4. GARDE ANTI-ECHO SUR LES FORMES
--------------------------------------------------------------------------------
  current_plan_drawnShapes_json est la seule propriete a DOUBLE SENS : le
  script de selection l'ecrit (formes a afficher) et l'objet la reecrit (formes
  dessinees par l'operateur). Le script d'enregistrement est donc declenche par
  ses propres ecritures autant que par celles de l'operateur.

  OnChangeDrawnShapesPlanViewer.cs compare la valeur recue a celle que la base
  sert pour ce plan (MyPnPvGetPlanShapes) : identiques, il n'y a rien a
  enregistrer. Le cout est une lecture (~ 40 ms). Une variable de travail
  memorisant la derniere valeur SERVIE rendrait le meme service sans aller SQL,
  au prix d'un objet Panorama supplementaire.

  Cote objet, une garde symetrique existe deja : une valeur lue identique a la
  derniere valeur ecrite par l'objet est ignoree (sans quoi la forme en cours
  de deplacement serait deselectionnee a chaque mouvement).

  Apres un enregistrement reussi, le script renvoie la liste TELLE QU'ELLE EST
  EN BASE : les formes creees par l'operateur ont recu un identifiant provisoire
  (plus grand id du plan + 1) que la base peut avoir remplace.

5. VOLUME DES ALARMES
--------------------------------------------------------------------------------
  Sur le jeu de test, 13 514 alarmes etaient en cours au moment de la mesure
  (ce nombre evolue avec l'exploitation du schema elem).
  MyPnPvGetPlanEvents les rend en ~ 1,1 s et ~ 570 Ko :
    - les alarmes portant sur un capteur POSE sur un plan (3 100 environ) sont
      detaillees une par une, car c'est element_id qui met le capteur en alarme
      et allume le halo des formes liees ;
    - les autres sont agregees par (node_id, priorite), avec leur cumul dans
      count : l'objet additionne les entrees de meme noeud et de meme priorite,
      le resultat sur les pastilles et les badges est identique.
  La constante C_PRIORITE_MIN des scripts filtre les priorites basses
  (0 Aucune, 6 Information, 8 Essai, 10 Anomalie...). Mesures sur le jeu de
  test : toutes priorites 483 Ko en 1 024 ms, >= 20 305 Ko en 993 ms, >= 30
  147 Ko en 899 ms. Le filtre allege donc le VOLUME de la propriete, mais
  presque pas le TEMPS : le cout est le balayage des alarmes en cours et leur
  jointure sur elem.Element, pas la serialisation.

  CADENCE : elle ne vient pas de la formule mais de la propriete updaterate
  de l'objet StringFormulaWks OnTimerEventsPlanViewerTrigger (5 secondes dans
  l'application, comme OnTimerDeltaListeElementsTrigger). La formule
  STRCAT(STR_DATE(), STR_TIME()) ne sert qu'a produire une valeur qui change
  a chaque reevaluation. Avec 5 s pour ~ 1 s de requete, le serveur SQL est
  occupe a 20 % : ne pas descendre sous 2 s.

6. CE QUE FIXE configuration_plan_json DANS L'EXEMPLE
--------------------------------------------------------------------------------
  Tout vient de la base (aucune fusion applicative, contrairement a
  MyPnListeElements) :
    title, showNoPlanIndicator, showConfigInfo, pinButtonPosition,
    eventPriorityOrder, shapeEditing, badges   -> pview.Setting
    editIcons                                  -> pview.EditIcon
    pinned                                     -> pview.PinnedView (les vues
        communes, Utilisateur = '*', plus celles de l'operateur courant)
    tree                                       -> sched.Location, sur
        C_PROFONDEUR niveaux (3 : Site > Batiment > Niveau)
    plans, layers, scale                       -> pview.[Plan], pview.PlanLayer

  Pour changer le titre ou les badges sans repasser par SQL :
    MyPnPvSetSetting("title", "Plans du site Nord", "operateur")
    MyPnPvSetSetting("badges", "[{\"value\":12,\"color\":\"blue\"}]", "operateur")
  puis relire configuration_plan_json.

7. MISE AU POINT
--------------------------------------------------------------------------------
  - MyPnPvLastError() donne le detail de la derniere erreur (les lectures
    renvoient "" et les actions un JSON { ok:false, error, number }) ;
  - les numeros 503xx viennent des procedures : 50301 JSON invalide,
    50303 noeud inconnu, 50304 plan inconnu (node_id / planIndex),
    50305 type de forme inconnu, 50306 show_mode inconnu, 50307 element
    inconnu, 50308 coordonnees hors de 0..1 ;
  - les traces PnTrace sont prefixees « [MyPnPlanViewerV2] » ;
  - hors Panorama, tests\dll-call.ps1 de l'extension appelle n'importe quelle
    methode, et tests\bench-extension.ps1 rejoue les 75 assertions du contrat ;
  - la page demo.html du composant, ouverte avec ?data=server, affiche les
    donnees reelles de la base (jeu « Donnees SQL » en tete de la liste des
    jeux d'essai), regenerables par « node tests\make-samples.js » apres une
    execution du banc de l'extension.
================================================================================
