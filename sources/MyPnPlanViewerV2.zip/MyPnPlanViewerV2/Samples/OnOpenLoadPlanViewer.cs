// =============================================================================
// OnOpenLoadPlanViewer — charge l'arbre, les plans et les alarmes en cours dans
// le composant MyPnPlanViewer, via l'extension MyPnPlanViewerExtension
// (schema pview de la base PostgreSQL VisioDEF4).
//   1. MyPnPvSetConnectionString / MyPnPvSetContexte / MyPnPvSetProfondeur
//   2. MyPnPvTestConnection      -> diagnostic de la connexion SQL
//   3. MyPnPvGetPlanConfiguration -> configuration_plan_json (arbre avec id,
//                                   plans, calques, echelles, options du
//                                   bandeau, icones d'edition, vues epinglees)
//   4. MyPnPvGetPlanEvents        -> configuration_events_json (alarmes)
//
// L'objet se reconstruit a la reception de configuration_plan_json et reecrit
// selectedNodePath (id 0 / planIndex 0) : OnChangeSelectedNodePathPlanViewer.cs
// prend alors le relais des que l'operateur choisit un noeud.
//
// Si la base est injoignable, le script bascule sur une CONFIGURATION REDUITE
// ECRITE EN DUR (un site, deux batiments, deux plans) : la page reste
// affichable pour une demonstration, mais rien ne sera persiste.
//
// A jouer sur l'evenement d'ouverture du synoptique (triggertype = 1).
// Voir aussi OnChangeSelectedNodePathPlanViewer.cs (capteurs et formes du plan
// choisi), OnChangeDrawnShapesPlanViewer.cs (enregistrement des formes),
// OnChangeDetailRequestPlanViewer.cs (clic capteur / badge) et
// OnTimerEventsPlanViewer.cs (rafraichissement des alarmes).
// =============================================================================
const string C_TRACE = "[MyPnPlanViewer] ";

// Profondeur de l'arbre servi : 3 = Site > Batiment > Niveau (585 noeuds sur le
// jeu de test), 4 = zones incluses (5 389 noeuds, JSON ~ 1 Mo).
const int C_PROFONDEUR = 3;

// Contexte pview servi (jeu d'options, de plans et d'epingles). "" = "default".
const string C_CONTEXTE = "default";

// Priorite minimale des alarmes remontees (0 = toutes). Au-dela de quelques
// milliers d'alarmes, filtrer allege nettement configuration_events_json.
const int C_PRIORITE_MIN = 0;

// -----------------------------------------------------------------------------
// 1. Connexion et contexte
// -----------------------------------------------------------------------------
string lCnx = (string)MyPnPlanViewer.DbCnxString;
if (!string.IsNullOrWhiteSpace(lCnx))
{
	MyPnPvSetConnectionString(lCnx);
}
MyPnPvSetContexte(C_CONTEXTE);
MyPnPvSetProfondeur(C_PROFONDEUR);

string lTest = MyPnPvTestConnection();
bool lSql = !string.IsNullOrEmpty(lTest);
if (lSql)
{
	PnTrace(C_TRACE + "connexion SQL : " + lTest, FuncScript.TRACE_LEVEL.INFO);
}
else
{
	PnTrace(C_TRACE + "SQL injoignable (" + MyPnPvLastError() + ") : configuration reduite.",
		FuncScript.TRACE_LEVEL.WARNING);
}

// -----------------------------------------------------------------------------
// 2. configuration_plan_json
// -----------------------------------------------------------------------------
// L'utilisateur courant sert a servir SES vues epinglees en plus des vues
// communes (Utilisateur = '*' dans pview.PinnedView).
string lUtilisateur = MyPnPvUtilisateur();

string lConfig = lSql ? MyPnPvGetPlanConfiguration(lUtilisateur) : "";
if (string.IsNullOrEmpty(lConfig) || lConfig[0] != '{')
{
	if (lSql)
	{
		PnTrace(C_TRACE + "configuration_plan_json illisible : " + MyPnPvLastError(),
			FuncScript.TRACE_LEVEL.ERROR);
	}
	lConfig = MyPnPvConfigurationDeRepli();
}
else
{
	PnTrace(C_TRACE + "configuration_plan_json : " + lConfig.Length + " car.", FuncScript.TRACE_LEVEL.DEBUG);
}

MyPnPlanViewer.configuration_plan_json = lConfig;

// La reconstruction vide la memoire des capteurs et des formes par plan : les
// deux proprietes de plan sont remises a "" pour ne pas afficher celles du
// plan precedent en attendant la premiere selection.
MyPnPlanViewer.current_plan_element_json = "";
MyPnPlanViewer.current_plan_drawnShapes_json = "";

// -----------------------------------------------------------------------------
// 3. configuration_events_json
// -----------------------------------------------------------------------------
if (lSql)
{
	string lEvents = MyPnPvGetPlanEvents(C_PRIORITE_MIN);
	if (!string.IsNullOrEmpty(lEvents) && lEvents[0] == '{')
	{
		MyPnPlanViewer.configuration_events_json = lEvents;
		PnTrace(C_TRACE + "configuration_events_json : " + lEvents.Length + " car.", FuncScript.TRACE_LEVEL.DEBUG);
	}
	else
	{
		PnTrace(C_TRACE + "alarmes illisibles : " + MyPnPvLastError(), FuncScript.TRACE_LEVEL.ERROR);
		MyPnPlanViewer.configuration_events_json = "";
	}
}
else
{
	MyPnPlanViewer.configuration_events_json = "";
}

// ----------------------------------------------------------------------------- utilitaires

// Utilisateur Panorama courant (vide si la session n'en expose pas).
string MyPnPvUtilisateur()
{
	try
	{
		string lNom = PnUserManager.UserName;
		return string.IsNullOrWhiteSpace(lNom) ? "" : lNom.Trim();
	}
	catch
	{
		return "";
	}
}

// Configuration minimale, utilisee quand la base est injoignable : elle suffit
// a verifier l'affichage, la navigation et le mode edition de l'objet.
string MyPnPvConfigurationDeRepli()
{
	return "{"
		+ "\"title\":\"Plans (hors ligne)\","
		+ "\"showNoPlanIndicator\":true,\"showConfigInfo\":false,"
		+ "\"pinButtonPosition\":\"end\",\"eventPriorityOrder\":\"desc\",\"shapeEditing\":true,"
		+ "\"editIcons\":[{\"filename\":\"Images/speeddial/check.png\",\"label\":\"Valide\"},"
		+ "{\"filename\":\"Images/speeddial/times.png\",\"label\":\"Retrait\"}],"
		+ "\"badges\":[],\"pinned\":[],"
		+ "\"tree\":[{\"id\":1,\"label\":\"Site (hors ligne)\","
		+ "\"plans\":[{\"filename\":\"Images/plan_site_hopital_face_nu.svg\",\"label\":\"Vue du site\"}],"
		+ "\"nodes\":["
		+ "{\"id\":11,\"label\":\"Batiment A\",\"plans\":[{\"filename\":\"Images/planA.jpg\",\"label\":\"Plan\","
		+ "\"scale\":{\"value\":120,\"unit\":\"m\"},"
		+ "\"layers\":[{\"label\":\"Zone a risque\",\"kind\":\"image\",\"filename\":\"Images/planA-zone-risque.png\"}]}]},"
		+ "{\"id\":12,\"label\":\"Batiment B\",\"plans\":[{\"filename\":\"Images/PlanB.jpg\",\"label\":\"Plan\"}]}"
		+ "]}]}";
}
