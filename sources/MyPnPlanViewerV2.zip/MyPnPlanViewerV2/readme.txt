﻿================================================================================
MyPnPlanViewerV2 - Objet d'IHM Web Panorama (implémentation « pure JS »)
Installation dans une application Panorama hôte
================================================================================

1. OBJET
--------------------------------------------------------------------------------
MyPnPlanViewerV2 reprend l'intégralité de MyPnPlanViewer (visualiseur de
plans avec bandeau, arbre de navigation, vues épinglées, représentations 2D
et 3D, calques image, zoom, SpeedDial, mode d'édition de formes à 13 outils)
en changeant sa façon de dialoguer avec l'application Panorama, et y ajoute
depuis le 2026-08-29 un MODE D'ÉDITION DES REPRÉSENTATIONS 3D (même cadenas :
vue par défaut, emprise au sol, fond de plan, étalon et mesures, objets 3D,
zones survolables et animables — § 10 bis) et, depuis le 2026-08-30, un
REPÈRE D'ORIENTATION 3D (cadran cliquable, flèche nord au sol), une VUE EN
PLAN (vue de dessus orthographique, nord en haut) et ses EXPORTS PNG / SVG
(dont une coupe horizontale vectorielle — § 10 ter) :

  - chaque nœud de l'arbre de navigation porte un IDENTIFIANT ENTIER UNIQUE
    (clé id, fournie par la configuration) ; l'objet construit lui-même le
    parent_id de chaque nœud à partir de l'imbrication de l'arbre ;
  - la configuration unique de la V1 est ÉCLATÉE en cinq propriétés lues :
    l'arbre et les plans (configuration_plan_json), les capteurs du plan
    affiché (current_plan_element_json), les alarmes en cours
    (configuration_events_json), les formes libres du plan affiché
    (current_plan_drawnShapes_json, en lecture ET en écriture) et la scène
    de la représentation 3D affichée (current_plan_scene3d_json, en lecture
    ET en écriture : vue par défaut, emprise, fond de plan, objets, zones) ;
  - les capteurs et les formes portent une règle d'affichage show_mode
    (masked / always_without_animation / always_with_animation), et leur
    représentation change selon la présence d'une alarme ;
  - la sélection de l'opérateur est remontée en JSON (selectedNodePath), et
    le clic sur un capteur du plan demande son détail à l'application
    (eventsDetailRequest_json).

Tout le reste — bandeau (fil d'Ariane, badges, bouton « + »), drawer
(recherche, vues épinglées renommables, arborescence avec pastilles), zone
des plans (2D avec zoom / déplacement / calques image / impression du plan
consulté, 3D Three.js, SpeedDial des calques), mode d'édition (cadenas, barre déplaçable, 13 outils, rotation,
étalon d'échelle, panneau Apparence / Propriétés) — est identique à la V1 ;
son mode d'emploi détaillé n'est pas répété ici, voir le readme.txt de
MyPnPlanViewer.

Différences V1 -> V2 en un tableau :

  V1                                   V2
  ----------------------------------   ----------------------------------------
  configuration_json (tout)            configuration_plan_json (arbre + plans,
                                       AVEC id par nœud ; plus de capteurs,
                                       de formes ni d'événements dedans)
  calques kind "markers"               current_plan_element_json
  clé events des nœuds                 configuration_events_json (liste plate,
                                       remontée automatique par parent_id)
  calques kind "shapes"                current_plan_drawnShapes_json (lecture)
  drawnShapes_json (écriture seule)    current_plan_drawnShapes_json (écriture)
  selectedNodePath (chaîne) +          selectedNodePath (objet JSON incluant
  selectedPlanIndex (entier)           planIndex)
  eventsDetailRequest_json (badge)     eventsDetailRequest_json (capteur ET
                                       badge, discriminés par la clé source)

Propriétés partagées avec l'application Panorama (six, toutes de type
chaîne de caractères ; détail et schémas aux § 6 à 11) :

  LUES par l'objet
  configuration_plan_json   Arbre de navigation (avec id), options, plans
                            et calques image. Reconstruction à chaque
                            changement (sauf badges fixes seuls : à chaud).
  current_plan_element_json Capteurs / éléments du plan affiché, avec
                            position, icônes et show_mode.
  configuration_events_json Alarmes en cours : liste plate d'événements
                            (id, element_id, node_id, priority, color,
                            count). Mise à jour à chaud des capteurs, des
                            formes liées, des pastilles et des badges.
  current_plan_drawnShapes_json
                            Formes libres du plan affiché (lecture).
  current_plan_scene3d_json Scène de la représentation 3D affichée : vue
                            par défaut de la caméra, emprise au sol, fond
                            de plan, objets ajoutés, zones (lecture, § 10 bis).

  ÉCRITES par l'objet
  selectedNodePath          Sélection courante : { id, parent_id, path,
                            labels, planIndex, filename, serial }.
  current_plan_drawnShapes_json
                            Formes libres du plan affiché, réécrites à
                            chaque modification de l'opérateur (écriture).
  current_plan_scene3d_json Scène du plan 3D affiché, réécrite à chaque
                            modification de l'opérateur (écriture).
  eventsDetailRequest_json  Demande de détail : clic sur un capteur du plan
                            ({ source: "element", ... }) ou sur un badge du
                            bandeau ({ source: "badge", ... }).

Contenu du dossier :
  index.html       Page Web de l'interface graphique (point d'entrée obligatoire)

  L'implémentation JavaScript est répartie en modules par domaine — scripts
  classiques chargés dans l'ORDRE IMPOSÉ par index.html, qui communiquent
  par l'espace de noms global MyPnPlanViewerV2NS :

  viewer-config.js       Normalisation des cinq propriétés lues + état
                         partagé (index des nœuds par id)
  viewer-dom.js          Références vers les éléments de la page
  viewer-edit-core.js    Mode édition : état, géométrie, capteurs couverts,
                         écriture de current_plan_drawnShapes_json
  viewer-edit-render.js  Mode édition : rendu du calque (formes, poignées,
                         aperçu du tracé)
  viewer-edit-panel.js   Mode édition : panneau « Apparence / Propriétés »
  viewer-edit-tools.js   Mode édition : cadenas, barre d'outils, interactions
  viewer-scene3d.js      Mode édition 3D : état de la scène du modèle, panneau
                         « Scène 3D », écriture de current_plan_scene3d_json
                         (§ 10 bis)
  viewer-scene3d-render.js
                         Mode édition 3D : rendu Three.js de la scène (emprise,
                         fond de plan, étalon, mesures, objets, poignées,
                         étiquettes)
  viewer-scene3d-zones.js
                         Zones du bâtiment : prismes ou groupes du modèle,
                         survol (surbrillance + carte), clic (détail),
                         clignotement sur alarme
  viewer-scene3d-helper.js
                         Repère d'orientation du cadre 3D : cadran SVG
                         (trièdre X/Y/Z, rose des vents N/E/S/O) cliquable,
                         bouton de la barre de zoom (§ 10 ter)
  viewer-scene3d-planview.js
                         Vue en plan : bouton « Vue en plan », menu (bascule,
                         exports), puce de mode 3D | Vue en plan (§ 10 ter)
  viewer-scene3d-export.js
                         Export PNG de la vue en plan : mode export, cadrage
                         de toute la scène, en-tête, téléchargement (§ 10 ter)
  viewer-scene3d-export-svg.js
                         Export SVG : modèle en image, fond de plan, entités
                         vectorielles, barre d'échelle, métadonnées (§ 10 ter)
  viewer-scene3d-export-cut.js
                         Coupe horizontale vectorielle du modèle pour le SVG
                         « coupe » (§ 10 ter)
  viewer-scene3d-tools.js
                         Mode édition 3D : outils au pointeur et au clavier
                         (tracés au sol, sélection, glissers de poignées)
  viewer-plan.js         Zone des plans 2D/3D, calques, SpeedDial, zoom
  viewer-print.js        Impression du plan 2D : bouton, menu, en-tête,
                         mise en page @media print (app.css)
  viewer-nav.js          Drawer, arbre, vues épinglées, application de la
                         configuration, événements (pastilles / badges),
                         écriture de selectedNodePath
  app.js                 Point d'entrée : raccordement aux propriétés
                         partagées Panorama (noms des propriétés en tête)

  app.css          Feuille de style
  three-viewer.bundle.js
                   Moteur de rendu 3D chargé par index.html : Three.js r160
                   (vendor/three), BufferGeometryUtils, OBJLoader, GLTFLoader,
                   OrbitControls et three-viewer.js regroupés en un script
                   classique — GÉNÉRÉ
                   par « node tests\build-three-bundle.js », à relancer après
                   toute modification de three-viewer.js. Un module ES ne se
                   charge pas depuis file:// : le bundle, si.
  three-viewer.js  Source du moteur 3D (module ES, non chargé directement).
                   Sous Panorama (HTTP) les fichiers .obj / .glb / .gltf sont
                   lus par fetch ; en file:// (demo.html) le navigateur refuse
                   tout fetch local : le moteur charge alors <fichier>.js
                   (texte du .obj ou base64 du .glb enregistré dans
                   window.ThreeViewerModels), généré par
                   « node tests\build-demo-model.js » (modèle du plan) et
                   « node tests\build-demo-models.js » (objets de
                   Images\models) — livrés pour la démonstration, à supprimer
                   avant déploiement avec demo.html.
  Images/models/   Objets 3D de démonstration de la clé editModels (cube,
                   cuve, borne en .obj ; cube en .glb), générés par
                   tests\build-demo-models.js
  MyPnSpeedDial/   Composant SpeedDial embarqué (MyPnSpeedDial.js / .css)
  vendor/pdf-lib/  pdf-lib : PDF du plan téléchargé quand le bac à sable
                   de l'IHM Web ignore window.print() (§ 14)
  vendor/three/    Three.js et ses modules BufferGeometryUtils / OBJLoader /
                   GLTFLoader / OrbitControls (sources du bundle ; non chargés
                   à l'exécution)
  Images/          Plans de démonstration et icônes des SpeedDial
                   (Images/speeddial/ est obligatoire ; les fichiers de
                   plans peuvent être remplacés par ceux de l'application ;
                   les repères « sans plan » sont des SVG inline de app.css)
  demo.html        Banc de test autonome (double-clic, sans Panorama) ;
                   peut être supprimé avant déploiement
  readme.txt       Ce fichier

L'objet n'a pas besoin de Back end C# : aucun traitement n'est effectué côté
serveur d'IHM Web, la classe ne sert qu'à porter les propriétés partagées.
La classe utilisateur est donc déclarée « sans implémentation » (sans objet C#).

Cela ne dit rien de l'ORIGINE des données : depuis le 28/08/2026, l'objet
dispose d'un back-end SQL complet — schéma pview de la base VisioDEF4 (PostgreSQL
depuis le 07/10/2026),
extension .NET MyPnPlanViewerExtension et scripts Panorama d'exemple — qui
alimente ses quatre propriétés lues et enregistre les formes qu'il écrit
(§ 16). Il reste utilisable tel quel avec des propriétés écrites à la main.


2. PRÉREQUIS
--------------------------------------------------------------------------------
- Une application Panorama hôte disposant du serveur d'IHM Web (Servin).
- La bibliothèque d'interfaçage Web Panorama, fournie par le serveur Web
  Panorama à l'adresse /static/fr/pn-insertable-object-lib.umd.js.
  Elle est référencée par index.html ; aucun fichier n'est à copier pour elle.
- Un navigateur avec WebGL pour les représentations 3D (à défaut, un message
  l'indique ; les plans 2D restent fonctionnels).


3. COPIE DES FICHIERS
--------------------------------------------------------------------------------
Copier l'intégralité du dossier MyPnPlanViewerV2, sous-dossiers compris, dans
le sous-répertoire UserClasses du répertoire de l'application Panorama hôte :

  <Dossier de l'application Panorama>\UserClasses\MyPnPlanViewerV2\index.html
  <Dossier de l'application Panorama>\UserClasses\MyPnPlanViewerV2\app.js
  <Dossier de l'application Panorama>\UserClasses\MyPnPlanViewerV2\viewer-*.js
                                     (les 18 modules listés au § 1)
  <Dossier de l'application Panorama>\UserClasses\MyPnPlanViewerV2\app.css
  <Dossier de l'application Panorama>\UserClasses\MyPnPlanViewerV2\three-viewer.bundle.js
  <Dossier de l'application Panorama>\UserClasses\MyPnPlanViewerV2\MyPnSpeedDial\...
  <Dossier de l'application Panorama>\UserClasses\MyPnPlanViewerV2\Images\...
                                     (dont Images\models\ si la clé editModels
                                     y fait référence)

Les sous-dossiers MyPnSpeedDial et Images sont obligatoires (three-viewer.js
et vendor\three ne servent qu'à régénérer le bundle : facultatifs à
l'exécution). Les dix-huit
fichiers viewer-*.js le sont tout autant : index.html les charge dans un
ordre imposé avant app.js (§ 1).

Les fichiers de plans, de calques et d'icônes de capteurs référencés par les
propriétés (clés filename, icon, icon_alarm : chemins relatifs au dossier de
l'objet) doivent être déposés dans ce même dossier — par convention dans
Images\.

Le nom du dossier (MyPnPlanViewerV2) est celui qui sera renseigné dans la
chaîne d'implémentation du descripteur de classe : il doit être respecté à
l'identique. L'ancienne V1 (dossier MyPnPlanViewer) a été retirée de
l'application le 2026-08-29 (archive zip dans le dossier archives du projet) :
MyPnPlanViewerV2 est désormais la seule implémentation. Les parties encore
utiles de son readme (schéma des formes, mode édition, recette) sont reprises
en annexes A, B et C en fin de ce document.


4. DÉCLARATION DE LA CLASSE UTILISATEUR
--------------------------------------------------------------------------------
Dans l'éditeur de configuration de Panorama, ouvrir le descripteur des classes
utilisateur de l'application hôte et créer une nouvelle classe :

  Nom             : CU_WEB_PlanViewerV2  (nom libre)
  Implémentation  : $front=MyPnPlanViewerV2

La valeur « $front=<nom du dossier> » désigne le dossier créé à l'étape 3 dans
UserClasses. Sans partie avant le « ; », la classe est déclarée sans objet Back
end C#. (Le fichier UserClasses\CU_WEB.CLS de cette application contient déjà
cette classe.)


5. DÉCLARATION DES PROPRIÉTÉS PARTAGÉES
--------------------------------------------------------------------------------
Toujours dans le descripteur de la classe, ajouter les sept propriétés
suivantes, toutes de type Chaîne de caractères (string), accès
lecture / écriture :

  configuration_plan_json        (lue)
  current_plan_element_json      (lue)
  configuration_events_json      (lue)
  current_plan_drawnShapes_json  (lue ET écrite)
  current_plan_scene3d_json      (lue ET écrite)
  selectedNodePath               (écrite)
  eventsDetailRequest_json       (écrite)

IMPORTANT : les noms doivent être orthographiés exactement ainsi (la casse est
significative) ; ce sont les noms utilisés par app.js dans
subscribeProperties et writeProperty. Une propriété absente du descripteur
fait échouer l'abonnement (les cinq premières) ou trace une erreur
d'écriture dans la console du navigateur (les quatre dernières).

Seule configuration_plan_json est indispensable au démarrage : tant qu'elle
est vide, la zone des plans affiche « Aucune représentation disponible ».
Les autres propriétés lues peuvent rester vides (aucun capteur, aucune
alarme, aucune forme).

Si les noms doivent être différents, modifier également les constantes
CONFIG_PROPERTY, ELEMENTS_PROPERTY, EVENTS_PROPERTY, DRAWN_SHAPES_PROPERTY,
SCENE3D_PROPERTY, SELECTED_NODE_PROPERTY et EVENTS_DETAIL_PROPERTY en tête du
fichier app.js.


6. DIALOGUE AVEC L'APPLICATION
--------------------------------------------------------------------------------
6.1 Identifiants

  Chaque nœud de l'arbre (configuration_plan_json), chaque capteur
  (current_plan_element_json), chaque événement (configuration_events_json)
  et chaque forme (current_plan_drawnShapes_json) porte une clé id : entier
  (ou chaîne ne contenant qu'un entier, par exemple "12"), UNIQUE dans sa
  famille, supérieur ou égal à 1. La valeur 0 est réservée : c'est le
  parent_id des nœuds de premier niveau, et l'id de la « racine » en mode
  sans navigation (clé plans à la racine, § 7).

  Un nœud sans id valide, ou dont l'id est déjà pris, est IGNORÉ avec toute
  sa descendance (comme un nœud sans libellé), et un avertissement est
  ajouté à la liste des avertissements de normalisation, visible dans
  l'info-bulle « i » du drawer et tracé dans la console (§ 14).

  parent_id n'est PAS fourni par l'application : l'objet le construit pour
  chaque nœud à partir de l'id du nœud qui le contient (0 au premier
  niveau). Il est remonté dans selectedNodePath et sert à la remontée des
  alarmes (§ 9).

6.2 Séquence

  L'objet est réactif : il affiche ce que l'application lui envoie et lui
  signale les choix de l'opérateur. Séquence type :

    application  ->  configuration_plan_json          (arbre, plans)
    application  ->  configuration_events_json        (alarmes en cours,
                                                       puis au fil de l'eau)
    opérateur    :   clic sur un nœud
    objet        ->  selectedNodePath { id, planIndex, ... }
    application  ->  current_plan_element_json        (capteurs de CE plan)
    application  ->  current_plan_drawnShapes_json    (formes de CE plan)
    opérateur    :   clic sur un capteur du plan
    objet        ->  eventsDetailRequest_json { source: "element", ... }
    opérateur    :   dessin / retouche d'une forme (cadenas ouvert)
    objet        ->  current_plan_drawnShapes_json    (toutes les formes du
                                                       plan affiché)

  L'application peut répondre à selectedNodePath avec un délai : entre-temps,
  le plan est affiché sans capteur ni forme — sauf si l'objet a déjà reçu
  les données de ce plan plus tôt : il les mémorise par plan (clé node_id +
  planIndex) et les réaffiche aussitôt en attendant une éventuelle nouvelle
  valeur. Cette mémoire vaut jusqu'à la prochaine RECONSTRUCTION (nouvelle
  valeur de configuration_plan_json) : les identifiants pouvant changer,
  elle est alors vidée, et l'application renvoie les capteurs en réponse
  aux sélections suivantes.

6.3 Règle d'affichage show_mode

  Portée par chaque capteur et chaque forme. Trois valeurs (casse
  indifférente ; toute autre valeur retombe sur le défaut) :

    Valeur                    Capteur                   Forme
    ------------------------  ------------------------  ---------------------
    "masked"                  jamais affiché, même en   jamais affichée, même
                              alarme                    si un capteur lié est
                                                        en alarme
    "always_without_          affiché avec sa           toujours affichée,
     animation"               représentation par        avec ou sans alarme
                              défaut (icon), inchangée  sur ses capteurs liés
                              en alarme
    "always_with_animation"   affiché ; en alarme,      affichée UNIQUEMENT
     (défaut des capteurs)    représentation d'alarme   si au moins un capteur
                              (icon_alarm, ou icon      lié est en alarme,
                              avec halo animé)          avec halo animé

  Défaut : "always_with_animation" pour les capteurs,
  "always_without_animation" pour les formes.

  MODE ÉDITION (cadenas ouvert) : toutes les formes du plan sont visibles,
  quelle que soit leur show_mode — celles qui seraient masquées cadenas
  fermé le sont en contour fantôme pointillé, pour rester sélectionnables
  et modifiables. Le cadenas fermé applique la règle.


7. configuration_plan_json — ARBRE ET PLANS
--------------------------------------------------------------------------------
Chaîne contenant un objet JSON. Tant qu'elle est vide, la zone des plans
affiche « Aucune représentation disponible / configuration_plan_json est
vide. » : il n'y a aucune configuration de repli embarquée.

L'objet se RECONSTRUIT à chaque changement de la propriété (drawer refermé,
filtre effacé, sélection annulée — et selectedNodePath est réécrit avec
id 0 / planIndex 0, voir § 11). Deux exceptions : si seuls les badges fixes
(clé badges) changent, ils sont mis à jour à chaud ; et si la nouvelle
valeur est vide ou invalide (message d'erreur dans la zone des plans),
selectedNodePath n'est PAS réécrit — sa dernière valeur reste celle de la
sélection précédente.

Exemple :

{
  "title": "Site Sud",
  "showNoPlanIndicator": true,
  "showConfigInfo": true,
  "showPrintButton": true,
  "pinButtonPosition": "end",
  "eventPriorityOrder": "asc",
  "shapeEditing": true,
  "editIcons": [
    { "filename": "Images/speeddial/check.png", "label": "Validé" },
    { "filename": "Images/speeddial/times.png", "label": "Retrait" }
  ],
  "editFloorImages": [
    { "filename": "Images/PlanD.png", "label": "Plan D" }
  ],
  "editModels": [
    { "filename": "Images/models/cuve.obj", "label": "Cuve", "size": 6,
      "color": "#0ea5e9" },
    { "filename": "Images/models/cube.glb", "label": "Cube glTF", "size": 3 }
  ],
  "badges": [ { "value": 12, "color": "blue" } ],
  "pinned": [
    { "id": 221, "label": "Site Nord Niv1 batD" },
    { "id": 111 }
  ],
  "tree": [
    { "id": 1, "label": "Site Sud",
      "plans": [
        { "filename": "Images/plan_site_hopital_face_nu.svg", "label": "Vue du site" }
      ],
      "nodes": [
        { "id": 11, "label": "Bâtiment A",
          "plans": [
            { "filename": "Images/planA.jpg", "label": "Plan",
              "scale": { "value": 120, "unit": "m" },
              "layers": [
                { "label": "Zone à risque", "kind": "image",
                  "filename": "Images/planA-zone-risque.png" }
              ]}
          ],
          "nodes": [
            { "id": 111, "label": "RDC batA" },
            { "id": 112, "label": "Niv1 batA" }
          ]},
        { "id": 12, "label": "Bâtiment D", "nodes": [
            { "id": 121, "label": "RDC batD",
              "plans": [ { "label": "Modèle 3D", "type": "model",
                           "filename": "Images/RB_SP_MD_011.obj" } ] },
            { "id": 122, "label": "Niv1 batD" }
          ]}
      ]},
    { "id": 2, "label": "Site Nord", "nodes": [
        { "id": 22, "label": "Bâtiment D", "nodes": [
            { "id": 221, "label": "Niv1 batD" }
          ]}
      ]}
  ]
}

Détail des clés (les clés sans mention « V2 » sont identiques à la V1, dont
le readme donne le détail complet) :

  title, showNoPlanIndicator, showConfigInfo, showPrintButton,
  pinButtonPosition, eventPriorityOrder, shapeEditing, editIcons, badges
      Comme en V1. showNoPlanIndicator (vrai par défaut) affiche, sur
      chaque ligne de l'arbre sans représentation, une petite image barrée
      rouge ; la sélection d'une telle ligne affiche dans la zone des plans
      « Aucune représentation disponible / Sélectionnez un élément avec un
      plan ». eventPriorityOrder ("asc" par défaut / "desc") fixe
      l'ordre d'importance des priorités des événements reçus par
      configuration_events_json. Tous les booléens acceptent aussi "true" /
      "false" et 0 / 1.
      editFloorImages — V2 : galerie des fonds de plan proposés par l'outil
      « Fond de plan » du mode édition 3D (§ 10 bis), même schéma que
      editIcons ({ filename, label }) ; facultative (le panneau accepte un
      chemin libre).
      editModels — V2 : bibliothèque des objets 3D de l'outil « Objet » du
      mode édition 3D (§ 10 bis) : { filename (.obj, .glb ou .gltf, relatif
      au dossier de l'objet), label, size (plus grande dimension RÉELLE de
      l'objet, dans l'unité du plan ; défaut 1), color (#rrggbb appliqué aux
      .obj, monochromes ; absent ou null : matériaux du fichier, cas des
      .glb), icon (vignette facultative de la galerie) }. Sans cette clé,
      l'outil « Objet » n'a rien à poser.
      showConfigInfo — V2 : FAUX par défaut (V1 : vrai). L'indicateur « i »
      du pied du drawer est un outil de MISE AU POINT (état de réception de
      chaque propriété lue, avertissements de normalisation) : il n'a pas sa
      place devant un opérateur. Le mettre à true pendant l'intégration.
      showPrintButton — booléen, vrai par défaut : bouton imprimante en
      bout de barre de zoom, qui imprime le plan 2D consulté. Un clic
      ouvre un menu à deux choix : « Plan entier » (le plan tel qu'il est
      affiché à 100 %, ajusté à la page) ou « Vue affichée » (le cadre
      tel qu'il est à l'écran, zoom et déplacement compris ; inactif sans
      zoom). Sont imprimés le plan de base, les calques image VISIBLES,
      les capteurs affichés et les formes (sans poignées ni tracé en
      cours), sous un en-tête portant le fil d'Ariane, le libellé de la
      représentation et la date/heure (jj/mm/aaaa hh:mm). L'orientation
      de la page suit le ratio du plan ou du cadre ; la mise en page vise
      la plus petite zone imprimable commune aux formats A4 et Letter
      (marges de 10 mm) : tout tient sur une page. Les représentations
      3D ne s'impriment pas (bouton masqué). À false, le bouton est
      masqué. L'impression passe par window.print() : dans un iframe
      sandbox sans allow-modals, l'objet le détecte et affiche
      « Impression bloquée par l'application hôte… » (§ 14).
      orientationHelper — "shown" (défaut), "hidden" ou "none" : repère
      d'orientation du cadre 3D (§ 10 ter) affiché à l'ouverture, masqué
      mais disponible par son bouton, ou absent (bouton compris). Booléen
      accepté (true = shown, false = none) ; valeur inconnue : shown avec
      avertissement.
      showPlanViewButton — booléen, vrai par défaut : bouton « Vue en plan »
      en bout de barre de zoom sur une représentation 3D (§ 10 ter) ; faux :
      ni bouton, ni menu, ni puce de mode.
      planExport — { pngScale, cutHeight } : réglages des exports de la vue
      en plan (§ 10 ter). pngScale = pixels du PNG par pixel écran du cadre
      (1 à 4, défaut 2) ; cutHeight = hauteur de la coupe horizontale du
      SVG « coupe » au-dessus du sol, en unités réelles du plan (> 0,
      défaut 1,2). Valeur hors bornes : défaut, avec avertissement.

  tree
      Arborescence de navigation. Clés d'un nœud :
        id        V2 — entier >= 1, OBLIGATOIRE et UNIQUE dans tout l'arbre
                  (§ 6.1). Nœud sans id valide ou en doublon : ignoré avec
                  sa descendance + avertissement.
        label     libellé, obligatoire (nœud sans libellé : ignoré avec sa
                  descendance). Les libellés forment le fil d'Ariane et la
                  clé path de selectedNodePath (joints par « — »). Des
                  libellés identiques sont admis (deux « Bâtiment D ») :
                  l'id lève l'ambiguïté.
        plans     représentation du nœud (voir plus bas) : UNE seule,
                  2D ou 3D.
        nodes     V2 — tableau de nœuds enfants (récursif). Le parent_id de
                  chaque enfant est l'id de ce nœud. La clé children de la
                  V1 est lue en repli si nodes est absente (« children »
                  est un terme réservé côté Panorama) ; si les deux sont
                  présentes, nodes l'emporte.
        events, alarm
                  V2 — IGNORÉES (avertissement). Les événements viennent de
                  configuration_events_json (§ 9).

  pinned
      Vues épinglées en tête de la navigation. Clés d'une vue :
        id      V2 — id du nœud visé (entier). Une entrée sans id valide, ou
                dont l'id ne correspond à aucun nœud de tree, est ignorée
                avec un avertissement. (La clé path de la V1 n'est plus
                lue.)
        label   libellé affiché ; défaut : les libellés du chemin du nœud
                joints par un espace.
      Retrait (×), renommage (✎ / double-clic) et signets ajoutés par le
      bouton « + » du bandeau : comme en V1. Les signets de l'opérateur
      visent eux aussi un id ; ils survivent aux reconstructions tant que
      l'id existe encore dans le nouvel arbre (sinon ils sont retirés).

  plans (à la racine)
      Mode sans navigation : si tree est absent ou vide, ces représentations
      sont affichées directement (drawer masqué, fil d'Ariane = title).
      V2 — selectedNodePath EST écrit dans ce mode, avec id 0 et parent_id 0
      (§ 11), pour que l'application sache quel plan est affiché et lui
      envoie ses capteurs et ses formes.

  Schéma d'une représentation (clé plans). Un nœud n'affiche QU'UNE
  représentation, 2D (image) ou 3D (modèle .obj) : la clé reste un tableau
  (compatibilité), mais seule la première entrée valide est retenue ; les
  suivantes sont ignorées avec un avertissement (info-bulle « i »). Le
  planIndex de selectedNodePath vaut donc 1 dès qu'une représentation est
  affichée :
        label     Libellé (texte alternatif de l'image).
        filename  Chemin du fichier relatif au dossier de l'objet. Image
                  JPG/PNG/SVG (2D) ou Wavefront .obj (3D). Entrée sans
                  filename : ignorée. (Ancienne clé file lue en repli.)
        type      "model" pour une représentation 3D ; la ligne du nœud
                  porte alors dans l'arbre un petit cube bleu (info-bulle
                  « Représentation 3D »).
        scale     { value, unit } : longueur réelle représentée par la
                  LARGEUR du plan, pour les cotes du mode édition (comme en
                  V1 ; un étalon "scale" dessiné reste prioritaire).
        layers    V2 — calques superposables de kind "image" UNIQUEMENT :
                  { label, kind: "image", filename } (PNG transparent de
                  mêmes dimensions que le plan, masqué au départ, affiché
                  par le SpeedDial des calques). Les calques "markers" et
                  "shapes" de la V1 sont IGNORÉS avec un avertissement :
                  capteurs et formes passent par current_plan_element_json
                  et current_plan_drawnShapes_json.


8. current_plan_element_json — CAPTEURS DU PLAN AFFICHÉ
--------------------------------------------------------------------------------
Chaîne contenant un objet JSON : les capteurs (éléments) à poser sur le plan
affiché, avec leur position. L'application l'écrit en réponse à
selectedNodePath (§ 6.2), et chaque fois que la liste change.

{
  "node_id": 11,
  "planIndex": 1,
  "elements": [
    { "id": 1001, "label": "Détecteur fumée D12", "x": 0.22, "y": 0.30,
      "show_mode": "always_with_animation",
      "icon": "Images/elements/detecteur.png",
      "icon_alarm": "Images/elements/detecteur-alarme.png",
      "size": 28,
      "props": { "Type": "Fumée", "Zone": "A3" } },
    { "id": 1002, "label": "Déclencheur manuel", "x": 0.55, "y": 0.48 }
  ]
}

  node_id, planIndex
      Plan auquel se rapportent ces capteurs : id du nœud et rang de la
      représentation (base 1) — ceux de la dernière valeur de
      selectedNodePath. Facultatifs mais RECOMMANDÉS : fournis TOUS LES
      DEUX, les capteurs sont mémorisés pour CE plan et affichés seulement
      s'il est celui à l'écran (une réponse tardive à une sélection
      précédente n'écrase donc pas le plan courant, et revenir sur un plan
      déjà reçu le raffiche aussitôt) ; absents — ou fournis incomplets,
      l'un sans l'autre —, les capteurs sont attribués au plan affiché au
      moment de la réception. Un tableau JSON nu est accepté (équivalent de
      { "elements": [...] } sans node_id).

  elements  tableau de capteurs. Clés d'un capteur :
        id         entier >= 1, OBLIGATOIRE, unique dans la liste (doublon :
                   seconde entrée ignorée + avertissement). C'est l'id que
                   l'application retrouve dans eventsDetailRequest_json, dans
                   la clé elements des formes et qu'elle cite dans
                   element_id des événements.
        label      libellé (carte au survol, info-bulle).
        x, y       position en fraction (0 à 1) de la largeur / hauteur du
                   plan. Obligatoires (capteur sans position numérique :
                   ignoré ; position hors de 0..1 : ramenée au bord, avec
                   un avertissement).
        show_mode  règle d'affichage (§ 6.3), défaut "always_with_animation".
        icon       chemin de l'image du capteur (relatif au dossier de
                   l'objet). Absent : pastille ronde par défaut.
        icon_alarm chemin de l'image en alarme. Absent : l'image icon (ou la
                   pastille) reste affichée, soulignée d'un halo animé de la
                   couleur de l'événement.
        size       taille en pixels à 100 % de zoom (8 à 128, défaut 24) ;
                   les capteurs suivent le zoom et le déplacement du plan.
        props      objet { nom: valeur } de propriétés libres (texte, nombre
                   ou booléen), affichées dans la carte au survol.

  Comportement :
  - les capteurs sont toujours affichés (pas de calque à activer), au-dessus
    du plan et des calques image, sous les formes libres ;
  - survol : petite carte avec le libellé et les propriétés ;
  - clic (cadenas du mode édition FERMÉ ou mode édition inactif) : écriture
    de eventsDetailRequest_json { source: "element", ... } (§ 11). Cadenas
    ouvert, les clics vont aux outils de dessin ;
  - alarme : un capteur dont l'id figure dans element_id d'un événement de
    configuration_events_json est en alarme ; effet selon show_mode (§ 6.3).
  - pendant le tracé d'une forme fermée (mode édition), les capteurs
    couverts sont soulignés d'un anneau bleu et listés sous le panneau.


9. configuration_events_json — ALARMES EN COURS
--------------------------------------------------------------------------------
Chaîne contenant un objet JSON : la liste plate des événements (alarmes) en
cours sur l'ensemble du site. L'application la réécrit au fil des
événements ; l'objet se met à jour À CHAUD (rien n'est reconstruit, la
sélection, le zoom, le drawer et les nœuds dépliés sont conservés).

{
  "events": [
    { "id": 7001, "element_id": 1001, "node_id": 11,
      "priority": 1, "color": "red", "count": 1, "label": "Détection fumée" },
    { "id": 7002, "node_id": 122, "priority": 2, "color": "amber", "count": 3 }
  ]
}

  Un tableau JSON nu est accepté. Clés d'un événement :
        id          entier, OBLIGATOIRE, unique (doublon : avertissement,
                    l'entrée est conservée). Identifiant de l'événement côté
                    application.
        element_id  entier, facultatif : capteur concerné (§ 8). Un capteur
                    est en alarme dès qu'au moins un événement le cite.
        node_id     entier, facultatif mais nécessaire aux pastilles et aux
                    badges : nœud de l'arbre où l'événement est compté. Un
                    node_id inconnu de l'arbre est ignoré pour l'arbre (mais
                    element_id reste appliqué au capteur).
        priority    numéro de priorité (entier, défaut 1).
        color       "red" (défaut), "amber", "blue", "magenta" ou couleur
                    CSS hexadécimale ("#RRGGBB" / "#RGB") : couleur de la
                    pastille, du badge et du halo d'alarme.
        count       nombre d'événements que représente l'entrée (défaut 1 ;
                    0 : entrée ignorée). Deux entrées de même node_id et de
                    même priorité sont cumulées.
        label       facultatif, libre (non affiché aujourd'hui).

  Effets (identiques à la clé events de la V1, mais calculés par l'objet) :
  - ARBRE : pastille unique par ligne, de la couleur de la priorité la plus
    importante (eventPriorityOrder). Nœud replié ou feuille : synthèse de
    tout son sous-arbre — c'est la REMONTÉE PAR parent_id : un événement
    compté sur le nœud 122 colore 122, puis 12 et 1 tant qu'ils sont
    repliés ; déplié, un nœud ne montre que ses événements propres.
  - BANDEAU : un badge par priorité présente dans le sous-arbre du nœud
    sélectionné (lui compris), cumul des count, du plus important au moins
    important ; clic : eventsDetailRequest_json { source: "badge", ... }.
  - CAPTEURS du plan affiché : état d'alarme selon element_id (§ 8, § 6.3).
  - FORMES du plan affiché : une forme est « en alarme » si l'un des ids de
    sa clé elements est en alarme (§ 10, § 6.3).

  Valeur vide : plus aucune alarme. JSON invalide : l'état précédent est
  CONSERVÉ et l'erreur est tracée (console + info-bulle « i »).


10. current_plan_drawnShapes_json — FORMES LIBRES DU PLAN AFFICHÉ
--------------------------------------------------------------------------------
Propriété à DOUBLE SENS.

  LECTURE : l'application y écrit les formes à afficher sur le plan affiché
  (en réponse à selectedNodePath, ou à tout moment). Même logique de
  mémorisation par plan que current_plan_element_json — node_id + planIndex
  fournis ensemble, mémoire vidée à la reconstruction (§ 6.2). Les formes
  reçues REMPLACENT celles que l'objet connaissait pour ce plan (y compris
  celles dessinées par l'opérateur : c'est l'application qui fait foi) ; si
  ce plan est affiché, la sélection et le tracé en cours du mode édition
  sont annulés (la forme visée peut avoir disparu).
  Les formes s'affichent dès que le plan l'est, AVEC OU SANS la clé
  shapeEditing : celle-ci ne conditionne que l'ÉDITION (cadenas, barre
  d'outils, poignées, panneau).

  ÉCRITURE : quand le mode édition est actif (clé shapeEditing, cadenas
  ouvert), chaque modification de l'opérateur (ajout, déplacement, retouche,
  rotation, apparence, nom, propriétés, suppression) réécrit la propriété
  avec TOUTES les formes du plan affiché.

  GARDE ANTI-ÉCHO : une valeur lue identique à la dernière valeur écrite par
  l'objet est ignorée (Panorama renvoie à l'objet ce qu'il vient d'écrire ;
  sans cette garde, la forme en cours de déplacement serait désélectionnée à
  chaque mouvement).

{
  "node_id": 11,
  "planIndex": 1,
  "filename": "Images/planA.jpg",
  "shapes": [
    { "id": 3001, "type": "polygon",
      "points": [[0.10, 0.20], [0.35, 0.20], [0.30, 0.45]],
      "fill": "rgba(220,38,38,0.18)", "stroke": "#dc2626", "strokeWidth": 2,
      "label": "Zone ATEX", "props": { "Local": "L12" },
      "show_mode": "always_with_animation",
      "elements": [1001, 1002] },
    { "id": 3002, "type": "circle", "cx": 0.62, "cy": 0.40, "r": 0.05,
      "show_mode": "always_without_animation" }
  ]
}

  node_id, planIndex, filename
      Plan concerné (§ 8). filename est informatif (fichier de la
      représentation) ; l'objet l'écrit toujours, ne l'exige pas en lecture.

  shapes  tableau de formes. Schéma d'une forme = celui des calques "shapes"
      de la V1 (type, coordonnées en fraction du plan, fill, stroke,
      strokeWidth, label, rotation, heads, fontSize / bold / italic / boxed,
      value / unit / shown pour l'étalon, etc. — détail complet dans le
      annexe A en fin de document), plus les clés V2 :
        id         entier >= 1, unique dans le plan. En lecture, une forme
                   sans id valide reçoit un id attribué par l'objet ; en
                   écriture, toute nouvelle forme dessinée reçoit le plus
                   grand id du plan + 1 (l'application peut le remplacer en
                   réécrivant la propriété).
        show_mode  règle d'affichage (§ 6.3), défaut
                   "always_without_animation". Réglable dans la section
                   « Affichage » du panneau du mode édition.
        elements   tableau d'ids de capteurs (§ 8) LIÉS à la forme. Une
                   forme est en alarme si l'un d'eux l'est. En lecture, la
                   liste de l'application est conservée telle quelle ; à la
                   création d'une forme fermée (polygone, rectangle, cercle,
                   ellipse, secteur) et à chaque modification de sa
                   GÉOMÉTRIE (déplacement, poignées, rotation), l'objet la
                   recalcule : ids des capteurs du plan situés dans la forme
                   (les tracés ouverts, textes, icônes et punaises n'en ont
                   pas : []). Indiquée dans l'indicateur « Capteurs couverts »
                   du mode édition.
        props      objet { nom: valeur } de propriétés libres.
      En écriture, les cotes portent en plus distance (texte affiché) et
      l'étalon planWidthValue (ignorées en lecture), comme en V1.


10 bis. current_plan_scene3d_json — SCÈNE DE LA REPRÉSENTATION 3D AFFICHÉE
--------------------------------------------------------------------------------
Propriété à DOUBLE SENS, pendant de current_plan_drawnShapes_json pour les
représentations 3D (type "model") : un document JSON par plan, qui décrit
tout ce que l'opérateur ajoute au modèle .obj en mode édition. Même
mémorisation par plan (node_id + planIndex fournis ensemble, sinon le plan
affiché ; mémoire vidée à la reconstruction), même remplacement intégral en
lecture (l'application fait foi), même écriture de TOUT le document à
chaque modification de l'opérateur (cadenas ouvert), même garde anti-écho.
Vide = scène vide (cadrage automatique, rien d'ajouté).

{
  "node_id": 121,
  "planIndex": 1,
  "filename": "Images/RB_SP_MD_011.obj",
  "serial": 3,
  "unit": "m",
  "scale": null,
  "camera": { "position": [150, 95, -170], "target": [0, 15, 0] },
  "north": { "angle": 30, "shown": true, "x": null, "z": null },
  "footprint": null,
  "floorImage": null,
  "measures": [],
  "objects": [],
  "zones": []
}

  node_id, planIndex, filename, serial
      Comme au § 10 (serial : compteur croissant des écritures de l'objet,
      ignoré en lecture).
  unit      unité réelle des longueurs du plan (défaut "m"), saisie dans le
            panneau « Scène 3D » ; sert aux mesures (étalon, cotes,
            surfaces) et aux objets ajoutés.
  scale     ÉCHELLE DU MODÈLE : { "value": v, "x1", "z1", "x2", "z2",
            "length", "shown" } où v est la longueur réelle (en unit) d'UNE
            unité du fichier .obj, et (x1, z1)-(x2, z2) l'ÉTALON tracé au
            sol par l'outil « Étalon » (2 clics), de longueur réelle length
            (saisie dans la section Étalon du panneau : value = length /
            longueur du segment en unités). Sans segment, value seule
            suffit ; sans value, length et le segment la déduisent ; sinon
            l'échelle est ignorée (avertissement). null = échelle inconnue :
            les mesures s'affichent en unités du modèle (« u »). shown faux
            masque l'étalon hors édition sans cesser d'étalonner.
  camera    VUE PAR DÉFAUT : position et cible de la caméra dans le repère
            du modèle (unités du fichier), ou null = cadrage automatique du
            modèle entier. Appliquée à l'ouverture du plan et par le bouton
            ↻ de la barre de zoom (qui affiche alors 100 %). En mode
            édition, le panneau « Scène 3D » propose « Définir la vue
            actuelle » (la caméra courante — orientation, zoom, cible —
            devient la vue par défaut, écrite aussitôt) et « Vue
            automatique » (camera null). Une clé camera incomplète vaut
            null (avertissement).
  north     NORD DU PLAN : { "angle", "shown", "x", "z" } — angle en degrés,
            sens horaire vu de dessus, 0 = axe -z du modèle ; shown (vrai)
            affiche la FLÈCHE NORD au sol (rouge, étiquette « N ») ; x / z :
            position de la flèche au sol (null = coin nord-est du modèle,
            en retrait ; renseignés dès que l'opérateur la déplace). Un
            nombre seul vaut { "angle" }. null ou absent = NORD INCONNU : le
            repère de coin n'a pas de rose des vents et la vue en plan met
            l'axe -z en haut (§ 10 ter). Une clé north sans angle fini vaut
            null (avertissement). Le nord oriente le repère, la vue en
            plan, les exports et leur en-tête.
  footprint EMPRISE AU SOL (marquage de la délimitation du plan) : polygone
            { "points": [[x, z], …] } d'au moins 3 sommets, en unités du
            modèle sur le plan du sol (face inférieure de la boîte
            englobante du modèle), avec stroke (couleur #rrggbb du contour,
            défaut "#1d4ed8"), strokeWidth (épaisseur du contour en unités
            du modèle ; null / absente = 0,4 % de la plus grande dimension
            au sol), dashed (pointillés, vrai par défaut), fill et
            fillOpacity (remplissage, défaut "#1d4ed8" et 0.12), altitude
            (hauteur au-dessus du sol, 0) et shown (vrai par défaut ; faux :
            invisible hors édition, estompée cadenas ouvert). Une seule
            emprise par plan ; null = aucune. Moins de 3 sommets valides :
            ignorée (avertissement).
  floorImage FOND DE PLAN : image PNG / JPG / SVG posée au sol, { "filename"
            (obligatoire, chemin relatif au dossier de l'objet), "x", "z"
            (centre, défaut 0), "width" (largeur au sol en unités du modèle ;
            null = moitié de la plus grande dimension du modèle), "height"
            (null = rapport hauteur / largeur de l'image), "rotation"
            (degrés, sens horaire vu de dessus, le haut de l'image regardant
            vers -z), "opacity" (0.85), "altitude" (0), "shown" (vrai) }.
            Un seul fond de plan par plan ; null = aucun. L'image est
            rastérisée en texture (les SVG y compris) ; introuvable, ou
            image locale refusée par WebGL en file://, le plan reste gris à
            sa place (avertissement en console).
  measures  MESURES au sol : tableau de { "id" (entier, attribué si absent),
            "type": "distance" (polyligne, 2 points au moins : longueur
            cumulée) ou "area" (polygone, 3 sommets au moins : aire),
            "points": [[x, z], …], "label" (préfixe de l'étiquette),
            "shown" }. L'étiquette 3D (sprite à taille écran constante)
            affiche « libellé : 12,50 m » selon l'échelle (« 12,50 u » sans
            échelle ; aire en m²). Type inconnu ou points insuffisants :
            mesure ignorée (avertissement).
  objects   OBJETS 3D AJOUTÉS : tableau de { "id" (attribué si absent),
            "filename" (obligatoire : .obj, .glb ou .gltf), "label", "x",
            "z" (point de pose au sol), "altitude" (0), "rotation" (degrés,
            sens horaire vu de dessus), "size" (plus grande dimension réelle
            en unit, défaut 1), "scale" (facteur supplémentaire, 1, borné à
            100), "color" (#rrggbb, ou null = matériaux du fichier),
            "shown" }. L'objet est chargé une fois par page (gabarit centré
            au sol), puis posé à sa taille réelle : size est converti en
            unités du modèle par l'échelle du plan (clé scale ; sans échelle,
            size est pris en unités du modèle), et multiplié par scale — les
            objets restent ainsi à l'échelle du bâtiment et entre eux. En
            attendant le fichier, ou s'il est illisible, un pavé gris (rouge
            en cas d'échec) tient la place. Objet sans fichier : ignoré
            (avertissement).
  zones     ZONES DU BÂTIMENT (découpage du modèle en volumes nommés, pour
            les mettre en évidence et les animer) : tableau de { "id",
            "label" (défaut « Zone n »), "description" (texte de la carte au
            survol), "points": [[x, z], …] (VOLUME TRACÉ : polygone au sol de
            3 sommets au moins, extrudé de baseHeight à baseHeight + height —
            unités du modèle), "baseHeight" (0), "height" (10), "color"
            (#rrggbb, défaut "#f59e0b"), "opacity" (0.35 : remplissage au
            survol et en alarme), "group" (nom d'un maillage du modèle —
            ligne o / g du .obj, nœud du glTF — : la zone est alors LIÉE À CE
            GROUPE, sans prisme, et c'est lui qui se colore ; null sinon),
            "show_mode" (§ 6.3 : always_without_animation = visible au survol
            seulement ; always_with_animation = CLIGNOTE dans sa couleur tant
            qu'un capteur lié est en alarme ; masked = jamais affichée ni
            survolable hors édition), "elements" (ids de capteurs liés, § 8 :
            l'état d'alarme vient de configuration_events_json, à chaud),
            "shown" }. Hors édition, une zone est invisible (mais reste sous
            le pointeur, en alarme ou non) ; au SURVOL, elle prend sa couleur
            et une carte contextuelle (libellé, description, capteurs en
            alarme) suit le pointeur ; un CLIC écrit
            eventsDetailRequest_json { "source": "zone", "zone_id", "node_id",
            "planIndex", "label", "elements", "serial" } (§ 11). Zone sans
            groupe ni 3 sommets valides : ignorée (avertissement).

Mode édition 3D : le cadenas est celui des formes 2D (clé shapeEditing ;
visible sur un modèle 3D comme sur un plan image). Ouvert sur un modèle, la
barre d'outils partagée bascule sur ses outils 3D et le panneau « Scène 3D »
remplace le panneau « Apparence / Propriétés » :

  Navigation    OrbitControls (glisser : rotation ; molette : zoom ; clic
                droit : déplacement). Un CLIC (sans glisser) sur l'emprise ou
                le fond de plan le sélectionne (section dédiée du panneau,
                poignées), un clic ailleurs désélectionne ; l'entité
                sélectionnée se déplace en la faisant glisser.
  Emprise       un clic par sommet sur le sol ; fermeture par clic sur le
                premier sommet (poignée blanche), double-clic ou Entrée ;
                Échap annule. Remplace l'emprise existante. Sélectionnée :
                poignées de sommets (glisser), section Emprise (contour,
                épaisseur, pointillés, fond, opacité, altitude, Afficher).
  Fond de plan  un clic sur le sol pose l'image centrée à cet endroit (premier
                fichier de la clé editFloorImages, ou chemin saisi dans le
                panneau). Sélectionné : poignées de coins (taille, rapport
                conservé), poignée ambre (rotation), glisser (déplacement) ;
                section Fond de plan (galerie, fichier, largeur, rotation,
                opacité, altitude, centre X / Z, Afficher, « Ajuster à
                l'emprise » : centre et dimensionne l'image sur le rectangle
                englobant de l'emprise).
  Étalon        deux clics au sol sur une longueur connue : le segment
                (ruban ambre à bouts perpendiculaires) est créé et
                sélectionné, sa longueur réelle est préremplie selon
                l'échelle en vigueur (ou en unités) ; la corriger dans la
                section Étalon (longueur, unité, Afficher) étalonne toutes
                les mesures du plan. Un seul étalon par plan (remplacé).
  Distance      un clic par point au sol, double-clic ou Entrée pour
                terminer : polyligne violette avec sa longueur cumulée en
                étiquette (section Mesure : libellé, Afficher).
  Surface       un clic par sommet, fermeture comme l'emprise : polygone
                violet (remplissage, contour pointillé) avec son aire au
                centre.
  Objet 3D      choisir l'objet dans la galerie « Objet à poser » du panneau
                (clé editModels), puis un clic sur le sol le pose, centré à
                cet endroit, à sa taille réelle. Sélectionné (clic sur son
                corps) : cercle de pied, poignée ambre (rotation autour de la
                verticale), poignée verte (taille : le facteur suit la
                distance au centre), glisser (déplacement) ; section Objet 3D
                (galerie, fichier, libellé, taille réelle, facteur, rotation,
                altitude, centre X / Z, couleur ou matériaux du fichier,
                Afficher).
  Zone          un clic par sommet au sol, fermeture comme l'emprise : le
                volume (hauteur par défaut = moitié de celle du modèle) est
                créé et sélectionné ; cadenas ouvert, les zones apparaissent
                en prismes translucides. Section Zone : libellé, description,
                base / hauteur, couleur, opacité, groupe du modèle (liste des
                maillages nommés ; « Volume tracé » sinon), règle
                d'affichage, capteurs liés (ids séparés par des virgules),
                Afficher.
  Supprimer     retire l'entité sélectionnée (touche Suppr aussi). Un clic
                sur le tracé d'un étalon ou d'une mesure, sur le corps d'un
                objet ou sur une zone, le sélectionne (poignées à glisser).
  Flèche nord   (clé north) la section générale du panneau porte « Nord (°) »
                (vide = inconnu ; saisir un angle crée la flèche à sa place
                par défaut) et « Flèche nord au sol ». Un clic sur la flèche
                la sélectionne (section Flèche nord : angle, centre X / Z,
                Afficher) ; glisser la flèche la déplace, la poignée ambre
                l'oriente (angle arrondi au degré) ; Suppr remet le nord à
                inconnu (north null).


10 ter. REPÈRE D'ORIENTATION, VUE EN PLAN ET EXPORTS PNG / SVG
--------------------------------------------------------------------------------
Sur une représentation 3D (type "model"), en consultation comme en édition :

  Repère d'orientation (viewer-scene3d-helper.js, clé orientationHelper)
      Cadran SVG en bas à gauche du cadre 3D, redessiné à chaque mouvement de
      la caméra : trièdre X (rouge) / Y (vert, vertical) / Z (bleu) du
      fichier .obj, demi-axes négatifs en creux, arrière estompé ; rose des
      vents N / E / S / O au sol selon la clé north de la scène (absente si
      le nord est inconnu), N en rouge. Cliquable : N / E / S / O placent la
      caméra face à ce côté (vue plongeante à 20°), X / Z depuis l'axe
      positif, Y = vue de dessus (nord en haut) ; cible et distance
      conservées, transition de 400 ms (immédiate si le système demande
      moins d'animations). Le bouton « repère » en bout de barre de zoom
      l'affiche ou le masque (état valable le temps de la page, réinitialisé
      à chaque nouvelle configuration ; état initial selon
      orientationHelper). Espace écran : jamais dans les exports ni les
      impressions.

  Vue en plan (viewer-scene3d-planview.js, clé showPlanViewButton)
      Bouton « Vue en plan » en bout de barre de zoom → menu : « Afficher la
      vue en plan » / « Revenir à la vue 3D », « Exporter en PNG », « Exporter
      en SVG », « Exporter en SVG (coupe) », et une indication (nord en haut
      à x°, ou nord inconnu : axe -z en haut). La vue en plan est une VUE DE
      DESSUS ORTHOGRAPHIQUE (sans perspective) du même rendu : la caméra
      glisse vers la verticale puis une caméra orthographique prend le
      relais, le haut de l'écran étant le nord ; glisser (bouton gauche)
      déplace, la molette et les boutons − / + zooment (100 % à l'entrée),
      la rotation est désactivée ; la puce « 3D | Vue en plan » en haut à
      gauche indique le mode. Le bouton ↻, une direction du repère de coin
      (sauf Y) ou le changement de représentation ramènent à la 3D (vue
      d'avant). Le mode édition reste utilisable en vue en plan (tracés au
      sol plus commodes) ; une vue par défaut reçue ou définie pendant la
      vue en plan est mémorisée sans être appliquée. Rien n'est écrit dans
      les propriétés.

  Export PNG (viewer-scene3d-export.js, clé planExport.pngScale)
      Fichier plan-<lieu>-<aaaammjj>-<hhmm>.png téléchargé (téléchargement
      déclenché par le clic de l'opérateur : autorisé par le bac à sable de
      l'IHM Web, comme le PDF de l'impression). Contenu : la vue en plan
      cadrée sur TOUTE LA SCÈNE (modèle, emprise, fond de plan, étalon,
      mesures, objets, zones tracées, flèche nord), rendue à pngScale
      pixels par pixel écran du cadre, sans poignées ni tracé en cours,
      entités masquées absentes, zones visibles comme en édition (sauf
      masked, et zones liées à un groupe : maillage coloré), sous un en-tête
      (fil d'Ariane, libellé de la représentation, « vue en plan (nord en
      haut, x°) », date et heure). L'objet passe en vue en plan s'il n'y est
      pas et y reste ; le cadrage de l'opérateur est rendu après la capture.

  Export SVG (viewer-scene3d-export-svg.js)
      Fichier plan-<lieu>-<date>.svg : même cadrage et même en-tête ; le
      modèle seul est rendu de dessus, sans fond, et inclus en <image> PNG
      base64 (groupe model) ; le fond de plan est inclus en <image>
      (texture du rendu en base64, ou chemin relatif si le navigateur refuse
      la lecture du canvas — image locale en file://) ; emprise, zones
      tracées (non masquées, avec leur libellé), étalon, mesures, objets
      (cercle de pied + libellé), flèche nord et étiquettes sont des VECTEURS
      dans des groupes nommés (footprint, zones, scale, measures, objects,
      north) ; barre d'échelle (1-2-5 × 10^n) si l'échelle est connue. La
      racine porte data-location, data-model, data-unit, data-scale-value
      (longueur réelle d'une unité du modèle), data-north, data-px-per-unit
      et data-plan-width (largeur réelle du dessin) : pour réemployer le
      fichier comme représentation 2D du nœud (§ 7, clé plans), le déposer
      dans Images\ et déclarer scale = { value: data-plan-width, unit }.
      Les capteurs ne figurent pas dans les exports (ils ne sont pas posés
      sur les représentations 3D).

  Export SVG « coupe » (viewer-scene3d-export-cut.js, clé planExport.cutHeight)
      Fichier plan-<lieu>-<date>.coupe.svg : comme le SVG, mais le modèle
      est remplacé par sa COUPE HORIZONTALE VECTORIELLE à cutHeight au-dessus
      du sol (unités réelles ; en unités du modèle sans échelle ; au plus
      90 % de la hauteur du modèle) : chaque triangle des maillages du
      fichier traversé par ce plan donne un segment, dédoublonnés puis
      chaînés en polylignes dans un <path> (groupe model, classe cut,
      attributs data-cut-height / data-cut-lines / data-cut-points). Plan
      « d'architecte » léger dont la qualité dépend du maillage (un modèle
      sans murs intérieurs ne donne que son contour) ; le sous-titre de
      l'en-tête précise « coupe à 1,20 m du sol ». Les objets ajoutés
      restent des cercles de pied.


11. PROPRIÉTÉS ÉCRITES PAR L'OBJET
--------------------------------------------------------------------------------
selectedNodePath
      Objet JSON écrit à chaque sélection d'un nœud (arbre ou vue épinglée),
      à chaque reconstruction (désélection) et, en mode sans navigation, à
      l'affichage du plan racine :

        { "id": 11,
          "parent_id": 1,
          "path": "Site Sud — Bâtiment A",
          "labels": ["Site Sud", "Bâtiment A"],
          "planIndex": 1,
          "filename": "Images/planA.jpg",
          "serial": 4 }

        id, parent_id  identifiants du nœud (§ 6.1). id 0 : aucun nœud
                       (mode sans navigation : plan racine ; planIndex 0 :
                       aucune sélection après une reconstruction).
        path, labels   fil d'Ariane, joint par « — » et sous forme de
                       tableau. Avec id 0 : [title] quand un plan racine
                       est affiché (mode sans navigation) ; vides sinon
                       (aucune sélection, ou configuration sans arbre ni
                       plan).
        planIndex      1 si une représentation est affichée (un nœud n'en
                       porte qu'une, § 7) ; 0 si le nœud n'en a aucune.
        filename       fichier de la représentation affichée ("" sinon).
        serial         compteur croissant : deux sélections identiques
                       successives sont distinguées sans remise à zéro côté
                       application.

eventsDetailRequest_json
      Objet JSON écrit à chaque clic de l'opérateur :
        sur un capteur du plan (cadenas fermé ou mode édition inactif) :
          { "source": "element", "element_id": 1001, "node_id": 11,
            "planIndex": 1, "label": "Détecteur fumée D12", "serial": 3 }
        sur un badge d'événements du bandeau :
          { "source": "badge", "node_id": 11, "path": "Site Sud — Bâtiment A",
            "priority": 1, "count": 3, "serial": 4 }
        sur une zone d'une représentation 3D (§ 10 bis, hors édition) :
          { "source": "zone", "zone_id": 1, "node_id": 121, "planIndex": 1,
            "label": "Aile Ouest", "elements": [1001], "serial": 5 }
      serial est un compteur commun croissant. C'est à l'application
      d'ouvrir le détail ; l'objet ne fait que transmettre la demande.

current_plan_drawnShapes_json : voir § 10.
current_plan_scene3d_json : voir § 10 bis.


12. INSERTION DE L'OBJET DANS UNE IHM
--------------------------------------------------------------------------------
1. Enregistrer le descripteur de classe et recharger la configuration.
2. Dans l'éditeur de synoptique, insérer une instance de la classe
   utilisateur CU_WEB_PlanViewerV2 à l'emplacement souhaité.
3. Dimensionner l'objet : il occupe toute la surface allouée (bandeau 56 px
   de haut, drawer ouvert 300 px de large).
4. Renseigner configuration_plan_json (§ 7) et, si besoin,
   configuration_events_json (§ 9).
5. Raccorder selectedNodePath à un traitement de l'application qui, à chaque
   nouvelle valeur (serial), écrit current_plan_element_json (§ 8),
   current_plan_drawnShapes_json (§ 10) et, pour un modèle 3D,
   current_plan_scene3d_json (§ 10 bis) pour le couple id / planIndex reçu.
6. Raccorder eventsDetailRequest_json à l'ouverture du détail (capteur ou
   nœud / priorité selon la clé source).
7. Si le mode édition est utilisé, relire current_plan_drawnShapes_json et
   current_plan_scene3d_json à chaque écriture de l'objet pour persister les
   formes et la scène 3D (l'objet ne les conserve que le temps de la page).
8. Enregistrer, puis démarrer / redémarrer l'application pour que le serveur
   d'IHM Web prenne en compte les nouveaux fichiers.


13. VÉRIFICATION (cahier de recette)
--------------------------------------------------------------------------------
Le banc demo.html (double-clic, § 14) permet de dérouler ces points sans
Panorama : il pousse les cinq propriétés lues et affiche les écritures.
« node tests\bench-demo.js » les rejoue automatiquement dans Chrome
(puppeteer-core, 160 assertions).

Arbre et identifiants (configuration_plan_json, exemple du § 7)
- Le bandeau affiche title, les badges fixes et le bouton drawer ; la zone
  des plans affiche « Sélectionnez un élément avec un plan ».
- Ouvrir le drawer : les deux vues épinglées de l'exemple (id 221 et 111)
  sont listées ; l'arbre montre Site Sud / Site Nord.
- Cliquer « Bâtiment A » : le fil d'Ariane affiche « Site Sud — Bâtiment
  A », le plan s'affiche, et selectedNodePath reçoit { id: 11, parent_id: 1,
  path: "Site Sud — Bâtiment A", labels: [...], planIndex: 1, filename:
  "Images/planA.jpg", serial: n }.
- « RDC batD » porte dans l'arbre le petit cube bleu « Représentation 3D » ;
  le cliquer affiche le modèle dans le cadre Three.js, et selectedNodePath
  porte planIndex 1 et filename "Images/RB_SP_MD_011.obj".
- Jeu « Cas limites » : « Quatre plans » n'affiche que « Plan 1 » et
  l'info-bulle « i » signale les représentations ignorées.
- Cliquer « Niv1 batA » (sans plan) : la zone des plans affiche « Aucune
  représentation disponible / Sélectionnez un élément avec un plan » ;
  selectedNodePath reçoit planIndex 0, filename "". Dans l'arbre, la ligne
  porte l'indicateur discret « sans plan » (image barrée rouge), que la clé
  showNoPlanIndicator: false masque.
- Cliquer la vue épinglée « Site Nord Niv1 batD » : le nœud 221 est
  sélectionné dans l'arbre (parents dépliés), selectedNodePath porte id 221,
  parent_id 22.
- Bouton « + » du bandeau : un signet vers le nœud courant s'ajoute (pas de
  doublon) ; réécrire configuration_plan_json : le signet survit si son id
  existe encore.
- Un nœud sans id, ou un id en doublon, disparaît avec sa descendance ; la
  ligne de contrôle du banc (ou l'info-bulle « i ») liste l'avertissement.
  De même pour une vue épinglée visant un id inconnu.
- Réécrire configuration_plan_json en ne changeant que badges : mise à jour
  à chaud (sélection, zoom et drawer conservés) ; tout autre changement
  reconstruit l'objet et selectedNodePath reçoit id 0 / planIndex 0 (sauf
  valeur vide ou invalide : reconstruction en état d'erreur, sans écriture,
  voir § 7).

Alarmes (configuration_events_json, exemple du § 9)
- Avec l'arbre du § 7 : « Site Sud » replié porte une pastille rouge
  (priorité 1 sur 11, remontée via parent_id) ; déplié, « Bâtiment A » est
  rouge et « Bâtiment D » ambre (priorité 2 sur 122) ; « Bâtiment D » déplié
  n'a plus de pastille et « Niv1 batD » est ambre.
- Sélectionner « Site Sud » : badges 1 (rouge) et 3 (ambre) ; « Bâtiment
  A » : 1 (rouge) seul ; « Niv1 batD » : 3 (ambre).
- Cliquer le badge rouge : eventsDetailRequest_json reçoit { source:
  "badge", node_id: 1, path: "Site Sud", priority: 1, count: 1, serial: 1 }.
- Réécrire configuration_events_json avec d'autres count : pastilles et
  badges suivent, sans que la sélection, le plan, le zoom ni le drawer ne
  bougent. Valeur vide : plus aucune pastille ni badge d'événement.
- Les événements avec un node_id inconnu ne produisent ni pastille ni
  badge ; un id d'événement en doublon produit un avertissement.

Capteurs (current_plan_element_json, exemple du § 8 ; dans le banc, la
« réponse automatique » les pousse à chaque sélection)
- Sélectionner « Bâtiment A » : les capteurs non "masked" apparaissent sur
  le plan — pastille ronde (sans clé icon) ou image (clé icon), à la taille
  size (pixels à 100 % de zoom), au-dessus des calques image. Un capteur
  "masked" n'apparaît jamais, même en alarme.
- Zoomer / déplacer le plan : les capteurs suivent exactement.
- Cliquer le bouton imprimante en bout de barre de zoom : un menu propose
  « Plan entier » et « Vue affichée » (cette dernière inactive tant que le
  plan n'est ni zoomé ni déplacé ; Échap ou un clic à l'extérieur referme
  le menu). Le choix ouvre le dialogue d'impression du navigateur avec le
  seul plan, ses calques visibles, ses capteurs et un en-tête (fil
  d'Ariane, libellé, date/heure), sur une page orientée selon le plan. Le
  bouton disparaît sur une représentation 3D (« RDC batD ») et si
  showPrintButton vaut false. Si le dialogue ne s'ouvre pas et qu'un
  message rouge « Impression bloquée par l'application hôte » apparaît,
  le cadre de l'objet interdit window.print() (§ 14).
- Survoler un capteur : une carte affiche son libellé et ses propriétés
  (clé props) ; elle disparaît à la sortie ou au zoom/déplacement.
- Cliquer un capteur (mode édition inactif ou cadenas fermé) :
  eventsDetailRequest_json reçoit { "source": "element", "element_id",
  "node_id", "planIndex", "label", "serial" } ; deux clics successifs
  donnent deux serial différents. Cadenas ouvert : le clic va aux outils.
- Alarmes (configuration_events_json, clé element_id) sur un capteur
  "always_with_animation" (défaut) : avec une clé icon_alarm, l'image
  bascule ; sans, la représentation par défaut se souligne d'un halo animé
  de la couleur de l'événement le plus important. Un capteur
  "always_without_animation" ne change pas. Réécrire la propriété : l'état
  suit À CHAUD, sans reconstruire le calque (le survol en cours ne saute
  pas) ; valeur vide : plus aucun capteur en alarme.
- Mode édition, tracé d'une forme fermée : les capteurs couverts sont
  soulignés d'un anneau bleu et listés dans l'indicateur « Capteurs
  couverts » ; leurs ids remplissent la clé elements de la forme écrite
  dans current_plan_drawnShapes_json.

Formes (current_plan_drawnShapes_json en lecture ; dans le banc, la
« réponse automatique » pousse celles de « Bâtiment A », plan 1)
- Sélectionner « Bâtiment A » (clé shapeEditing indifférente) : les formes
  reçues s'affichent selon leur show_mode — le cercle « toujours
  affichée » ; le polygone « sur alarme », lié au capteur 1001, visible
  avec un halo pulsé de la couleur de l'événement tant que 1001 est en
  alarme ; le rectangle « masquée », jamais visible cadenas fermé.
- Vider configuration_events_json : le polygone disparaît, À CHAUD ;
  restaurer les événements : il réapparaît.
- Une forme sans id valide en reçoit un (après le plus grand id reçu) ; un
  id en doublon est ré-attribué, avec un avertissement (info-bulle « i »).
  Une forme incomplète ou de type inconnu est ignorée (avertissement).
- Avec "shapeEditing": true et le cadenas ouvert : TOUTES les formes sont
  visibles — celles invisibles cadenas fermé en contour fantôme
  pointillé —, sélectionnables et retouchables comme des formes dessinées
  (apparence, poignées, rotation, nom, propriétés). La section
  « Affichage » du panneau règle la clé show_mode de la forme
  sélectionnée.
- Liaison elements : un changement d'APPARENCE (couleur, nom, propriétés,
  show_mode) conserve la liste posée par l'application ; un changement de
  GÉOMÉTRIE (déplacement, poignées, rotation, champs secteur) d'une forme
  FERMÉE la recalcule (capteurs couverts). Chaque modification réécrit
  toutes les formes du plan avec leurs clés id, show_mode et elements.
- La valeur que l'objet vient d'écrire lui revient par l'abonnement
  (écho Panorama) : elle est ignorée (ligne « écho de la dernière
  écriture » dans l'info-bulle « i » / le panneau du banc).

Mode édition (écriture de current_plan_drawnShapes_json)
- Avec "shapeEditing": true, ouvrir le cadenas, dessiner un rectangle : la
  propriété reçoit { node_id: 11, planIndex: 1, filename: "Images/planA.jpg",
  shapes: [ { type: "rect", ..., elements: [...] } ] } — elements liste les
  ids des capteurs du plan couverts par le rectangle ([1001, 1002] dans le
  jeu du banc s'il les recouvre, [] sinon). Changer de représentation puis
  revenir : les formes réapparaissent.
- Tous les outils, le panneau, la rotation, l'étalon et les cotes se
  comportent comme en V1 : description en annexe B, recette en annexe C.

Messages de la zone des plans
    « En attente de configuration_plan_json… »  l'abonnement n'a rien reçu :
        vérifier que la propriété est déclarée dans le descripteur (§ 5).
    « configuration_plan_json est vide. »       la propriété n'a pas de
        valeur : la renseigner (§ 7).
    « configuration_plan_json : JSON invalide » la chaîne n'est pas un objet
        JSON valide ; le détail figure dans la console du navigateur.
    « Sélectionnez un élément avec un plan »    JSON valide, aucun élément
        sélectionné.
    <chemin d'un élément>                       l'élément sélectionné n'a
        aucune représentation.
- Si l'objet apparaît estompé, la connexion au serveur d'IHM Web est perdue.

Scène 3D (current_plan_scene3d_json, § 10 bis)
- Cocher « édition de formes », cliquer « RDC batD » (modèle 3D) : la
  réponse automatique pousse une vue par défaut ; la caméra s'y place et le
  cadenas est visible en haut à droite.
- Ouvrir le cadenas : la barre montre l'outil « Navigation » (outils 2D
  masqués) et le panneau « Scène 3D » indique « Vue enregistrée ».
- Tourner / zoomer le modèle : le panneau signale que la vue actuelle
  diffère ; « Définir la vue actuelle » écrit la propriété (node_id 121,
  planIndex 1, serial, unit, camera) ; l'écho est ignoré ; le bouton ↻
  revient à cette vue (100 %).
- « Vue automatique » écrit camera null et recadre le modèle entier.
- Pousser une scène avec une autre camera (éditeur current_plan_scene3d_json,
  « Appliquer (lecture) ») : la caméra s'y place ; avec le node_id d'un
  autre plan, la scène est mémorisée sans effet ; avec une camera
  incomplète, avertissement et vue automatique.
- Fermer le cadenas : barre et panneau disparaissent ; sur un plan 2D, le
  cadenas et la barre reviennent en mode 2D.

Repère d'orientation, vue en plan et exports (§ 10 ter)
- « RDC batD » (modèle 3D) : le cadran du repère est en bas à gauche (X / Y
  / Z et N / E / S / O, le nord du jeu d'essai étant à 30°) et le bouton
  « repère » de la barre de zoom est enfoncé ; sur un plan 2D, ni cadran ni
  bouton. Cliquer N : la caméra se place au sud, face au nord ; cliquer Y :
  vue de dessus. Le bouton masque puis réaffiche le cadran.
- Cadenas ouvert : la section « Repère d'orientation » du panneau montre
  Nord 30 et « Flèche nord au sol » coché ; saisir 90 écrit north
  { angle 90, shown true, x null, z null } ; en vue de dessus (reculer de
  deux crans), un clic sur la flèche rouge (coin nord-est du modèle) la
  sélectionne (section Flèche nord, poignée ambre) ; glisser la poignée
  vers le sud écrit angle 180 ; saisir un centre X l'écrit avec le z par
  défaut ; Suppr écrit north null (cadran sans rose des vents, flèche
  retirée, champ Nord vide).
- Pousser { "north": 45 } : rose des vents et flèche reviennent ; { "north":
  { "shown": true } } : avertissement, nord inconnu. orientationHelper
  "none" : ni bouton ni cadran ; "hidden" : bouton seul, non enfoncé ;
  valeur inconnue : avertissement, shown.
- Bouton « Vue en plan » → « Afficher la vue en plan » : vue de dessus sans
  perspective, nord en haut, puce « Vue en plan », 100 % ; + donne 130 % ;
  glisser déplace sans tourner ; cliquer N du repère ou ↻ ramène à la 3D
  (↻ : vue par défaut, 100 %). Le cadenas ouvert en vue en plan y reste et
  la flèche nord s'y sélectionne au clic ; un plan 2D puis retour au
  modèle : 3D en perspective. showPlanViewButton false : ni bouton ni
  puce. Nord inconnu : le menu l'indique ; Échap ferme le menu.
- « Exporter en PNG » : passage en vue en plan, fichier plan-site-sud-
  batiment-d-rdc-batd-<date>.png (2 × le cadre + en-tête de 92 px) montrant
  toute la scène, flèche nord comprise, en-tête blanc avec le fil d'Ariane ;
  cadrage rendu ensuite (cible d'origine, 100 %) ; pendant l'export les
  poignées disparaissent et les zones sont visibles ; planExport.pngScale 1
  donne la taille du cadre (+ 46 px), 9 : avertissement et 2.
- « Exporter en SVG » : fichier .svg s'ouvrant dans le navigateur : en-tête,
  fond de plan, image du modèle (transparente hors du bâtiment), emprise,
  zone « Aile Ouest », étalon 60,00 m, mesures, cercle « Cuve », flèche N,
  barre d'échelle 10,00 m ; racine data-north="30", data-scale-value,
  data-plan-width. Sans nord ni échelle : attributs vides, ni barre ni
  flèche, sous-titre « nord inconnu ».
- « Exporter en SVG (coupe) » : fichier .coupe.svg dont le modèle est un
  <path> de murs (centaines de points), fond de plan et flèche conservés,
  sous-titre « coupe à 1,20 m du sol » ; planExport.cutHeight 3 coupe à 3 m
  (9,58 unités), -1 : avertissement et 1,2.

Emprise au sol et fond de plan (§ 10 bis)
- « RDC batD » : la scène du jeu d'essai montre une emprise en pointillés
  bleus autour du bâtiment et le Plan D posé au sol, cadenas fermé comme
  ouvert (sans poignées cadenas fermé).
- Cadenas ouvert, outil « Emprise » : un clic par sommet sur le sol
  (curseur de visée), ligne élastique, poignées de sommets ; Entrée ferme :
  la propriété est écrite avec footprint (sommets, pointillés, contour par
  défaut) et l'emprise est sélectionnée (section Emprise, 4 poignées,
  Supprimer actif).
- Section Emprise : contour, pointillés, fond, opacité, altitude, Afficher
  sont écrits ; glisser un sommet le déplace sans faire tourner la caméra ;
  Suppr écrit footprint null.
- Clic sur le fond de plan : section Fond de plan (galerie editFloorImages,
  fichier, largeur 200), 5 poignées ; largeur et rotation saisies sont
  écrites et rendues ; la vignette SVG de la galerie remplace l'image
  (rastérisée) ; l'outil « Fond de plan » pose une nouvelle image au clic
  (premier fichier de la galerie, largeur automatique) ; « Ajuster à
  l'emprise » centre et dimensionne l'image sur l'emprise.
- Une emprise à 2 sommets ou un fond de plan sans fichier sont ignorés
  (avertissements dans l'info-bulle « i »).

Étalon et mesures (§ 10 bis)
- « RDC batD » : l'étalon du jeu d'essai (191,6 unités = 60 m) et deux
  mesures (« Façade : 30,00 m », « Parking : 156,90 m² ») sont étiquetés ;
  le panneau indique « Échelle : 1 unité du modèle = 0,31 m (étalon tracé) ».
- Outil Étalon, deux clics au sol : segment écrit (scale x1..z2), longueur
  préremplie selon l'échelle en vigueur ; saisir 50 : value 0,5 écrit et
  toutes les étiquettes sont recalculées.
- Outil Distance (3 points + Entrée) : mesure écrite (id suivant, type
  distance) avec sa longueur ; le libellé saisi précède la valeur. Outil
  Surface (4 sommets + Entrée) : aire écrite. Suppr ou le bouton Supprimer
  retire la mesure sélectionnée ; un clic sur un tracé le sélectionne
  (poignées).
- Étalon supprimé : scale null, les mesures passent en unités du modèle
  (« 95,80 u »), le panneau signale l'échelle inconnue.
- Un scale sans value ni étalon et une mesure de type inconnu sont ignorés
  (avertissements).

Objets 3D (§ 10 bis)
- « RDC batD » : la cuve du jeu d'essai (cuve.obj, 6 m, bleue) est posée à
  côté du bâtiment à l'échelle de l'étalon (facteur 9,58 sur un cylindre de
  2 unités).
- Outil Objet : la galerie « Objet à poser » liste les 4 objets de
  editModels ; choisir « Cube glTF » puis cliquer au sol : l'objet est écrit
  (id suivant, fichier .glb, taille 3, position du clic, color null), chargé
  par GLTFLoader (base64 en file://) avec ses matériaux, sélectionné (section
  Objet 3D, 2 poignées).
- Section Objet 3D : rotation 45 et facteur 2 écrits et rendus ; décocher
  « Fichier » et choisir une couleur l'applique ; la poignée verte glissée au
  double de son rayon double le facteur.
- Clic sur le corps de la cuve (après recul de la caméra) : sélectionnée
  (libellé, taille réelle et équivalent en unités) ; Suppr la retire.
- Un objet sans fichier est ignoré (avertissement), un id manquant est
  attribué, un facteur > 100 est borné ; cadenas fermé, les objets restent
  rendus sans poignées.

Zones (§ 10 bis)
- « RDC batD », cadenas fermé : la zone « Aile Ouest » (prisme sur l'aile
  ouest, capteur 1001 lié, en alarme dans le jeu d'essai) clignote en ambre ;
  la survoler la colore et affiche sa carte (libellé, description, « 1
  capteur en alarme ») ; la cliquer écrit eventsDetailRequest_json
  { source: "zone", zone_id: 1, … }.
- Survoler le bâtiment hors du prisme : la zone « Bâtiment entier », liée au
  groupe RB-SP-MD-011 du .obj, colore tout le modèle ; le pointeur sorti,
  le matériau d'origine est restauré.
- Vider configuration_events_json : la zone cesse de clignoter (à chaud) ;
  remettre l'alarme la fait repartir.
- Cadenas ouvert : prismes en fantôme ; outil Zone (4 sommets + Entrée) :
  zone écrite (id suivant, hauteur par défaut, libellé « Zone n »), section
  Zone avec la liste des groupes du modèle ; libellé, hauteur, capteurs et
  règle saisis sont écrits ; lier au groupe supprime le prisme ; Suppr
  retire la zone.
- Une zone sans groupe ni 3 sommets est ignorée (avertissement).


14. MISE AU POINT
--------------------------------------------------------------------------------
Scène 3D : depuis file:// (demo.html en double-clic hors banc), WebGL refuse
les images locales (fond de plan gris, avertissement en console) et fetch les
fichiers locaux (objets .obj / .glb chargés par leur <fichier>.js, sinon pavé
rouge) ; sous Panorama (HTTP) tout est servi normalement. Le banc puppeteer
lance Chrome avec --allow-file-access-from-files, ce qui lève ces deux limites.
Exports de la vue en plan (§ 10 ter) : en file://, le fond de plan du SVG est
référencé par son chemin relatif si le navigateur refuse la lecture de son
canvas (image locale) ; les fichiers PNG / SVG sont téléchargés par un lien
de téléchargement cliqué (autorisé par le bac à sable de l'IHM Web,
allow-downloads). Le rendu WebGL est créé avec un canal alpha : la capture du
modèle seul pour le SVG est transparente hors des maillages.

Console du navigateur (F12) : les échecs d'écriture, les erreurs d'analyse
des cinq propriétés lues, les échecs d'abonnement et les erreurs de
chargement de fichiers y sont tracés, préfixés « MyPnPlanViewerV2 : ». Les
AVERTISSEMENTS DE NORMALISATION (nœud sans id, id en doublon, vue épinglée
vers un id inconnu, clés V1 ignorées, capteur sans position...) sont tracés
par console.warn à chaque nouvelle valeur et listés, avec l'état de
réception de chaque propriété lue, en tête de l'info-bulle de l'icône « i »
en bas du drawer (clé showConfigInfo).

Banc de test demo.html : s'ouvre en double-clic (file://) sans Panorama ni
serveur Web. Un stub de la bibliothèque d'interfaçage simule Panorama ; le
banc pousse les cinq propriétés lues (jeux d'essai + éditeurs JSON), montre
les écritures de l'objet (selectedNodePath, eventsDetailRequest_json,
current_plan_drawnShapes_json) et simule des alarmes. Seule limite : la 3D
exige un serveur HTTP (module ES).

Encodage : chaînes affichées en ASCII pur (entités HTML dans index.html et
demo.html, échappements \uXXXX dans les .js), commentaires accentués admis
dans les .js, BOM UTF-8 partout ; fins de ligne CRLF pour les .js, app.css
et ce readme, LF pour index.html et demo.html.

Modules : scripts par domaine (liste au § 1), chargés par index.html dans un
ordre imposé — config et dom d'abord, puis edit-core / edit-render /
edit-panel / edit-tools, scene3d / scene3d-render / scene3d-zones /
scene3d-helper / scene3d-planview / scene3d-export / scene3d-export-svg /
scene3d-export-cut / scene3d-tools, plan, print, nav, et enfin app.js. Un fichier
ajouté ou renommé doit être reporté dans cette liste de balises <script> (et dans
demo.html) en respectant l'ordre.

Rappel : l'objet s'exécute dans un bac à sable (iframe sandbox « allow-forms
allow-scripts »). Sont notamment interdits : la navigation de la page
principale, les téléchargements sans action de l'utilisateur, l'ouverture de
fenêtres contextuelles ou modales natives.

Impression : window.print() est lui aussi soumis au bac à sable. Le serveur
d'IHM Web (WebServerApplication) insère l'objet dans un iframe
sandbox="allow-forms allow-scripts allow-downloads", valeur codée en dur :
sans allow-modals, Chrome et Firefox ignorent print() silencieusement
(console : « Ignored call to 'print()'. The document is sandboxed, and the
'allow-modals' keyword is not set ») et sans allow-popups aucune fenêtre ne
peut s'ouvrir. En revanche allow-downloads autorise un téléchargement
déclenché par un clic. L'objet applique donc un REPLI « PDF TÉLÉCHARGÉ » :
  - il reconnaît le bac à sable à l'origine opaque du document
    (window.origin vaut "null" ; demo.html en file:// est exclue) et, par
    sécurité, à l'absence de l'événement beforeprint après un appel à
    window.print() ;
  - le cadre du plan est alors rastérisé sur un canvas (image de base,
    calques image visibles, formes libres, capteurs avec leur anneau
    d'alarme ; mode « Plan entier » ou « Vue affichée ») — les images sont
    rechargées en mode CORS, Servin répondant Access-Control-Allow-Origin:
    * sur les fichiers statiques (sinon le canvas serait « souillé ») ;
  - un PDF A4 (vendor/pdf-lib, portrait ou paysage selon le cadre, marges
    10 mm, même en-tête que l'impression) est téléchargé sous le nom
    plan-<fil d'Ariane>-<aaaammjj-hhmm>.pdf ; un message informatif sous la
    barre de zoom l'annonce (l'opérateur l'ouvre et l'imprime depuis son
    lecteur PDF). Le menu le signale d'avance (« IHM Web : le plan sera
    enregistré en PDF »).
  NS.exportPlanPdf(mode) produit le même PDF sur demande, hors bac à sable.

Bancs de test de l'impression : tests\server.js (serveur HTTP du dossier +
bouchon de la bibliothèque Panorama poussant configuration_plan_json, port
8171, en-tête CORS comme Servin), tests\bench-print.js (puppeteer-core +
Chrome local, 82 assertions, captures et PDF dans tests\out\ ; window.print()
y est bouchonné, Chrome headless n'ouvrant pas de dialogue ; le rendu est
vérifié sous émulation du média print et le repli PDF avec un print() muet)
et tests\bench-print-sandbox.js (20 assertions en VRAI bac à sable :
tests\sandbox-host.html insère index.html dans un iframe portant
exactement l'attribut sandbox de Servin, port 8172 ; les PDF téléchargés
sont capturés par le protocole DevTools dans tests\out\).


15. VARIANTE : SERVEUR WEB DE DÉVELOPPEMENT (optionnel)
--------------------------------------------------------------------------------
Pour servir la page depuis un serveur Web externe de développement au lieu des
fichiers copiés à l'étape 3 :
  - créer le sous-répertoire UserClasses\MyPnPlanViewerV2,
  - y déposer un fichier redirect_url.txt contenant uniquement l'adresse de
    l'application Web, par exemple :
        https://MonServeurDev/
  - conserver l'implémentation $front=MyPnPlanViewerV2 si index.html est
    directement accessible à cette adresse ; sinon compléter par le chemin,
    par exemple :
        $front=MyPnPlanViewerV2,Page1/

Note : hors IHM Web Panorama, la bibliothèque /static/fr/pn-insertable-object-lib.umd.js
n'est pas servie et la page ne peut pas démarrer ; utiliser demo.html (§ 14).


16. BACK-END SQL (base PostgreSQL VisioDEF4)
--------------------------------------------------------------------------------
Les six propriétés du § 6 peuvent être servies par une chaîne complète, sur le
modèle des composants MyPnScheduler, MyPnListeElements et MyPnParametrage.
Depuis le 07/10/2026, la base est PostgreSQL (extension 2.0.0 par ODBC) : les
procédures T-SQL citées ci-dessous sont devenues des fonctions en minuscules
(usp_GetPlanConfiguration -> pview.get_plan_configuration, usp_SaveShapes ->
pview.save_shapes...), le contrat des propriétés est inchangé ; détail dans
database\MyPnPlanViewerV2\readme.txt.
Trois briques, chacune avec son propre readme :

  database\MyPnPlanViewerV2\        MODÈLE DE DONNÉES — schéma pview :
      01-schema.sql                 11 tables, index, purge
      02-procedures.sql             1 vue et les fonctions (JSON, actions)
      03-sample-data.sql            jeu d'exemple (§ ci-dessous)
      04-validate.sql               banc de validation, 75 assertions
      05-scene3d.sql                scène 3D : 3 tables, 2 fonctions, jeu
                                    d'exemple, options editFloorImages /
                                    editModels
      06-validate-scene3d.sql       banc de validation de la scène 3D
      readme.txt                    modèle, fonctions, pièges du portage

  ..\..\MyPnPlanViewerExtension\    EXTENSION .NET / COM (GLOBALSCRIPT) :
      MyPnPlanViewerExtension.cs    26 méthodes MyPnPv*, contrat string-only
      tests\bench-extension.ps1     banc, 87 assertions
      tests\dll-call.ps1            appel unitaire d'une méthode
      readme.txt                    contrat, compilation, pièges

  Samples\                          SCRIPTS PANORAMA (5 scripts C#) :
      OnOpenLoadPlanViewer.cs       ouverture : configuration + alarmes
      OnChangeSelectedNodePath…     sélection : capteurs + formes du plan
      OnChangeDrawnShapes…          enregistrement des formes (garde anti-écho)
      OnChangeScene3D…              enregistrement de la scène 3D (garde anti-écho)
      OnChangeDetailRequest…        clic capteur / badge
      OnTimerEventsPlanViewer.cs    rafraîchissement des alarmes (2 à 5 s)
      readme.txt                    déclencheurs, cycle de vie, volumes

Ce que le schéma pview apporte, et ce qu'il RÉUTILISE :

  L'arbre de navigation EST sched.Location (le schéma du scheduler) : l'id
  entier d'un nœud est son LocationId, et le parent_id vient de l'imbrication.
  Les capteurs SONT elem.Element (le schéma de la liste des éléments) : l'id
  d'un capteur est son ElementId, celui-là même que l'application retrouve dans
  eventsDetailRequest_json et qui ouvre le même détail que dans
  MyPnListeElements. Les alarmes SONT elem.ElementEvent (Fin IS NULL).
  Rien n'est dupliqué : un capteur renommé dans la liste des éléments l'est
  aussitôt sur le plan.

  pview ne porte que ce qui manquait : les représentations rattachées à un lieu
  (pview.Plan, l'Ordre donnant le planIndex), leurs calques image
  (pview.PlanLayer), la POSITION x / y des capteurs (pview.ElementPosition, en
  fraction 0..1), les FORMES LIBRES avec une colonne par clé du contrat du § 10
  (pview.Shape, pview.ShapeElement, pview.ShapeProperty), les vues épinglées
  (pview.PinnedView), les options du bandeau (pview.Setting, pview.EditIcon) et
  un journal des écritures (pview.ChangeLog).

Correspondance propriété / procédure / méthode :

  configuration_plan_json       usp_GetPlanConfiguration MyPnPvGetPlanConfiguration
  current_plan_element_json     usp_GetPlanElements      MyPnPvGetPlanElementsFor
  configuration_events_json     usp_GetPlanEvents        MyPnPvGetPlanEvents
  current_plan_drawnShapes_json usp_GetPlanShapes        MyPnPvGetPlanShapesFor
    (écriture)                  usp_SaveShapes           MyPnPvSaveShapes
  current_plan_scene3d_json     usp_GetPlanScene3D       MyPnPvGetPlanScene3DFor
    (écriture)                  usp_SaveScene3D          MyPnPvSaveScene3D
                                (05-scene3d.sql ; script OnChangeScene3D…)
  eventsDetailRequest_json      usp_GetElementDetail /   MyPnPvHandleDetailRequest
                                usp_GetNodeEvents
  selectedNodePath               (déclencheur des deux propriétés de plan)

Jeu de test livré (03-sample-data.sql, contexte « default ») : 537
représentations, UNE par lieu — la vue du site pour chaque site, l'implantation
pour chaque bâtiment (le premier porte à la place un modèle 3D, seul : cube
« Représentation 3D » dans l'arbre), le plan coté pour neuf niveaux sur dix
(48 niveaux restent sans représentation : indicateur « sans plan ») — 145
calques « Zone à risque », 51 840 capteurs positionnés
(120 par plan de niveau, positions déterministes), 42 formes libres couvrant
les 14 types du mode édition avec leurs capteurs couverts et leurs propriétés,
5 vues épinglées, 8 icônes d'édition, et l'image par défaut des 10 types
d'éléments (Images\elements\, copiée depuis IMAGES\Elements et IMAGES\Metiers).
Les alarmes en cours du schéma elem (13 514 au moment de la mesure ; le
nombre évolue avec l'exploitation) alimentent pastilles, badges et halos :
celles qui portent sur un capteur posé sur un plan sont détaillées une
par une, les autres agrégées par nœud et priorité (~ 570 Ko, ~ 1,1 s).

Vérification : demo.html?data=server affiche ces données réelles (jeu
« Données SQL » en tête de la liste des jeux d'essai) ; tests\samples.js est
régénéré par « node tests\make-samples.js » à partir des échantillons du banc
de l'extension, et tests\bench-server.js rejoue 22 assertions dans Chrome
(tests\bench-demo.js : 160 assertions sur les jeux d'essai embarqués).

================================================================================
ANNEXE A. SCHÉMA D'UNE FORME (calques "shapes" et current_plan_drawnShapes_json)
================================================================================

Repris du readme de l'ancienne V1 (§ 6, retirée le 2026-08-29). Une forme est
un objet JSON dont type est obligatoire ; toutes les coordonnées sont en
fraction 0 à 1 du plan de base. Les clés propres à la V2 (id, elements) sont
décrites au § 6.

  type    "polygon", "polyline", "rect",
          "circle", "ellipse", "sector", "line",
          "arrow", "measure", "scale", "label",
          "callout", "icon" ou "pin".
  points  (polygon : au moins 3 sommets ;
          polyline : au moins 2) tableau de
          sommets [x, y] ou { "x": …, "y": … }.
  x, y, w, h  (rect, icon) coin haut-gauche et
          dimensions ; icon porte en plus filename
          (chemin d'image relatif au dossier de
          l'objet).
  cx, cy, r   (circle, sector) centre ; r en
          fraction de la LARGEUR du plan.
          sector porte en plus startAngle et
          endAngle (degrés, 0 = est, sens
          horaire).
  cx, cy, rx, ry  (ellipse) centre et demi-axes
          (rx en fraction de la largeur, ry de
          la hauteur).
  x1, y1, x2, y2  (line, arrow, measure) ; la
          flèche porte en plus heads, extrémité
          fléchée : "end" pointe en (x2, y2)
          (défaut, valeur retenue si la clé est
          absente ou inconnue), "start" pointe
          en (x1, y1), "both" pointes aux deux
          extrémités. La cote affiche la
          distance selon l'échelle du plan
          (étalon "scale", sinon clé scale de la
          représentation, sinon en % de sa
          largeur).
  x1, y1, x2, y2, value, unit, shown  (scale)
          étalon d'échelle : value (nombre > 0,
          obligatoire) est la longueur réelle
          du segment, unit l'unité affichée
          (défaut "m"), shown (défaut true)
          l'affiche ou non sur le plan.
          Affiché ou non, il étalonne les cotes
          du plan, en priorité sur la clé scale
          de la représentation. C'est la forme
          écrite par l'outil « échelle » du
          mode édition : la réafficher ici
          referme la boucle (les cotes de
          l'opérateur restent justes).
  x, y, text  (label) point d'ancrage et texte,
          avec fontSize (pixels écran, défaut
          14), bold, italic, boxed (encadré).
  tx, ty, x, y, text  (callout) pointe sur la
          cible et centre de la boîte, avec
          fontSize, bold, italic.
  x, y    (pin) pointe de la punaise.
  fill    couleur CSS de remplissage ("none" :
          transparent) ; défaut : rouge
          translucide.
  stroke  couleur CSS du trait ("none" :
          transparent) ; défaut : rouge.
  strokeWidth  épaisseur du trait, en pixels
          écran (constante à tout niveau de
          zoom) ; défaut : 2.
  label   info-bulle de la forme.
  rotation  (rect, ellipse, icon, label) angle
          de rotation en degrés, sens horaire,
          autour du centre de la forme (du
          point d'ancrage pour label) ; défaut
          0. Les autres types se tournent par
          leurs coordonnées mêmes (c'est ainsi
          que le mode édition les écrit).

Une forme incomplète ou d'un type inconnu est
ignorée.

================================================================================
ANNEXE B. MODE ÉDITION (clé shapeEditing de configuration_plan_json)
================================================================================

Repris du readme de l'ancienne V1 (§ 6, clé shapeEditing). Les noms de
propriétés sont ceux de la V2 ; la clé sensors de la V1 (libellés des
capteurs couverts) est devenue elements (ids des capteurs, § 6) ; les « points
des calques markers » de la V1 sont en V2 les capteurs de
current_plan_element_json posés sur le plan.

  Booléen, false par défaut. Active le mode d'édition de formes
  personnalisées sur les plans 2D. Sans objet sur les représentations
  3D, où il est masqué.

  CADENAS. Par défaut la barre d'édition est masquée : seul un petit
  cadenas discret apparaît en haut à droite de la zone des plans.
  Fermé (gris) : les formes déjà dessinées restent affichées mais ne
  sont pas modifiables. Un clic l'ouvre (bleu) : la barre d'outils
  apparaît en haut au centre. Un nouveau clic la masque et annule le
  tracé en cours. L'état du cadenas vaut pour la page (il n'est pas
  réinitialisé au changement de représentation).

  BARRE D'OUTILS. Boutons réduits à leur ICÔNE, regroupés en
  Sélection | Formes | Annotations, séparés par un filet ; l'outil
  actif prend une pastille blanche cerclée de bleu ; le bouton
  Supprimer est en bout de barre. Le libellé de chaque outil, suivi de
  son mode d'emploi, s'affiche en info-bulle au survol de la souris :
  la barre tient ainsi en ~460 px quelle que soit la largeur de la
  zone des plans.
  La barre se DÉPLACE à la souris par la poignée pointillée de son
  extrémité gauche : glisser pour la poser où l'on veut dans la zone
  des plans (elle reste bornée au cadre, et y est ramenée si la
  fenêtre rétrécit). Descendue dans la moitié basse, ses info-bulles
  s'affichent au-dessus d'elle. La position tient pour la page, comme
  l'état du cadenas.

  Outils, par famille :
    - Au cliquer-glisser : ellipse (du centre ; Ctrl GAUCHE maintenu :
      cercle), secteur circulaire (du centre ; le glisser fixe rayon et
      direction, ouverture de 60° ajustable ensuite), rectangle (Ctrl
      GAUCHE : carré), ligne / connecteur, flèche (pointe à l'arrivée
      par défaut ; section « Flèche » du panneau pour l'inverser ou en
      mettre une à chaque extrémité), échelle (étalonnage visuel :
      glisser sur une longueur connue du plan — un mur coté, une
      porte... — puis saisir sa longueur réelle et son unité dans la
      section « Échelle » du panneau ; un seul étalon par plan, le
      nouveau remplace l'ancien ; la case « Afficher sur le plan »
      masque l'étalon sans le désactiver), cote / mesure (distance
      affichée selon l'échelle du plan : étalon de l'outil échelle,
      sinon clé scale de la représentation, sinon en % de sa largeur),
      étiquette de rappel (glisser de la cible vers l'étiquette ; la
      pointe reste ancrée sur la cible).
      Pour la LIGNE, la FLÈCHE, la COTE et l'ÉTALON, Ctrl GAUCHE
      maintenu contraint le tracé sur un multiple de 45° : traits
      parfaitement horizontaux, verticaux ou en diagonale, donc
      perpendiculaires entre eux. L'aperçu suit l'appui et le
      relâchement de la touche sans attendre un mouvement de souris.
    - Au clic par sommet : polygone (fermeture par clic sur le premier
      sommet, double-clic ou Entrée), polyligne (fin par double-clic ou
      Entrée) ; Ctrl GAUCHE contraint de même chaque segment sur le
      précédent (angles droits ou à 45°) ; Échap annule le tracé en
      cours.
    - Au clic : libellé (le panneau règle texte, taille, gras,
      italique, encadré ou non), icône / image, punaise / marqueur
      ponctuel.
      L'outil « icône / image » ouvre d'abord, sous la barre, une
      GALERIE DE VIGNETTES des images déclarées par la clé editIcons :
      on y choisit visuellement l'image, puis on clique sur le plan
      pour la poser. La dernière image choisie reste retenue d'une
      pose à l'autre ; Échap referme la galerie (le champ « Fichier »
      du panneau permet toujours un chemin libre). Sans clé editIcons,
      la galerie ne s'ouvre pas.
    - Outil « Sélection » : clic sur une forme pour la sélectionner,
      glisser pour la déplacer ; poignées d'ajustement selon le type
      (sommets, coins, rayon, demi-axes de l'ellipse, rayon et angles
      du secteur, extrémités des lignes/flèches/cotes, pointe de
      l'étiquette de rappel) ; Ctrl GAUCHE conserve cercle/carré au
      redimensionnement et contraint sur 45° les extrémités de lignes
      et les sommets de polygones/polylignes ; bouton Supprimer ou
      touche Suppr pour retirer la forme. Hors des formes, le
      déplacement du plan à la souris reste possible ; pendant un
      tracé, il est suspendu (le zoom à la molette reste actif).
      ROTATION : toute forme orientable sélectionnée (rectangle,
      ellipse, icône, libellé, polygone, polyligne, secteur, ligne,
      flèche, cote, étalon — pas la punaise ni l'étiquette de rappel)
      porte en plus une POIGNÉE RONDE BLEUE, reliée à son bord par un
      filet et posée un peu au-delà de la forme : la glisser fait
      tourner la forme autour de son centre (segments : autour du
      milieu ; libellé : autour de son point d'ancrage) ; Ctrl GAUCHE
      contraint l'angle sur un multiple de 15°. Rectangle, ellipse,
      icône et libellé conservent leur angle dans la clé rotation de
      current_plan_drawnShapes_json (leurs poignées de coins et de demi-axes
      suivent la rotation, et le redimensionnement garde le coin
      opposé immobile) ; les autres types sont tournés dans leurs
      coordonnées mêmes (sommets, extrémités ou angles du secteur
      réécrits, sans changement de schéma), et ramenés dans le plan
      s'ils en sortaient. La section « Rotation » du panneau donne
      l'angle au degré près (voir ci-dessous).

  PANNEAU « APPARENCE / PROPRIÉTÉS », sous le cadenas, visible
  uniquement lorsqu'une forme est sélectionnée (il disparaît à la
  désélection) : couleur et opacité du fond, couleur et épaisseur du
  contour, chacun avec une case « Transparent », appliqués à la forme
  avec aperçu immédiat. Une forme au contour transparent garde un
  contour fantôme pointillé pendant l'édition (cadenas ouvert), pour
  rester repérable et sélectionnable ; cadenas fermé, elle s'affiche
  telle quelle. La dernière apparence choisie devient aussi celle des
  prochaines formes tracées (l'aperçu du tracé en cours la reflète).
  Selon le type sélectionné, le panneau ajoute : texte / taille /
  gras / italique / encadré (libellé, étiquette de rappel), sens des
  pointes (flèche : trois vignettes — pointe à l'arrivée, au départ,
  ou aux deux extrémités ; le choix vaut aussi pour les flèches
  suivantes), rayon (%)
  et angles début/fin en degrés (secteur — 0° = est, sens horaire),
  longueur réelle / unité / case « Afficher sur le plan » (étalon
  d'échelle — décochée, l'étalon garde un contour fantôme cadenas
  ouvert et disparaît cadenas fermé, mais continue d'étalonner les
  cotes), galerie d'icônes + chemin de fichier (icône / image), et,
  pour toute forme orientable, la section « Rotation » : champ
  « Angle (°) » (degrés, sens horaire, aperçu immédiat) et deux
  boutons de quart de tour (-90° / +90°). L'angle affiché est celui
  de la clé rotation pour rectangle, ellipse, icône et libellé,
  l'orientation du segment (0° = est, sens horaire, de son origine
  vers son extrémité) pour ligne, flèche, cote et étalon, et la
  rotation cumulée depuis le tracé pour polygone et polyligne ; le
  secteur se règle par ses angles de début et de fin (section
  Secteur, dont les champs suivent aussi les poignées). La partie
  « Propriétés » porte un nom (info-bulle de la forme, clé label de
  current_plan_drawnShapes_json) et des propriétés libres nom/valeur ajoutées par
  le bouton « + Ajouter une propriété » (clé props), par exemple pour
  nommer une zone et la qualifier.

  Pendant le tracé et sur la forme sélectionnée, un indicateur (sous
  le panneau) liste les capteurs couverts par la forme : les points
  des calques "markers" du plan courant (calques affichés ou non)
  situés à l'intérieur de la forme — formes FERMÉES uniquement
  (polygone, rectangle, cercle, ellipse, secteur) ; les tracés
  ouverts, textes, icônes et punaises écrivent elements: []. Les
  marqueurs couverts sont soulignés d'un anneau bleu quand leur calque
  est affiché. Les ids des capteurs couverts sont aussi écrits dans la clé
  elements de chaque forme de current_plan_drawnShapes_json (§ 11).
  À chaque modification, l'ensemble des formes du plan courant est
  écrit dans la propriété current_plan_drawnShapes_json (§ 6 et § 11) — les cotes y
  portent en plus une clé distance (texte affiché) et l'étalon
  d'échelle une clé planWidthValue (§ 11), ignorées au réaffichage. Les formes sont mémorisées par plan le temps de la
  page : elles survivent aux changements de représentation et de
  configuration, mais pas au rechargement de la page. Leur persistance
  incombe à l'application, qui peut les réafficher via un calque
  "shapes" (clé layers).

================================================================================
ANNEXE C. CAHIER DE RECETTE DU MODE ÉDITION
================================================================================

Repris du readme de l'ancienne V1 (§ 8). À jouer sur demo.html (jeu
« Édition ») ou sur un plan 2D de l'application, avec "shapeEditing": true.

- Avec "shapeEditing": true : le petit cadenas apparaît en haut à droite des
  plans 2D (pas sur les modèles 3D ni sans représentation) et la barre
  d'édition est masquée. Cliquer le cadenas : il s'ouvre (bleu) et la barre
  d'outils apparaît en haut au centre, en icônes seules — groupes
  Sélection | Formes (ellipse, secteur, rectangle, polygone, polyligne) |
  Annotations (ligne, flèche, libellé, icône, rappel, échelle, cote,
  punaise), bouton Supprimer en bout.
  Survoler un bouton : une info-bulle sombre donne le nom de l'outil et
  son mode d'emploi. Saisir la poignée pointillée à gauche de la barre et
  la glisser ailleurs dans la zone des plans : la barre suit, reste
  entièrement visible même en visant hors du cadre, et ses info-bulles
  passent au-dessus d'elle une fois descendue. Rétrécir l'objet : la barre
  est ramenée dans le cadre.
- Dessiner une forme de chaque famille : ellipse et rectangle au
  cliquer-glisser — refaire chacun avec Ctrl GAUCHE maintenu et vérifier
  cercle et carré parfaits (aussi au redimensionnement par poignée) ;
  secteur (glisser depuis le centre, ouverture 60°, puis régler rayon et
  angles par les poignées et par les champs du panneau) ; polygone et
  polyligne au clic par sommet (fermeture/fin : double-clic ou Entrée) ;
  ligne, flèche et cote au cliquer-glisser (la cote affiche la distance
  selon l'échelle du plan : étalon de l'outil échelle, sinon clé scale,
  sinon un % de sa largeur) ; libellé et punaise au clic ; icône au clic
  après avoir choisi la vignette dans la galerie ouverte par l'outil ;
  étiquette de rappel en glissant de la cible vers l'emplacement de la
  boîte. Sélectionner, déplacer, ajuster par les poignées, supprimer. À
  chaque modification, la propriété current_plan_drawnShapes_json de l'instance
  reçoit le JSON des formes du plan courant. Changer de représentation
  puis revenir : les formes dessinées réapparaissent (cadenas resté
  ouvert : la barre aussi).
- Refaire une ligne, une flèche, une cote et une polyligne avec Ctrl
  GAUCHE maintenu : les traits se calent sur l'horizontale, la verticale
  ou 45°, et les segments successifs d'une polyligne restent
  perpendiculaires. Relâcher puis réappuyer la touche pendant le tracé :
  l'aperçu suit aussitôt. Même contrainte en tirant l'extrémité d'une
  ligne ou un sommet de polyligne déjà tracés.
- Sélectionner une flèche : la section « Flèche » du panneau propose trois
  vignettes. Cliquer la deuxième : la pointe passe à l'autre extrémité ;
  la troisième : une pointe à chaque bout. current_plan_drawnShapes_json reflète le
  choix (clé heads : "end", "start", "both"), qui s'applique aussi aux
  flèches tracées ensuite.
- Sélectionner un rectangle : une poignée ronde bleue apparaît au-dessus,
  reliée à son bord par un filet. La glisser autour du rectangle : il
  tourne (Ctrl GAUCHE : par pas de 15°), ses poignées de coins suivent,
  et tirer un coin garde le coin opposé immobile. La section « Rotation »
  du panneau affiche l'angle ; y saisir 45, ou cliquer un bouton de
  quart de tour, tourne la forme ; current_plan_drawnShapes_json porte la clé
  rotation. Refaire avec une ellipse, une icône et un libellé (clé
  rotation), puis avec un polygone, une flèche et un secteur : ce sont
  leurs coordonnées qui sont réécrites (points, x1..y2, startAngle /
  endAngle) ; pour la flèche, le champ donne l'orientation du segment.
  Réafficher via un calque "shapes" un rectangle avec "rotation": 30 :
  il apparaît tourné.
- Avec une clé editIcons renseignée, activer l'outil « icône / image » :
  une galerie de vignettes s'ouvre sous la barre. Cliquer une vignette
  (elle se cercle de bleu), puis cliquer sur le plan : c'est cette image
  qui est posée. Rouvrir l'outil : le dernier choix est toujours retenu ;
  Échap referme la galerie.
- Définir une échelle avec l'outil « échelle » : glisser sur une longueur
  connue du plan (un mur coté, une porte...). Le panneau s'ouvre sur la
  section Échelle, champ « Longueur » présélectionné : saisir la valeur
  réelle et l'unité. L'étalon s'affiche (« Échelle : 5 m ») et toutes les
  cotes du plan — dessinées ou portées par un calque "shapes" — affichent
  désormais la distance selon cet étalon, prioritaire sur la clé scale de
  la représentation ; dans current_plan_drawnShapes_json, l'étalon porte value, unit,
  shown et planWidthValue (§ 11). Décocher « Afficher sur le plan » :
  l'étalon passe en contour fantôme pointillé tant que le cadenas est
  ouvert et disparaît cadenas fermé, mais les cotes restent étalonnées ;
  recocher le réaffiche. Retracer un étalon remplace le précédent (un
  seul par plan) ; le supprimer ramène les cotes à la clé scale du plan,
  sinon aux pourcentages.
- Refermer le cadenas : la barre disparaît, les formes restent affichées
  mais ne sont plus ni sélectionnables ni modifiables.
- Sélectionner une forme dessinée (outil Sélection) fait apparaître le
  panneau « Apparence / Propriétés » sous le cadenas ; il disparaît à la
  désélection (clic hors des formes, Échap, suppression). Modifier le
  fond, l'opacité, le contour ou l'épaisseur : la forme change
  immédiatement et current_plan_drawnShapes_json est réécrite (clés fill, stroke,
  strokeWidth) ; les formes tracées ensuite (et l'aperçu pendant leur
  tracé) reprennent la dernière apparence choisie. Cocher « Transp. » sur
  le contour : la forme garde un contour fantôme pointillé tant que le
  cadenas est ouvert, et s'affiche sans contour une fois verrouillé
  (fill/stroke valent "none" dans current_plan_drawnShapes_json). Sur un libellé ou
  une étiquette de rappel, la section Texte règle texte, taille, gras,
  italique et encadrement ; sur une flèche, la section Flèche règle le
  sens des pointes ; sur un secteur, la section Secteur règle rayon et
  angles ; sur une icône, la galerie (clé editIcons) et le champ
  « Fichier » remplacent l'image. Saisir un nom (affiché en info-bulle de
  la forme, clé label) et ajouter des propriétés nom/valeur par
  « + Ajouter une propriété » (clé props).
- Toujours cadenas ouvert, sur un plan avec calque "markers" : pendant le
  tracé d'une forme fermée (et sur la forme sélectionnée), l'indicateur
  « Capteurs couverts » apparaît sous le panneau et liste les marqueurs
  situés dans la forme ; ceux-ci sont soulignés d'un anneau bleu si leur
  calque est affiché. Dans current_plan_drawnShapes_json, chaque forme porte la clé
  elements avec leurs ids (tableau vide pour les tracés ouverts, textes,
  icônes et punaises).

