﻿/* ============================================================
   MyPnPlanViewerV2 — module « scene3d-export-svg »
   ============================================================
   Export SVG de la vue en plan d'une représentation 3D (menu du bouton
   « Vue en plan »). Même cadrage « plan entier » et même en-tête que
   l'export PNG (viewer-scene3d-export.js, dont ce module réutilise
   withExportScene, ensurePlanView, sceneBounds et subtitle), mais :
     - le MODÈLE seul (entités masquées) est rendu de dessus SANS FOND
       (canal alpha) et inclus en <image> base64, au-dessus du fond de plan
       (viewer-scene3d-export-cut.js peut le remplacer par une coupe
       horizontale vectorielle) ;
     - le fond de plan est inclus en <image> (texture déjà chargée par le
       rendu, ou, si le canvas est refusé — image locale en file:// —, par
       son chemin relatif) ;
     - emprise, étalon, mesures, objets, zones tracées, flèche nord et
       leurs étiquettes sont des VECTEURS (<polygon>, <polyline>,
       <circle>, <text>) dans des groupes nommés ;
     - une barre d'échelle (1-2-5 × 10^n) si l'échelle du modèle est
       connue.
   Le repère du dessin est en pixels CSS du cadre (largeur W du canvas) ;
   la racine porte data-scale-value (longueur réelle d'une unité du
   modèle), data-unit, data-north (degrés), data-plan-width (largeur
   réelle du dessin, à reporter dans la clé scale d'une représentation 2D
   qui réemploierait ce fichier) et data-px-per-unit. Fichier
   plan-<lieu>-<date>.svg téléchargé (NS.downloadBytes).

   Chargé après viewer-scene3d-export.js et avant viewer-scene3d-tools.js
   (ordre imposé par index.html, readme.txt § 1).

   NOTE ENCODAGE : chaînes affichées en ASCII pur (\uXXXX), commentaires
   accentués, BOM UTF-8, fins de ligne CRLF (readme.txt § 14).
   ============================================================ */
(function (global) {
  'use strict';

  const NS = global.MyPnPlanViewerV2NS = global.MyPnPlanViewerV2NS || {};
  const state = NS.state;
  const X = NS.scene3dExport;

  const HEADER = X.HEADER_PX;
  const FONT = '"Segoe UI", system-ui, sans-serif';
  const BACKGROUND = '#f6f8fb';
  const SCALE_COLOR = '#f59e0b';
  const MEASURE_COLOR = '#7c3aed';
  const NORTH_COLOR = '#dc2626';
  const OBJECT_COLOR = '#64748b';
  const ZONE_FILL_ALPHA = 0.18;
  let busy = false;

  function viewer() {
    return global.ThreeViewer || null;
  }

  // split/join plutot que des regex : un litteral /"/ tromperait l automate d echappement des chaines (outillage).
  const esc = (s) => String(s).split('&').join('&amp;').split('<').join('&lt;').split('>').join('&gt;').split(String.fromCharCode(34)).join('&quot;');
  const f = (n) => String(Math.round(n * 100) / 100);

  /* Repère du dessin, à partir de la caméra orthographique cadrée : u =
     abscisse vers l'est, v = ordonnée vers le nord (unités du modèle) ;
     px(x, z) -> [X, Y] en pixels du SVG (Y sous l'en-tête). */
  function frame() {
    const v = viewer();
    const c = v.getContext();
    const cam = v.getPlanCamera();
    const W = c.canvas.clientWidth, H = c.canvas.clientHeight;
    const n = [cam.up.x, cam.up.z];
    const e = [-cam.up.z, cam.up.x];
    const t = c.controls.target;
    const cu = t.x * e[0] + t.z * e[1], cv = t.x * n[0] + t.z * n[1];
    const hw = (cam.right - cam.left) / (2 * cam.zoom), hh = (cam.top - cam.bottom) / (2 * cam.zoom);
    const k = W / (2 * hw);
    return {
      W, H, k, n, e, cu, cv, hw, hh,
      px: (x, z) => [W / 2 + ((x * e[0] + z * e[1]) - cu) * k, HEADER + H / 2 - ((x * n[0] + z * n[1]) - cv) * k],
      // Angle SVG (degrés) d'un vecteur du sol (dx, dz).
      angle: (dx, dz) => Math.atan2(-(dx * n[0] + dz * n[1]), dx * e[0] + dz * e[1]) * 180 / Math.PI,
    };
  }

  /* ---------------------- Éléments ---------------------- */

  const measureCtx = document.createElement('canvas').getContext('2d');
  function textWidth(text, size, weight) {
    measureCtx.font = (weight || 400) + ' ' + size + 'px ' + FONT;
    return measureCtx.measureText(text).width;
  }

  function pointsAttr(F, pts) {
    return pts.map((p) => { const q = F.px(p[0], p[1]); return f(q[0]) + ',' + f(q[1]); }).join(' ');
  }

  /* Étiquette comme les sprites du rendu : cartouche blanc bordé de la
     couleur, texte 12 px, centré sur (X, Y) et posé au-dessus. */
  function label(text, X, Y, color) {
    if (!text) return '';
    const w = textWidth(text, 12, 600) + 14, h = 20;
    const x = X - w / 2, y = Y - h - 3;
    return '<g class="label"><rect x="' + f(x) + '" y="' + f(y) + '" width="' + f(w) + '" height="' + h +
      '" rx="5" fill="#ffffff" fill-opacity="0.92" stroke="' + color + '" stroke-width="1.2"/>' +
      '<text x="' + f(X) + '" y="' + f(y + h / 2) + '" font-family=\'' + FONT + '\' font-size="12" font-weight="600" fill="#0f172a" text-anchor="middle" dominant-baseline="central">' +
      esc(text) + '</text></g>';
  }

  function centroid(points) {
    let sx = 0, sz = 0;
    for (const p of points) { sx += p[0]; sz += p[1]; }
    return [sx / points.length, sz / points.length];
  }

  function header(F, now, extra) {
    const W = F.W;
    return '<g id="header"><rect x="0" y="0" width="' + W + '" height="' + HEADER + '" fill="#ffffff"/>' +
      '<text x="14" y="16" font-family=\'' + FONT + '\' font-size="13" font-weight="600" fill="#0f172a" dominant-baseline="central">' + esc(state.currentLocation || '') + '</text>' +
      '<text x="14" y="33" font-family=\'' + FONT + '\' font-size="11" fill="#64748b" dominant-baseline="central">' + esc(X.subtitle() + (extra ? ' \u2014 ' + extra : '')) + '</text>' +
      '<text x="' + (W - 14) + '" y="16" font-family=\'' + FONT + '\' font-size="11" fill="#64748b" text-anchor="end" dominant-baseline="central">' + esc(NS.formatPrintDateTime(now)) + '</text>' +
      '<rect x="0" y="' + (HEADER - 1) + '" width="' + W + '" height="1" fill="#e2e8f0"/></g>';
  }

  /* Fond de plan : texture du rendu (canvas -> PNG base64) ou chemin. */
  function floorImage(F, fi) {
    if (!fi || !fi.shown) return '';
    const r = NS.scene3dRender;
    const w = fi.width || r.defaultFloorWidth();
    const entry = r.textures.get(fi.filename);
    const aspect = fi.height && w ? fi.height / w : (entry && entry.aspect ? entry.aspect : 0.7);
    const h = w * aspect;
    let href = fi.filename;
    if (entry && entry.tex && entry.tex.image && entry.tex.image.toDataURL) {
      try { href = entry.tex.image.toDataURL('image/png'); } catch (cause) { /* canvas souillé (file://) : chemin */ }
    }
    const c = F.px(fi.x, fi.z);
    const rho = (fi.rotation || 0) * Math.PI / 180;
    // Le haut de l'image regarde vers -z tourné de rotation (horaire vu de dessus).
    const deg = F.angle(Math.sin(rho), -Math.cos(rho)) + 90;
    return '<g id="floorImage" transform="translate(' + f(c[0]) + ' ' + f(c[1]) + ') rotate(' + f(deg) + ')" opacity="' + f(fi.opacity) + '">' +
      '<image x="' + f(-w * F.k / 2) + '" y="' + f(-h * F.k / 2) + '" width="' + f(w * F.k) + '" height="' + f(h * F.k) +
      '" preserveAspectRatio="none" href="' + esc(href) + '"/></g>';
  }

  function footprint(F, fp) {
    if (!fp || !fp.shown) return '';
    const r = NS.scene3dRender;
    const sw = (fp.strokeWidth || r.defaultStrokeWidth()) * F.k;
    return '<g id="footprint"><polygon points="' + pointsAttr(F, fp.points) + '" fill="' + fp.fill + '" fill-opacity="' + f(fp.fillOpacity) +
      '" stroke="' + fp.stroke + '" stroke-width="' + f(sw) + '"' + (fp.dashed ? ' stroke-dasharray="' + f(sw * 4) + ' ' + f(sw * 2.5) + '"' : '') + '/></g>';
  }

  function zones(F, list) {
    const out = [];
    for (const z of list) {
      if (!z.shown || z.group || z.show_mode === 'masked' || z.points.length < 3) continue;
      const c = F.px.apply(null, centroid(z.points));
      out.push('<g class="zone" data-id="' + z.id + '"><polygon points="' + pointsAttr(F, z.points) + '" fill="' + z.color + '" fill-opacity="' + ZONE_FILL_ALPHA +
        '" stroke="' + z.color + '" stroke-width="1.2"/>' +
        (z.label ? '<text x="' + f(c[0]) + '" y="' + f(c[1]) + '" font-family=\'' + FONT + '\' font-size="11" font-weight="600" fill="' + z.color + '" text-anchor="middle" dominant-baseline="central">' + esc(z.label) + '</text>' : '') + '</g>');
    }
    return '<g id="zones">' + out.join('') + '</g>';
  }

  function scaleBar(F) {
    const s = NS.scaleFactor();
    if (!s) return '';
    const pxPerUnit = F.k / s;   // pixels par unité réelle
    let L = Math.pow(10, Math.floor(Math.log10(120 / pxPerUnit)));
    for (const m of [1, 2, 5, 10]) { if (L * m * pxPerUnit >= 70) { L *= m; break; } }
    const w = L * pxPerUnit;
    const x = 16, y = HEADER + F.H - 22;
    const text = NS.formatNumber(L) + ' ' + (state.currentPlan && NS.scene3d.scene ? NS.scene3d.scene.unit : 'm');
    return '<g id="scaleBar"><rect x="' + x + '" y="' + y + '" width="' + f(w) + '" height="5" fill="#0f172a"/>' +
      '<rect x="' + x + '" y="' + y + '" width="' + f(w / 2) + '" height="5" fill="#ffffff" stroke="#0f172a" stroke-width="1"/>' +
      '<text x="' + x + '" y="' + (y - 4) + '" font-family=\'' + FONT + '\' font-size="10" fill="#0f172a">0</text>' +
      '<text x="' + f(x + w) + '" y="' + (y - 4) + '" font-family=\'' + FONT + '\' font-size="10" fill="#0f172a" text-anchor="end">' + esc(text) + '</text></g>';
  }

  function scaleEntity(F, s) {
    if (!s || s.x1 === null || !s.shown) return '';
    const a = F.px(s.x1, s.z1), b = F.px(s.x2, s.z2);
    const dx = b[0] - a[0], dy = b[1] - a[1];
    const len = Math.hypot(dx, dy) || 1;
    const nx = -dy / len * 6, ny = dx / len * 6;
    const tick = (p) => '<line x1="' + f(p[0] - nx) + '" y1="' + f(p[1] - ny) + '" x2="' + f(p[0] + nx) + '" y2="' + f(p[1] + ny) + '"/>';
    return '<g id="scale" stroke="' + SCALE_COLOR + '" stroke-width="2.5" stroke-linecap="round"><line x1="' + f(a[0]) + '" y1="' + f(a[1]) + '" x2="' + f(b[0]) + '" y2="' + f(b[1]) + '"/>' +
      tick(a) + tick(b) + label(NS.formatLength(Math.hypot(s.x2 - s.x1, s.z2 - s.z1)), (a[0] + b[0]) / 2, (a[1] + b[1]) / 2, SCALE_COLOR) + '</g>';
  }

  function measures(F, list) {
    const out = [];
    for (const m of list) {
      if (!m.shown || m.points.length < 2) continue;
      if (m.type === 'area') {
        const c = F.px.apply(null, centroid(m.points));
        out.push('<g class="measure area" data-id="' + m.id + '"><polygon points="' + pointsAttr(F, m.points) + '" fill="' + MEASURE_COLOR + '" fill-opacity="0.15" stroke="' + MEASURE_COLOR + '" stroke-width="2" stroke-dasharray="8 5"/>' +
          label((m.label ? m.label + ' : ' : '') + NS.formatArea(NS.polygonArea(m.points)), c[0], c[1], MEASURE_COLOR) + '</g>');
      } else {
        const end = F.px.apply(null, m.points[m.points.length - 1]);
        out.push('<g class="measure distance" data-id="' + m.id + '"><polyline points="' + pointsAttr(F, m.points) + '" fill="none" stroke="' + MEASURE_COLOR + '" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>' +
          label((m.label ? m.label + ' : ' : '') + NS.formatLength(NS.polylineLength(m.points, false)), end[0], end[1], MEASURE_COLOR) + '</g>');
      }
    }
    return '<g id="measures">' + out.join('') + '</g>';
  }

  function objects(F, list) {
    const r = NS.scene3dRender;
    const out = [];
    for (const o of list) {
      if (!o.shown) continue;
      const c = F.px(o.x, o.z);
      const rad = r.objectRadius(o) * F.k;
      const color = o.color || OBJECT_COLOR;
      out.push('<g class="object" data-id="' + o.id + '" data-filename="' + esc(o.filename) + '"><circle cx="' + f(c[0]) + '" cy="' + f(c[1]) + '" r="' + f(rad) +
        '" fill="' + color + '" fill-opacity="0.55" stroke="' + color + '" stroke-width="1.5"/>' +
        label(o.label, c[0], c[1] - rad, color) + '</g>');
    }
    return '<g id="objects">' + out.join('') + '</g>';
  }

  function north(F, n) {
    if (!n || !n.shown) return '';
    const r = NS.scene3dRender;
    const pts = r.northPoints(n);
    const c = r.northPosition(n);
    const tip = pts[0];
    const l = F.px(c[0] + (tip[0] - c[0]) * 1.3, c[1] + (tip[1] - c[1]) * 1.3);
    return '<g id="north"><polygon points="' + pointsAttr(F, pts) + '" fill="' + NORTH_COLOR + '"/>' + label('N', l[0], l[1] + 10, NORTH_COLOR) + '</g>';
  }

  /* ---------------------- Document ---------------------- */

  /* Document SVG complet (chaîne) de la vue en plan cadrée sur toute la
     scène, ou null si le modèle n'est pas chargé. modelLayer : fonction
     facultative (F) -> chaîne SVG remplaçant l'image du modèle (coupe
     vectorielle, viewer-scene3d-export-cut.js) ; extra : complément du
     sous-titre de l'en-tête. */
  function renderSvg(now, modelLayer, extra) {
    const v = viewer();
    const scene = NS.scene3d.scene || NS.emptyScene3d();
    const r = NS.scene3dRender;
    let F = null, shot = null;
    X.withExportScene(() => {
      const box = X.sceneBounds();
      const restore = box ? v.fitPlanView(box) : () => {};
      try {
        F = frame();
        if (!modelLayer) {
          // Modèle seul : les entités (groupe scene3d) sont masquées.
          r.group.visible = false;
          try { shot = v.snapshot(X.pngScale(), { transparent: true }); } finally { r.group.visible = true; }
        }
      } finally {
        restore();
      }
    });
    if (!F) return null;
    const total = HEADER + F.H;
    const s = NS.scaleFactor();
    const northAngle = NS.northAngle();
    const parts = [];
    parts.push('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="' + F.W + '" height="' + total + '" viewBox="0 0 ' + F.W + ' ' + total + '"' +
      ' data-generator="MyPnPlanViewerV2" data-location="' + esc(state.currentLocation || '') + '" data-model="' + esc(state.currentPlan ? state.currentPlan.filename : '') + '"' +
      ' data-unit="' + esc(scene.unit) + '" data-scale-value="' + (s ? s : '') + '" data-north="' + (northAngle === null ? '' : northAngle) + '"' +
      ' data-px-per-unit="' + f(F.k) + '" data-plan-width="' + (s ? f(2 * F.hw * s) : '') + '" data-drawing-top="' + HEADER + '">');
    parts.push('<title>' + esc((state.currentLocation || 'Plan') + ' \u2014 vue en plan') + '</title>');
    parts.push('<rect width="' + F.W + '" height="' + total + '" fill="' + BACKGROUND + '"/>');
    parts.push(header(F, now, extra));
    parts.push('<g id="drawing">');
    parts.push(floorImage(F, scene.floorImage));
    parts.push(modelLayer ? modelLayer(F) : '<g id="model"><image x="0" y="' + HEADER + '" width="' + F.W + '" height="' + F.H + '" href="' + shot.toDataURL('image/png') + '"/></g>');
    parts.push(footprint(F, scene.footprint));
    parts.push(zones(F, scene.zones));
    parts.push(scaleEntity(F, scene.scale));
    parts.push(measures(F, scene.measures));
    parts.push(objects(F, scene.objects));
    parts.push(north(F, scene.north));
    parts.push(scaleBar(F));
    parts.push('</g></svg>');
    return parts.join('\n');
  }

  /* Export SVG : promesse du nom du fichier téléchargé, ou null. Résultat
     mémorisé dans NS.lastPlanExport (bancs). opts : { modelLayer, extra
     (cf. renderSvg), suffix (avant .svg, ex. "coupe") }. */
  async function exportSvg(opts) {
    const v = viewer();
    if (!v || !v.isActive() || !NS.sceneAvailable() || busy) return null;
    busy = true;
    const now = new Date();
    try {
      if (!X.ensurePlanView()) throw new Error('vue en plan indisponible (mod\u00e8le non charg\u00e9)');
      const svg = renderSvg(now, opts && opts.modelLayer, opts && opts.extra);
      if (!svg) throw new Error('rendu indisponible');
      const blob = new Blob([svg], { type: 'image/svg+xml;charset=utf-8' });
      const name = NS.exportFileName((opts && opts.suffix ? opts.suffix + '.' : '') + 'svg', now);
      NS.downloadBytes(blob, name, 'image/svg+xml');
      NS.lastPlanExport = { kind: 'svg', name, blob, text: svg };
      NS.showPrintNotice('Vue en plan enregistr\u00e9e en SVG (' + name + ').', 'info', 8000);
      return name;
    } catch (cause) {
      console.error('MyPnPlanViewer : export SVG impossible', cause);
      NS.showPrintNotice('Export SVG impossible : ' + (cause && cause.message ? cause.message : cause));
      return null;
    } finally {
      busy = false;
    }
  }

  /* ------------------- Exposition sur l'espace de noms ------------------- */
  Object.assign(NS.scene3dExport, { exportSvg, renderSvg, svgFrame: frame, svgLabel: label });
})(globalThis);
