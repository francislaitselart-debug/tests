﻿/* ============================================================
   MyPnPlanViewerV2 — module « edit-panel »
   ============================================================
   Panneau « Apparence / Propriétés » du mode d'édition. Sous forme de
   carte sous le cadenas, visible uniquement lorsqu'une forme est
   sélectionnée :

     - apparence : couleur/opacité du fond et couleur/épaisseur du contour,
       chacun avec une case « Transparent » — appliqués à la forme et
       mémorisés dans NS.edit.style pour les prochains tracés (une forme au
       contour transparent garde un contour fantôme pendant l'édition,
       cf. viewer-edit-render.js) ;
     - sections selon le type de forme : texte (libellé / étiquette de
       rappel : texte, taille, gras, italique, encadré), flèche
       (extrémité(s) portant la pointe : arrivée, départ ou les deux),
       secteur (rayon en % de la largeur du plan, angles de début et de
       fin en degrés),
       échelle (étalon : longueur réelle du segment, unité, case
       « Afficher sur le plan »), icône (galerie de la clé editIcons +
       chemin libre), rotation (formes orientables : champ « Angle » en
       degrés, sens horaire — clé rotation, orientation du segment ou
       rotation cumulée selon le type, cf. NS.shapeAngle — et deux boutons
       de quart de tour) ;
     - propriétés : nom (info-bulle, clé label) et propriétés libres
       { nom: valeur } (clé props).

   Les champs que les poignées font varier (angle de rotation, rayon et
   angles du secteur) sont rafraîchis à chaque redessin de la forme
   sélectionnée, hors saisie en cours (syncLiveFields).

   Le tout est écrit dans current_plan_drawnShapes_json. Complète viewer-edit-core.js
   (ordre de chargement : readme § 1).

   NOTE ENCODAGE : chaînes affichées en ASCII pur (\uXXXX), commentaires
   accentués, BOM UTF-8, fins de ligne CRLF (readme.txt § 14).
   ============================================================ */
(function (global) {
  'use strict';

  const NS = global.MyPnPlanViewerV2NS = global.MyPnPlanViewerV2NS || {};
  const ed = NS.edit;
  const state = NS.state;
  const clampNum = NS.clampNum;

  // Types sans remplissage (lignes ouvertes, marqueurs, images) : les
  // rangées Fond / Opacité du panneau sont masquées.
  const NO_FILL_TYPES = ['polyline', 'line', 'arrow', 'measure', 'scale',
    'pin', 'icon'];
  // Types sans contour réglable (l'icône est une image telle quelle).
  const NO_STROKE_TYPES = ['icon'];
  // Types portant du texte (section « Texte » du panneau).
  const TEXT_TYPES = ['label', 'callout'];

  function hexToRgba(hex, alpha) {
    const n = parseInt(hex.slice(1), 16);
    return 'rgba(' + (n >> 16 & 255) + ', ' + (n >> 8 & 255) + ', ' +
      (n & 255) + ', ' + alpha + ')';
  }

  /* Couleurs CSS d'une forme dessinée : « none » si la case Transparent
     est cochée, sinon son style propre, sinon les défauts du module. */
  function drawnShapeFill(s) {
    if (s.fillNone) return 'none';
    if (s.fillColor) return hexToRgba(s.fillColor, s.fillOpacity);
    // Forme reçue de l'application avec une couleur css non convertible
    // vers les clés du panneau (nom de couleur…) : utilisée telle quelle.
    return s.fill || NS.DRAWN_SHAPE_FILL;
  }

  function drawnShapeStroke(s) {
    if (s.strokeNone) return 'none';
    return s.strokeColor || s.stroke || NS.DRAWN_SHAPE_STROKE;
  }

  /* Galerie des icônes déclarées par la clé editIcons de la configuration,
     reconstruite à chaque sélection d'une forme icône. Un clic remplace le
     fichier de la forme sélectionnée. */
  function buildIconGallery(selectedFile) {
    const gallery = NS.dom.shapeIconGallery;
    gallery.textContent = '';
    for (const icon of state.currentConfig.editIcons) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.style.backgroundImage = 'url("' + icon.filename + '")';
      btn.title = icon.label || icon.filename;
      btn.setAttribute('aria-label', btn.title);
      btn.classList.toggle('selected', icon.filename === selectedFile);
      btn.addEventListener('click', () => {
        if (!ed.selected || ed.selected.type !== 'icon') return;
        ed.selected.filename = icon.filename;
        NS.dom.shapeIconFile.value = icon.filename;
        buildIconGallery(icon.filename);
        NS.renderEditLayer();
        NS.writeDrawnShapes();
      });
      gallery.appendChild(btn);
    }
  }

  /* Sens des pointes de la flèche sélectionnée : des trois vignettes de la
     section « Flèche », celle en vigueur est cerclée de bleu. */
  function syncArrowHeads() {
    const heads = NS.normalizeArrowHeads(
      ed.selected ? ed.selected.heads : ed.style.arrowHeads);
    for (const btn of NS.dom.shapeArrowHeads.querySelectorAll('button')) {
      btn.classList.toggle('selected', btn.dataset.heads === heads);
    }
  }

  /* Champ « Angle » de la section Rotation, masquée pour les types sans
     angle (NS.shapeAngle null). Le champ n'est pas réécrit pendant que
     l'opérateur y saisit (sauf force : fin de saisie, boutons). */
  function syncRotationField(src, force) {
    const dom = NS.dom;
    const angle = NS.shapeAngle(src);
    dom.shapeRotationSection.hidden = angle === null;
    if (angle === null) return;
    if (!force && document.activeElement === dom.shapeRotation) return;
    dom.shapeRotation.value = String(Math.round(angle * 10) / 10);
  }

  /* Champs reflétant une géométrie que les poignées modifient (angle de
     rotation ; rayon et angles du secteur) : rafraîchis à chaque redessin
     de la forme sélectionnée, hors champ en cours de saisie. */
  function syncLiveFields() {
    const src = ed.selected;
    if (!src) return;
    syncRotationField(src, false);
    if (src.type === 'sector') {
      const dom = NS.dom;
      const fields = [
        [dom.shapeSectorRadius, Math.round(src.r * 100)],
        [dom.shapeSectorStart, Math.round(src.startAngle)],
        [dom.shapeSectorEnd, Math.round(src.endAngle)],
      ];
      for (const [input, value] of fields) {
        if (document.activeElement !== input) input.value = String(value);
      }
    }
  }

  /* Recharge tous les champs du panneau depuis la forme sélectionnée.
     Appelé uniquement quand la cible du panneau change
     (syncStylePanelIfNeeded) : recharger pendant une saisie écraserait le
     champ en cours d'édition. Le panneau n'est visible que lorsqu'une
     forme est sélectionnée. */
  function syncStylePanel() {
    const dom = NS.dom;
    if (!NS.editActive() || !ed.selected) {
      dom.shapeStylePanel.hidden = true;
      return;
    }
    dom.shapeStylePanel.hidden = false;
    const src = ed.selected;
    const type = src.type;

    dom.shapeFillRow.hidden = NO_FILL_TYPES.indexOf(type) !== -1;
    dom.shapeOpacityRow.hidden = dom.shapeFillRow.hidden;
    dom.shapeFillColor.value = src.fillColor || ed.style.fillColor;
    dom.shapeFillNone.checked = Boolean(src.fillNone);
    dom.shapeFillOpacity.value = String(Math.round(
      (src.fillOpacity != null ? src.fillOpacity : ed.style.fillOpacity) * 100));
    dom.shapeFillOpacityVal.textContent = dom.shapeFillOpacity.value;
    dom.shapeStrokeColor.value = src.strokeColor || ed.style.strokeColor;
    dom.shapeStrokeNone.checked = Boolean(src.strokeNone);
    dom.shapeStrokeWidth.value = String(src.strokeWidth || ed.style.strokeWidth);
    dom.shapeShowMode.value = src.show_mode || NS.SHAPE_SHOW_MODE_DEFAULT;
    // Les rangées contour restent affichées pour la punaise (sa couleur
    // vient du contour) mais sont masquées pour l'icône (image telle
    // quelle). L'épaisseur n'a pas de sens pour punaise et icône.
    const strokeHidden = NO_STROKE_TYPES.indexOf(type) !== -1;
    dom.shapeStrokeColor.parentElement.parentElement.hidden = strokeHidden;
    dom.shapeStrokeWidth.parentElement.hidden =
      strokeHidden || type === 'pin' || type === 'label' || type === 'callout';

    // Section texte (libellé / étiquette de rappel).
    const isText = TEXT_TYPES.indexOf(type) !== -1;
    dom.shapeTextSection.hidden = !isText;
    if (isText) {
      dom.shapeTextInput.value = src.text || '';
      dom.shapeFontSize.value = String(src.fontSize || 14);
      dom.shapeBoldInput.checked = Boolean(src.bold);
      dom.shapeItalicInput.checked = Boolean(src.italic);
      // L'étiquette de rappel est toujours encadrée : case masquée.
      dom.shapeBoxedWrap.hidden = type === 'callout';
      dom.shapeBoxedInput.checked = Boolean(src.boxed);
    }

    // Section secteur.
    dom.shapeSectorSection.hidden = type !== 'sector';
    if (type === 'sector') {
      dom.shapeSectorRadius.value = String(Math.round(src.r * 100));
      dom.shapeSectorStart.value = String(Math.round(src.startAngle));
      dom.shapeSectorEnd.value = String(Math.round(src.endAngle));
    }

    // Section flèche : extrémité(s) portant la pointe.
    dom.shapeArrowSection.hidden = type !== 'arrow';
    if (type === 'arrow') syncArrowHeads();

    // Section étalon d'échelle.
    dom.shapeScaleSection.hidden = type !== 'scale';
    if (type === 'scale') {
      dom.shapeScaleValue.value = String(src.value);
      dom.shapeScaleUnit.value = src.unit || 'm';
      dom.shapeScaleShown.checked = src.shown !== false;
    }

    // Section icône / image.
    dom.shapeIconSection.hidden = type !== 'icon';
    if (type === 'icon') {
      dom.shapeIconFile.value = src.filename || '';
      buildIconGallery(src.filename || '');
    }

    // Section rotation (formes orientables).
    syncRotationField(src, true);

    dom.shapeNameInput.value = src.label || '';
    renderShapeProps();
  }

  function syncStylePanelIfNeeded() {
    const target = NS.editActive() ? ed.selected : null;
    if (target === ed.stylePanelTarget) {
      // Même forme : seuls les champs que les poignées font varier
      // (rotation, secteur) sont rafraîchis.
      if (target) syncLiveFields();
      return;
    }
    ed.stylePanelTarget = target;
    syncStylePanel();
  }

  /* Applique les champs d'apparence du panneau à la forme sélectionnée
     (écrite dans current_plan_drawnShapes_json en fin de saisie : write). L'apparence
     choisie est aussi mémorisée dans NS.edit.style : elle devient celle
     des prochaines formes tracées. */
  function applyPanelStyle(write) {
    if (!ed.selected) return;
    const dom = NS.dom;
    const style = {
      fillColor: dom.shapeFillColor.value,
      fillOpacity: clampNum((Number(dom.shapeFillOpacity.value) || 0) / 100, 0, 1),
      fillNone: dom.shapeFillNone.checked,
      strokeColor: dom.shapeStrokeColor.value,
      strokeNone: dom.shapeStrokeNone.checked,
      strokeWidth: clampNum(Math.round(Number(dom.shapeStrokeWidth.value)) || 2, 1, 12),
    };
    dom.shapeFillOpacityVal.textContent = String(Math.round(style.fillOpacity * 100));
    ed.style = Object.assign({}, ed.style, style);
    Object.assign(ed.selected, style);
    NS.renderEditLayer();
    if (write) NS.writeDrawnShapes();
  }

  /* Applique les champs de la section texte au libellé / à l'étiquette
     sélectionné(e) ; taille et style deviennent aussi les défauts des
     prochains textes posés. */
  function applyTextStyle(write) {
    if (!ed.selected || TEXT_TYPES.indexOf(ed.selected.type) === -1) return;
    const dom = NS.dom;
    const fontSize = clampNum(Math.round(Number(dom.shapeFontSize.value)) || 14, 6, 72);
    const text = dom.shapeTextInput.value.trim();
    ed.selected.text = text.length > 0 ? text : 'Texte';
    ed.selected.fontSize = fontSize;
    ed.selected.bold = dom.shapeBoldInput.checked;
    ed.selected.italic = dom.shapeItalicInput.checked;
    if (ed.selected.type === 'label') {
      ed.selected.boxed = dom.shapeBoxedInput.checked;
    }
    ed.style.fontSize = fontSize;
    ed.style.bold = dom.shapeBoldInput.checked;
    ed.style.italic = dom.shapeItalicInput.checked;
    if (ed.selected.type === 'label') ed.style.boxed = dom.shapeBoxedInput.checked;
    NS.renderEditLayer();
    if (write) NS.writeDrawnShapes();
  }

  /* Applique les champs numériques de la section secteur. */
  function applySectorFields(write) {
    if (!ed.selected || ed.selected.type !== 'sector') return;
    const dom = NS.dom;
    const wrap = (v) => ((Math.round(Number(v) || 0) % 360) + 360) % 360;
    ed.selected.r = clampNum((Number(dom.shapeSectorRadius.value) || 1) / 100,
      0.002, 1);
    ed.selected.startAngle = wrap(dom.shapeSectorStart.value);
    ed.selected.endAngle = wrap(dom.shapeSectorEnd.value);
    NS.renderEditLayer();
    // Géométrie changée : la liaison elements du secteur est recalculée.
    if (write) NS.writeDrawnShapes(ed.selected);
  }

  /* Applique le champ « Angle » de la section rotation à la forme
     sélectionnée (aperçu immédiat, écriture en fin de saisie). Champ vide
     ou non numérique : rien n'est appliqué. */
  function applyRotationField(write) {
    if (!ed.selected || NS.shapeAngle(ed.selected) === null) return;
    const raw = NS.dom.shapeRotation.value.trim();
    if (raw === '') return;
    const angle = Number(raw);
    if (!Number.isFinite(angle)) return;
    NS.setShapeAngle(ed.selected, angle);
    NS.renderEditLayer();
    // Géométrie changée : la liaison elements est recalculée.
    if (write) NS.writeDrawnShapes(ed.selected);
  }

  /* Applique les champs de la section échelle à l'étalon sélectionné. Les
     cotes du calque d'édition suivent immédiatement (renderEditLayer,
     via measureLabel) ; celles des calques "shapes" sont retracées en fin
     de saisie (syncScaleDependents, appelé par writeDrawnShapes). */
  function applyScaleFields(write) {
    if (!ed.selected || ed.selected.type !== 'scale') return;
    const dom = NS.dom;
    const value = Number(dom.shapeScaleValue.value);
    ed.selected.value = Number.isFinite(value) && value > 0 ? value : 1;
    ed.selected.unit = dom.shapeScaleUnit.value.trim() || 'm';
    ed.selected.shown = dom.shapeScaleShown.checked;
    NS.renderEditLayer();
    if (write) NS.writeDrawnShapes();
  }

  /* (Re)construit les lignes de propriétés libres { nom: valeur } de la
     forme sélectionnée. Reconstruit au changement de sélection et à
     l'ajout/retrait d'une ligne — pas pendant la saisie, pour ne pas
     perdre le focus. */
  function renderShapeProps() {
    const shapePropsList = NS.dom.shapePropsList;
    shapePropsList.textContent = '';
    if (!ed.selected) return;
    for (const prop of ed.selected.props || []) {
      const row = document.createElement('div');
      row.className = 'shape-prop-row';
      const name = document.createElement('input');
      name.type = 'text';
      name.placeholder = 'Nom';
      name.setAttribute('aria-label', 'Nom de la propri\u00e9t\u00e9');
      name.value = prop.name;
      name.addEventListener('change', () => {
        prop.name = name.value.trim();
        NS.writeDrawnShapes();
      });
      const value = document.createElement('input');
      value.type = 'text';
      value.placeholder = 'Valeur';
      value.setAttribute('aria-label', 'Valeur de la propri\u00e9t\u00e9');
      value.value = prop.value;
      value.addEventListener('change', () => {
        prop.value = value.value.trim();
        NS.writeDrawnShapes();
      });
      const remove = document.createElement('button');
      remove.type = 'button';
      remove.className = 'shape-prop-rm';
      remove.title = 'Retirer la propri\u00e9t\u00e9';
      remove.setAttribute('aria-label', 'Retirer la propri\u00e9t\u00e9');
      remove.textContent = '\u00d7';
      remove.addEventListener('click', () => {
        const index = ed.selected.props.indexOf(prop);
        if (index !== -1) ed.selected.props.splice(index, 1);
        renderShapeProps();
        NS.writeDrawnShapes();
      });
      row.appendChild(name);
      row.appendChild(value);
      row.appendChild(remove);
      shapePropsList.appendChild(row);
    }
  }

  /* ---------------- Écouteurs des champs du panneau ---------------- */

  const dom = NS.dom;

  /* Champs d'apparence : aperçu immédiat (input), écriture dans
     current_plan_drawnShapes_json en fin de saisie (change). Les cases Transparent
     s'appliquent et s'écrivent immédiatement. */
  for (const input of [dom.shapeFillColor, dom.shapeFillOpacity,
                       dom.shapeStrokeColor, dom.shapeStrokeWidth]) {
    input.addEventListener('input', () => applyPanelStyle(false));
    input.addEventListener('change', () => {
      applyPanelStyle(true);
      // Réaffiche la valeur bornée après une saisie libre au clavier.
      dom.shapeStrokeWidth.value = String((ed.selected || ed.style).strokeWidth);
    });
  }
  for (const box of [dom.shapeFillNone, dom.shapeStrokeNone]) {
    box.addEventListener('change', () => applyPanelStyle(true));
  }

  /* Section texte : aperçu immédiat pendant la frappe, écriture en fin de
     saisie ; cases de style appliquées et écrites immédiatement. */
  for (const input of [dom.shapeTextInput, dom.shapeFontSize]) {
    input.addEventListener('input', () => applyTextStyle(false));
    input.addEventListener('change', () => {
      applyTextStyle(true);
      if (ed.selected && TEXT_TYPES.indexOf(ed.selected.type) !== -1) {
        dom.shapeTextInput.value = ed.selected.text;
        dom.shapeFontSize.value = String(ed.selected.fontSize);
      }
    });
  }
  for (const box of [dom.shapeBoldInput, dom.shapeItalicInput, dom.shapeBoxedInput]) {
    box.addEventListener('change', () => applyTextStyle(true));
  }

  /* Section flèche : le sens choisi s'applique aussitôt à la flèche
     sélectionnée, s'écrit dans current_plan_drawnShapes_json, et devient celui des
     prochaines flèches tracées (comme l'apparence). */
  for (const btn of dom.shapeArrowHeads.querySelectorAll('button')) {
    btn.addEventListener('click', () => {
      const heads = NS.normalizeArrowHeads(btn.dataset.heads);
      ed.style.arrowHeads = heads;
      if (ed.selected && ed.selected.type === 'arrow') {
        ed.selected.heads = heads;
        NS.renderEditLayer();
        NS.writeDrawnShapes();
      }
      syncArrowHeads();
      // Un bouton focalisé re-cliquerait sur Entrée.
      btn.blur();
    });
  }

  /* Section secteur : aperçu immédiat, écriture en fin de saisie. */
  for (const input of [dom.shapeSectorRadius, dom.shapeSectorStart,
                       dom.shapeSectorEnd]) {
    input.addEventListener('input', () => applySectorFields(false));
    input.addEventListener('change', () => {
      applySectorFields(true);
      if (ed.selected && ed.selected.type === 'sector') {
        dom.shapeSectorRadius.value = String(Math.round(ed.selected.r * 100));
        dom.shapeSectorStart.value = String(Math.round(ed.selected.startAngle));
        dom.shapeSectorEnd.value = String(Math.round(ed.selected.endAngle));
      }
    });
  }

  /* Section échelle : aperçu immédiat (les cotes suivent), écriture en fin
     de saisie ; la case « Afficher sur le plan » s'applique et s'écrit
     immédiatement. */
  for (const input of [dom.shapeScaleValue, dom.shapeScaleUnit]) {
    input.addEventListener('input', () => applyScaleFields(false));
    input.addEventListener('change', () => {
      applyScaleFields(true);
      // Réaffiche les valeurs retenues après une saisie libre.
      if (ed.selected && ed.selected.type === 'scale') {
        dom.shapeScaleValue.value = String(ed.selected.value);
        dom.shapeScaleUnit.value = ed.selected.unit;
      }
    });
  }
  dom.shapeScaleShown.addEventListener('change', () => applyScaleFields(true));

  /* Section rotation : aperçu immédiat, écriture en fin de saisie (la
     valeur est alors réaffichée ramenée dans [0, 360[) ; les boutons de
     quart de tour s'appliquent et s'écrivent immédiatement. */
  dom.shapeRotation.addEventListener('input', () => applyRotationField(false));
  dom.shapeRotation.addEventListener('change', () => {
    applyRotationField(true);
    if (ed.selected) syncRotationField(ed.selected, true);
  });
  for (const [btn, delta] of [[dom.shapeRotateCcw, -90], [dom.shapeRotateCw, 90]]) {
    btn.addEventListener('click', () => {
      if (!ed.selected || !NS.isRotatable(ed.selected)) return;
      NS.rotateShape(ed.selected, delta);
      NS.renderEditLayer();
      NS.writeDrawnShapes(ed.selected);
      syncRotationField(ed.selected, true);
      // Un bouton focalisé re-cliquerait sur Entrée.
      btn.blur();
    });
  }

  /* Section icône : chemin libre vers un fichier du dossier de l'objet. */
  dom.shapeIconFile.addEventListener('change', () => {
    if (!ed.selected || ed.selected.type !== 'icon') return;
    ed.selected.filename = dom.shapeIconFile.value.trim();
    buildIconGallery(ed.selected.filename);
    NS.renderEditLayer();
    NS.writeDrawnShapes();
  });

  /* Section « Affichage » : règle show_mode de la forme sélectionnée
     (readme § 6.3), appliquée et écrite immédiatement. Une forme rendue
     invisible cadenas fermé reste affichée en contour fantôme tant que le
     cadenas est ouvert. */
  dom.shapeShowMode.addEventListener('change', () => {
    if (!ed.selected) return;
    ed.selected.show_mode = dom.shapeShowMode.value;
    NS.renderEditLayer();
    NS.writeDrawnShapes();
  });

  dom.shapeNameInput.addEventListener('change', () => {
    if (!ed.selected) return;
    ed.selected.label = dom.shapeNameInput.value.trim();
    NS.renderEditLayer(); // met à jour l'info-bulle de la forme
    NS.writeDrawnShapes();
  });

  dom.shapePropAddBtn.addEventListener('click', () => {
    if (!ed.selected) return;
    ed.selected.props.push({ name: '', value: '' });
    renderShapeProps();
    // Focus sur le champ « nom » de la ligne qui vient d'être ajoutée.
    const inputs = dom.shapePropsList.querySelectorAll('input');
    if (inputs.length >= 2) inputs[inputs.length - 2].focus();
  });

  /* ------------------- Exposition sur l'espace de noms ------------------- */
  NS.hexToRgba = hexToRgba;
  NS.drawnShapeFill = drawnShapeFill;
  NS.drawnShapeStroke = drawnShapeStroke;
  NS.syncStylePanelIfNeeded = syncStylePanelIfNeeded;
})(globalThis);
