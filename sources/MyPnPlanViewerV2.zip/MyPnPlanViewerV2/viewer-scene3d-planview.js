﻿/* ============================================================
   MyPnPlanViewerV2 — module « scene3d-planview »
   ============================================================
   Vue en plan d'une représentation 3D : vue de dessus orthographique
   (nord en haut selon la clé north de la scène, sans perspective), que
   l'on consulte dans l'objet — déplacement à la souris, zoom — et dont
   les modules d'export (viewer-scene3d-export*.js) tirent le PNG et le
   SVG. La permutation des caméras est faite par three-viewer.js
   (ThreeViewer.setPlanView) ; ce module porte le bouton « Vue en plan »
   de la barre de zoom (#planViewBtn, masquable par la clé de
   configuration showPlanViewButton), son menu (#planViewMenu : bascule,
   export PNG, export SVG) et la puce de mode (#planModeChip : 3D | Vue en
   plan) en haut à gauche du cadre 3D.

   En vue en plan : le bouton ↻ de la barre de zoom et les directions du
   repère de coin ramènent à la 3D ; le mode édition reste utilisable (les
   tracés au sol y sont même plus commodes). Rien n'est écrit dans les
   propriétés.

   Chargé après viewer-scene3d-helper.js et avant viewer-scene3d-tools.js
   (ordre imposé par index.html, readme.txt § 1).

   NOTE ENCODAGE : chaînes affichées en ASCII pur (\uXXXX), commentaires
   accentués, BOM UTF-8, fins de ligne CRLF (readme.txt § 14).
   ============================================================ */
(function (global) {
  'use strict';

  const NS = global.MyPnPlanViewerV2NS = global.MyPnPlanViewerV2NS || {};
  const state = NS.state;
  const {
    threeViewport, planViewBtn, planViewSep, planViewMenu, planViewToggle, planViewToggleLabel,
    planViewPng, planViewSvg, planViewSvgCut, planViewHint, planModeChip, planModeChip3d, planModeChipPlan,
  } = NS.dom;

  function viewer() {
    return global.ThreeViewer || null;
  }

  /* Représentation 3D affichée et bouton autorisé par la configuration. */
  function available() {
    return Boolean(NS.sceneAvailable && NS.sceneAvailable() &&
      state.currentConfig && state.currentConfig.showPlanViewButton !== false);
  }

  function isPlanView() {
    const v = viewer();
    return Boolean(v && v.isPlanView && v.isPlanView());
  }

  /* ---------------------- Bascule ---------------------- */

  function setPlanView(on, opts) {
    const v = viewer();
    if (!v || !v.setPlanView || !NS.sceneAvailable()) return;
    const o = Object.assign({ north: NS.northAngle ? (NS.northAngle() || 0) : 0 }, opts || {});
    v.setPlanView(Boolean(on), o);
    refreshChip();
  }

  function refreshChip() {
    const on = isPlanView();
    const show = available();
    planModeChip.hidden = !show;
    planModeChip3d.classList.toggle('on', !on);
    planModeChipPlan.classList.toggle('on', on);
    planViewBtn.classList.toggle('on', on);
    planViewToggleLabel.textContent = on ? 'Revenir \u00e0 la vue 3D' : 'Afficher la vue en plan';
    threeViewport.classList.toggle('plan-view', on);
  }

  /* Visibilité du bouton et de la puce : appelée à chaque changement de
     représentation (viewer-plan.js). */
  function refreshButton() {
    const show = available();
    planViewBtn.hidden = !show;
    planViewSep.hidden = !show;
    closeMenu();
    refreshChip();
  }

  /* ---------------------- Menu ---------------------- */

  function isMenuOpen() {
    return !planViewMenu.hidden;
  }

  function openMenu() {
    if (!available()) return;
    const exp = NS.scene3dExport || {};
    planViewPng.disabled = typeof exp.exportPng !== 'function';
    planViewSvg.disabled = typeof exp.exportSvg !== 'function';
    planViewSvgCut.disabled = typeof exp.exportSvgCut !== 'function';
    const north = NS.northAngle ? NS.northAngle() : null;
    planViewHint.textContent = (north === null
      ? 'Nord inconnu : le haut de la vue est l\u2019axe \u2212Z du mod\u00e8le (saisir le nord dans le panneau Sc\u00e8ne 3D).'
      : 'Nord en haut (' + NS.formatNumber(north) + '\u00b0).') +
      ' Glisser pour d\u00e9placer, molette pour zoomer ; \u21bb revient \u00e0 la 3D.';
    planViewMenu.hidden = false;
    planViewBtn.setAttribute('aria-expanded', 'true');
    planViewToggle.focus();
  }

  function closeMenu() {
    if (!isMenuOpen()) return;
    planViewMenu.hidden = true;
    planViewBtn.setAttribute('aria-expanded', 'false');
  }

  planViewBtn.addEventListener('click', () => {
    if (isMenuOpen()) closeMenu();
    else openMenu();
    planViewBtn.blur();
  });

  planViewToggle.addEventListener('click', () => {
    closeMenu();
    setPlanView(!isPlanView());
  });

  /* Exports : fournis par les modules viewer-scene3d-export*.js (PNG, SVG) ;
     ils passent en vue en plan si besoin. */
  planViewPng.addEventListener('click', () => {
    closeMenu();
    if (NS.scene3dExport && NS.scene3dExport.exportPng) NS.scene3dExport.exportPng();
  });
  planViewSvg.addEventListener('click', () => {
    closeMenu();
    if (NS.scene3dExport && NS.scene3dExport.exportSvg) NS.scene3dExport.exportSvg();
  });
  planViewSvgCut.addEventListener('click', () => {
    closeMenu();
    if (NS.scene3dExport && NS.scene3dExport.exportSvgCut) NS.scene3dExport.exportSvgCut();
  });

  // Clic hors du menu (et hors du bouton, qui gère lui-même la bascule).
  document.addEventListener('pointerdown', (e) => {
    if (!isMenuOpen()) return;
    if (planViewMenu.contains(e.target) || planViewBtn.contains(e.target)) return;
    closeMenu();
  }, true);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && isMenuOpen()) {
      closeMenu();
      e.stopPropagation();
    }
  }, true);

  // La puce suit les sorties de la vue en plan décidées ailleurs (bouton ↻,
  // repère de coin, changement de modèle).
  function watch() {
    const v = viewer();
    if (!v || typeof v.onPlanViewChange !== 'function') return false;
    v.onPlanViewChange(refreshChip);
    return true;
  }
  NS.onThreeViewerReady(watch);

  /* ------------------- Exposition sur l'espace de noms ------------------- */
  NS.scene3dPlanView = { setPlanView, isPlanView, openMenu, closeMenu, refreshChip };
  NS.refreshPlanViewButton = refreshButton;
})(globalThis);
