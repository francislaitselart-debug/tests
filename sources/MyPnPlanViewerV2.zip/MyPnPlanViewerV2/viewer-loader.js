﻿/* ============================================================
   MyPnPlanViewerV2 — module « loader »
   ============================================================
   Chargement À LA DEMANDE des deux dépendances lourdes de l'objet, pour
   ne pas les faire payer à toutes les ouvertures :

     three-viewer.bundle.js         (887 Ko) moteur 3D, chargé à la
                                    première représentation 3D affichée
                                    (viewer-plan.js, showModelPlan) ;
     vendor/pdf-lib/pdf-lib.min.js  (525 Ko) repli PDF de l'impression,
                                    chargé au premier PDF demandé
                                    (viewer-print.js, buildPdf).

   Une ouverture qui n'affiche qu'un plan 2D et n'imprime pas ne télécharge
   donc ni l'un ni l'autre, et n'ouvre aucun contexte WebGL.

   Les modules de la scène 3D se raccordent au moteur par
   NS.onThreeViewerReady(rappel) : le rappel part tout de suite si le
   moteur est déjà là, sinon dès que le bundle est arrivé. Ils restent
   écrits pour un moteur absent (viewer-scene3d-render.js, ctx()).

   Chargé EN PREMIER par index.html : ce module ne dépend d'aucun autre.

   NOTE ENCODAGE : chaînes affichées en ASCII pur (échappements unicode),
   commentaires accentués, BOM UTF-8, fins de ligne CRLF (readme.txt § 14).
   ============================================================ */
(function (global) {
  'use strict';

  const NS = global.MyPnPlanViewerV2NS = global.MyPnPlanViewerV2NS || {};

  const THREE_BUNDLE = 'three-viewer.bundle.js';
  const PDF_LIB = 'vendor/pdf-lib/pdf-lib.min.js';

  /* Une promesse par URL : le script n'est demandé qu'une fois et les
     appels suivants attendent la même promesse. Un échec est oublié, pour
     qu'une nouvelle tentative reste possible (réseau rétabli). */
  const pending = new Map();

  function loadScriptOnce(src) {
    const known = pending.get(src);
    if (known) return known;
    const promise = new Promise(function (resolve, reject) {
      const el = document.createElement('script');
      el.src = src;
      el.onload = function () { resolve(src); };
      el.onerror = function () {
        pending.delete(src);
        reject(new Error(src + ' : chargement impossible'));
      };
      document.head.appendChild(el);
    });
    pending.set(src, promise);
    return promise;
  }

  /* ---------------------- Moteur 3D ---------------------- */

  /* Rappels des modules de la scène en attente du moteur. */
  const waiting = [];

  function call(cb) {
    try {
      cb(global.ThreeViewer || null);
    } catch (cause) {
      console.error('MyPnPlanViewerV2 : raccordement au moteur 3D impossible', cause);
    }
  }

  function onThreeViewerReady(cb) {
    if (typeof cb !== 'function') return;
    if (global.ThreeViewer) call(cb);
    else waiting.push(cb);
  }

  /* Charge le bundle si besoin, raccorde les modules en attente et rend le
     moteur (null si le chargement a échoué : l'appelant le signale). */
  function ensureThreeViewer() {
    if (global.ThreeViewer) return Promise.resolve(global.ThreeViewer);
    return loadScriptOnce(THREE_BUNDLE).then(function () {
      while (waiting.length) call(waiting.shift());
      return global.ThreeViewer || null;
    });
  }

  /* ---------------------- pdf-lib ---------------------- */

  function ensurePdfLib() {
    if (global.PDFLib) return Promise.resolve(global.PDFLib);
    return loadScriptOnce(PDF_LIB).then(function () { return global.PDFLib || null; });
  }

  /* ------------------- Exposition sur l'espace de noms ------------------- */
  NS.loadScriptOnce = loadScriptOnce;
  NS.onThreeViewerReady = onThreeViewerReady;
  NS.ensureThreeViewer = ensureThreeViewer;
  NS.threeViewerLoaded = function () { return Boolean(global.ThreeViewer); };
  NS.ensurePdfLib = ensurePdfLib;
})(globalThis);
