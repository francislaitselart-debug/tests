﻿/* ============================================================
   MyPnPlanViewerV2 — module « scene3d »
   ============================================================
   Mode d'édition d'une représentation 3D et scène 3D du plan affiché.

   Le cadenas et la barre d'outils sont PARTAGÉS avec le mode d'édition
   des formes 2D (clé shapeEditing, viewer-edit-tools.js) : sur un modèle
   3D, la barre bascule sur ses outils 3D (classe mode-3d) et le panneau
   « Scène 3D » remplace le panneau « Apparence / Propriétés ».

   La scène est reçue et écrite par current_plan_scene3d_json (readme
   § 10 bis) : un document JSON par plan 3D, mémorisé par plan (clé
   node_id:planIndex, NS.elementsKey) le temps de la page comme les
   formes, et RÉÉCRIT en entier à chaque modification de l'opérateur
   (serial croissant), avec la même garde anti-écho (app.js).

   Contenu de la scène (NS.emptyScene3d, viewer-config.js) :
     unit        unité réelle des longueurs (défaut « m ») ;
     scale       échelle du modèle : value = longueur réelle (en unit) d'une
                 unité du fichier, avec l'étalon tracé { x1, z1, x2, z2,
                 length, shown } ; null = inconnue (mesures en unités) ;
     camera      vue par défaut { position, target } dans le repère du
                 modèle, ou null = cadrage automatique. Appliquée à
                 l'ouverture du plan et par le bouton de réinitialisation
                 du zoom (three-viewer.js setDefaultView) ;
     north       nord du plan { angle, shown, x, z } : oriente la rose des
                 vents du repère (viewer-scene3d-helper.js), la vue en plan
                 et les exports ; flèche au sol déplaçable ; null = inconnu ;
     footprint   emprise au sol : polygone { points [[x,z]…], stroke,
                 strokeWidth, dashed, fill, fillOpacity, altitude, shown } ;
     floorImage  fond de plan image posé au sol { filename, x, z, width,
                 height, rotation, opacity, altitude, shown } ;
     measures    mesures { id, type "distance" | "area", points, label,
                 shown } ;
     objects     objets 3D ajoutés ;
     zones       zones / volumes du bâtiment.

   Ce module porte l'état, l'écriture, les conversions (échelle, formats)
   et le panneau « Scène 3D » ; le rendu Three.js est dans
   viewer-scene3d-render.js, les interactions au pointeur et au clavier
   dans viewer-scene3d-tools.js.

   NOTE ENCODAGE : chaînes affichées en ASCII pur (\uXXXX), commentaires
   accentués, BOM UTF-8, fins de ligne CRLF (readme.txt § 14).
   ============================================================ */
(function (global) {
  'use strict';

  const NS = global.MyPnPlanViewerV2NS = global.MyPnPlanViewerV2NS || {};
  const ed = NS.edit;
  const state = NS.state;
  const clampNum = NS.clampNum;

  /* ---- État du mode d'édition de la scène 3D ---- */
  const sc = NS.scene3d = {
    /* Scènes par plan 3D (clé NS.elementsKey), reçues de l'application ou
       modifiées par l'opérateur, jusqu'à la prochaine reconstruction
       (vidé par applyConfig, viewer-nav.js). */
    store: new Map(),
    scene: null,       // scène du plan 3D affiché (référence dans store)
    key: null,         // sa clé
    tool: 'orbit',     // outil actif de la barre en mode 3D
    selected: null,    // 'footprint' | 'floorImage' | 'scale' | 'measure' | 'object' | 'zone' | 'north' | null
    selectedIndex: -1, // rang de la mesure / de l'objet / de la zone sélectionné dans sa liste
    serial: 0,         // compteur des écritures de current_plan_scene3d_json

    /* Apparence de la prochaine emprise tracée : mise à jour par le panneau
       à chaque réglage de l'emprise sélectionnée (comme NS.edit.style). */
    style3d: {
      stroke: '#1d4ed8',
      strokeWidth: null,     // null : épaisseur automatique (0,4 % du modèle)
      dashed: true,
      fill: '#1d4ed8',
      fillOpacity: 0.12,
    },
    pendingFloorImage: '',   // fichier du prochain fond de plan posé ('' : 1er de la galerie)
    pendingModel: '',        // fichier du prochain objet posé ('' : 1er de editModels)
  };

  const render = () => NS.scene3dRender;

  /* Une représentation 3D est affichée. */
  function sceneAvailable() {
    return state.activeMode === 'three' && Boolean(state.currentPlan);
  }

  /* Le mode édition 3D est DISPONIBLE (cadenas visible) : clé shapeEditing
     et modèle 3D affiché ; ACTIF une fois le cadenas ouvert. */
  function sceneEditAvailable() {
    return ed.enabled && sceneAvailable();
  }

  function sceneEditActive() {
    return sceneEditAvailable() && ed.unlocked;
  }

  function viewer() {
    return global.ThreeViewer || null;
  }

  /* Scène du plan 3D affiché, créée vide au besoin. */
  function currentScene() {
    if (!sceneAvailable()) return null;
    const key = NS.elementsKey(state.currentPlan);
    let scene = sc.store.get(key);
    if (!scene) {
      scene = NS.emptyScene3d();
      sc.store.set(key, scene);
    }
    sc.key = key;
    sc.scene = scene;
    return scene;
  }

  /* Reçue de l'application (app.js applyScene3d) : REMPLACE la scène
     mémorisée pour le plan visé et, s'il est affiché, l'applique au
     visualiseur — l'application fait foi, y compris sur ce que l'opérateur
     vient de modifier (la garde anti-écho écarte les relectures). */
  function setPlanScene3d(key, scene) {
    sc.store.set(key, scene);
    if (sceneAvailable() && NS.elementsKey(state.currentPlan) === key) {
      sc.key = key;
      sc.scene = scene;
      sc.selected = null;
      sc.selectedIndex = -1;
      if (NS.scene3dTools) NS.scene3dTools.cancelDraft();
      applyScene();
      rebuild();
      syncPanel();
    }
  }

  /* Résumé d'une scène pour l'état de réception (info-bulle « i »). */
  function describeScene3d(scene) {
    const parts = [scene.camera ? 'vue par d\u00e9faut enregistr\u00e9e' : 'vue automatique'];
    if (scene.scale) parts.push('\u00e9chelle 1 u = ' + formatNumber(scene.scale.value) + ' ' + scene.unit);
    if (scene.north) parts.push('nord ' + formatNumber(scene.north.angle) + '\u00b0');
    if (scene.footprint) parts.push('emprise ' + scene.footprint.points.length + ' sommets');
    if (scene.floorImage) parts.push('fond de plan');
    if (scene.measures.length) parts.push(scene.measures.length + ' mesure(s)');
    if (scene.objects.length) parts.push(scene.objects.length + ' objet(s)');
    if (scene.zones.length) parts.push(scene.zones.length + ' zone(s)');
    if (scene.unit && scene.unit !== 'm' && !scene.scale) parts.push('unit\u00e9 ' + scene.unit);
    return parts.join(', ');
  }

  /* Applique la scène courante au visualiseur Three.js : vue par défaut.
     Le contenu (emprise, fond de plan…) est rendu par rebuild. */
  function applyScene() {
    const v = viewer();
    if (!v || !sc.scene) return;
    v.setDefaultView(sc.scene.camera);
  }

  function rebuild() {
    const r = render();
    if (r) r.rebuild();
  }

  /* Écrit toute la scène du plan affiché dans current_plan_scene3d_json. */
  function writeScene3d() {
    const scene = sc.scene;
    const plan = state.currentPlan;
    if (!scene || !plan) return;
    const nodeId = state.selectedNode ? state.selectedNode.id : 0;
    const planIndex = state.currentPlans.indexOf(plan) + NS.SELECTED_PLAN_BASE;
    sc.serial += 1;
    const out = {
      node_id: nodeId,
      planIndex,
      filename: plan.filename,
      serial: sc.serial,
      unit: scene.unit,
      scale: scene.scale,
      camera: scene.camera,
      north: scene.north,
      footprint: scene.footprint,
      floorImage: scene.floorImage,
      measures: scene.measures,
      objects: scene.objects,
      zones: scene.zones,
    };
    NS.writeProperty(NS.SCENE3D_PROPERTY, JSON.stringify(out));
  }

  /* Modification par le panneau ou les outils : redessine, rafraîchit le
     panneau, écrit (sauf write === false : aperçu). */
  function commit(write) {
    rebuild();
    syncPanel();
    if (write !== false) writeScene3d();
  }

  /* Sélection d'une entité (null : aucune). */
  function selectScene3d(kind, index) {
    const idx = kind === 'measure' || kind === 'object' || kind === 'zone' ? index : -1;
    if (sc.selected === kind && sc.selectedIndex === idx) return;
    sc.selected = kind;
    sc.selectedIndex = idx;
    rebuild();
    syncPanel();
  }

  /* Supprime l'entité sélectionnée (bouton Supprimer, touche Suppr). */
  function deleteSelectedScene3d() {
    if (!sceneEditActive() || !sc.scene || !sc.selected) return;
    const scene = sc.scene;
    if (sc.selected === 'footprint') scene.footprint = null;
    else if (sc.selected === 'floorImage') scene.floorImage = null;
    else if (sc.selected === 'scale') scene.scale = null;
    else if (sc.selected === 'north') scene.north = null;
    else if (sc.selected === 'measure' && scene.measures[sc.selectedIndex]) scene.measures.splice(sc.selectedIndex, 1);
    else if (sc.selected === 'object' && scene.objects[sc.selectedIndex]) scene.objects.splice(sc.selectedIndex, 1);
    else if (sc.selected === 'zone' && scene.zones[sc.selectedIndex]) scene.zones.splice(sc.selectedIndex, 1);
    else return;
    sc.selected = null;
    sc.selectedIndex = -1;
    commit();
  }

  /* ---------------------- Échelle, longueurs, formats ---------------------- */

  /* Longueur réelle d'une unité du modèle (clé scale), ou null. */
  function scaleFactor() {
    return sc.scene && sc.scene.scale ? sc.scene.scale.value : null;
  }

  function unitLabel() {
    return sc.scene ? sc.scene.unit : 'm';
  }

  function polylineLength(points, closed) {
    let len = 0;
    const n = points.length;
    const last = closed ? n : n - 1;
    for (let i = 0; i < last; i++) {
      const a = points[i], b = points[(i + 1) % n];
      len += Math.hypot(b[0] - a[0], b[1] - a[1]);
    }
    return len;
  }

  /* Aire d'un polygone au sol (formule du lacet), en unités² du modèle. */
  function polygonArea(points) {
    let s = 0;
    const n = points.length;
    for (let i = 0; i < n; i++) {
      const a = points[i], b = points[(i + 1) % n];
      s += a[0] * b[1] - b[0] * a[1];
    }
    return Math.abs(s) / 2;
  }

  /* Nombre à deux décimales, virgule décimale, milliers séparés par une
     espace. */
  function formatNumber(v) {
    const fixed = (Math.round(v * 100) / 100).toFixed(2);
    const [int, dec] = fixed.split('.');
    const grouped = int.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    return grouped + ',' + dec;
  }

  /* Longueur en unités du modèle -> texte réel (« 12,50 m ») ou, sans
     échelle, en unités du modèle (« 12,50 u »). */
  function formatLength(modelUnits) {
    const k = scaleFactor();
    return k ? formatNumber(modelUnits * k) + ' ' + unitLabel() : formatNumber(modelUnits) + ' u';
  }

  function formatArea(modelUnits2) {
    const k = scaleFactor();
    return k ? formatNumber(modelUnits2 * k * k) + ' ' + unitLabel() + '\u00b2' : formatNumber(modelUnits2) + ' u\u00b2';
  }

  /* ------------------------ Panneau « Scène 3D » ------------------------ */

  // Ne recopie la valeur que si le champ n'est pas en cours de saisie.
  function setField(input, value) {
    if (document.activeElement === input) return;
    input.value = value;
  }

  function syncGeneral() {
    const d = NS.dom;
    const scene = sc.scene;
    const v = viewer();
    const cam = scene ? scene.camera : null;
    let status;
    if (!cam) {
      status = 'Vue automatique : cadrage du mod\u00e8le entier. Orientez et zoomez la vue, puis enregistrez-la.';
    } else if (v && !v.isAtDefaultView()) {
      status = 'Vue enregistr\u00e9e ; la vue actuelle en diff\u00e8re (le bouton \u21bb y revient, \u00ab D\u00e9finir \u00bb la remplace).';
    } else {
      status = 'Vue enregistr\u00e9e : appliqu\u00e9e \u00e0 l\u2019ouverture du plan et par le bouton \u21bb.';
    }
    d.sceneViewStatus.textContent = status;
    d.sceneViewAutoBtn.disabled = !cam;
    setField(d.sceneUnitInput, scene ? scene.unit : 'm');
    syncNorthFields(d.sceneNorthAngle, d.sceneNorthShown);
    const k = scaleFactor();
    d.sceneScaleStatus.textContent = k
      ? '\u00c9chelle : 1 unit\u00e9 du mod\u00e8le = ' + formatNumber(k) + ' ' + unitLabel() +
        (scene.scale.x1 !== null ? ' (\u00e9talon trac\u00e9).' : '.')
      : '\u00c9chelle inconnue : mesures en unit\u00e9s du mod\u00e8le (u). Tracez un \u00e9talon (outil \u00c9talon) sur une longueur connue.';
    const parts = [];
    if (scene && scene.footprint) parts.push('l\u2019emprise');
    if (scene && scene.floorImage) parts.push('le fond de plan');
    if (scene && scene.scale && scene.scale.x1 !== null) parts.push('l\u2019\u00e9talon');
    if (scene && scene.measures.length) parts.push('une mesure');
    if (scene && scene.objects.length) parts.push('un objet');
    if (scene && scene.zones.length) parts.push('une zone');
    if (scene && scene.north) parts.push('la fl\u00e8che nord');
    d.sceneHint.textContent = parts.length
      ? 'Cliquez ' + parts.join(', ') + ' pour le r\u00e9gler. Outils : Emprise, Fond de plan, \u00c9talon, Distance, Surface, Objet, Zone.'
      : 'Outils de la barre : Emprise, Surface et Zone (un clic par sommet au sol), Fond de plan et Objet (un clic), \u00c9talon et Distance (clics au sol).';
    // Galerie de l'outil Objet : l'objet à poser au prochain clic.
    const library = state.currentConfig.editModels || [];
    d.sceneModelPick.hidden = sc.tool !== 'object';
    if (sc.tool === 'object') {
      buildModelGallery(d.sceneModelPickGallery, sc.pendingModel || (library[0] ? library[0].filename : ''), (entry) => {
        sc.pendingModel = entry.filename;
        syncPanel();
      });
      d.sceneModelPickEmpty.hidden = library.length > 0;
    }
  }

  /* Champs du nord (section générale et section de la flèche) : angle
     vide = nord inconnu ; la case « Afficher » n'a de sens qu'avec un nord. */
  function syncNorthFields(angleInput, shownInput) {
    const n = sc.scene ? sc.scene.north : null;
    setField(angleInput, n ? String(n.angle) : '');
    shownInput.checked = Boolean(n && n.shown);
    shownInput.disabled = !n;
  }

  function syncNorth() {
    const d = NS.dom;
    const n = sc.scene.north;
    if (!n) return;
    syncNorthFields(d.sceneNorthAngle2, d.sceneNorthShown2);
    const r = render();
    const pos = r ? r.northPosition(n) : [n.x || 0, n.z || 0];
    setField(d.sceneNorthX, String(pos[0]));
    setField(d.sceneNorthZ, String(pos[1]));
    d.sceneNorthInfo.textContent = 'Nord \u00e0 ' + formatNumber(n.angle) + '\u00b0 de l\u2019axe \u2212Z du mod\u00e8le (sens horaire vu de dessus)' +
      (n.x === null ? ', fl\u00e8che \u00e0 sa place par d\u00e9faut (nord-est du mod\u00e8le)' : '') +
      ' \u2014 glisser la fl\u00e8che pour la d\u00e9placer, la poign\u00e9e ambre pour l\u2019orienter.';
  }

  /* Galerie des objets de la clé editModels : un bouton par entrée
     (vignette icon si fournie, sinon libellé), l'entrée courante marquée. */
  function buildModelGallery(container, current, onPick) {
    container.textContent = '';
    for (const entry of state.currentConfig.editModels || []) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'scene-model-btn';
      btn.title = (entry.label || entry.filename) + ' \u2014 ' + formatNumber(entry.size) + ' ' + unitLabel();
      if (entry.icon) {
        btn.classList.add('has-icon');
        btn.style.backgroundImage = 'url("' + entry.icon.replace(/"/g, '%22') + '")';
      }
      btn.textContent = entry.label || entry.filename.replace(/^.*\//, '');
      btn.classList.toggle('selected', entry.filename === current);
      btn.addEventListener('click', () => onPick(entry));
      container.appendChild(btn);
    }
  }

  function syncZone() {
    const d = NS.dom;
    const z = sc.scene.zones[sc.selectedIndex];
    if (!z) return;
    setField(d.sceneZoneLabel, z.label || '');
    setField(d.sceneZoneDesc, z.description || '');
    setField(d.sceneZoneBase, String(z.baseHeight));
    setField(d.sceneZoneHeight, String(z.height));
    setField(d.sceneZoneColor, z.color);
    setField(d.sceneZoneOpacity, String(Math.round(z.opacity * 100)));
    d.sceneZoneOpacityVal.textContent = String(Math.round(z.opacity * 100));
    // Groupes nomm\u00e9s du mod\u00e8le : liste reconstruite (le mod\u00e8le peut changer).
    const names = NS.scene3dZones ? NS.scene3dZones.modelGroupNames() : [];
    const select = d.sceneZoneGroup;
    if (document.activeElement !== select) {
      select.textContent = '';
      const none = document.createElement('option');
      none.value = '';
      none.textContent = 'Volume tracé (aucun)';
      select.appendChild(none);
      const list = names.slice();
      if (z.group && !list.includes(z.group)) list.unshift(z.group);
      for (const n of list) {
        const opt = document.createElement('option');
        opt.value = n;
        opt.textContent = n + (names.includes(n) ? '' : ' (absent du modèle)');
        select.appendChild(opt);
      }
      select.value = z.group || '';
    }
    d.sceneZoneGroupHint.textContent = names.length
      ? names.length + ' groupe(s) nommé(s) dans le modèle.'
      : 'Le modèle ne déclare aucun groupe nommé (lignes o / g du .obj).';
    setField(d.sceneZoneShowMode, z.show_mode);
    setField(d.sceneZoneElements, z.elements.join(', '));
    d.sceneZoneShown.checked = z.shown;
    const r = render();
    d.sceneZoneInfo.textContent = z.group
      ? 'Zone liée au groupe « ' + z.group + ' » du modèle.'
      : z.points.length + ' sommets, ' + (r ? 'base ' + formatLength(0) + ' + ' : '') + 'hauteur ' + formatLength(z.height) +
        ' — glisser un sommet pour l’ajuster, la zone pour la déplacer.';
  }

  function syncObject() {
    const d = NS.dom;
    const o = sc.scene.objects[sc.selectedIndex];
    if (!o) return;
    buildModelGallery(d.sceneObjectGallery, o.filename, (entry) => {
      o.filename = entry.filename;
      if (!o.label) o.label = entry.label;
      commit();
    });
    setField(d.sceneObjectFile, o.filename);
    setField(d.sceneObjectLabel, o.label || '');
    setField(d.sceneObjectSize, String(o.size));
    d.sceneObjectSizeUnit.textContent = unitLabel();
    setField(d.sceneObjectScale, String(o.scale));
    setField(d.sceneObjectRotation, String(o.rotation));
    setField(d.sceneObjectAltitude, String(o.altitude));
    setField(d.sceneObjectX, String(o.x));
    setField(d.sceneObjectZ, String(o.z));
    d.sceneObjectColorNone.checked = !o.color;
    d.sceneObjectColor.disabled = !o.color;
    if (o.color) setField(d.sceneObjectColor, o.color);
    d.sceneObjectShown.checked = o.shown;
    const r = render();
    const k = scaleFactor();
    d.sceneObjectInfo.textContent = 'Plus grande dimension ' + formatNumber(o.size * o.scale) + ' ' + unitLabel() +
      (k ? ' (' + formatNumber(r ? r.objectSizeUnits(o) * o.scale : 0) + ' unités du modèle)' : ' (sans échelle : en unités du modèle)') +
      ' — glisser l’objet pour le déplacer ; poignées : ambre = rotation, verte = taille.';
  }

  function syncFootprint() {
    const d = NS.dom;
    const fp = sc.scene.footprint;
    setField(d.sceneFpStroke, fp.stroke);
    setField(d.sceneFpStrokeWidth, fp.strokeWidth === null ? '' : String(fp.strokeWidth));
    const r = render();
    d.sceneFpStrokeWidth.placeholder = r ? String(r.defaultStrokeWidth()) : 'auto';
    d.sceneFpDashed.checked = fp.dashed;
    setField(d.sceneFpFill, fp.fill);
    setField(d.sceneFpFillOpacity, String(Math.round(fp.fillOpacity * 100)));
    d.sceneFpFillOpacityVal.textContent = String(Math.round(fp.fillOpacity * 100));
    setField(d.sceneFpAltitude, String(fp.altitude));
    d.sceneFpShown.checked = fp.shown;
    d.sceneFpInfo.textContent = fp.points.length + ' sommets, p\u00e9rim\u00e8tre ' +
      formatLength(polylineLength(fp.points, true)) + ', aire ' + formatArea(polygonArea(fp.points)) +
      ' \u2014 glisser un sommet pour l\u2019ajuster, l\u2019emprise pour la d\u00e9placer.';
  }

  function buildFloorGallery(current) {
    const gallery = NS.dom.sceneFloorGallery;
    gallery.textContent = '';
    for (const entry of state.currentConfig.editFloorImages || []) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.title = entry.label || entry.filename;
      btn.style.backgroundImage = 'url("' + entry.filename.replace(/"/g, '%22') + '")';
      btn.classList.toggle('selected', entry.filename === current);
      btn.addEventListener('click', () => {
        if (!sceneEditActive() || !sc.scene || !sc.scene.floorImage) return;
        sc.scene.floorImage.filename = entry.filename;
        sc.scene.floorImage.height = null;
        commit();
      });
      gallery.appendChild(btn);
    }
  }

  function syncFloor() {
    const d = NS.dom;
    const fi = sc.scene.floorImage;
    buildFloorGallery(fi.filename);
    setField(d.sceneFloorFile, fi.filename);
    setField(d.sceneFloorWidth, fi.width === null ? '' : String(fi.width));
    const r = render();
    d.sceneFloorWidth.placeholder = r ? String(r.defaultFloorWidth()) : 'auto';
    setField(d.sceneFloorRotation, String(fi.rotation));
    setField(d.sceneFloorOpacity, String(Math.round(fi.opacity * 100)));
    d.sceneFloorOpacityVal.textContent = String(Math.round(fi.opacity * 100));
    setField(d.sceneFloorAltitude, String(fi.altitude));
    setField(d.sceneFloorX, String(fi.x));
    setField(d.sceneFloorZ, String(fi.z));
    d.sceneFloorShown.checked = fi.shown;
    d.sceneFloorFitBtn.disabled = !sc.scene.footprint;
  }

  function scaleSegmentLength() {
    const s = sc.scene.scale;
    return s && s.x1 !== null ? Math.hypot(s.x2 - s.x1, s.z2 - s.z1) : 0;
  }

  function syncScale() {
    const d = NS.dom;
    const s = sc.scene.scale;
    const seg = scaleSegmentLength();
    d.sceneScaleInfo.textContent = 'Segment de ' + formatNumber(seg) + ' unit\u00e9s du mod\u00e8le. ' +
      'Saisissez sa longueur r\u00e9elle : elle \u00e9talonne toutes les mesures du plan.';
    setField(d.sceneScaleLength, s.length === null ? '' : String(s.length));
    setField(d.sceneScaleUnit, sc.scene.unit);
    d.sceneScaleShown.checked = s.shown;
    d.sceneScaleResult.textContent = '1 unit\u00e9 du mod\u00e8le = ' + formatNumber(s.value) + ' ' + sc.scene.unit;
  }

  function syncMeasure() {
    const d = NS.dom;
    const m = sc.scene.measures[sc.selectedIndex];
    if (!m) return;
    d.sceneMeasureInfo.textContent = m.type === 'area'
      ? 'Surface : ' + formatArea(polygonArea(m.points)) + ' (' + m.points.length + ' sommets, p\u00e9rim\u00e8tre ' +
        formatLength(polylineLength(m.points, true)) + ')'
      : 'Distance : ' + formatLength(polylineLength(m.points, false)) + ' (' + m.points.length + ' points)';
    setField(d.sceneMeasureLabel, m.label || '');
    d.sceneMeasureShown.checked = m.shown;
  }

  function syncPanel() {
    const d = NS.dom;
    const active = sceneEditActive();
    d.scenePanel.hidden = !active;
    if (!active) return;
    let sel = sc.scene ? sc.selected : null;
    if (sel === 'measure' && !sc.scene.measures[sc.selectedIndex]) sel = null;
    if (sel === 'object' && !sc.scene.objects[sc.selectedIndex]) sel = null;
    if (sel === 'zone' && !sc.scene.zones[sc.selectedIndex]) sel = null;
    if (sel === 'north' && !sc.scene.north) sel = null;
    d.sceneGeneralSection.hidden = Boolean(sel);
    d.sceneNorthSection.hidden = sel !== 'north';
    d.sceneFootprintSection.hidden = sel !== 'footprint';
    d.sceneFloorSection.hidden = sel !== 'floorImage';
    d.sceneScaleSection.hidden = sel !== 'scale';
    d.sceneMeasureSection.hidden = sel !== 'measure';
    d.sceneObjectSection.hidden = sel !== 'object';
    d.sceneZoneSection.hidden = sel !== 'zone';
    d.shapeDeleteBtn.disabled = !sel;
    if (sel === 'footprint') syncFootprint();
    else if (sel === 'floorImage') syncFloor();
    else if (sel === 'scale') syncScale();
    else if (sel === 'measure') syncMeasure();
    else if (sel === 'object') syncObject();
    else if (sel === 'zone') syncZone();
    else if (sel === 'north') syncNorth();
    else syncGeneral();
  }

  /* Recharge la sc\u00e8ne du plan courant, l'applique, la redessine et
     rafraîchit le panneau et la barre. Appelé par refreshShapeEditing
     (viewer-edit-tools.js) à chaque changement de représentation, de
     configuration ou d'\u00e9tat du cadenas \u2014 apr\u00e8s que le visualiseur a re\u00e7u
     le fichier du plan. */
  function refreshScene3dEditing() {
    sc.selected = null;
    sc.selectedIndex = -1;
    if (NS.scene3dTools) NS.scene3dTools.cancelDraft();
    const scene = currentScene();
    if (!scene) {
      sc.scene = null;
      sc.key = null;
    } else {
      applyScene();
    }
    setSceneTool('orbit');
    rebuild();
    syncPanel();
  }

  function setSceneTool(tool) {
    const changed = sc.tool !== tool;
    sc.tool = tool;
    for (const btn of NS.dom.shapeEditToolbar.querySelectorAll('button[data-tool3d]')) {
      btn.classList.toggle('active', btn.dataset.tool3d === tool);
    }
    NS.dom.threeViewport.classList.toggle('scene-drawing', sceneEditActive() && tool !== 'orbit');
    if (changed) {
      if (NS.scene3dTools) NS.scene3dTools.onToolChange();
      if (tool !== 'orbit' && sc.selected) selectScene3d(null);
      else syncPanel();
    }
  }

  /* ------------------------------ Commandes ------------------------------ */

  const d = NS.dom;

  // \u00ab D\u00e9finir la vue actuelle \u00bb : la cam\u00e9ra courante devient la vue par
  // d\u00e9faut du plan (\u00e9crite aussit\u00f4t).
  d.sceneViewSetBtn.addEventListener('click', () => {
    const v = viewer();
    if (!v || !sc.scene || !sceneEditActive()) return;
    sc.scene.camera = v.getCameraState();
    applyScene();
    syncPanel();
    writeScene3d();
  });

  // \u00ab Vue automatique \u00bb : plus de vue enregistr\u00e9e, recadrage du mod\u00e8le.
  d.sceneViewAutoBtn.addEventListener('click', () => {
    if (!sc.scene || !sceneEditActive()) return;
    sc.scene.camera = null;
    applyScene();
    syncPanel();
    writeScene3d();
  });

  function applyUnit(input) {
    if (!sc.scene || !sceneEditActive()) return;
    const unit = NS.normalizeText(input.value) || 'm';
    if (unit === sc.scene.unit) {
      input.value = unit;
      return;
    }
    sc.scene.unit = unit;
    commit();
  }
  d.sceneUnitInput.addEventListener('change', () => applyUnit(d.sceneUnitInput));
  d.sceneScaleUnit.addEventListener('change', () => applyUnit(d.sceneScaleUnit));

  for (const btn of d.shapeEditToolbar.querySelectorAll('button[data-tool3d]')) {
    btn.addEventListener('click', () => {
      setSceneTool(btn.dataset.tool3d);
      btn.blur();
    });
  }

  // Bouton Supprimer de la barre (partag\u00e9 avec le mode 2D, o\u00f9 le clic est
  // sans effet faute de forme s\u00e9lectionn\u00e9e).
  d.shapeDeleteBtn.addEventListener('click', deleteSelectedScene3d);

  const numOr = (text, fallback) => {
    const n = Number(String(text).replace(',', '.'));
    return text !== '' && Number.isFinite(n) ? n : fallback;
  };

  /* Champs d'une entité : getter de l'entit\u00e9, \u00e9v\u00e9nement, application ;
     input = aper\u00e7u (pas d'écriture), change = écriture. */
  function field(getter, input, event, apply, write) {
    input.addEventListener(event, () => {
      if (!sceneEditActive() || !sc.scene) return;
      const entity = getter();
      if (!entity) return;
      apply(entity, input);
      commit(write);
    });
  }

  /* Emprise. Les réglages d'apparence deviennent ceux des prochaines
     emprises (style3d). */
  const fp = () => sc.scene.footprint;
  field(fp, d.sceneFpStroke, 'input', (e, i) => { e.stroke = i.value; sc.style3d.stroke = i.value; }, false);
  field(fp, d.sceneFpStroke, 'change', (e, i) => { e.stroke = i.value; sc.style3d.stroke = i.value; });
  field(fp, d.sceneFpStrokeWidth, 'change', (e, i) => {
    const n = numOr(i.value.trim(), null);
    e.strokeWidth = n !== null && n > 0 ? n : null;
    sc.style3d.strokeWidth = e.strokeWidth;
  });
  field(fp, d.sceneFpDashed, 'change', (e, i) => { e.dashed = i.checked; sc.style3d.dashed = i.checked; });
  field(fp, d.sceneFpFill, 'input', (e, i) => { e.fill = i.value; sc.style3d.fill = i.value; }, false);
  field(fp, d.sceneFpFill, 'change', (e, i) => { e.fill = i.value; sc.style3d.fill = i.value; });
  const fpOpacity = (e, i) => {
    e.fillOpacity = clampNum(Number(i.value) / 100, 0, 1);
    sc.style3d.fillOpacity = e.fillOpacity;
  };
  field(fp, d.sceneFpFillOpacity, 'input', fpOpacity, false);
  field(fp, d.sceneFpFillOpacity, 'change', fpOpacity);
  field(fp, d.sceneFpAltitude, 'change', (e, i) => { e.altitude = numOr(i.value.trim(), 0); });
  field(fp, d.sceneFpShown, 'change', (e, i) => { e.shown = i.checked; });

  /* Fond de plan. */
  const fi = () => sc.scene.floorImage;
  field(fi, d.sceneFloorFile, 'change', (e, i) => {
    e.filename = NS.normalizeText(i.value);
    e.height = null;
  });
  field(fi, d.sceneFloorWidth, 'change', (e, i) => {
    const n = numOr(i.value.trim(), null);
    if (n !== null && n > 0) {
      if (e.height && e.width) e.height = Math.round(e.height * n / e.width * 100) / 100;
      e.width = n;
    } else {
      e.width = null;
      e.height = null;
    }
  });
  field(fi, d.sceneFloorRotation, 'change', (e, i) => {
    const n = numOr(i.value.trim(), 0);
    e.rotation = Math.round((((n % 360) + 360) % 360) * 100) / 100;
  });
  const fiOpacity = (e, i) => { e.opacity = clampNum(Number(i.value) / 100, 0, 1); };
  field(fi, d.sceneFloorOpacity, 'input', fiOpacity, false);
  field(fi, d.sceneFloorOpacity, 'change', fiOpacity);
  field(fi, d.sceneFloorAltitude, 'change', (e, i) => { e.altitude = numOr(i.value.trim(), 0); });
  field(fi, d.sceneFloorX, 'change', (e, i) => { e.x = numOr(i.value.trim(), e.x); });
  field(fi, d.sceneFloorZ, 'change', (e, i) => { e.z = numOr(i.value.trim(), e.z); });
  field(fi, d.sceneFloorShown, 'change', (e, i) => { e.shown = i.checked; });

  // « Ajuster à l'emprise » : le fond de plan couvre le rectangle englobant
  // de l'emprise (rotation nulle, rapport libre).
  d.sceneFloorFitBtn.addEventListener('click', () => {
    if (!sceneEditActive() || !sc.scene || !sc.scene.floorImage || !sc.scene.footprint) return;
    const pts = sc.scene.footprint.points;
    const xs = pts.map((p) => p[0]), zs = pts.map((p) => p[1]);
    const minX = Math.min(...xs), maxX = Math.max(...xs);
    const minZ = Math.min(...zs), maxZ = Math.max(...zs);
    const e = sc.scene.floorImage;
    e.x = Math.round((minX + maxX) / 2 * 100) / 100;
    e.z = Math.round((minZ + maxZ) / 2 * 100) / 100;
    e.width = Math.round((maxX - minX) * 100) / 100;
    e.height = Math.round((maxZ - minZ) * 100) / 100;
    e.rotation = 0;
    commit();
  });

  /* Étalon : la longueur réelle saisie fixe le facteur d'échelle. */
  const sca = () => sc.scene.scale;
  field(sca, d.sceneScaleLength, 'change', (e, i) => {
    const n = numOr(i.value.trim(), null);
    const seg = scaleSegmentLength();
    if (n !== null && n > 0 && seg > 0) {
      e.length = n;
      e.value = Math.round(n / seg * 1e6) / 1e6;
    }
  });
  field(sca, d.sceneScaleShown, 'change', (e, i) => { e.shown = i.checked; });

  /* Nord : angle saisi dans l'une ou l'autre section (vide = nord inconnu,
     la flèche disparaît), flèche au sol (affichage, position). */
  function applyNorthAngle(input) {
    if (!sceneEditActive() || !sc.scene) return;
    const n = numOr(input.value.trim(), null);
    if (n === null) {
      if (!sc.scene.north) { input.value = ''; return; }
      sc.scene.north = null;
      if (sc.selected === 'north') { sc.selected = null; sc.selectedIndex = -1; }
      commit();
      return;
    }
    const angle = Math.round((((n % 360) + 360) % 360) * 100) / 100;
    if (sc.scene.north) sc.scene.north.angle = angle;
    else sc.scene.north = { angle, shown: true, x: null, z: null };
    commit();
  }
  d.sceneNorthAngle.addEventListener('change', () => applyNorthAngle(d.sceneNorthAngle));
  d.sceneNorthAngle2.addEventListener('change', () => applyNorthAngle(d.sceneNorthAngle2));
  const nor = () => sc.scene.north;
  field(nor, d.sceneNorthShown, 'change', (e, i) => { e.shown = i.checked; });
  field(nor, d.sceneNorthShown2, 'change', (e, i) => { e.shown = i.checked; });
  const northPos = (e) => (render() ? render().northPosition(e) : [e.x || 0, e.z || 0]);
  field(nor, d.sceneNorthX, 'change', (e, i) => { const p = northPos(e); e.x = numOr(i.value.trim(), p[0]); e.z = p[1]; });
  field(nor, d.sceneNorthZ, 'change', (e, i) => { const p = northPos(e); e.z = numOr(i.value.trim(), p[1]); e.x = p[0]; });

  /* Mesure sélectionnée. */
  const mea = () => sc.scene.measures[sc.selectedIndex];
  field(mea, d.sceneMeasureLabel, 'change', (e, i) => { e.label = NS.normalizeText(i.value); });
  field(mea, d.sceneMeasureShown, 'change', (e, i) => { e.shown = i.checked; });

  /* Objet sélectionné. */
  const obj = () => sc.scene.objects[sc.selectedIndex];
  field(obj, d.sceneObjectFile, 'change', (e, i) => { e.filename = NS.normalizeText(i.value); });
  field(obj, d.sceneObjectLabel, 'change', (e, i) => { e.label = NS.normalizeText(i.value); });
  field(obj, d.sceneObjectSize, 'change', (e, i) => {
    const n = numOr(i.value.trim(), null);
    if (n !== null && n > 0) e.size = n;
  });
  field(obj, d.sceneObjectScale, 'change', (e, i) => {
    const n = numOr(i.value.trim(), null);
    if (n !== null && n > 0) e.scale = Math.min(100, n);
  });
  field(obj, d.sceneObjectRotation, 'change', (e, i) => {
    const n = numOr(i.value.trim(), 0);
    e.rotation = Math.round((((n % 360) + 360) % 360) * 100) / 100;
  });
  field(obj, d.sceneObjectAltitude, 'change', (e, i) => { e.altitude = numOr(i.value.trim(), 0); });
  field(obj, d.sceneObjectX, 'change', (e, i) => { e.x = numOr(i.value.trim(), e.x); });
  field(obj, d.sceneObjectZ, 'change', (e, i) => { e.z = numOr(i.value.trim(), e.z); });
  field(obj, d.sceneObjectColor, 'input', (e, i) => { e.color = i.value; }, false);
  field(obj, d.sceneObjectColor, 'change', (e, i) => { e.color = i.value; });
  field(obj, d.sceneObjectColorNone, 'change', (e, i) => {
    e.color = i.checked ? null : (d.sceneObjectColor.value || '#64748b');
  });
  field(obj, d.sceneObjectShown, 'change', (e, i) => { e.shown = i.checked; });

  /* Zone sélectionnée. */
  const zon = () => sc.scene.zones[sc.selectedIndex];
  field(zon, d.sceneZoneLabel, 'change', (e, i) => { e.label = NS.normalizeText(i.value); });
  field(zon, d.sceneZoneDesc, 'change', (e, i) => { e.description = NS.normalizeText(i.value); });
  field(zon, d.sceneZoneBase, 'change', (e, i) => { e.baseHeight = Math.max(0, numOr(i.value.trim(), 0)); });
  field(zon, d.sceneZoneHeight, 'change', (e, i) => {
    const n = numOr(i.value.trim(), null);
    if (n !== null && n > 0) e.height = n;
  });
  field(zon, d.sceneZoneColor, 'input', (e, i) => { e.color = i.value; }, false);
  field(zon, d.sceneZoneColor, 'change', (e, i) => { e.color = i.value; });
  const zOpacity = (e, i) => { e.opacity = clampNum(Number(i.value) / 100, 0, 1); };
  field(zon, d.sceneZoneOpacity, 'input', zOpacity, false);
  field(zon, d.sceneZoneOpacity, 'change', zOpacity);
  field(zon, d.sceneZoneGroup, 'change', (e, i) => { e.group = i.value || null; });
  field(zon, d.sceneZoneShowMode, 'change', (e, i) => { e.show_mode = NS.normalizeShowMode(i.value, e.show_mode); });
  field(zon, d.sceneZoneElements, 'change', (e, i) => {
    e.elements = i.value.split(/[\s,;]+/).map((s) => NS.normalizeId(Number(s))).filter((x) => x !== null);
  });
  field(zon, d.sceneZoneShown, 'change', (e, i) => { e.shown = i.checked; });

  // Le panneau suit les mouvements de la caméra (vue enregistrée ou non,
  // vue actuelle différente ou non).
  function watchCamera() {
    const v = viewer();
    if (!v || typeof v.onCameraChange !== 'function') return false;
    v.onCameraChange(() => {
      if (sceneEditActive() && !sc.selected) syncGeneral();
    });
    return true;
  }
  // three-viewer.bundle.js n'est charge qu'a la premiere representation 3D
  // affichee : le raccordement part des que le moteur est la
  // (viewer-loader.js).
  NS.onThreeViewerReady(watchCamera);

  /* ------------------- Exposition sur l'espace de noms ------------------- */
  NS.sceneAvailable = sceneAvailable;
  NS.sceneEditAvailable = sceneEditAvailable;
  NS.sceneEditActive = sceneEditActive;
  NS.refreshScene3dEditing = refreshScene3dEditing;
  NS.setPlanScene3d = setPlanScene3d;
  NS.describeScene3d = describeScene3d;
  NS.writeScene3d = writeScene3d;
  NS.syncScenePanel = syncPanel;
  NS.setSceneTool = setSceneTool;
  NS.selectScene3d = selectScene3d;
  NS.deleteSelectedScene3d = deleteSelectedScene3d;
  NS.commitScene3d = commit;
  NS.polylineLength = polylineLength;
  NS.polygonArea = polygonArea;
  NS.formatNumber = formatNumber;
  NS.formatLength = formatLength;
  NS.formatArea = formatArea;
  NS.scaleFactor = scaleFactor;
  /* Angle du nord du plan 3D affiché (degrés), ou null si inconnu. */
  NS.northAngle = () => (sc.scene && sc.scene.north ? sc.scene.north.angle : null);
})(globalThis);
