﻿/* ============================================================
   MyPnPlanViewerV2 — module « config »
   ============================================================
   Normalisation des quatre propriétés lues (configuration_plan_json,
   configuration_events_json, current_plan_element_json,
   current_plan_drawnShapes_json) et état partagé du visualiseur.

   Toute valeur absente ou du mauvais type retombe sur son défaut : une
   configuration partielle reste valide, et une propriété illisible donne
   un visualiseur vide (avec message) plutôt qu'une erreur. Ce qui est
   ignoré avec une raison utile à l'intégrateur (nœud sans id, id en
   doublon, clé V1 obsolète...) est consigné dans une liste
   d'AVERTISSEMENTS (warn), affichée dans l'info-bulle « i » du drawer et
   tracée dans la console par app.js.

   Les modules du composant sont des scripts classiques chargés dans
   l'ordre imposé par index.html (voir readme.txt § 1) : config, dom,
   edit-core, edit-render, edit-panel, edit-tools, plan, nav, puis app.js.
   Ils communiquent par l'espace de noms global MyPnPlanViewerV2NS.

   NOTE ENCODAGE : toutes les chaînes destinées à l'affichage sont écrites
   en ASCII pur (échappements \uXXXX pour les caractères accentués), afin
   de rester correctes même si le serveur livre le fichier avec un mauvais
   charset. Seuls les commentaires utilisent des caractères accentués.
   Le fichier porte un BOM UTF-8 et des fins de ligne CRLF.
   ============================================================ */
(function (global) {
  'use strict';

  const NS = global.MyPnPlanViewerV2NS = global.MyPnPlanViewerV2NS || {};

  // Séparateur des libellés dans le fil d'Ariane et selectedNodePath
  // (tiret cadratin U+2014 entouré d'espaces).
  const PATH_SEPARATOR = ' \u2014 ';

  // Couleurs nommées admises pour les badges du bandeau (classes
  // count-badge.*) et les pastilles d'événements de l'arbre. Une couleur
  // CSS hexadécimale (#RRGGBB ou #RGB) est aussi acceptée partout où une
  // couleur de badge est attendue.
  const BADGE_COLORS = ['red', 'amber', 'blue', 'magenta'];
  const HEX_COLOR = /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i;

  // Ordre d'importance des priorités d'événements (clé eventPriorityOrder) :
  // 'asc' = le plus petit numéro est le plus important (défaut), 'desc' =
  // le plus grand numéro est le plus important.
  const EVENT_PRIORITY_ORDERS = ['asc', 'desc'];

  // Emplacements admis pour le bouton « + » du bandeau (clé
  // pinButtonPosition) : 'end' = bout de ligne (défaut), 'afterTitle' = juste
  // derrière le dernier libellé du fil d'Ariane, avant les badges.
  const PIN_BUTTON_POSITIONS = ['end', 'afterTitle'];

  // Règles d'affichage des capteurs et des formes (clé show_mode, readme
  // § 6.3). Casse indifférente ; toute autre valeur retombe sur le défaut
  // propre à chaque famille (capteur : avec animation ; forme : sans).
  const SHOW_MODES = ['masked', 'always_without_animation', 'always_with_animation'];
  const ELEMENT_SHOW_MODE_DEFAULT = 'always_with_animation';
  const SHAPE_SHOW_MODE_DEFAULT = 'always_without_animation';

  /* Avertissements de la normalisation en cours : liste remplie par warn()
     pendant normalizeConfig / normalizeEventList / normalizeElements, puis
     restituée dans le résultat (clé warnings). Les messages sont affichés :
     ASCII pur. */
  let warnings = null;
  function warn(message) {
    if (warnings) warnings.push(message);
  }
  function beginWarnings() {
    warnings = [];
    return warnings;
  }
  function endWarnings() {
    const list = warnings || [];
    warnings = null;
    return list;
  }

  /* ---------------------- Utilitaires partagés ---------------------- */

  function clampNum(value, lo, hi) {
    return Math.min(hi, Math.max(lo, value));
  }

  /* ---------------- Normalisation de configuration_plan_json ---------------- */

  function normalizeText(value) {
    return typeof value === 'string' && value.trim().length > 0
      ? value.trim()
      : '';
  }

  // Un drapeau peut être sérialisé en booléen (false), en chaîne ("false",
  // "FALSE") ou en nombre (0/1) selon l'outil qui assemble le JSON côté
  // Panorama : toutes ces formes sont acceptées. Toute autre valeur retombe
  // sur le défaut.
  function normalizeBoolean(value, fallback) {
    if (typeof value === 'boolean') return value;
    if (typeof value === 'number' && Number.isFinite(value)) return value !== 0;
    if (typeof value === 'string') {
      const s = value.trim().toLowerCase();
      if (s === 'true' || s === '1') return true;
      if (s === 'false' || s === '0') return false;
    }
    return fallback;
  }

  // La valeur d'un badge peut être sérialisée en nombre ("value": 8) ou en
  // texte ("value": "8") : les deux donnent le même affichage.
  function normalizeBadgeValue(value) {
    if (typeof value === 'number' && Number.isFinite(value)) {
      return String(value);
    }
    return normalizeText(value);
  }

  // Couleur d'un badge ou d'une pastille : nom admis (BADGE_COLORS, casse
  // indifférente) ou couleur hexadécimale ; toute autre valeur donne 'red'.
  function normalizeBadgeColor(value) {
    const s = normalizeText(value).toLowerCase();
    if (BADGE_COLORS.includes(s) || HEX_COLOR.test(s)) return s;
    return 'red';
  }

  // Entier sérialisé en nombre (3) ou en chaîne ("3") ; null si absent ou
  // invalide. Une valeur décimale est arrondie.
  function normalizeInteger(value) {
    const n = typeof value === 'number' ? value
      : typeof value === 'string' && value.trim().length > 0 ? Number(value)
      : NaN;
    return Number.isFinite(n) ? Math.round(n) : null;
  }

  // Identifiant (clé id des nœuds, capteurs, événements et formes ; clés
  // element_id / node_id des événements) : entier >= 1, en nombre ou en
  // chaîne ne contenant qu'un entier ("12") ; null si absent ou invalide.
  // La valeur 0 est réservée (parent_id du premier niveau, racine du mode
  // sans navigation), elle n'est donc jamais un id valide.
  function normalizeId(value) {
    const n = typeof value === 'number' ? value
      : typeof value === 'string' && /^\s*\d+\s*$/.test(value) ? Number(value)
      : NaN;
    return Number.isInteger(n) && n >= 1 ? n : null;
  }

  // Règle d'affichage show_mode (SHOW_MODES), casse indifférente ; toute
  // autre valeur retombe sur le défaut passé.
  function normalizeShowMode(value, fallback) {
    const s = normalizeText(value).toLowerCase();
    return SHOW_MODES.includes(s) ? s : fallback;
  }

  /* Libellé court d'une entrée pour les avertissements : son libellé, ou à
     défaut son id (numérique ou chaîne), ou son rang. */
  function describe(entry, index) {
    const label = normalizeText(entry && entry.label);
    if (label) return '"' + label + '"';
    const id = entry && entry.id !== undefined ? normalizeBadgeValue(entry.id) : '';
    return id ? 'id ' + id : 'entr\u00e9e n\u00b0 ' + (index + 1);
  }

  // Casse indifférente ; "ascending" / "descending" acceptés ; toute autre
  // valeur retombe sur 'asc'.
  function normalizeEventPriorityOrder(value) {
    const s = normalizeText(value).toLowerCase();
    return EVENT_PRIORITY_ORDERS.find((o) => s === o || s === o + 'ending') || 'asc';
  }

  // Chemin de fichier d'une entrée (plan, calque image, icône, forme icon) :
  // clé filename ; l'ancienne clé file, obsolète, est encore lue en repli.
  function normalizeFilename(entry) {
    return normalizeText(entry.filename) || normalizeText(entry.file);
  }

  // Fraction 0..1 de la largeur/hauteur du plan de base.
  function normalizeFraction(value) {
    if (typeof value !== 'number' || !Number.isFinite(value)) return null;
    return Math.min(1, Math.max(0, value));
  }

  /* Épaisseur du trait d'une forme, en pixels écran (constante à tout
     niveau de zoom). 0 = clé absente ou invalide : défaut du rendu (2 px,
     cf. shapeSvgNode). */
  function normalizeStrokeWidth(value) {
    if (typeof value !== 'number' || !Number.isFinite(value) || value <= 0) {
      return 0;
    }
    return Math.min(20, value);
  }

  /* Propriétés libres d'un point de calque "markers" (clé props) : objet
     { nom: valeur } aux valeurs scalaires (texte, nombre, booléen),
     restitué en tableau ordonné { name, value } pour la carte de détails
     affichée au survol du marqueur. Toute autre forme est ignorée. */
  function normalizePointProps(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return [];
    const props = [];
    for (const key of Object.keys(value)) {
      const name = normalizeText(key);
      const raw = value[key];
      if (name.length === 0) continue;
      if (typeof raw !== 'string' && typeof raw !== 'number' &&
          typeof raw !== 'boolean') {
        continue;
      }
      props.push({ name, value: String(raw).trim() });
    }
    return props;
  }

  /* Sommet d'un polygone : accepté sous la forme [x, y] ou { x, y },
     en fraction (0 à 1) du plan de base. */
  function normalizeShapePoint(value) {
    const source = Array.isArray(value)
      ? { x: value[0], y: value[1] }
      : value && typeof value === 'object' ? value : {};
    const x = normalizeFraction(source.x);
    const y = normalizeFraction(source.y);
    return x === null || y === null ? null : { x, y };
  }

  // Angle en degrés, ramené dans [0, 360[. null si invalide.
  function normalizeAngle(value) {
    if (typeof value !== 'number' || !Number.isFinite(value)) return null;
    return ((value % 360) + 360) % 360;
  }

  /* Rotation d'une forme (rect, ellipse, icon, label) en degrés, sens
     horaire, autour de son centre — ramenée dans [0, 360[ ; 0 (aucune
     rotation) si la clé est absente ou invalide, ce qui préserve les
     formes écrites avant son apparition. */
  function normalizeRotation(value) {
    const angle = normalizeAngle(value);
    return angle === null ? 0 : angle;
  }

  /* Extrémité(s) d'une flèche portant la pointe : "end" (arrivée, défaut),
     "start" (départ) ou "both" (les deux). Toute autre valeur retombe sur
     "end", ce qui préserve les flèches écrites avant l'apparition de la
     clé. */
  const ARROW_HEADS = ['end', 'start', 'both'];

  function normalizeArrowHeads(value) {
    return ARROW_HEADS.indexOf(value) === -1 ? 'end' : value;
  }

  // Taille de police d'un libellé, en pixels écran (au zoom 100 %).
  function normalizeFontSize(value) {
    if (typeof value !== 'number' || !Number.isFinite(value)) return 14;
    return Math.min(72, Math.max(6, Math.round(value)));
  }

  /* Formes géométriques d'un calque "shapes" — mêmes types que le mode
     d'édition (current_plan_drawnShapes_json), ce qui permet de réafficher tel quel ce
     que l'opérateur a dessiné :
       polygon   points (au moins 3 sommets [x,y] ou {x,y})
       polyline  points (au moins 2 sommets), tracé ouvert sans remplissage
       rect      x, y, w, h (+ rotation)
       circle    cx, cy, r (r en fraction de la LARGEUR du plan)
       ellipse   cx, cy, rx (fraction de la largeur), ry (de la hauteur)
                 (+ rotation)
       sector    cx, cy, r (fraction de la largeur), startAngle, endAngle
                 (degrés, sens horaire, 0 = est)
       line / arrow / measure   x1, y1, x2, y2 (flèche : clé heads —
                 "end" pointe en x2,y2 (défaut), "start" en x1,y1,
                 "both" aux deux extrémités ; cote : distance affichée
                 selon l'échelle effective du plan — étalon "scale"
                 dessiné ou d'un calque, sinon clé scale de la
                 représentation, sinon % de la largeur)
       scale     x1, y1, x2, y2, value, unit, shown — étalon d'échelle
                 (outil « échelle » du mode édition) : value est la
                 longueur réelle du segment (nombre > 0, obligatoire),
                 unit l'unité affichée (défaut « m »), shown (défaut
                 true) affiche ou non l'étalon sur le plan. Affiché ou
                 non, il étalonne les cotes du plan, en priorité sur la
                 clé scale de la représentation.
       label     x, y (point d'ancrage), text, fontSize (px), bold, italic,
                 boxed (encadré) (+ rotation, autour du point d'ancrage)
       callout   tx, ty (pointe sur la cible), x, y (centre de la boîte),
                 text, fontSize, bold, italic
       icon      x, y (coin haut-gauche), w, h, filename (chemin d'image)
                 (+ rotation)
       pin       x, y (pointe de la punaise)
     Toutes les coordonnées sont en fraction (0 à 1) du plan de base.
     rotation (rect, ellipse, icon, label) : angle en degrés, sens horaire,
     autour du centre de la forme (du point d'ancrage pour le libellé) ;
     défaut 0. Les autres types se tournent par leurs coordonnées mêmes
     (le mode édition les réécrit tournées : viewer-edit-core.js).
     fill/stroke sont des couleurs CSS libres (« none » : transparent) ;
     strokeWidth est l'épaisseur du trait en pixels écran (défaut 2) ;
     label est l'info-bulle de la forme. Une forme incomplète ou d'un type
     inconnu est ignorée. */
  function normalizeShapes(list) {
    return (Array.isArray(list) ? list : [])
      .map((item) => {
        const entry = item && typeof item === 'object' ? item : {};
        const common = {
          label: normalizeText(entry.label),
          fill: normalizeText(entry.fill),
          stroke: normalizeText(entry.stroke),
          strokeWidth: normalizeStrokeWidth(entry.strokeWidth),
        };

        if (entry.type === 'polygon') {
          const points = (Array.isArray(entry.points) ? entry.points : [])
            .map(normalizeShapePoint)
            .filter(Boolean);
          return points.length >= 3
            ? Object.assign({ type: 'polygon', points }, common)
            : null;
        }
        if (entry.type === 'rect') {
          const x = normalizeFraction(entry.x);
          const y = normalizeFraction(entry.y);
          const w = normalizeFraction(entry.w);
          const h = normalizeFraction(entry.h);
          return x === null || y === null || !w || !h
            ? null
            : Object.assign({ type: 'rect', x, y, w, h,
                              rotation: normalizeRotation(entry.rotation) },
                            common);
        }
        if (entry.type === 'circle') {
          const cx = normalizeFraction(entry.cx);
          const cy = normalizeFraction(entry.cy);
          const r = normalizeFraction(entry.r);
          return cx === null || cy === null || !r
            ? null
            : Object.assign({ type: 'circle', cx, cy, r }, common);
        }
        if (entry.type === 'ellipse') {
          const cx = normalizeFraction(entry.cx);
          const cy = normalizeFraction(entry.cy);
          const rx = normalizeFraction(entry.rx);
          const ry = normalizeFraction(entry.ry);
          return cx === null || cy === null || !rx || !ry
            ? null
            : Object.assign({ type: 'ellipse', cx, cy, rx, ry,
                              rotation: normalizeRotation(entry.rotation) },
                            common);
        }
        if (entry.type === 'sector') {
          const cx = normalizeFraction(entry.cx);
          const cy = normalizeFraction(entry.cy);
          const r = normalizeFraction(entry.r);
          const startAngle = normalizeAngle(entry.startAngle);
          const endAngle = normalizeAngle(entry.endAngle);
          return cx === null || cy === null || !r ||
              startAngle === null || endAngle === null
            ? null
            : Object.assign(
                { type: 'sector', cx, cy, r, startAngle, endAngle }, common);
        }
        if (entry.type === 'polyline') {
          const points = (Array.isArray(entry.points) ? entry.points : [])
            .map(normalizeShapePoint)
            .filter(Boolean);
          return points.length >= 2
            ? Object.assign({ type: 'polyline', points }, common)
            : null;
        }
        if (entry.type === 'line' || entry.type === 'arrow' ||
            entry.type === 'measure') {
          const x1 = normalizeFraction(entry.x1);
          const y1 = normalizeFraction(entry.y1);
          const x2 = normalizeFraction(entry.x2);
          const y2 = normalizeFraction(entry.y2);
          if (x1 === null || y1 === null || x2 === null || y2 === null) {
            return null;
          }
          const segment = { type: entry.type, x1, y1, x2, y2 };
          if (entry.type === 'arrow') {
            segment.heads = normalizeArrowHeads(entry.heads);
          }
          return Object.assign(segment, common);
        }
        if (entry.type === 'scale') {
          const x1 = normalizeFraction(entry.x1);
          const y1 = normalizeFraction(entry.y1);
          const x2 = normalizeFraction(entry.x2);
          const y2 = normalizeFraction(entry.y2);
          const value = typeof entry.value === 'number' &&
              Number.isFinite(entry.value) && entry.value > 0
            ? entry.value
            : null;
          return x1 === null || y1 === null || x2 === null || y2 === null ||
              value === null
            ? null
            : Object.assign({
                type: 'scale', x1, y1, x2, y2, value,
                unit: normalizeText(entry.unit) || 'm',
                shown: normalizeBoolean(entry.shown, true),
              }, common);
        }
        if (entry.type === 'label') {
          const x = normalizeFraction(entry.x);
          const y = normalizeFraction(entry.y);
          const text = normalizeText(entry.text);
          return x === null || y === null || text.length === 0
            ? null
            : Object.assign({
                type: 'label', x, y, text,
                fontSize: normalizeFontSize(entry.fontSize),
                bold: normalizeBoolean(entry.bold, false),
                italic: normalizeBoolean(entry.italic, false),
                boxed: normalizeBoolean(entry.boxed, false),
                rotation: normalizeRotation(entry.rotation),
              }, common);
        }
        if (entry.type === 'callout') {
          const tx = normalizeFraction(entry.tx);
          const ty = normalizeFraction(entry.ty);
          const x = normalizeFraction(entry.x);
          const y = normalizeFraction(entry.y);
          const text = normalizeText(entry.text);
          return tx === null || ty === null || x === null || y === null ||
              text.length === 0
            ? null
            : Object.assign({
                type: 'callout', tx, ty, x, y, text,
                fontSize: normalizeFontSize(entry.fontSize),
                bold: normalizeBoolean(entry.bold, false),
                italic: normalizeBoolean(entry.italic, false),
              }, common);
        }
        if (entry.type === 'icon') {
          const x = normalizeFraction(entry.x);
          const y = normalizeFraction(entry.y);
          const w = normalizeFraction(entry.w);
          const h = normalizeFraction(entry.h);
          return x === null || y === null || !w || !h
            ? null
            : Object.assign({
                type: 'icon', x, y, w, h,
                filename: normalizeFilename(entry),
                rotation: normalizeRotation(entry.rotation),
              }, common);
        }
        if (entry.type === 'pin') {
          const x = normalizeFraction(entry.x);
          const y = normalizeFraction(entry.y);
          return x === null || y === null
            ? null
            : Object.assign({ type: 'pin', x, y }, common);
        }
        return null;
      })
      .filter(Boolean);
  }

  /* Calques superposables d'une représentation 2D : V2 n'admet que les
     calques kind "image" (PNG transparent superposé). Les calques "markers"
     et "shapes" de la V1 sont ignorés avec un avertissement — capteurs et
     formes passent par current_plan_element_json et
     current_plan_drawnShapes_json (readme § 7). */
  function normalizeLayers(list, planLabel) {
    return (Array.isArray(list) ? list : [])
      .map((item, i) => {
        const entry = item && typeof item === 'object' ? item : {};
        const kind = normalizeText(entry.kind).toLowerCase() || 'markers';

        if (kind !== 'image') {
          warn('Plan "' + planLabel + '" : calque ' + describe(entry, i) +
            ' de kind "' + kind + '" ignor\u00e9 (V2 : calques "image" seulement ; ' +
            'capteurs et formes passent par les propri\u00e9t\u00e9s d\u00e9di\u00e9es)');
          return null;
        }
        const layer = {
          kind: 'image',
          label: normalizeText(entry.label),
          filename: normalizeFilename(entry),
        };
        if (layer.filename.length === 0) {
          warn('Plan "' + planLabel + '" : calque image ' + describe(entry, i) +
            ' sans filename ignor\u00e9');
          return null;
        }
        return layer;
      })
      .filter(Boolean);
  }

  /* Échelle facultative d'un plan 2D (clé scale d'une représentation) :
     { value, unit } où value est la longueur réelle représentée par la
     LARGEUR totale du plan et unit l'unité affichée (défaut « m »).
     Utilisée par l'outil cote / mesure du mode édition ; sans échelle, la
     cote affiche un pourcentage de la largeur du plan. Un étalon d'échelle
     (forme "scale") dessiné par l'opérateur ou porté par un calque
     "shapes" est prioritaire sur cette clé (NS.effectiveScale). */
  /* Repère d'orientation du cadre 3D (clé orientationHelper) : "shown"
     (affiché à l'ouverture, défaut), "hidden" (bouton disponible, repère
     masqué au départ) ou "none" (ni repère ni bouton). Booléen accepté :
     true = shown, false = none. */
  const ORIENTATION_HELPER_MODES = ['shown', 'hidden', 'none'];
  function normalizeOrientationHelper(value) {
    if (value === undefined || value === null || value === '' || value === true) return 'shown';
    if (value === false) return 'none';
    const text = String(value).trim().toLowerCase();
    if (ORIENTATION_HELPER_MODES.includes(text)) return text;
    warn('Cl\u00e9 orientationHelper inconnue \u00ab ' + String(value) + ' \u00bb : shown');
    return 'shown';
  }

  /* Exports de la vue en plan (clé planExport) : { pngScale } = pixels du
     PNG par pixel écran du cadre (1 à 4, défaut 2) ; { cutHeight } =
     hauteur de la coupe horizontale du SVG au-dessus du sol, en unités
     réelles du plan (> 0, défaut 1,2). */
  function normalizePlanExport(value) {
    const source = value && typeof value === 'object' ? value : {};
    let k = typeof source.pngScale === 'number' && Number.isFinite(source.pngScale) ? source.pngScale : 2;
    if (k < 1 || k > 4) {
      warn('Cl\u00e9 planExport.pngScale hors de 1 \u00e0 4 (' + k + ') : 2');
      k = 2;
    }
    let h = source.cutHeight === undefined || source.cutHeight === null ? 1.2 : source.cutHeight;
    if (typeof h !== 'number' || !Number.isFinite(h) || h <= 0) {
      warn('Cl\u00e9 planExport.cutHeight invalide (' + String(h) + ') : 1,2');
      h = 1.2;
    }
    return { pngScale: k, cutHeight: h };
  }

  function normalizeScale(value) {
    const source = value && typeof value === 'object' ? value : {};
    if (typeof source.value !== 'number' || !Number.isFinite(source.value) ||
        source.value <= 0) {
      return null;
    }
    return { value: source.value, unit: normalizeText(source.unit) || 'm' };
  }

  /* Représentations d'un nœud (clé plans) ou de la racine. Un nœud
     n'affiche QU'UNE représentation, 2D (image) ou 3D (modèle) : si
     plusieurs entrées valides sont reçues, seule la première est retenue,
     avec un avertissement (owner : libellé du nœud, pour le message). */
  function normalizePlans(list, owner) {
    const plans = (Array.isArray(list) ? list : [])
      .map((item) => {
        const entry = item && typeof item === 'object' ? item : {};
        const type = entry.type === 'model' ? 'model' : 'image';

        const label =
          normalizeText(entry.label) ||
          (type === 'model' ? 'Mod\u00e8le 3D' : 'Plan');
        return {
          type,
          filename: normalizeFilename(entry),
          label,
          layers: type === 'model' ? [] : normalizeLayers(entry.layers, label),
          scale: type === 'model' ? null : normalizeScale(entry.scale),
        };
      })
      // Une représentation sans fichier est ignorée.
      .filter((plan) => plan.filename.length > 0);
    if (plans.length > 1) {
      warn((owner ? 'N\u0153ud "' + owner + '"' : 'Cl\u00e9 plans de la racine') +
        ' : ' + plans.length + ' repr\u00e9sentations re\u00e7ues, seule la ' +
        'premi\u00e8re ("' + plans[0].label + '") est affich\u00e9e');
    }
    return plans.slice(0, 1);
  }

  /* Galerie d'icônes proposée par l'outil « icône / image » du mode
     d'édition (clé editIcons, racine de la configuration) : entrées
     { filename, label }, chemins relatifs au dossier de l'objet. */
  function normalizeEditIcons(list) {
    return (Array.isArray(list) ? list : [])
      .map((item) => {
        const entry = item && typeof item === 'object' ? item : {};
        return {
          filename: normalizeFilename(entry),
          label: normalizeText(entry.label),
        };
      })
      .filter((icon) => icon.filename.length > 0);
  }

  /* Bibliothèque d'objets 3D de l'outil « Objet » du mode édition 3D (clé
     editModels, racine de la configuration) : { filename (.obj / .glb /
     .gltf, relatif au dossier de l'objet), label, size (plus grande
     dimension réelle, en unité du plan ; défaut 1), color (#rrggbb appliqué
     aux .obj ; null = matériaux du fichier), icon (vignette facultative) }. */
  function normalizeEditModels(list) {
    return (Array.isArray(list) ? list : [])
      .map((item) => {
        const entry = item && typeof item === 'object' ? item : {};
        return {
          filename: normalizeFilename(entry),
          label: normalizeText(entry.label),
          size: typeof entry.size === 'number' && Number.isFinite(entry.size) && entry.size > 0 ? entry.size : 1,
          color: normalizeHexColor(entry.color, null),
          icon: normalizeText(entry.icon),
        };
      })
      .filter((m) => m.filename.length > 0);
  }

  /* Nœuds récursifs de l'arbre de navigation (readme § 7). Chaque nœud
     normalisé porte :
       id         identifiant fourni par la configuration (entier >= 1,
                  unique dans tout l'arbre) ;
       parent_id  id du nœud qui le contient, 0 au premier niveau —
                  CONSTRUIT ici, jamais lu dans la configuration ;
       label, labels (libellés depuis la racine), path (libellés joints par
                  PATH_SEPARATOR : fil d'Ariane et clé path de
                  selectedNodePath) ;
       plans, children (lus depuis la clé nodes, ou children en repli) ;
       events     événements en cours du nœud lui-même : tableau vide ici,
                  rempli par viewer-nav.js à partir de
                  configuration_events_json (la synthèse par sous-arbre
                  est calculée à l'affichage).
     Un nœud sans libellé, sans id valide ou dont l'id est déjà pris est
     ignoré avec toute sa descendance (avertissement). Les clés events et
     alarm de la V1 sont ignorées (avertissement). byId reçoit chaque nœud
     retenu, indexé par id. */
  function normalizeNodes(list, parentId, parentLabels, byId) {
    return (Array.isArray(list) ? list : [])
      .map((item, i) => {
        const entry = item && typeof item === 'object' ? item : {};
        const label = normalizeText(entry.label);
        if (label.length === 0) {
          warn('N\u0153ud sans libell\u00e9 ignor\u00e9 avec sa descendance (' +
            describe(entry, i) + (parentLabels.length ? ', sous "' +
            parentLabels[parentLabels.length - 1] + '"' : '') + ')');
          return null;
        }
        const id = normalizeId(entry.id);
        if (id === null) {
          warn('N\u0153ud "' + label + '" sans id valide (entier >= 1) : ' +
            'ignor\u00e9 avec sa descendance');
          return null;
        }
        if (byId.has(id)) {
          warn('N\u0153ud "' + label + '" : id ' + id + ' d\u00e9j\u00e0 port\u00e9 par "' +
            byId.get(id).label + '" : ignor\u00e9 avec sa descendance');
          return null;
        }
        if (entry.events !== undefined || entry.alarm !== undefined) {
          warn('N\u0153ud "' + label + '" : cl\u00e9 events / alarm ignor\u00e9e ' +
            '(V2 : les \u00e9v\u00e9nements viennent de configuration_events_json)');
        }

        const labels = parentLabels.concat(label);
        const node = {
          id,
          parent_id: parentId,
          label,
          labels,
          path: labels.join(PATH_SEPARATOR),
          plans: normalizePlans(entry.plans, label),
          children: [],
          events: [],
        };
        // Indexé AVANT la descente : un enfant réutilisant l'id de son
        // parent est ainsi détecté comme doublon.
        byId.set(id, node);
        // Clé d'entrée nodes ; children (V1) lue en repli — « children »
        // est un terme réservé côté Panorama.
        node.children = normalizeNodes(
          entry.nodes !== undefined ? entry.nodes : entry.children,
          id, labels, byId);
        return node;
      })
      .filter(Boolean);
  }

  /* Vues épinglées (readme § 7) : { id, label }. L'id doit désigner un nœud
     retenu de l'arbre ; sinon l'entrée est ignorée avec un avertissement.
     defaultLabel (libellés du chemin joints par un espace) sert de libellé
     par défaut et de texte d'invite au renommage. */
  function normalizePinned(list, byId) {
    return (Array.isArray(list) ? list : [])
      .map((item, i) => {
        const entry = item && typeof item === 'object' ? item : {};
        const id = normalizeId(entry.id);
        if (id === null) {
          warn('Vue \u00e9pingl\u00e9e ' + describe(entry, i) + ' sans id valide : ignor\u00e9e');
          return null;
        }
        const node = byId.get(id);
        if (!node) {
          warn('Vue \u00e9pingl\u00e9e ' + describe(entry, i) + ' : aucun n\u0153ud d\u2019id ' +
            id + ' dans l\u2019arbre : ignor\u00e9e');
          return null;
        }
        return pinForNode(node, normalizeText(entry.label));
      })
      .filter(Boolean);
  }

  /* Vue épinglée ou signet vers un nœud : utilisé par la normalisation et
     par le bouton « + » du bandeau (viewer-nav.js). label est le libellé
     AFFICHÉ, muté par le renommage en place (viewer-nav.js) ; configLabel
     garde le libellé d'origine de la configuration, seul pris en compte
     dans l'empreinte structurelle (structuralKey) — le renommage ne doit
     pas faire passer une mise à jour « badges seuls » pour un changement
     de structure. */
  function pinForNode(node, label) {
    const defaultLabel = node.labels.join(' ');
    const initial = label || defaultLabel;
    return { id: node.id, label: initial, defaultLabel, configLabel: initial };
  }

  // Casse indifférente ("aftertitle", "AfterTitle"...) ; toute autre valeur
  // retombe sur 'end'.
  function normalizePinButtonPosition(value) {
    const s = normalizeText(value).toLowerCase();
    return PIN_BUTTON_POSITIONS.find((p) => p.toLowerCase() === s) || 'end';
  }

  function normalizeBadges(list) {
    return (Array.isArray(list) ? list : [])
      .map((item) => {
        const entry = item && typeof item === 'object' ? item : {};

        return {
          value: normalizeBadgeValue(entry.value),
          color: normalizeBadgeColor(entry.color),
        };
      })
      .filter((badge) => badge.value.length > 0);
  }

  /* Configuration complète (configuration_plan_json, readme § 7). Outre
     les clés de la V1, le résultat porte :
       byId      Map id -> nœud normalisé (tous niveaux confondus) ;
       warnings  avertissements de normalisation (ASCII), affichés dans
                 l'info-bulle « i » du drawer et tracés dans la console. */
  function normalizeConfig(raw) {
    const source = raw && typeof raw === 'object' ? raw : {};
    beginWarnings();
    const byId = new Map();
    const tree = normalizeNodes(source.tree, 0, [], byId);
    const pinned = normalizePinned(source.pinned, byId);
    if (tree.length > 0 && source.plans !== undefined) {
      warn('Cl\u00e9 plans \u00e0 la racine ignor\u00e9e : tree est renseign\u00e9');
    }
    const plans = tree.length > 0 ? [] : normalizePlans(source.plans);

    return {
      title: normalizeText(source.title),
      showNoPlanIndicator: normalizeBoolean(source.showNoPlanIndicator, true),
      // Indicateur « i » du pied du drawer : outil de MISE AU POINT (état des
      // propriétés reçues, avertissements). Masqué par défaut ; à activer
      // explicitement par showConfigInfo pendant l'intégration.
      showConfigInfo: normalizeBoolean(source.showConfigInfo, false),
      shapeEditing: normalizeBoolean(source.shapeEditing, false),
      // Bouton imprimante de la barre de zoom (viewer-print.js).
      showPrintButton: normalizeBoolean(source.showPrintButton, true),
      // Repère d'orientation du cadre 3D (viewer-scene3d-helper.js).
      orientationHelper: normalizeOrientationHelper(source.orientationHelper),
      // Bouton « Vue en plan » de la barre de zoom (viewer-scene3d-planview.js).
      showPlanViewButton: normalizeBoolean(source.showPlanViewButton, true),
      // Exports de la vue en plan (viewer-scene3d-export.js).
      planExport: normalizePlanExport(source.planExport),
      pinButtonPosition: normalizePinButtonPosition(source.pinButtonPosition),
      eventPriorityOrder: normalizeEventPriorityOrder(source.eventPriorityOrder),
      badges: normalizeBadges(source.badges),
      tree,
      byId,
      pinned,
      plans,
      editIcons: normalizeEditIcons(source.editIcons),
      // Galerie des fonds de plan de l'outil « Fond de plan » du mode
      // édition 3D (même schéma que editIcons).
      editFloorImages: normalizeEditIcons(source.editFloorImages),
      // Bibliothèque des objets 3D de l'outil « Objet » du mode édition 3D.
      editModels: normalizeEditModels(source.editModels),
      warnings: endWarnings(),
      // Message affiché sous le repère « Aucune représentation disponible »
      // quand la configuration est absente, vide ou invalide.
      error: '',
    };
  }

  /* ============================================================
     configuration_events_json — alarmes en cours (readme § 9)
     ============================================================
     Objet { events: [...] } ou tableau nu. Résultat :
       list       événements retenus { id, element_id, node_id, priority,
                  color, count, label } (element_id / node_id : null si
                  absents) ;
       byNode     Map node_id -> [{ priority, color, count }] cumulés par
                  priorité (couleur de la première entrée), pour les
                  pastilles et les badges ;
       byElement  Map element_id -> [événements], pour l'état d'alarme des
                  capteurs et des formes liées ;
       warnings   avertissements. */
  function normalizeEventList(raw) {
    const source = Array.isArray(raw) ? raw
      : raw && typeof raw === 'object' && Array.isArray(raw.events) ? raw.events
      : [];
    beginWarnings();
    if (raw && typeof raw === 'object' && !Array.isArray(raw) && !Array.isArray(raw.events)) {
      warn('configuration_events_json : cl\u00e9 events absente ou non tableau : ' +
        'aucun \u00e9v\u00e9nement');
    }
    const list = [];
    const seen = new Set();
    const byNode = new Map();
    const byElement = new Map();

    source.forEach((item, i) => {
      const entry = item && typeof item === 'object' ? item : {};
      const id = normalizeId(entry.id);
      if (id === null) {
        warn('\u00c9v\u00e9nement ' + describe(entry, i) + ' sans id valide : ignor\u00e9');
        return;
      }
      if (seen.has(id)) {
        warn('\u00c9v\u00e9nement id ' + id + ' en doublon (entr\u00e9e conserv\u00e9e)');
      }
      seen.add(id);
      const count = entry.count === undefined ? 1 : normalizeInteger(entry.count);
      if (count === null || count <= 0) {
        warn('\u00c9v\u00e9nement id ' + id + ' : count nul ou invalide : ignor\u00e9');
        return;
      }
      const priority = entry.priority === undefined ? 1 : normalizeInteger(entry.priority);
      const ev = {
        id,
        element_id: normalizeId(entry.element_id),
        node_id: normalizeId(entry.node_id),
        priority: priority === null ? 1 : priority,
        color: normalizeBadgeColor(entry.color),
        count,
        label: normalizeText(entry.label),
      };
      list.push(ev);

      if (ev.node_id !== null) {
        let acc = byNode.get(ev.node_id);
        if (!acc) byNode.set(ev.node_id, acc = []);
        const known = acc.find((e) => e.priority === ev.priority);
        if (known) known.count += ev.count;
        else acc.push({ priority: ev.priority, color: ev.color, count: ev.count });
      }
      if (ev.element_id !== null) {
        let acc = byElement.get(ev.element_id);
        if (!acc) byElement.set(ev.element_id, acc = []);
        acc.push(ev);
      }
    });

    return { list, byNode, byElement, warnings: endWarnings() };
  }

  /* ============================================================
     current_plan_element_json — capteurs du plan affiché (readme § 8)
     ============================================================
     Objet { node_id, planIndex, elements: [...] } ou tableau nu. Résultat :
       node_id, planIndex  plan visé (null si absents : plan affiché) ;
       elements            capteurs retenus { id, label, x, y, show_mode,
                           icon, icon_alarm, size, props } ;
       warnings. */
  function normalizeElements(raw) {
    const bare = Array.isArray(raw);
    const source = bare ? {} : raw && typeof raw === 'object' ? raw : {};
    const items = bare ? raw : Array.isArray(source.elements) ? source.elements : [];
    beginWarnings();
    if (!bare && raw && typeof raw === 'object' && !Array.isArray(source.elements)) {
      warn('current_plan_element_json : cl\u00e9 elements absente ou non tableau : ' +
        'aucun capteur');
    }
    const seen = new Set();
    const elements = [];

    items.forEach((item, i) => {
      const entry = item && typeof item === 'object' ? item : {};
      const id = normalizeId(entry.id);
      if (id === null) {
        warn('Capteur ' + describe(entry, i) + ' sans id valide : ignor\u00e9');
        return;
      }
      if (seen.has(id)) {
        warn('Capteur id ' + id + ' en doublon : seconde entr\u00e9e ignor\u00e9e');
        return;
      }
      const x = normalizeFraction(entry.x);
      const y = normalizeFraction(entry.y);
      if (x === null || y === null) {
        warn('Capteur id ' + id + ' sans position valide (x, y en fraction 0..1) : ignor\u00e9');
        return;
      }
      if (x !== entry.x || y !== entry.y) {
        warn('Capteur id ' + id + ' : position hors du plan (' + entry.x + ', ' +
          entry.y + ') ramen\u00e9e au bord');
      }
      seen.add(id);
      const size = normalizeInteger(entry.size);
      elements.push({
        id,
        label: normalizeText(entry.label),
        x,
        y,
        show_mode: normalizeShowMode(entry.show_mode, ELEMENT_SHOW_MODE_DEFAULT),
        icon: normalizeText(entry.icon),
        icon_alarm: normalizeText(entry.icon_alarm),
        size: size === null ? 24 : clampNum(size, 8, 128),
        props: normalizePointProps(entry.props),
      });
    });

    return {
      node_id: bare ? null : normalizeId(source.node_id),
      planIndex: bare ? null : normalizeId(source.planIndex),
      elements,
      warnings: endWarnings(),
    };
  }

  /* ============================================================
     current_plan_drawnShapes_json en LECTURE (readme § 10)
     ============================================================
     Objet { node_id, planIndex, filename, shapes } ou tableau nu. Chaque
     forme suit le schéma des formes du mode édition (normalizeShapes),
     plus les clés V2 :
       id         entier >= 1, unique dans le plan ; une forme sans id
                  valide en reçoit un (après le plus grand id présent), un
                  doublon est ré-attribué avec un avertissement ;
       show_mode  règle d'affichage (défaut always_without_animation) ;
       elements   ids des capteurs liés (les valeurs invalides sont
                  écartées) ;
       props      propriétés libres { nom: valeur }.
     L'apparence css reçue (fill / stroke) est convertie vers les clés du
     panneau du mode édition (fillColor / fillOpacity / fillNone,
     strokeColor / strokeNone) quand son format le permet — la forme reste
     ainsi retouchable à l'identique ; sinon les clés css sont conservées
     telles quelles (drawnShapeFill / drawnShapeStroke les replient). */
  function internalizeAppearance(s) {
    const HEX6 = /^#[0-9a-f]{6}$/i;
    const HEX3 = /^#([0-9a-f])([0-9a-f])([0-9a-f])$/i;
    const RGBA = /^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([0-9.]+)\s*)?\)$/i;
    const toHex = (r, g, b) => '#' + [r, g, b]
      .map((n) => Math.min(255, +n).toString(16).padStart(2, '0')).join('');
    const parse = (css) => {
      const v = (css || '').trim();
      if (v.toLowerCase() === 'none') return { none: true };
      if (HEX6.test(v)) return { color: v.toLowerCase(), alpha: 1 };
      const h3 = HEX3.exec(v);
      if (h3) return { color: ('#' + h3[1] + h3[1] + h3[2] + h3[2] + h3[3] + h3[3]).toLowerCase(), alpha: 1 };
      const m = RGBA.exec(v);
      if (m) return { color: toHex(m[1], m[2], m[3]), alpha: m[4] === undefined ? 1 : clampNum(Number(m[4]), 0, 1) };
      return null;
    };
    const fill = parse(s.fill);
    if (fill) {
      if (fill.none) s.fillNone = true;
      else { s.fillColor = fill.color; s.fillOpacity = fill.alpha; }
      // Les clés du panneau font désormais foi : la clé css est retirée
      // (shapeSvgNode la préférerait au style interne, et une retouche
      // d'apparence resterait sans effet à l'écran).
      delete s.fill;
    }
    const stroke = parse(s.stroke);
    if (stroke) {
      if (stroke.none) s.strokeNone = true;
      else s.strokeColor = stroke.color;
      delete s.stroke;
    }
  }

  function normalizeDrawnShapes(raw) {
    const bare = Array.isArray(raw);
    const source = bare ? {} : raw && typeof raw === 'object' ? raw : {};
    const items = bare ? raw : Array.isArray(source.shapes) ? source.shapes : [];
    beginWarnings();
    if (!bare && raw && typeof raw === 'object' && !Array.isArray(source.shapes)) {
      warn('current_plan_drawnShapes_json : cl\u00e9 shapes absente ou non tableau : ' +
        'aucune forme');
    }
    const seen = new Set();
    const shapes = [];

    items.forEach((item, i) => {
      const entry = item && typeof item === 'object' ? item : {};
      const shape = normalizeShapes([entry])[0];
      if (!shape) {
        warn('Forme ' + describe(entry, i) + ' incompl\u00e8te ou de type inconnu : ignor\u00e9e');
        return;
      }
      let id = normalizeId(entry.id);
      if (id !== null && seen.has(id)) {
        warn('Forme id ' + id + ' en doublon : nouvel id attribu\u00e9');
        id = null;
      }
      if (id !== null) seen.add(id);
      shape.id = id;
      shape.show_mode = normalizeShowMode(entry.show_mode, SHAPE_SHOW_MODE_DEFAULT);
      shape.elements = (Array.isArray(entry.elements) ? entry.elements : [])
        .map(normalizeId)
        .filter((x) => x !== null);
      shape.props = normalizePointProps(entry.props);
      internalizeAppearance(shape);
      shapes.push(shape);
    });

    // Ids manquants (ou en doublon) : attribués après le plus grand id reçu.
    let next = 0;
    for (const s of shapes) if (s.id !== null && s.id > next) next = s.id;
    for (const s of shapes) if (s.id === null) s.id = ++next;

    return {
      node_id: bare ? null : normalizeId(source.node_id),
      planIndex: bare ? null : normalizeId(source.planIndex),
      shapes,
      warnings: endWarnings(),
    };
  }

  /* ============================================================
     current_plan_scene3d_json — scène d'une représentation 3D (§ 10 bis)
     ============================================================
     Un document par plan 3D : unité des longueurs, échelle du modèle,
     vue par défaut de la caméra, emprise au sol, fond de plan, objets
     ajoutés et zones — toutes normalisées ici. */
  function emptyScene3d() {
    return {
      unit: 'm',
      scale: null,
      camera: null,
      north: null,
      footprint: null,
      floorImage: null,
      measures: [],
      objects: [],
      zones: [],
    };
  }

  /* Triplet [x, y, z] de nombres finis, ou null. */
  function normalizeVec3(value) {
    if (!Array.isArray(value) || value.length !== 3) return null;
    const out = value.map((n) => (typeof n === 'number' && Number.isFinite(n) ? n : null));
    return out.includes(null) ? null : out;
  }

  /* Vue par défaut : { position: [x,y,z], target: [x,y,z] } dans le repère
     du modèle ; null (ou absente) = cadrage automatique du modèle. */
  function normalizeCamera(value) {
    if (value === null || value === undefined) return null;
    const source = value && typeof value === 'object' ? value : {};
    const position = normalizeVec3(source.position);
    const target = normalizeVec3(source.target);
    if (!position || !target) {
      warn('current_plan_scene3d_json : cl\u00e9 camera incompl\u00e8te (position et ' +
        'target [x, y, z] attendus) : vue automatique');
      return null;
    }
    return { position, target };
  }

  /* Échelle du modèle : value = longueur réelle (en unit) d'UNE unité du
     modèle, avec l'étalon tracé par l'outil « Étalon » : segment au sol
     (x1, z1) - (x2, z2), longueur réelle length (qui, si value manque, la
     déduit), shown. null = échelle inconnue (mesures en unités du modèle). */
  function normalizeScale3d(value) {
    if (value === null || value === undefined) return null;
    const source = value && typeof value === 'object' ? value : {};
    const num = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : null);
    const seg = [source.x1, source.z1, source.x2, source.z2].map(num);
    const hasSegment = !seg.includes(null) && Math.hypot(seg[2] - seg[0], seg[3] - seg[1]) > 0;
    const length = num(source.length) > 0 ? source.length : null;
    let val = num(source.value) > 0 ? source.value : null;
    if (val === null && hasSegment && length !== null) {
      val = length / Math.hypot(seg[2] - seg[0], seg[3] - seg[1]);
    }
    if (val === null) {
      warn('current_plan_scene3d_json : cl\u00e9 scale sans value > 0 (ni \u00e9talon avec length) : \u00e9chelle ignor\u00e9e');
      return null;
    }
    return {
      value: val,
      x1: hasSegment ? seg[0] : null,
      z1: hasSegment ? seg[1] : null,
      x2: hasSegment ? seg[2] : null,
      z2: hasSegment ? seg[3] : null,
      length: hasSegment ? (length !== null ? length : Math.hypot(seg[2] - seg[0], seg[3] - seg[1]) * val) : null,
      shown: normalizeBoolean(source.shown, true),
    };
  }

  /* Mesures au sol : { id, type "distance" (2 points au moins) | "area"
     (3 sommets au moins), points, label, shown }. */
  function normalizeMeasures(list) {
    const out = [];
    const seen = new Set();
    (Array.isArray(list) ? list : []).forEach((item, i) => {
      const entry = item && typeof item === 'object' ? item : {};
      const type = entry.type === 'area' ? 'area' : (entry.type === 'distance' ? 'distance' : null);
      const points = normalizeGroundPoints(entry.points);
      if (!type || points.length < (type === 'area' ? 3 : 2)) {
        warn('current_plan_scene3d_json : mesure ' + (i + 1) + ' de type inconnu ou sans assez de points : ignor\u00e9e');
        return;
      }
      let id = normalizeId(entry.id);
      if (id !== null && seen.has(id)) id = null;
      out.push({ id, type, points, label: normalizeText(entry.label), shown: normalizeBoolean(entry.shown, true) });
      if (id !== null) seen.add(id);
    });
    let next = 0;
    for (const m of out) if (m.id !== null && m.id > next) next = m.id;
    for (const m of out) if (m.id === null) m.id = ++next;
    return out;
  }

  /* Couleur hexadécimale #rrggbb (celle des champs couleur du panneau) ;
     #rgb est étendu ; toute autre écriture est ramenée au défaut. */
  function normalizeHexColor(value, fallback) {
    const text = normalizeText(value);
    if (/^#[0-9a-f]{6}$/i.test(text)) return text.toLowerCase();
    if (/^#[0-9a-f]{3}$/i.test(text)) {
      return ('#' + text[1] + text[1] + text[2] + text[2] + text[3] + text[3]).toLowerCase();
    }
    return fallback;
  }

  /* Nombre fini, ou fallback ; min (optionnel) : borne inférieure stricte. */
  function normalizeNumber(value, fallback, min) {
    if (typeof value !== 'number' || !Number.isFinite(value)) return fallback;
    if (min !== undefined && value <= min) return fallback;
    return value;
  }

  /* Sommets au sol [[x, z], …] (ou { x, z }) : les entrées invalides sont
     ignorées. */
  function normalizeGroundPoints(list) {
    return (Array.isArray(list) ? list : [])
      .map((p) => {
        if (Array.isArray(p) && p.length >= 2) return [p[0], p[1]];
        if (p && typeof p === 'object') return [p.x, p.z];
        return null;
      })
      .filter((p) => p && typeof p[0] === 'number' && Number.isFinite(p[0]) &&
        typeof p[1] === 'number' && Number.isFinite(p[1]));
  }

  /* Emprise au sol : polygone d'au moins 3 sommets, contour (couleur,
     épaisseur en unités du modèle ou null = automatique, pointillés),
     remplissage (couleur, opacité), altitude, affichage. */
  function normalizeFootprint(value) {
    if (value === null || value === undefined) return null;
    const source = value && typeof value === 'object' ? value : {};
    const points = normalizeGroundPoints(source.points);
    if (points.length < 3) {
      warn('current_plan_scene3d_json : emprise (footprint) sans 3 sommets [x, z] valides : ignor\u00e9e');
      return null;
    }
    return {
      points,
      stroke: normalizeHexColor(source.stroke, '#1d4ed8'),
      strokeWidth: normalizeNumber(source.strokeWidth, null, 0),
      dashed: normalizeBoolean(source.dashed, true),
      fill: normalizeHexColor(source.fill, '#1d4ed8'),
      fillOpacity: clampNum(normalizeNumber(source.fillOpacity, 0.12), 0, 1),
      altitude: normalizeNumber(source.altitude, 0),
      shown: normalizeBoolean(source.shown, true),
    };
  }

  /* Fond de plan : image posée au sol, centrée en (x, z), de largeur width
     (null = automatique) et hauteur height (null = rapport de l'image),
     tournée de rotation degrés (sens horaire vu de dessus). */
  function normalizeFloorImage(value) {
    if (value === null || value === undefined) return null;
    const source = value && typeof value === 'object' ? value : {};
    const filename = normalizeFilename(source);
    if (!filename) {
      warn('current_plan_scene3d_json : fond de plan (floorImage) sans fichier : ignor\u00e9');
      return null;
    }
    const rotation = normalizeNumber(source.rotation, 0);
    return {
      filename,
      x: normalizeNumber(source.x, 0),
      z: normalizeNumber(source.z, 0),
      width: normalizeNumber(source.width, null, 0),
      height: normalizeNumber(source.height, null, 0),
      rotation: ((rotation % 360) + 360) % 360,
      opacity: clampNum(normalizeNumber(source.opacity, 0.85), 0, 1),
      altitude: normalizeNumber(source.altitude, 0),
      shown: normalizeBoolean(source.shown, true),
    };
  }

  /* Objets 3D ajoutés : { id, filename (.obj / .glb), label, x, z, altitude,
     rotation (degrés, sens horaire vu de dessus), size (plus grande
     dimension réelle en unit), scale (facteur, 1), color (#rrggbb ou null =
     matériaux du fichier), shown }. */
  function normalizeObjects(list) {
    const out = [];
    const seen = new Set();
    (Array.isArray(list) ? list : []).forEach((item, i) => {
      const entry = item && typeof item === 'object' ? item : {};
      const filename = normalizeFilename(entry);
      if (!filename) {
        warn('current_plan_scene3d_json : objet ' + (i + 1) + ' sans fichier : ignor\u00e9');
        return;
      }
      let id = normalizeId(entry.id);
      if (id !== null && seen.has(id)) id = null;
      const rotation = normalizeNumber(entry.rotation, 0);
      out.push({
        id,
        filename,
        label: normalizeText(entry.label),
        x: normalizeNumber(entry.x, 0),
        z: normalizeNumber(entry.z, 0),
        altitude: normalizeNumber(entry.altitude, 0),
        rotation: ((rotation % 360) + 360) % 360,
        size: normalizeNumber(entry.size, 1, 0),
        scale: Math.min(100, normalizeNumber(entry.scale, 1, 0)),
        color: normalizeHexColor(entry.color, null),
        shown: normalizeBoolean(entry.shown, true),
      });
      if (id !== null) seen.add(id);
    });
    let next = 0;
    for (const o of out) if (o.id !== null && o.id > next) next = o.id;
    for (const o of out) if (o.id === null) o.id = ++next;
    return out;
  }

  /* Zones du bâtiment : { id, label, description, points [[x, z], …] (3 au
     moins, sauf zone liée à un groupe), baseHeight, height, color, opacity
     (au survol / en alarme), group (nom d'un maillage du modèle, ou null),
     show_mode (§ 6.3), elements (ids de capteurs liés), shown }. */
  function normalizeZones(list) {
    const out = [];
    const seen = new Set();
    (Array.isArray(list) ? list : []).forEach((item, i) => {
      const entry = item && typeof item === 'object' ? item : {};
      const group = normalizeText(entry.group) || null;
      const points = normalizeGroundPoints(entry.points);
      if (!group && points.length < 3) {
        warn('current_plan_scene3d_json : zone ' + (i + 1) + ' sans groupe ni 3 sommets [x, z] valides : ignor\u00e9e');
        return;
      }
      let id = normalizeId(entry.id);
      if (id !== null && seen.has(id)) id = null;
      out.push({
        id,
        label: normalizeText(entry.label),
        description: normalizeText(entry.description),
        points,
        baseHeight: Math.max(0, normalizeNumber(entry.baseHeight, 0)),
        height: normalizeNumber(entry.height, 10, 0),
        color: normalizeHexColor(entry.color, '#f59e0b'),
        opacity: clampNum(normalizeNumber(entry.opacity, 0.35), 0, 1),
        group,
        show_mode: normalizeShowMode(entry.show_mode, SHAPE_SHOW_MODE_DEFAULT),
        elements: (Array.isArray(entry.elements) ? entry.elements : []).map(normalizeId).filter((x) => x !== null),
        shown: normalizeBoolean(entry.shown, true),
      });
      if (id !== null) seen.add(id);
    });
    let next = 0;
    for (const z of out) if (z.id !== null && z.id > next) next = z.id;
    for (const z of out) { if (z.id === null) z.id = ++next; if (!z.label) z.label = 'Zone ' + z.id; }
    return out;
  }

  /* Nord du plan 3D (clé north) : { angle (degrés, sens horaire vu de
     dessus, 0 = axe -z du modèle), shown (flèche au sol, vrai), x, z
     (position de la flèche au sol ; null = coin nord-est du modèle) }. Un
     nombre seul vaut { angle }. Sans angle fini : null (nord inconnu) avec
     avertissement. */
  function normalizeNorth(value) {
    if (value === null || value === undefined) return null;
    if (typeof value === 'number') value = { angle: value };
    const source = value && typeof value === 'object' ? value : {};
    const num = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : null);
    const angle = num(source.angle);
    if (angle === null) {
      warn('current_plan_scene3d_json : cl\u00e9 north sans angle : nord inconnu');
      return null;
    }
    const x = num(source.x), z = num(source.z);
    const placed = x !== null && z !== null;
    return {
      angle: Math.round((((angle % 360) + 360) % 360) * 100) / 100,
      shown: normalizeBoolean(source.shown, true),
      x: placed ? x : null,
      z: placed ? z : null,
    };
  }

  function normalizeScene3d(raw) {
    const source = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
    beginWarnings();
    const scene = emptyScene3d();
    scene.unit = normalizeText(source.unit) || 'm';
    scene.scale = normalizeScale3d(source.scale);
    scene.camera = normalizeCamera(source.camera);
    scene.north = normalizeNorth(source.north);
    scene.footprint = normalizeFootprint(source.footprint);
    scene.floorImage = normalizeFloorImage(source.floorImage);
    scene.measures = normalizeMeasures(source.measures);
    scene.objects = normalizeObjects(source.objects);
    scene.zones = normalizeZones(source.zones);
    return {
      node_id: normalizeId(source.node_id),
      planIndex: normalizeId(source.planIndex),
      scene,
      warnings: endWarnings(),
    };
  }

  /* ============================================================
     État partagé du visualiseur
     ============================================================
     Muté par les modules plan (représentation affichée) et nav (sélection
     de l'opérateur) ; lu par tous. */
  NS.state = {
    /* 'image' ou 'three' : quel visualiseur est actif, pour savoir à qui la
       barre de zoom (partagée) doit transmettre ses clics. */
    activeMode: 'image',

    /* Configuration courante, représentations de l'élément sélectionné,
       représentation affichée et chemin affiché dans le fil d'Ariane. */
    currentConfig: normalizeConfig(null),
    currentPlans: [],
    currentPlan: null,
    currentLocation: '',

    /* Nœud sélectionné par l'opérateur (objet normalisé de
       currentConfig.tree, retrouvé par id dans currentConfig.byId) ; null
       tant qu'aucun emplacement n'a été sélectionné depuis la dernière
       configuration, et en mode sans navigation. Le bouton « + » du bandeau
       n'est actif qu'après une sélection. */
    selectedNode: null,

    /* Compteur des écritures de selectedNodePath (clé serial) : deux
       sélections identiques successives sont ainsi distinguées par
       l'application. */
    selectionSerial: 0,

    /* Compteur des demandes de détail (clics sur un badge du bandeau ou un
       capteur du plan), écrit dans eventsDetailRequest_json pour que deux
       clics identiques successifs soient vus comme deux changements. */
    eventsDetailSerial: 0,

    /* Alarmes en cours (configuration_events_json normalisée par
       normalizeEventList) : distribuées sur les nœuds de l'arbre (clé
       events de chaque nœud) par viewer-nav.js, et consultées par les
       capteurs et les formes du plan affiché. */
    events: { list: [], byNode: new Map(), byElement: new Map(), warnings: [] },

    /* Capteurs du plan affiché (current_plan_element_json), après
       résolution du plan visé : tableau d'éléments normalisés. Mémorisés
       par plan dans elementsCache (clé node_id:planIndex) le temps de la
       page. */
    currentElements: [],
    elementsCache: new Map(),

    /* État de réception de chaque propriété lue — texte affiché en tête de
       l'info-bulle « i » du drawer (nom -> ligne d'état). */
    propertyStatus: {},

    /* Signets ajoutés par l'opérateur avec le bouton « + » du bandeau. Ils
       s'empilent à la suite des vues épinglées de la configuration, dans la
       même liste, et survivent à une reconstruction (nouvelle valeur de
       configuration_plan_json) ; mais ils ne vivent que le temps de la page
       (aucune persistance côté Panorama). */
    userPinned: [],

    /* Éléments DOM des calques actuellement affichés sur le plan (image ou
       marqueurs) : la barre de zoom leur applique la même transformation
       qu'à planImage, afin qu'ils restent parfaitement superposés à tout
       niveau de zoom/déplacement. */
    layerElements: [],
  };

  /* Clé de mémorisation par plan, le temps de la page (jusqu'à la
     prochaine RECONSTRUCTION — les identifiants peuvent alors changer) :
     « node_id:planIndex », les identifiants mêmes que l'application
     renvoie dans current_plan_element_json et
     current_plan_drawnShapes_json. elementsKeyFor la construit à partir
     d'une valeur reçue ; elementsKey pour un plan affiché (le plan doit
     figurer dans state.currentPlans ; id 0 en mode sans navigation). */
  function elementsKeyFor(nodeId, planIndex) {
    return nodeId + ':' + planIndex;
  }
  function elementsKey(plan) {
    const nodeId = NS.state.selectedNode ? NS.state.selectedNode.id : 0;
    return elementsKeyFor(nodeId,
      NS.state.currentPlans.indexOf(plan) + NS.SELECTED_PLAN_BASE);
  }

  /* ------------------- Exposition sur l'espace de noms ------------------- */
  NS.PATH_SEPARATOR = PATH_SEPARATOR;
  NS.elementsKey = elementsKey;
  NS.elementsKeyFor = elementsKeyFor;
  NS.clampNum = clampNum;
  NS.normalizeText = normalizeText;
  NS.normalizeBoolean = normalizeBoolean;
  NS.normalizeFraction = normalizeFraction;
  NS.normalizeArrowHeads = normalizeArrowHeads;
  NS.normalizeRotation = normalizeRotation;
  NS.normalizeShapes = normalizeShapes;
  NS.normalizeId = normalizeId;
  NS.normalizeShowMode = normalizeShowMode;
  NS.pinForNode = pinForNode;
  NS.normalizeConfig = normalizeConfig;
  NS.normalizeEventList = normalizeEventList;
  NS.normalizeElements = normalizeElements;
  NS.normalizeDrawnShapes = normalizeDrawnShapes;
  NS.emptyScene3d = emptyScene3d;
  NS.normalizeScene3d = normalizeScene3d;
  NS.ORIENTATION_HELPER_MODES = ORIENTATION_HELPER_MODES;
  NS.SHOW_MODES = SHOW_MODES;
  NS.ELEMENT_SHOW_MODE_DEFAULT = ELEMENT_SHOW_MODE_DEFAULT;
  NS.SHAPE_SHOW_MODE_DEFAULT = SHAPE_SHOW_MODE_DEFAULT;
})(globalThis);
