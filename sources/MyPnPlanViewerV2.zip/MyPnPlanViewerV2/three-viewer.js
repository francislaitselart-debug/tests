﻿// Visualiseur 3D basé sur Three.js (vendor/three), pour comparaison avec
// le moteur WebGL natif écrit à la main dans app.js. Ce module expose
// window.ThreeViewer, seul point de contact avec le script classique app.js
// (qui gère l'arbre de navigation, le sélecteur de plans et la barre de
// zoom partagée entre les deux moteurs).
import * as THREE from 'three';
import { OBJLoader } from './vendor/three/examples/jsm/loaders/OBJLoader.js';
import { GLTFLoader } from './vendor/three/examples/jsm/loaders/GLTFLoader.js';
import { OrbitControls } from './vendor/three/examples/jsm/controls/OrbitControls.js';

const viewport = document.getElementById('threeViewport');
const canvas = document.getElementById('threeCanvas');
const loadingEl = document.getElementById('threeLoading');
const zoomLevelEl = document.getElementById('zoomLevel');
const zoomInBtn = document.getElementById('zoomInBtn');
const zoomOutBtn = document.getElementById('zoomOutBtn');
const zoomResetBtn = document.getElementById('zoomResetBtn');

// alpha : le tampon garde un canal de transparence pour les captures sans
// fond (export SVG) ; à l'écran, scene.background reste opaque.
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
renderer.setPixelRatio(window.devicePixelRatio || 1);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0xf6f8fb);

const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 10000);

/* VUE EN PLAN : caméra orthographique de dessus (nord en haut), permutée
   avec la caméra perspective (activeCamera). OrbitControls la pilote en
   déplacement et zoom seuls (rotation désactivée, bouton gauche =
   déplacement). getContext().camera est un accesseur : les modules de la
   scène voient toujours la caméra active. Cf. setPlanView. */
const orthoCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 10000);
let activeCamera = camera;
let planView = false;
let planSaved = null;      // { position, target } de la perspective avant la vue en plan
let planAzimuth = 0;       // azimut (rad) de la vue de dessus : -nord
let tween = null;          // requestAnimationFrame de la transition en cours
let animationMs = 400;     // durée des transitions (0 : immédiates, bancs)
const PLAN_TILT = 0.5 * Math.PI / 180;   // dévers de la perspective de dessus (azimut défini)
const planListeners = [];

scene.add(new THREE.AmbientLight(0xffffff, 0.45));
const sun = new THREE.DirectionalLight(0xffffff, 1.1);
sun.position.set(0.4, 0.8, 0.5);
scene.add(sun);

const material = new THREE.MeshStandardMaterial({ color: 0x9fb0c2, metalness: 0.05, roughness: 0.9 });
const objLoader = new OBJLoader();
const gltfLoader = new GLTFLoader();
const cache = new Map();

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = false;
controls.addEventListener('change', render);
/* Rappels notifiés à chaque mouvement de la caméra (panneau « Scène 3D »
   de viewer-scene3d.js). */
const cameraListeners = [];
controls.addEventListener('change', () => { for (const cb of cameraListeners) cb(); });
controls.addEventListener('start', () => viewport.classList.add('dragging'));
controls.addEventListener('end', () => viewport.classList.remove('dragging'));

let defaultDistance = 1;
const defaultTarget = new THREE.Vector3();
const defaultPosition = new THREE.Vector3();
let currentObject = null;
let active = false;

/* Cadrage automatique du modèle affiché (frameObject) et bornes de zoom
   associées ; vue par défaut IMPOSÉE par la scène du plan
   (current_plan_scene3d_json, clé camera : { position, target } dans le
   repère du modèle), null = cadrage automatique. */
const autoTarget = new THREE.Vector3();
const autoPosition = new THREE.Vector3();
let autoMinDistance = 0.1;
let autoMaxDistance = 10000;
let customView = null;
/* Boîte englobante du modèle affiché (null tant qu'il n'est pas chargé),
   rappels de fin de chargement et d'avant-rendu (modules de la scène 3D :
   objets posés au sol, poignées à taille écran constante). */
let modelBox = null;
const modelListeners = [];
const beforeRenderListeners = [];

function frameObject(object) {
  const box = new THREE.Box3().setFromObject(object);
  modelBox = box;
  const center = box.getCenter(new THREE.Vector3());
  const size = Math.max(0.1, box.getSize(new THREE.Vector3()).length());
  const dist = size * 1.1;

  camera.near = dist / 100;
  camera.far = dist * 100;
  camera.updateProjectionMatrix();

  autoTarget.copy(center);
  autoPosition.set(center.x + dist * 0.6, center.y + dist * 0.45, center.z + dist * 0.6);
  autoMinDistance = dist * 0.15;
  autoMaxDistance = dist * 6;
  applyDefaultView();
  resetView();
  for (const cb of modelListeners) cb();
}

/* Vue par défaut effective : la vue enregistrée par la scène (customView)
   si elle existe, sinon le cadrage automatique. Sa distance réelle (et non
   le rayon d'encadrement brut) est celle qui correspond à "100%" dans la
   barre de zoom ; les bornes de zoom l'englobent toujours. */
function applyDefaultView() {
  if (customView) {
    defaultTarget.fromArray(customView.target);
    defaultPosition.fromArray(customView.position);
  } else {
    defaultTarget.copy(autoTarget);
    defaultPosition.copy(autoPosition);
  }
  defaultDistance = defaultPosition.distanceTo(defaultTarget);
  controls.minDistance = Math.min(autoMinDistance, defaultDistance);
  controls.maxDistance = Math.max(autoMaxDistance, defaultDistance);
}

/* { position: [x,y,z], target: [x,y,z] } de nombres finis, ou null. */
function normalizeView(view) {
  if (!view || typeof view !== 'object') return null;
  const ok = (a) => Array.isArray(a) && a.length === 3 &&
    a.every((n) => typeof n === 'number' && Number.isFinite(n));
  if (!ok(view.position) || !ok(view.target)) return null;
  return { position: view.position.slice(), target: view.target.slice() };
}

/* Impose (ou retire, avec null) la vue par défaut du modèle affiché ; la
   caméra y est replacée aussitôt. Peut être appelé avant la fin du
   chargement du fichier : frameObject la reprend alors. */
function setDefaultView(view) {
  customView = normalizeView(view);
  if (currentObject) {
    applyDefaultView();
    // En vue en plan, la vue par défaut est mémorisée sans être appliquée
    // (cadenas, scène reçue) : l'opérateur reste sur sa vue de dessus.
    if (!planView) resetView();
    render();
  }
}

/* Position et cible courantes de la caméra (repère du modèle, arrondies
   au millième) : ce que la scène enregistre comme vue par défaut. */
function getCameraState() {
  const round = (v) => Math.round(v * 1000) / 1000;
  return {
    position: activeCamera.position.toArray().map(round),
    target: controls.target.toArray().map(round),
  };
}

function isAtDefaultView() {
  if (planView) return false;
  return camera.position.distanceTo(defaultPosition) < 1e-3 &&
    controls.target.distanceTo(defaultTarget) < 1e-3;
}

function resetView() {
  // Le bouton de réinitialisation quitte aussi la vue en plan.
  if (planView) leavePlanView(false);
  if (tween) { cancelAnimationFrame(tween); tween = null; }
  camera.position.copy(defaultPosition);
  controls.target.copy(defaultTarget);
  controls.update();
}

function resizeToDisplaySize() {
  const w = canvas.clientWidth, h = canvas.clientHeight;
  if (w === 0 || h === 0) return;
  const needResize = canvas.width !== Math.round(w * renderer.getPixelRatio()) ||
    canvas.height !== Math.round(h * renderer.getPixelRatio());
  if (needResize) {
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    updateOrthoFrustum();
  }
}

/* Frustum de la caméra orthographique : la hauteur visible au plan de la
   cible égale celle de la perspective à la même distance (pas de saut à la
   permutation), la largeur suit le rapport du canvas ; le zoom est porté
   par orthoCamera.zoom. */
function updateOrthoFrustum() {
  const dist = orthoCamera.position.distanceTo(controls.target) || defaultDistance || 1;
  const halfH = dist * Math.tan(camera.fov * Math.PI / 360);
  const halfW = halfH * (camera.aspect || 1);
  orthoCamera.left = -halfW;
  orthoCamera.right = halfW;
  orthoCamera.top = halfH;
  orthoCamera.bottom = -halfH;
  orthoCamera.near = camera.near;
  orthoCamera.far = camera.far;
  orthoCamera.updateProjectionMatrix();
}

/* Direction (depuis la cible) d'une vue de dessus légèrement penchée vers
   le sud, pour que le haut de l'écran soit le nord (azimut = -nord). */
function topDirection(az) {
  return new THREE.Vector3(Math.sin(PLAN_TILT) * Math.sin(az), Math.cos(PLAN_TILT), Math.sin(PLAN_TILT) * Math.cos(az));
}

function reducedMotion() {
  return Boolean(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
}

/* Transition de la caméra PERSPECTIVE vers (pos, target) — Vector3 — en
   ms millisecondes (animationMs par défaut ; 0 ou prefers-reduced-motion :
   immédiate). Une transition en cours est abandonnée. */
function animateTo(pos, target, ms, done) {
  if (tween) { cancelAnimationFrame(tween); tween = null; }
  const dur = reducedMotion() ? 0 : (ms === undefined ? animationMs : ms);
  const p0 = camera.position.clone(), t0 = controls.target.clone();
  const start = performance.now();
  const step = (now) => {
    const k = dur ? Math.min(1, (now - start) / dur) : 1;
    const e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
    camera.position.lerpVectors(p0, pos, e);
    controls.target.lerpVectors(t0, target, e);
    controls.update();
    render();
    if (k < 1) {
      tween = requestAnimationFrame(step);
    } else {
      tween = null;
      if (done) done();
    }
  };
  step(start);
}

function notifyPlanView() {
  for (const cb of planListeners) cb(planView);
}

/* Entre en vue en plan : la perspective glisse vers la verticale
   (transition), puis la caméra orthographique prend le relais à la même
   distance, exactement à la verticale de la cible, « haut » = nord (angle
   north en degrés, sens horaire vu de dessus, 0 = -z). */
function enterPlanView(north, animate) {
  if (planView || !currentObject) return;
  planView = true;
  planSaved = { position: camera.position.clone(), target: controls.target.clone() };
  planAzimuth = -(north || 0) * Math.PI / 180;
  const dist = camera.position.distanceTo(controls.target);
  const top = controls.target.clone().add(topDirection(planAzimuth).multiplyScalar(dist));
  const swap = () => {
    if (!planView) return;   // sortie demandée pendant la transition
    const t = north || 0;
    orthoCamera.up.set(Math.sin(t * Math.PI / 180), 0, -Math.cos(t * Math.PI / 180));
    orthoCamera.position.copy(controls.target).add(new THREE.Vector3(0, dist, 0));
    orthoCamera.zoom = 1;
    orthoCamera.lookAt(controls.target);
    activeCamera = orthoCamera;
    controls.object = orthoCamera;
    controls.enableRotate = false;
    controls.mouseButtons.LEFT = THREE.MOUSE.PAN;
    controls.minZoom = 0.2;
    controls.maxZoom = 8;
    updateOrthoFrustum();
    controls.update();
    notifyPlanView();
    render();
  };
  controls.enableRotate = false;
  if (animate) {
    animateTo(top, controls.target.clone(), undefined, swap);
  } else {
    camera.position.copy(top);
    controls.update();
    swap();
  }
}

/* Sort de la vue en plan : la perspective reprend à la verticale (distance
   effective = distance / zoom orthographique) puis revient, avec ou sans
   transition, à la vue d'avant. */
function leavePlanView(animate) {
  if (!planView) return;
  if (tween) { cancelAnimationFrame(tween); tween = null; }
  planView = false;
  const saved = planSaved;
  planSaved = null;
  if (activeCamera === orthoCamera) {
    const dist = orthoCamera.position.distanceTo(controls.target) / (orthoCamera.zoom || 1);
    camera.position.copy(controls.target).add(topDirection(planAzimuth).multiplyScalar(dist));
    orthoCamera.zoom = 1;
  }
  activeCamera = camera;
  controls.object = camera;
  controls.enableRotate = true;
  controls.mouseButtons.LEFT = THREE.MOUSE.ROTATE;
  controls.update();
  notifyPlanView();
  if (saved && animate) {
    animateTo(saved.position, saved.target);
  } else {
    if (saved) {
      camera.position.copy(saved.position);
      controls.target.copy(saved.target);
      controls.update();
    }
    render();
  }
}

/* Capture du rendu courant (vue en plan ou 3D) à l'échelle demandée
   (pixels par pixel CSS, 0,5 à 4) : le canvas est rendu à cette résolution
   puis copié dans un canvas 2D — dans la même tâche, avant toute
   recomposition, ce qui dispense de preserveDrawingBuffer — et l'affichage
   est restauré. opts.transparent : sans fond (canal alpha), pour superposer
   l'image à d'autres couches. Renvoie le canvas 2D (exports PNG / SVG). */
function snapshot(scale, opts) {
  const w = canvas.clientWidth, h = canvas.clientHeight;
  const pr = renderer.getPixelRatio();
  const k = Math.max(0.5, Math.min(4, scale || 1));
  const transparent = Boolean(opts && opts.transparent);
  const background = scene.background;
  if (transparent) {
    scene.background = null;
    renderer.setClearColor(0x000000, 0);
  }
  renderer.setPixelRatio(k);
  renderer.setSize(w, h, false);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  updateOrthoFrustum();
  for (const cb of beforeRenderListeners) cb();
  renderer.render(scene, activeCamera);
  const out = document.createElement('canvas');
  out.width = canvas.width;
  out.height = canvas.height;
  out.getContext('2d').drawImage(canvas, 0, 0);
  if (transparent) {
    scene.background = background;
    renderer.setClearColor(0x000000, 1);
  }
  renderer.setPixelRatio(pr);
  renderer.setSize(w, h, false);
  render();
  return out;
}

/* Cadre la vue en plan sur une boîte au sol { minX, maxX, minZ, maxZ }
   (unités du modèle) avec une marge relative : la cible passe au centre,
   le zoom orthographique ajuste la boîte (tournée selon le nord) au cadre.
   Renvoie une fonction qui restaure la cible et le zoom d'avant (exports).
   Sans effet hors vue en plan. */
function fitPlanView(box, margin) {
  if (!planView || activeCamera !== orthoCamera) return () => {};
  const saved = { target: controls.target.clone(), zoom: orthoCamera.zoom };
  const up = orthoCamera.up;                       // nord (au sol)
  const right = new THREE.Vector3(-up.z, 0, up.x);  // est
  let uMin = Infinity, uMax = -Infinity, vMin = Infinity, vMax = -Infinity;
  for (const x of [box.minX, box.maxX]) {
    for (const z of [box.minZ, box.maxZ]) {
      const u = x * right.x + z * right.z, v = x * up.x + z * up.z;
      uMin = Math.min(uMin, u); uMax = Math.max(uMax, u);
      vMin = Math.min(vMin, v); vMax = Math.max(vMax, v);
    }
  }
  const m = 1 + (margin === undefined ? 0.06 : margin);
  const w = Math.max(1e-3, (uMax - uMin) * m), h = Math.max(1e-3, (vMax - vMin) * m);
  const cu = (uMin + uMax) / 2, cv = (vMin + vMax) / 2;
  const center = new THREE.Vector3(cu * right.x + cv * up.x, controls.target.y, cu * right.z + cv * up.z);
  const dist = orthoCamera.position.distanceTo(controls.target);
  controls.target.copy(center);
  orthoCamera.position.copy(center).add(new THREE.Vector3(0, dist, 0));
  orthoCamera.zoom = THREE.MathUtils.clamp(
    Math.min((orthoCamera.right - orthoCamera.left) / w, (orthoCamera.top - orthoCamera.bottom) / h),
    controls.minZoom, controls.maxZoom);
  orthoCamera.updateProjectionMatrix();
  controls.update();
  render();
  return () => {
    if (!planView || activeCamera !== orthoCamera) return;
    controls.target.copy(saved.target);
    orthoCamera.position.copy(saved.target).add(new THREE.Vector3(0, dist, 0));
    orthoCamera.zoom = saved.zoom;
    orthoCamera.updateProjectionMatrix();
    controls.update();
    render();
  };
}

/* Bascule de la vue en plan. opts : { north (degrés), animate (vrai) }. */
function setPlanView(on, opts) {
  const o = opts || {};
  const animate = o.animate !== false;
  if (on) enterPlanView(o.north, animate);
  else leavePlanView(animate);
}

function render() {
  if (!active) return;
  resizeToDisplaySize();
  for (const cb of beforeRenderListeners) cb();
  renderer.render(scene, activeCamera);
  updateZoomUI();
}

function updateZoomUI() {
  if (!active) return;
  if (planView) {
    // Vue en plan : zoom orthographique (100 % à l'entrée) ; ↻ ramène à la 3D.
    zoomLevelEl.textContent = Math.round(orthoCamera.zoom * 100) + '%';
    zoomInBtn.disabled = orthoCamera.zoom >= controls.maxZoom - 1e-3;
    zoomOutBtn.disabled = orthoCamera.zoom <= controls.minZoom + 1e-3;
    zoomResetBtn.disabled = false;
    return;
  }
  const dist = camera.position.distanceTo(controls.target);
  const pct = Math.round((defaultDistance / dist) * 100);
  zoomLevelEl.textContent = pct + '%';
  zoomInBtn.disabled = dist <= controls.minDistance + 1e-3;
  zoomOutBtn.disabled = dist >= controls.maxDistance - 1e-3;
  zoomResetBtn.disabled =
    Math.abs(dist - defaultDistance) < 1e-3 && camera.position.distanceTo(defaultPosition) < 1e-3;
}

function dollyBy(factor) {
  if (planView && activeCamera === orthoCamera) {
    orthoCamera.zoom = THREE.MathUtils.clamp(orthoCamera.zoom * factor, controls.minZoom, controls.maxZoom);
    orthoCamera.updateProjectionMatrix();
    controls.update();
    render();
    return;
  }
  const offset = camera.position.clone().sub(controls.target);
  const newLen = THREE.MathUtils.clamp(offset.length() / factor, controls.minDistance, controls.maxDistance);
  offset.setLength(newLen);
  camera.position.copy(controls.target).add(offset);
  controls.update();
  render();
}

/* Fichier de modèle .glb / .gltf (GLTFLoader) ou .obj (OBJLoader). */
function isGltf(fileUrl) {
  return /\.(glb|gltf)(\?.*)?$/i.test(fileUrl);
}

/* base64 -> ArrayBuffer (modèles .glb embarqués pour file://). */
function base64ToBuffer(b64) {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes.buffer;
}

/* Lecture d'un fichier de modèle : Object3D résolu (scène du glTF, ou
   groupe de l'OBJ). Sous Panorama (HTTP), le chargeur lit le fichier par
   fetch. Depuis file:// (demo.html en double-clic), le navigateur refuse
   tout fetch / XHR de fichier local (CORS) mais accepte une balise
   <script> : on charge alors <fichier>.js, généré par
   tests/build-demo-model.js (modèle du plan) ou tests/build-demo-models.js
   (objets de la bibliothèque), qui enregistre le TEXTE du .obj ou le
   BASE64 du .glb dans window.ThreeViewerModels[fichier]. Sert au modèle du
   plan comme aux objets ajoutés (viewer-scene3d-render.js). */
function loadModel(fileUrl, onProgress) {
  const gltf = isGltf(fileUrl);
  if (location.protocol !== 'file:') {
    return new Promise((resolve, reject) => {
      const loader = gltf ? gltfLoader : objLoader;
      loader.load(
        fileUrl,
        (result) => resolve(gltf ? result.scene : result),
        (evt) => { if (onProgress && evt.total) onProgress(evt.loaded / evt.total); },
        reject
      );
    });
  }
  return new Promise((resolve, reject) => {
    const models = window.ThreeViewerModels || (window.ThreeViewerModels = {});
    const done = () => {
      const data = models[fileUrl];
      if (data === undefined) {
        reject(new Error(fileUrl + '.js ne d\u00e9clare pas ThreeViewerModels["' + fileUrl + '"]'));
      } else if (gltf) {
        gltfLoader.parse(base64ToBuffer(data), '', (result) => resolve(result.scene), reject);
      } else {
        resolve(objLoader.parse(data));
      }
    };
    if (models[fileUrl] !== undefined) return done();
    const script = document.createElement('script');
    script.src = fileUrl + '.js';
    script.onload = done;
    script.onerror = () => reject(new Error('file:// : ' + fileUrl + '.js introuvable ' +
      '(g\u00e9n\u00e9rer avec node tests/build-demo-model.js ou build-demo-models.js)'));
    document.head.appendChild(script);
  });
}

async function show(fileUrl) {
  active = true;
  // Un autre modèle : la vue en plan ne survit pas au changement.
  if (planView) leavePlanView(false);
  // La vue par défaut appartient au plan : viewer-scene3d.js la redonne
  // (setDefaultView) juste après cet appel si la scène du plan en a une.
  customView = null;
  modelBox = null;
  loadingEl.hidden = false;
  loadingEl.textContent = 'Chargement du mod\u00e8le 3D\u2026';

  let object = cache.get(fileUrl);
  if (!object) {
    try {
      object = await loadModel(fileUrl, (frac) => {
        loadingEl.textContent = 'Chargement du mod\u00e8le 3D\u2026 ' + Math.round(frac * 100) + '%';
      });
      // Un .obj est monochrome (matériau du visualiseur) ; un glTF garde
      // ses matériaux.
      if (!isGltf(fileUrl)) object.traverse((child) => { if (child.isMesh) child.material = material; });
      cache.set(fileUrl, object);
    } catch (err) {
      loadingEl.textContent = 'Impossible de charger le mod\u00e8le 3D.';
      console.error(err);
      return;
    }
  }

  if (currentObject) scene.remove(currentObject);
  currentObject = object;
  scene.add(object);
  frameObject(object);
  loadingEl.hidden = true;
  render();
}

function hide() {
  active = false;
  if (planView) leavePlanView(false);
}

/* L'objet est librement redimensionné dans le synoptique hôte : un nouveau
   rendu recale la taille du canvas (resizeToDisplaySize) quand ce moteur
   est actif. */
window.addEventListener('resize', render);

window.ThreeViewer = {
  show,
  hide,
  zoomIn: () => dollyBy(1.3),
  zoomOut: () => dollyBy(1 / 1.3),
  reset: () => { resetView(); render(); },
  isActive: () => active,
  /* Scène du plan (viewer-scene3d.js) : vue par défaut et caméra. */
  setDefaultView,
  getCameraState,
  isAtDefaultView,
  hasDefaultView: () => customView !== null,
  onCameraChange: (cb) => { cameraListeners.push(cb); },
  /* Chargement d'un fichier .obj / .glb (objets ajoutés à la scène). */
  loadModel,
  /* Object3D du modèle affiché (groupes nommés des zones), ou null. */
  getModelObject: () => currentObject,
  onModelLoaded: (cb) => { modelListeners.push(cb); },
  onBeforeRender: (cb) => { beforeRenderListeners.push(cb); },
  /* Boîte englobante du modèle chargé : { min, max, center, size } en
     tableaux [x, y, z], ou null. Le sol est min[1]. */
  getModelBounds: () => modelBox ? {
    min: modelBox.min.toArray(), max: modelBox.max.toArray(),
    center: modelBox.getCenter(new THREE.Vector3()).toArray(),
    size: modelBox.getSize(new THREE.Vector3()).toArray(),
  } : null,
  /* Vue en plan (viewer-scene3d-planview.js) : bascule, état, rappels,
     transition de caméra réutilisable (repère de coin), caméras. */
  setPlanView,
  isPlanView: () => planView,
  onPlanViewChange: (cb) => { planListeners.push(cb); },
  animateTo,
  setAnimationMs: (ms) => { animationMs = ms; },
  getAnimationMs: () => animationMs,
  getPlanCamera: () => orthoCamera,
  /* Capture du rendu à l'échelle donnée et cadrage « plan entier »
     (viewer-scene3d-export.js). */
  snapshot,
  fitPlanView,
  /* Objets Three.js exposés aux modules d'édition de la scène (emprise,
     fond de plan, objets ajoutés, zones). camera est un accesseur : la
     caméra ACTIVE (perspective, ou orthographique en vue en plan). */
  getContext: () => ({ THREE, scene, get camera() { return activeCamera; }, renderer, controls, viewport, canvas, render }),
};
