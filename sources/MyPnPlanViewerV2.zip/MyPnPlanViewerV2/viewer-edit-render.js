﻿/* ============================================================
   MyPnPlanViewerV2 — module « edit-render »
   ============================================================
   Rendu du calque d'édition (planEditLayer) : formes dessinées, poignées
   d'ajustement et de rotation de la forme sélectionnée, et aperçu du
   tracé en cours.

   Les formes du plan (reçues de l'application ou dessinées) restent
   AFFICHÉES tant qu'un plan 2D l'est (shapesAvailable), avec ou sans mode
   édition ; leur règle show_mode s'applique cadenas fermé (masquage,
   halo d'alarme des capteurs liés — NS.shapeDisplay). Les poignées, la
   sélection et l'aperçu n'apparaissent que cadenas ouvert (editActive) ;
   les formes alors invisibles cadenas fermé passent en contour fantôme
   (pe-hidden-mode), comme celles au contour transparent (pe-ghost).
   Complète le socle viewer-edit-core.js (ordre de chargement : readme § 1).

   NOTE ENCODAGE : chaînes affichées en ASCII pur (\uXXXX), commentaires
   accentués, BOM UTF-8, fins de ligne CRLF (readme.txt § 14).
   ============================================================ */
(function (global) {
  'use strict';

  const NS = global.MyPnPlanViewerV2NS = global.MyPnPlanViewerV2NS || {};
  const ed = NS.edit;

  // Distance écran (px) entre le bord de la forme et sa poignée de rotation.
  const ROTATE_HANDLE_PX = 24;

  /* Types rendus par un seul élément SVG : l'aperçu de tracé peut être
     recoloré par style en ligne (styleDraftNode). Les types composites
     (groupes <g> : flèche, cote, étiquette…) portent leurs couleurs sur
     leurs enfants — l'aperçu leur passe directement les couleurs du style
     courant en défauts. */
  const SIMPLE_TYPES = ['polygon', 'polyline', 'rect', 'circle', 'ellipse',
    'sector', 'line'];

  function isSimpleType(type) {
    return SIMPLE_TYPES.indexOf(type) !== -1;
  }

  /* Couleurs d'aperçu du tracé en cours : celles des prochaines formes
     (NS.edit.style), fond atténué pour distinguer l'aperçu de la forme
     finale. */
  function previewFill() {
    return ed.style.fillNone
      ? 'none'
      : NS.hexToRgba(ed.style.fillColor, ed.style.fillOpacity * 0.6);
  }

  function previewStroke() {
    return ed.style.strokeNone ? '#94a3b8' : ed.style.strokeColor;
  }

  /* Redessine entièrement le calque d'édition : formes, poignées de la
     forme sélectionnée et tracé en cours. Les éléments sont peu nombreux :
     le redessin intégral reste négligeable. */
  function renderEditLayer() {
    const { planEditLayer, planImage, shapeDeleteBtn } = NS.dom;
    // Attribut hidden explicite : la propriété hidden n'existe pas sur les
    // éléments SVG (cf. setLayerHidden, module plan).
    if (!NS.shapesAvailable()) {
      planEditLayer.setAttribute('hidden', '');
      NS.updateShapeCoverage();
      NS.syncStylePanelIfNeeded();
      return;
    }
    const w = planImage.offsetWidth, h = planImage.offsetHeight;
    if (!w || !h) {
      planEditLayer.setAttribute('hidden', '');
      NS.updateShapeCoverage();
      NS.syncStylePanelIfNeeded();
      return;
    }
    planEditLayer.removeAttribute('hidden');

    const vbH = NS.SHAPES_VIEW_W * h / w;
    planEditLayer.setAttribute('viewBox', '0 0 ' + NS.SHAPES_VIEW_W + ' ' + vbH);
    planEditLayer.textContent = '';

    // Les formes ne captent le pointeur qu'avec l'outil « sélectionner »
    // du mode actif : avec un outil de tracé, on doit pouvoir dessiner
    // par-dessus ; cadenas fermé, le plan reste déplaçable au travers.
    const active = NS.editActive();
    const interactive = active && ed.tool === 'select';
    ed.shapes.forEach((shape, index) => {
      // Étalon d'échelle déclaré masqué (case « Afficher sur le plan »
      // décochée) : invisible cadenas fermé ; cadenas ouvert, contour
      // fantôme pour rester réglable et sélectionnable.
      const hiddenScale = shape.type === 'scale' && shape.shown === false;
      // Règle show_mode (readme § 6.3) : cadenas fermé, une forme masquée
      // (ou « sur alarme » sans capteur lié en alarme) n'est pas rendue ;
      // cadenas ouvert, elle passe en contour fantôme.
      const display = NS.shapeDisplay(shape);
      if (!active && (hiddenScale || !display.shown)) return;
      const el = NS.shapeSvgNode(shape, vbH,
        NS.drawnShapeFill(shape), NS.drawnShapeStroke(shape));
      el.classList.add('pe-shape');
      // Contour fantôme des formes au contour transparent, pour rester
      // repérables et sélectionnables pendant l'édition uniquement.
      if (active && (hiddenScale || NS.drawnShapeStroke(shape) === 'none')) {
        el.classList.add('pe-ghost');
      }
      if (active && !display.shown) el.classList.add('pe-hidden-mode');
      if (display.shown && display.alarmColor) {
        el.classList.add('pe-shape-alarm');
        el.style.setProperty('--alarm-color', display.alarmColor);
      }
      if (active && shape === ed.selected) {
        el.classList.add('pe-selected');
        if (isSimpleType(shape.type)) {
          el.setAttribute('stroke-width', (shape.strokeWidth || 2) + 1);
        }
      }
      el.dataset.shapeIndex = String(index);
      el.style.pointerEvents = interactive ? 'auto' : 'none';
      planEditLayer.appendChild(el);
    });

    if (active && ed.selected) appendEditHandles(vbH);
    if (active && ed.draft) appendEditDraft(vbH);
    shapeDeleteBtn.disabled = !ed.selected;
    NS.updateShapeCoverage();
    NS.syncStylePanelIfNeeded();
  }

  /* Poignée d'ajustement en unités du viewBox. code est relu par le
     pointerdown du calque (viewer-edit-tools.js) : v<i> sommet, c<i> coin,
     r rayon, rx/ry demi-axes, a0/a1 angles, p1/p2 extrémités, tip pointe,
     rot rotation. Un curseur vide laisse la feuille de style décider. */
  function handleNodeVb(vx, vy, code, cursor, vbH) {
    const c = document.createElementNS(NS.SVG_NS, 'circle');
    c.setAttribute('cx', vx);
    c.setAttribute('cy', vy);
    c.setAttribute('r', NS.handleRadius());
    c.setAttribute('vector-effect', 'non-scaling-stroke');
    c.classList.add('pe-handle');
    c.dataset.handle = code;
    c.style.pointerEvents = 'auto';
    c.style.cursor = cursor;
    NS.dom.planEditLayer.appendChild(c);
    return c;
  }

  /* Curseur de redimensionnement selon la direction (degrés, sens horaire,
     0 = est) de l'axe tiré par la poignée : la forme peut être tournée, le
     curseur suit (est-ouest, diagonale, nord-sud, autre diagonale). */
  function dirCursor(deg) {
    const sector = Math.round((((deg % 180) + 180) % 180) / 45) % 4;
    return ['ew-resize', 'nwse-resize', 'ns-resize', 'nesw-resize'][sector];
  }

  /* Poignée de rotation de la forme sélectionnée : disque bleu relié au
     bord de la forme par un filet, posé ROTATE_HANDLE_PX pixels au-delà
     d'elle dans sa direction « haut » — direction qui tourne AVEC la
     forme, si bien que la poignée reste sous le pointeur pendant le
     glisser (viewer-edit-tools.js rejoue la rotation à chaque
     mouvement) :
       - rectangle, icône, ellipse : au-dessus du centre (rotation - 90°),
         libellé : au-dessus de son point d'ancrage ;
       - polygone, polyligne : au-delà du sommet le plus éloigné du centre
         des sommets, direction rotation cumulée - 90° ;
       - secteur : dans l'axe du secteur, au-delà de la poignée de rayon ;
       - ligne, flèche, cote, étalon : perpendiculaire au milieu du
         segment (au-dessus d'un segment tracé de gauche à droite). */
  function appendRotateHandle(s, vbH) {
    const W = NS.SHAPES_VIEW_W;
    const rect = NS.dom.planImage.getBoundingClientRect();
    if (!rect.width) return;
    const k = NS.planRatio();
    const off = ROTATE_HANDLE_PX / rect.width; // px écran -> fraction de largeur
    const c = NS.shapePivot(s);
    let dir, edge;
    if (s.type === 'rect' || s.type === 'icon') {
      dir = NS.shapeRotation(s) - 90;
      edge = s.h * k / 2;
    } else if (s.type === 'ellipse') {
      dir = NS.shapeRotation(s) - 90;
      edge = s.ry * k;
    } else if (s.type === 'label') {
      dir = NS.shapeRotation(s) - 90;
      // Hauteur du texte (fontSize au zoom 100 %, qui suit le zoom).
      edge = (s.fontSize || 14) / (NS.dom.planImage.offsetWidth || 1);
    } else if (s.type === 'polygon' || s.type === 'polyline') {
      dir = (Number(s.rotation) || 0) - 90;
      edge = 0;
      for (const p of s.points) {
        edge = Math.max(edge, Math.hypot(p.x - c.x, (p.y - c.y) * k));
      }
    } else if (s.type === 'sector') {
      dir = s.startAngle + NS.sectorOpening(s) / 2;
      edge = s.r;
    } else {
      dir = NS.shapeAngle(s) - 90;
      edge = 8 / rect.width; // au-delà du texte de la cote
    }
    const from = NS.offsetPoint(c, dir, edge);
    const to = NS.offsetPoint(c, dir, edge + off);
    const link = document.createElementNS(NS.SVG_NS, 'line');
    link.setAttribute('x1', from.x * W);
    link.setAttribute('y1', from.y * vbH);
    link.setAttribute('x2', to.x * W);
    link.setAttribute('y2', to.y * vbH);
    link.setAttribute('vector-effect', 'non-scaling-stroke');
    link.classList.add('pe-rotate-link');
    NS.dom.planEditLayer.appendChild(link);
    handleNodeVb(to.x * W, to.y * vbH, 'rot', '', vbH)
      .classList.add('pe-rotate');
  }

  function appendEditHandles(vbH) {
    const W = NS.SHAPES_VIEW_W;
    const mk = (fx, fy, code, cursor) =>
      handleNodeVb(fx * W, fy * vbH, code, cursor, vbH);
    const s = ed.selected;

    if (s.type === 'polygon' || s.type === 'polyline') {
      s.points.forEach((p, i) => mk(p.x, p.y, 'v' + i, 'move'));
    } else if (s.type === 'rect' || s.type === 'icon') {
      // Coins tournés avec la forme (clé rotation), curseurs suivant la
      // diagonale de chaque coin.
      const rot = NS.shapeRotation(s);
      const c = NS.rectCenter(s);
      NS.rectCorners(s).forEach((p, i) => {
        const q = rot ? NS.rotatePoint(p, c, rot) : p;
        mk(q.x, q.y, 'c' + i, dirCursor((i % 2 === 0 ? 45 : 135) + rot));
      });
    } else if (s.type === 'circle') {
      mk(s.cx + s.r, s.cy, 'r', 'ew-resize');
    } else if (s.type === 'ellipse') {
      // Extrémités des demi-axes, tournées avec l'ellipse.
      const rot = NS.shapeRotation(s);
      const c = { x: s.cx, y: s.cy };
      const hx = NS.rotatePoint({ x: s.cx + s.rx, y: s.cy }, c, rot);
      const hy = NS.rotatePoint({ x: s.cx, y: s.cy + s.ry }, c, rot);
      mk(hx.x, hx.y, 'rx', dirCursor(rot));
      mk(hy.x, hy.y, 'ry', dirCursor(rot + 90));
    } else if (s.type === 'sector') {
      // Rayon au milieu de l'arc, angles aux deux extrémités.
      const mid = NS.sectorPoint(s, s.startAngle + NS.sectorOpening(s) / 2, vbH);
      handleNodeVb(mid.x, mid.y, 'r', 'move', vbH);
      const p0 = NS.sectorPoint(s, s.startAngle, vbH);
      handleNodeVb(p0.x, p0.y, 'a0', 'crosshair', vbH);
      const p1 = NS.sectorPoint(s, s.endAngle, vbH);
      handleNodeVb(p1.x, p1.y, 'a1', 'crosshair', vbH);
    } else if (s.type === 'line' || s.type === 'arrow' ||
               s.type === 'measure' || s.type === 'scale') {
      mk(s.x1, s.y1, 'p1', 'move');
      mk(s.x2, s.y2, 'p2', 'move');
    } else if (s.type === 'callout') {
      mk(s.tx, s.ty, 'tip', 'move');
    }
    // label, pin : pas de poignée d'ajustement (déplacement au corps de la
    // forme ; la taille du texte se règle dans le panneau).

    // Poignée de rotation des formes orientables (le libellé en a une).
    if (NS.isRotatable(s)) appendRotateHandle(s, vbH);
  }

  /* Aperçu aux couleurs du panneau d'apparence (style en ligne :
     prioritaire sur le fill/stroke de la classe pe-draft, dont le trait
     pointillé est conservé). Fond atténué pour distinguer l'aperçu de la
     forme finale. */
  function styleDraftNode(el) {
    el.style.fill = previewFill();
    el.style.stroke = previewStroke();
    el.style.strokeWidth = ed.style.strokeWidth;
  }

  function appendEditDraft(vbH) {
    const planEditLayer = NS.dom.planEditLayer;
    const d = ed.draft;
    if (d.type === 'polygon' || d.type === 'polyline') {
      const pts = d.cursor ? d.points.concat([d.cursor]) : d.points;
      if (pts.length >= 2) {
        const poly = document.createElementNS(NS.SVG_NS,
          d.type === 'polygon' ? 'polygon' : 'polyline');
        poly.setAttribute('points',
          pts.map((p) => (p.x * NS.SHAPES_VIEW_W) + ',' + (p.y * vbH)).join(' '));
        poly.setAttribute('vector-effect', 'non-scaling-stroke');
        poly.classList.add('pe-draft');
        styleDraftNode(poly);
        if (d.type === 'polyline') poly.style.fill = 'none';
        planEditLayer.appendChild(poly);
      }
      // Premier sommet mis en évidence : cliquer dessus ferme le polygone
      // (simple repère de départ pour la polyligne).
      const first = d.points[0];
      const c = document.createElementNS(NS.SVG_NS, 'circle');
      c.setAttribute('cx', first.x * NS.SHAPES_VIEW_W);
      c.setAttribute('cy', first.y * vbH);
      c.setAttribute('r', NS.handleRadius());
      c.classList.add('pe-handle');
      planEditLayer.appendChild(c);
      return;
    }
    const shape = NS.draftToShape(d, true);
    if (!shape) return;
    const el = NS.shapeSvgNode(shape, vbH, previewFill(), previewStroke());
    el.classList.add('pe-draft');
    if (isSimpleType(shape.type)) styleDraftNode(el);
    planEditLayer.appendChild(el);
  }

  /* ------------------- Exposition sur l'espace de noms ------------------- */
  NS.renderEditLayer = renderEditLayer;
})(globalThis);
