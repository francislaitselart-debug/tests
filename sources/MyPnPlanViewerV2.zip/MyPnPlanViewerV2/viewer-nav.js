﻿/* ============================================================
   MyPnPlanViewerV2 — module « nav »
   ============================================================
   Navigation : drawer, fil d'Ariane, badges du bandeau (événements en cours
   de l'élément sélectionné + badges fixes), vues épinglées et signets de
   l'opérateur (par id), arborescence du site (avec pastilles d'événements),
   recherche insensible à la casse et aux accents, application d'une
   configuration complète (applyConfig), distribution des alarmes de
   configuration_events_json sur l'arbre (applyEvents, à chaud) et écriture
   de selectedNodePath (writeSelectedNode). Ordre de chargement : readme § 1.

   NOTE ENCODAGE : chaînes affichées en ASCII pur (\uXXXX), commentaires
   accentués, BOM UTF-8, fins de ligne CRLF (readme.txt § 14).
   ============================================================ */
(function (global) {
  'use strict';

  const NS = global.MyPnPlanViewerV2NS = global.MyPnPlanViewerV2NS || {};
  const state = NS.state;
  const {
    drawerBtn, siteNav, siteTitle, topbarBadges, pinAddBtn, navSearch,
    navSearchWrap, navSearchClear, pinnedList, treeRoot, noResult, navFooter,
  } = NS.dom;

  /* Ligne affichée sous le repère « Aucune représentation disponible »
     tant que l'opérateur n'a pas choisi un nœud portant une représentation
     (aucune sélection, ou nœud sans plan). */
  NS.NO_PLAN_HINT = 'S\u00e9lectionnez un \u00e9l\u00e9ment avec un plan';

  drawerBtn.addEventListener('click', () => {
    const open = siteNav.classList.toggle('open');
    drawerBtn.setAttribute('aria-expanded', String(open));
    siteNav.setAttribute('aria-hidden', String(!open));
  });

  function setDrawerOpen(open) {
    siteNav.classList.toggle('open', open);
    drawerBtn.setAttribute('aria-expanded', String(open));
    siteNav.setAttribute('aria-hidden', String(!open));
  }

  /* Sélection d'un emplacement (arbre ou vue épinglée) : met à jour le fil
     d'Ariane, affiche le(s) plan(s) associé(s) — ou le repère générique s'il
     n'y en a pas — et écrit la sélection dans selectedNodePath. */
  function goTo(node) {
    state.currentLocation = node.path;
    state.selectedNode = node;
    updatePinAddBtn();
    siteTitle.textContent = node.path;
    renderBadges();
    // Nœud sans représentation : la zone des plans invite à en choisir un
    // autre (le chemin du nœud est déjà dans le fil d'Ariane).
    NS.showPlans(node.plans, node.plans.length ? node.path : NS.NO_PLAN_HINT);
    writeSelectedNode();
  }

  /* Écrit selectedNodePath (readme § 11) : { id, parent_id, path, labels,
     planIndex, filename, serial } d'après le nœud sélectionné et la
     représentation affichée. Sans nœud sélectionné, id et parent_id valent
     0 : plan racine du mode sans navigation (planIndex >= 1, path = title)
     ou aucune sélection après une reconstruction (planIndex 0, path vide).
     Appelé à chaque sélection et à chaque reconstruction (applyConfig).
     Un nœud ne portant qu'une représentation, planIndex vaut 1 dès qu'une
     représentation est affichée, 0 sinon.
     serial croît à chaque écriture : deux sélections identiques successives
     restent distinguables par l'application. */
  function writeSelectedNode() {
    const node = state.selectedNode;
    const plan = state.currentPlan;
    const planIndex = plan
      ? state.currentPlans.indexOf(plan) + NS.SELECTED_PLAN_BASE
      : 0;
    const rootPlan = !node && planIndex > 0;
    state.selectionSerial += 1;
    NS.writeProperty(NS.SELECTED_NODE_PROPERTY, JSON.stringify({
      id: node ? node.id : 0,
      parent_id: node ? node.parent_id : 0,
      path: node ? node.path : rootPlan ? state.currentLocation : '',
      labels: node ? node.labels : rootPlan ? [state.currentLocation] : [],
      planIndex,
      filename: plan ? plan.filename : '',
      serial: state.selectionSerial,
    }));
  }

  /* ------------- Événements en cours : pastilles et badges ------------- */

  /* Comparateur d'importance de deux événements (clé eventPriorityOrder) :
     le plus important d'abord. */
  function compareByImportance(a, b) {
    return state.currentConfig.eventPriorityOrder === 'desc'
      ? b.priority - a.priority
      : a.priority - b.priority;
  }

  /* Synthèse des événements d'un nœud ET de sa descendance : un cumul par
     priorité (couleur de la première entrée rencontrée), du plus important
     au moins important. */
  function subtreeEvents(node) {
    const byPriority = new Map();
    (function collect(n) {
      for (const ev of n.events) {
        const acc = byPriority.get(ev.priority);
        if (acc) acc.count += ev.count;
        else byPriority.set(ev.priority, Object.assign({}, ev));
      }
      n.children.forEach(collect);
    })(node);
    return Array.from(byPriority.values()).sort(compareByImportance);
  }

  /* Valeur CSS d'une couleur de badge : nom admis -> variable de sévérité
     (--sev-red...), couleur hexadécimale telle quelle sinon. */
  function badgeColorCss(color) {
    return color.charAt(0) === '#' ? color : 'var(--sev-' + color + ')';
  }

  /* Pastille d'événements d'une ligne de l'arbre : une seule par ligne,
     colorée selon la priorité la plus importante. Nœud replié (ou feuille) :
     celle de tout son sous-arbre, lui compris ; nœud déplié : celle de ses
     propres événements, ou pastille masquée s'il n'en a pas (ceux des
     descendants sont alors visibles sur leurs lignes). Crée, met à jour ou
     retire la pastille selon les événements du nœud passé. */
  function updateEventDot(el, node) {
    const rowEnd = el.querySelector(':scope > .row .row-end');
    let dot = rowEnd.querySelector('.event-dot');
    const all = subtreeEvents(node);
    if (all.length === 0) {
      if (dot) dot.remove();
      return;
    }
    if (!dot) {
      dot = document.createElement('span');
      dot.className = 'event-dot';
      dot.title = '\u00c9v\u00e9nements en cours';
      rowEnd.appendChild(dot);
    }
    const own = node.events.slice().sort(compareByImportance);
    dot.dataset.allColor = badgeColorCss(all[0].color);
    dot.dataset.ownColor = own.length ? badgeColorCss(own[0].color) : '';
    refreshEventDot(el);
  }

  /* Applique l'état replié/déplié du nœud à sa pastille : couleur et
     visibilité (cf. updateEventDot). */
  function refreshEventDot(el) {
    const dot = el.querySelector(':scope > .row .event-dot');
    if (!dot) return;
    const collapsed = !el.classList.contains('expanded');
    const color = collapsed ? dot.dataset.allColor : dot.dataset.ownColor;
    dot.style.background = color;
    dot.classList.toggle('dot-hidden', color.length === 0);
  }

  /* Mise à jour à chaud des pastilles de tout l'arbre (nouvelle valeur des
     événements, structure inchangée) : les lignes du DOM sont parcourues en
     parallèle des nœuds de la nouvelle configuration, dans l'ordre de
     buildTree. */
  function refreshTreeDots(nodes, container) {
    const els = Array.from(container.children)
      .filter((el) => el.classList.contains('tree-node'));
    nodes.forEach((node, i) => {
      const el = els[i];
      if (!el) return;
      updateEventDot(el, node);
      const kids = el.querySelector(':scope > .children');
      if (kids) refreshTreeDots(node.children, kids);
    });
  }

  function buildTree(nodes, container) {
    for (const node of nodes) {
      const el = document.createElement('div');
      el.className = 'tree-node';

      const hasChildren = node.children.length > 0;
      const planCount = node.plans.length;

      const row = document.createElement('div');
      row.className = 'row';
      // Id du nœud porté par la ligne : permet de retrouver la ligne d'un
      // nœud pour la sélectionner depuis un signet (selectTreeRow).
      row.dataset.id = String(node.id);

      const caret = document.createElement('span');
      caret.className = 'caret' + (hasChildren ? '' : ' leaf');
      caret.innerHTML = '&rsaquo;';
      row.appendChild(caret);

      const label = document.createElement('span');
      label.textContent = node.label;
      row.appendChild(label);

      if (planCount === 0 && state.currentConfig.showNoPlanIndicator) {
        const noPlan = document.createElement('span');
        noPlan.className = 'no-plan-indicator';
        noPlan.title = 'Aucun plan \u00e0 visualiser';
        row.appendChild(noPlan);
      }
      // Représentation 3D (modèle .obj) : petit cube, toujours affiché.
      if (planCount > 0 && node.plans[0].type === 'model') {
        const model = document.createElement('span');
        model.className = 'model-indicator';
        model.title = 'Repr\u00e9sentation 3D';
        row.appendChild(model);
      }

      const rowEnd = document.createElement('span');
      rowEnd.className = 'row-end';
      row.appendChild(rowEnd);
      el.appendChild(row);
      // Pastille d'événements (nœud replié à la construction).
      updateEventDot(el, node);

      if (hasChildren) {
        const kids = document.createElement('div');
        kids.className = 'children';
        buildTree(node.children, kids);
        el.appendChild(kids);
      }

      row.addEventListener('click', () => {
        if (hasChildren) {
          el.classList.toggle('expanded');
          refreshEventDot(el);
        }
        for (const r of treeRoot.querySelectorAll('.row')) r.classList.remove('selected');
        row.classList.add('selected');
        goTo(node);
      });

      container.appendChild(el);
    }
  }

  /* Marque comme sélectionnée la ligne de l'arbre du nœud d'id donné et
     déplie ses parents pour la rendre visible — même résultat qu'un clic de
     l'opérateur sur cette ligne. Si aucune ligne ne porte cet id, tout est
     simplement désélectionné. */
  function selectTreeRow(id) {
    const key = String(id);
    let target = null;
    for (const r of treeRoot.querySelectorAll('.row')) {
      r.classList.remove('selected');
      if (r.dataset.id === key) target = r;
    }
    if (!target) return;

    target.classList.add('selected');
    for (let el = target.parentElement; el && el !== treeRoot; el = el.parentElement) {
      if (el.classList.contains('tree-node')) {
        el.classList.add('expanded');
        refreshEventDot(el);
      }
    }
  }

  /* Élément DOM d'une vue épinglée / d'un signet { id, label,
     defaultLabel } : navigation directe vers le nœud visé (par id),
     sélectionné et rendu visible dans l'arbre.
     Le bouton × retire l'entrée (celles de la configuration réapparaissent à
     la prochaine reconstruction ; les signets de l'opérateur, non).
     Le bouton ✎ (ou un double-clic) renomme l'entrée en place : le libellé
     est remplacé par un champ de saisie, Entrée / perte du focus valide,
     Échap annule, un libellé vide rétablit le libellé par défaut (chemin
     joint par des espaces). Le nouveau libellé est porté par l'objet pin
     lui-même : même durée de vie que l'entrée (voir readme § 7, pinned). */
  function createPinnedElement(pin) {
    const el = document.createElement('div');
    el.className = 'pinned';
    // Vue réellement affichée : l'anti-doublon du bouton « + » parcourt le
    // DOM, pour qu'une vue de la configuration retirée par × puisse être
    // ré-épinglée par l'opérateur.
    el._pin = pin;

    const icon = document.createElement('span');
    icon.className = 'pin';
    icon.innerHTML = '&#9906;';
    el.appendChild(icon);

    const label = document.createElement('span');
    label.className = 'pin-label';
    label.textContent = pin.label;
    el.appendChild(label);

    const rename = document.createElement('button');
    rename.type = 'button';
    rename.className = 'rename';
    rename.title = 'Renommer';
    rename.setAttribute('aria-label', 'Renommer le raccourci');
    // U+FE0E : glyphe texte (monochrome), pas l'emoji couleur de Windows.
    rename.innerHTML = '&#9998;&#xFE0E;';
    rename.addEventListener('click', (e) => {
      e.stopPropagation();
      startRename();
    });
    el.appendChild(rename);

    const close = document.createElement('button');
    close.type = 'button';
    close.className = 'close';
    close.title = 'Retirer';
    close.innerHTML = '&times;';
    close.addEventListener('click', (e) => {
      e.stopPropagation();
      const i = state.userPinned.indexOf(pin);
      if (i !== -1) state.userPinned.splice(i, 1);
      el.remove();
    });
    el.appendChild(close);

    el.addEventListener('click', () => {
      // Pas de navigation pendant la saisie d'un nouveau libellé.
      if (el.classList.contains('editing')) return;
      // L'id est vérifié à la normalisation (vue de la configuration) et à
      // chaque reconstruction (signet de l'opérateur) : le nœud existe.
      const node = state.currentConfig.byId.get(pin.id);
      if (!node) return;
      selectTreeRow(node.id);
      goTo(node);
    });

    el.addEventListener('dblclick', (e) => {
      e.preventDefault();
      startRename();
    });

    /* Bascule le libellé en champ de saisie. Le double-clic ayant déjà
       déclenché deux clics (donc la navigation), rien à annuler ici. */
    function startRename() {
      if (el.classList.contains('editing')) return;
      el.classList.add('editing');

      const input = document.createElement('input');
      input.type = 'text';
      input.className = 'pin-rename';
      input.value = pin.label;
      input.placeholder = pin.defaultLabel;
      input.setAttribute('aria-label', 'Libell\u00e9 du raccourci');
      input.maxLength = 120;
      label.replaceWith(input);
      input.focus();
      input.select();

      let done = false;
      const finish = (commit) => {
        if (done) return;
        done = true;
        if (commit) {
          const value = input.value.trim();
          pin.label = value || pin.defaultLabel;
          label.textContent = pin.label;
        }
        // Le retrait du champ déclenche son blur : le drapeau done l'ignore.
        input.replaceWith(label);
        el.classList.remove('editing');
        // Le filtre de recherche en cours doit s'appliquer au nouveau libellé.
        applyFilter();
      };

      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          finish(true);
        } else if (e.key === 'Escape') {
          e.preventDefault();
          e.stopPropagation();
          finish(false);
        }
      });
      input.addEventListener('blur', () => finish(true));
      // Clics dans le champ : ni navigation, ni second renommage.
      input.addEventListener('click', (e) => e.stopPropagation());
      input.addEventListener('dblclick', (e) => e.stopPropagation());
    }

    return el;
  }

  function renderPinned(pins) {
    pinnedList.textContent = '';
    for (const pin of pins) pinnedList.appendChild(createPinnedElement(pin));
  }

  /* ---------- Bouton « + » du bandeau : ajout d'un signet ---------- */

  function updatePinAddBtn() {
    pinAddBtn.disabled = !state.selectedNode;
    pinAddBtn.title = state.selectedNode
      ? 'Ajouter un signet vers cet emplacement'
      : 'S\u00e9lectionnez d\u2019abord un emplacement dans la navigation';
  }

  /* Emplacement du bouton « + » (clé pinButtonPosition) : en bout de bandeau
     (défaut, calé à droite par margin-left:auto) ou juste derrière le fil
     d'Ariane, avant les badges. Le bouton est déplacé dans le DOM plutôt que
     réordonné en CSS, pour que l'ordre de tabulation suive l'affichage ; la
     classe pin-after-title du bandeau ajuste la marge (app.css). */
  function placePinAddBtn(position) {
    const afterTitle = position === 'afterTitle';
    const topbar = siteTitle.parentElement;
    if (afterTitle) siteTitle.after(pinAddBtn);
    else topbar.appendChild(pinAddBtn);
    topbar.classList.toggle('pin-after-title', afterTitle);
  }

  /* Empile un signet vers l'emplacement courant du fil d'Ariane, à la suite
     des vues épinglées. Un emplacement déjà présent n'est pas dupliqué. */
  pinAddBtn.addEventListener('click', () => {
    const node = state.selectedNode;
    if (!node) return;
    const pin = NS.pinForNode(node, '');

    // Doublon jugé sur les vues AFFICHÉES : une vue de la configuration
    // retirée par l'opérateur (×) reste dans currentConfig.pinned mais peut
    // être ré-épinglée en signet.
    const alreadyPinned = Array.prototype.some.call(
      pinnedList.children,
      (el) => el._pin && el._pin.id === pin.id,
    );
    if (alreadyPinned) return;

    state.userPinned.push(pin);
    pinnedList.appendChild(createPinnedElement(pin));
    // Le filtre de recherche en cours doit s'appliquer au nouveau signet.
    applyFilter();
  });

  /* Badges du bandeau, à droite du fil d'Ariane : d'abord les événements en
     cours de l'élément sélectionné (synthèse par priorité de son sous-arbre,
     plus important d'abord, un badge cliquable par priorité), puis les
     badges fixes de la configuration (clé badges, purement décoratifs). */
  function renderBadges() {
    topbarBadges.textContent = '';

    const node = state.selectedNode;
    for (const ev of node ? subtreeEvents(node) : []) {
      const el = document.createElement('button');
      el.type = 'button';
      el.className = 'count-badge event-badge';
      el.style.background = badgeColorCss(ev.color);
      el.textContent = ev.count;
      el.title = '\u00c9v\u00e9nements en cours - Cliquer pour consulter le d\u00e9tail';
      el.setAttribute('aria-label', 'Priorit\u00e9 ' + ev.priority + ' : ' +
        ev.count + ' \u00e9v\u00e9nement(s) en cours, consulter le d\u00e9tail');
      el.addEventListener('click', () => requestEventsDetail(ev));
      topbarBadges.appendChild(el);
    }

    for (const badge of state.currentConfig.badges) {
      const el = document.createElement('span');
      el.className = 'count-badge';
      if (badge.color.charAt(0) === '#') el.style.background = badge.color;
      else el.classList.add(badge.color);
      el.textContent = badge.value;
      topbarBadges.appendChild(el);
    }
  }

  /* Clic sur un badge d'événements : demande de détail écrite dans
     eventsDetailRequest_json (readme § 11) — { source: "badge", node_id,
     path, priority, count, serial }, serial croissant (compteur commun aux
     clics sur les capteurs du plan) pour que deux clics identiques
     successifs soient distingués par l'application. */
  function requestEventsDetail(ev) {
    const node = state.selectedNode;
    state.eventsDetailSerial += 1;
    NS.writeProperty(NS.EVENTS_DETAIL_PROPERTY, JSON.stringify({
      source: 'badge',
      node_id: node ? node.id : 0,
      path: node ? node.path : state.currentLocation,
      priority: ev.priority,
      count: ev.count,
      serial: state.eventsDetailSerial,
    }));
  }

  /* ---------- Recherche / filtrage de l'arbre de navigation ---------- */

  /* Comparaison insensible à la casse et aux accents ("bat" matche "Bâtiment") */
  function normalizeForSearch(s) {
    return s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  }

  /* Un nœud reste affiché si son libellé matche ou si un descendant matche ;
     les parents d'un résultat sont dépliés le temps du filtre. */
  function filterTreeNode(el, query) {
    const label = normalizeForSearch(el.querySelector(':scope > .row').textContent);
    const selfMatch = label.includes(query);
    let childMatch = false;
    const kids = el.querySelector(':scope > .children');
    if (kids) {
      for (const child of kids.children) {
        if (filterTreeNode(child, query)) childMatch = true;
      }
    }
    const visible = selfMatch || childMatch;
    el.classList.toggle('filter-hidden', !visible);
    el.classList.toggle('filter-open', childMatch);
    /* Si seul le parent matche, ses enfants redeviennent tous visibles */
    if (selfMatch && kids) {
      for (const child of kids.children) child.classList.remove('filter-hidden');
    }
    return visible;
  }

  function applyFilter() {
    const raw = navSearch.value.trim();
    navSearchWrap.classList.toggle('has-value', raw.length > 0);
    const query = normalizeForSearch(raw);
    let any = false;

    for (const p of pinnedList.querySelectorAll('.pinned')) {
      // Seul le libellé compte (pas les glyphes des boutons ✎ et ×).
      const labelEl = p.querySelector('.pin-label');
      const text = labelEl ? labelEl.textContent : p.textContent;
      const visible = !query || normalizeForSearch(text).includes(query);
      p.classList.toggle('filter-hidden', !visible);
      if (visible) any = true;
    }

    if (!query) {
      for (const el of treeRoot.querySelectorAll('.tree-node')) {
        el.classList.remove('filter-hidden', 'filter-open');
      }
      noResult.classList.remove('visible');
      return;
    }

    for (const el of treeRoot.children) {
      if (filterTreeNode(el, query)) any = true;
    }
    noResult.classList.toggle('visible', !any);
  }

  navSearch.addEventListener('input', applyFilter);

  navSearchClear.addEventListener('click', () => {
    navSearch.value = '';
    applyFilter();
    navSearch.focus();
  });

  /* Empreinte de la configuration hors données « chaudes » (badges fixes)
     et hors données dérivées (index byId, avertissements, clé events des
     nœuds — alimentée par configuration_events_json) : deux configurations
     de même empreinte ne diffèrent que par ces données et se mettent à jour
     sans reconstruction. */
  function structuralKey(config) {
    const strip = (nodes) => nodes.map((n) => ({
      id: n.id, label: n.label, plans: n.plans, children: strip(n.children),
    }));
    return JSON.stringify(Object.assign({}, config, {
      badges: null, byId: null, warnings: null, tree: strip(config.tree),
      // Libellé d'ORIGINE des vues épinglées : le libellé affiché (label)
      // est renommable en place par l'opérateur et ne doit pas invalider
      // le chemin « à chaud ».
      pinned: config.pinned.map((p) => ({ id: p.id, label: p.configLabel })),
    }));
  }

  /* ============================================================
     Alarmes en cours (configuration_events_json)
     ============================================================ */

  /* Distribue les alarmes en cours (state.events.byNode, normalisées par
     viewer-config.js) sur les nœuds de l'arbre courant : la clé events de
     chaque nœud reçoit ses événements PROPRES ({ priority, color, count }
     cumulés par priorité), ou un tableau vide. La synthèse par sous-arbre
     — la remontée le long des parent_id — est faite à l'affichage par
     subtreeEvents (pastilles des nœuds repliés, badges du bandeau). */
  function distributeEvents() {
    const byNode = state.events.byNode;
    for (const node of state.currentConfig.byId.values()) {
      node.events = byNode.get(node.id) || [];
    }
  }

  /* Nouvelle valeur de configuration_events_json (normalisée par
     NS.normalizeEventList dans app.js) : mise à jour À CHAUD des pastilles
     de l'arbre et des badges du bandeau, puis des capteurs et des formes du
     plan affiché (modules plan / edit, via NS.refreshAlarms quand ils
     l'exposent). Rien n'est reconstruit : sélection, zoom, drawer et nœuds
     dépliés sont conservés. */
  function applyEvents(events) {
    state.events = events;
    distributeEvents();
    refreshTreeDots(state.currentConfig.tree, treeRoot);
    renderBadges();
    if (typeof NS.refreshAlarms === 'function') NS.refreshAlarms();
    // Zones de la scène 3D liées à des capteurs (viewer-scene3d-zones.js).
    if (typeof NS.refreshZoneAlarms === 'function') NS.refreshZoneAlarms();
  }

  /* ============================================================
     Application d'une configuration complète
     ============================================================
     Reconstruit le bandeau, la navigation et la zone des plans. Deux modes :
     - tree renseigné : l'opérateur navigue dans l'arbre, aucun élément n'est
       sélectionné au départ ;
     - tree absent/vide : les représentations de la clé plans (racine) sont
       affichées directement, sans navigation (drawer masqué). */
  function applyConfig(config) {
    // Mise à jour à chaud : si seuls les badges fixes changent — structure,
    // plans et options identiques —, rien n'est reconstruit : l'opérateur
    // garde sa sélection, le plan affiché et son zoom, le drawer et les
    // nœuds dépliés. (Les alarmes, elles, arrivent par
    // configuration_events_json et ne passent jamais par ici.)
    if (!config.error && structuralKey(config) === structuralKey(state.currentConfig)) {
      // Les objets nœuds de la configuration courante sont référencés par
      // les lignes de l'arbre (fermetures de buildTree), par state.selectedNode
      // et par les signets : ils sont CONSERVÉS, seules les données chaudes
      // sont reportées dans la configuration courante.
      state.currentConfig.badges = config.badges;
      state.currentConfig.warnings = config.warnings;
      renderBadges();
      return;
    }

    state.currentConfig = config;
    NS.edit.enabled = config.shapeEditing;
    // Les alarmes déjà reçues sont reportées sur le nouvel arbre (avant sa
    // construction : buildTree pose les pastilles). Les capteurs mémorisés
    // par plan se rapportaient à l'ancien arbre : l'application les renverra
    // en réponse aux prochaines sélections.
    distributeEvents();
    state.elementsCache.clear();
    state.currentElements = [];
    // Même règle pour les formes : leur mémoire par plan (node_id +
    // planIndex) ne survit pas au changement d'identifiants.
    NS.edit.store.clear();

    // Icône d'inspection de la configuration en bas du drawer, masquable
    // par la clé showConfigInfo.
    navFooter.hidden = !config.showConfigInfo;

    // Les signets ajoutés par l'opérateur (bouton « + ») sont conservés à la
    // suite des vues épinglées de la configuration — tant que le nœud visé
    // existe encore dans le nouvel arbre.
    state.userPinned = state.userPinned.filter((pin) => config.byId.has(pin.id));
    renderPinned(config.pinned.concat(state.userPinned));

    treeRoot.textContent = '';
    const hasTree = config.tree.length > 0;
    // display:flex du bouton prime sur l'attribut hidden : le masquage passe
    // aussi par la règle .drawer-btn[hidden] dans app.css.
    drawerBtn.hidden = !hasTree;
    // Sans arbre, pas de navigation ni de signets : le bouton « + » est
    // masqué comme le drawer. Aucune sélection tant que l'opérateur n'a pas
    // choisi un emplacement dans la nouvelle arborescence.
    pinAddBtn.hidden = !hasTree;
    placePinAddBtn(config.pinButtonPosition);
    state.selectedNode = null;
    updatePinAddBtn();
    renderBadges();
    setDrawerOpen(false);
    navSearch.value = '';
    applyFilter();

    state.currentLocation = config.title;
    siteTitle.textContent = config.title;
    if (hasTree) {
      buildTree(config.tree, treeRoot);
      NS.showPlans(null, config.error || NS.NO_PLAN_HINT);
    } else {
      NS.showPlans(config.plans, config.error || config.title);
    }

    // L'application est prévenue de ce qui est affiché : désélection (id 0,
    // planIndex 0) ou plan racine du mode sans navigation (id 0,
    // planIndex 1). Rien n'est écrit tant que la configuration est absente,
    // vide ou invalide.
    if (!config.error) writeSelectedNode();
  }

  /* ------------------- Exposition sur l'espace de noms ------------------- */
  NS.applyConfig = applyConfig;
  NS.applyEvents = applyEvents;
  NS.writeSelectedNode = writeSelectedNode;
})(globalThis);
